	.att_syntax
	.file	"knn_index_layout_main.mojo"
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI0_0:
	.long	0x3d000000
.LCPI0_1:
	.long	0x00800000
.LCPI0_2:
	.long	0x00000001
.LCPI0_3:
	.long	0x80000000
.LCPI0_4:
	.long	0x3a800000
.LCPI0_5:
	.long	0x45800000
.LCPI0_6:
	.long	0x37800000
	.text
	.prefalign	4, .Lfunc_end0, nop
	.type	"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])",@function
"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	xorl	%r9d, %r9d
	movl	$4, %r11d
	testq	%rdi, %rdi
	cmovleq	%r9, %rdi
	movq	%rdi, 8(%rsp)
	jle	.LBB0_1
	movq	%rcx, %rax
	movq	%rsi, %rcx
	sarq	$63, %rcx
	andnq	%rsi, %rcx, %r13
	xorl	%r9d, %r9d
	movq	%r13, %rcx
	subq	$1, %rcx
	cmovbq	%r9, %rcx
	movq	%rcx, 24(%rsp)
	movl	$0, %ecx
	testq	%rsi, %rsi
	jle	.LBB0_2
	movq	%rdx, %rbx
	movabsq	$-7723592293110705685, %rcx
	imulq	%rcx, %rax
	movabsq	$6064256500045838244, %rcx
	addq	%rax, %rcx
	movq	%rcx, 16(%rsp)
	movq	8(%rsp), %rax
	subq	$1, %rax
	cmovbq	%r9, %rax
	movabsq	$-8769763576025852407, %rdi
	movl	$61, %r14d
	vmovss	.LCPI0_0(%rip), %xmm1
	xorl	%r15d, %r15d
	xorl	%ecx, %ecx
	jmp	.LBB0_6
	.p2align	4
.LBB0_5:
	movq	8(%rsp), %r15
	movq	32(%rsp), %rax
	subq	%rax, %r15
	subq	$1, %rax
	jb	.LBB0_2
.LBB0_6:
	movq	%rax, 32(%rsp)
	movq	%r15, %r8
	movabsq	$-7046029254386353131, %rax
	imulq	%rax, %r8
	movq	%r15, %rax
	movabsq	$970881267037344822, %rdx
	imulq	%rdx
	movq	%rdx, %rax
	shrq	$63, %rax
	addq	%rdx, %rax
	leaq	(%rax,%rax,8), %rdx
	leaq	(%rax,%rdx,2), %rax
	movq	%r15, %rdx
	subq	%rax, %rdx
	movl	$0, %eax
	movl	$19, %esi
	cmovnel	%esi, %eax
	movq	%r15, %rsi
	sarq	$63, %rsi
	andl	%eax, %esi
	addq	%rdx, %rsi
	movq	%rsi, %rbp
	shlq	$4, %rbp
	addq	%rsi, %rbp
	addq	16(%rsp), %r8
	movq	%r8, 40(%rsp)
	movq	24(%rsp), %rax
	movq	%r13, %r12
	jmp	.LBB0_7
	.p2align	4
.LBB0_15:
	vmovss	%xmm0, (%r11,%r9,4)
	incq	%r9
	movq	%r12, %rax
	addq	$-1, %rax
	jae	.LBB0_5
.LBB0_7:
	movq	%r13, %r10
	subq	%r12, %r10
	movq	%rax, %r12
	leaq	(%r10,%r15), %r8
	leaq	(%r10,%r10,4), %rax
	leaq	(%r10,%rax,2), %rsi
	addq	%rbp, %rsi
	movq	%rsi, %rax
	imulq	%rdi
	addq	%rsi, %rdx
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$5, %rdx
	addq	%rax, %rdx
	imulq	$61, %rdx, %rax
	movq	%rsi, %rdx
	subq	%rax, %rdx
	movl	$0, %eax
	cmovnel	%r14d, %eax
	sarq	$63, %rsi
	andl	%eax, %esi
	leaq	-30(%rdx,%rsi), %rax
	vcvtsi2ss	%rax, %xmm15, %xmm0
	vmulss	%xmm1, %xmm0, %xmm0
	cmpq	$1, %rbx
	je	.LBB0_11
	cmpq	$2, %rbx
	je	.LBB0_12
	cmpq	$3, %rbx
	jne	.LBB0_13
	movabsq	$-4658895280553007687, %rdx
	imulq	%rdx, %r10
	addq	40(%rsp), %r10
	movq	%r10, %rax
	shrq	$30, %rax
	xorq	%r10, %rax
	imulq	%rdx, %rax
	movq	%rax, %rdx
	shrq	$27, %rdx
	xorq	%rax, %rdx
	movabsq	$58627862985511403, %rax
	imulq	%rax, %rdx
	shrq	$40, %rdx
	movzwl	%dx, %eax
	vcvtsi2ss	%rax, %xmm15, %xmm0
	vmulss	.LCPI0_6(%rip), %xmm0, %xmm0
	cmpq	%rcx, %r9
	jl	.LBB0_15
	jmp	.LBB0_14
	.p2align	4
.LBB0_12:
	leaq	3(%r8), %rax
	testq	%r8, %r8
	cmovnsq	%r8, %rax
	sets	%dl
	andq	$-4, %rax
	subq	%rax, %r8
	setne	%al
	andb	%dl, %al
	movzbl	%al, %eax
	leaq	(%r8,%rax,4), %rax
	cmpq	$3, %rax
	sete	%dl
	cmpq	$2, %rax
	sete	%sil
	cmpq	$1, %rax
	sete	%al
	kmovd	%edx, %k1
	vmovss	.LCPI0_1(%rip), %xmm0 {%k1} {z}
	kmovd	%esi, %k1
	vmovss	.LCPI0_2(%rip), %xmm0 {%k1}
	kmovd	%eax, %k1
	vmovss	.LCPI0_3(%rip), %xmm0 {%k1}
.LBB0_13:
	cmpq	%rcx, %r9
	jl	.LBB0_15
.LBB0_14:
	xorl	%eax, %eax
	testq	%rcx, %rcx
	sete	%al
	leaq	(%rax,%rcx,2), %rax
	movq	%rdi, %r14
	movq	%r11, %rdi
	movq	%r9, %rsi
	movq	%rcx, %rdx
	movq	%rax, %rcx
	vmovaps	%xmm0, 48(%rsp)
	callq	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"@PLT
	vmovaps	48(%rsp), %xmm0
	vmovss	.LCPI0_0(%rip), %xmm1
	movq	%r14, %rdi
	movl	$61, %r14d
	movq	%rax, %r11
	movq	%rdx, %r9
	jmp	.LBB0_15
	.p2align	4
.LBB0_11:
	movq	%r8, %rax
	movabsq	$6148914691236517206, %rdx
	imulq	%rdx
	movq	%rdx, %rax
	shrq	$63, %rax
	addq	%rdx, %rax
	leaq	(%rax,%rax,2), %rax
	xorl	%edx, %edx
	movq	%r8, %rsi
	subq	%rax, %rsi
	setne	%dl
	leal	(%rdx,%rdx,2), %eax
	sarq	$63, %r8
	andl	%eax, %r8d
	addq	%rsi, %r8
	vcvtsi2ss	%r8, %xmm15, %xmm0
	vmulss	.LCPI0_4(%rip), %xmm0, %xmm0
	vaddss	.LCPI0_5(%rip), %xmm0, %xmm0
	cmpq	%rcx, %r9
	jl	.LBB0_15
	jmp	.LBB0_14
.LBB0_1:
	xorl	%ecx, %ecx
.LBB0_2:
	movq	%r11, %rax
	movq	%r9, %rdx
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end0-"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI1_0:
	.quad	511
	.quad	7
.LCPI1_1:
	.quad	55
	.quad	61
.LCPI1_2:
	.quad	9
	.quad	3
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI1_3:
	.quad	40
	.quad	48
	.quad	56
	.quad	64
.LCPI1_4:
	.quad	8
	.quad	16
	.quad	24
	.quad	32
.LCPI1_6:
	.quad	8
	.quad	8
	.quad	8
	.quad	4
.LCPI1_8:
	.quad	8
	.quad	4
	.quad	4
	.quad	4
.LCPI1_9:
	.quad	8
	.quad	8
	.quad	4
	.quad	4
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI1_5:
	.quad	8
.LCPI1_7:
	.quad	4
	.text
	.prefalign	4, .Lfunc_end1, nop
	.type	"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])",@function
"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1560, %rsp
	.cfi_def_cfa_offset 1616
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, %r13
	movq	%r8, %r12
	movq	%rcx, %rbp
	movl	%edx, 4(%rsp)
	movq	%rdi, %r14
	movq	1680(%rsp), %rbx
	movq	1728(%rsp), %r10
	movq	1720(%rsp), %rax
	movq	1704(%rsp), %rcx
	movq	1696(%rsp), %rdx
	movq	1688(%rsp), %rdi
	cmpq	$3, %rax
	je	.LBB1_4
	testq	%rax, %rax
	jne	.LBB1_10
	movq	%rsi, 8(%rsp)
	movq	%rdx, %rax
	imulq	%rdi, %rax
	leaq	255(%rax), %rcx
	addq	$510, %rax
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	movq	%rax, %rdx
	sarq	$8, %rdx
	andq	$-256, %rax
	movq	%rcx, %rsi
	sarq	$63, %rsi
	xorl	%ebx, %ebx
	cmpq	%rcx, %rax
	cmovneq	%rsi, %rbx
	addq	%rdx, %rbx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	movl	$1, %esi
	movl	$1, %edx
	movl	$73, %ecx
	movl	$58, %r8d
	movq	%rbx, %rdi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movb	$1, %r15b
	testb	$1, %al
	jne	.LBB1_3
	movq	%rbp, 24(%rsp)
	movq	%r12, 32(%rsp)
	testb	$1, 4(%rsp)
	je	.LBB1_25
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
.LBB1_25:
	movq	$0, 544(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %r12
	leaq	192(%rsp), %rbp
	movq	%r12, %rdi
	xorl	%esi, %esi
	movq	%rbp, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	208(%rsp), %rsi
	btq	$61, %rsi
	jb	.LBB1_34
	testq	%rsi, %rsi
	js	.LBB1_29
	movq	200(%rsp), %rsi
	jmp	.LBB1_30
.LBB1_4:
	movq	%rsi, 8(%rsp)
	movq	%rbp, 24(%rsp)
	vmovq	%rdi, %xmm0
	vmovq	%rdx, %xmm1
	vpunpcklqdq	%xmm0, %xmm1, %xmm0
	vpaddq	.LCPI1_0(%rip), %xmm0, %xmm0
	vpsraq	$63, %xmm0, %xmm1
	vpsrlvq	.LCPI1_1(%rip), %xmm1, %xmm2
	vpaddq	%xmm2, %xmm0, %xmm2
	vmovdqa	.LCPI1_2(%rip), %xmm3
	vpsravq	%xmm3, %xmm2, %xmm2
	vpsllvq	%xmm3, %xmm2, %xmm3
	vpcmpneqq	%xmm0, %xmm3, %k1
	vpaddq	%xmm1, %xmm2, %xmm2 {%k1}
	vmovq	%xmm2, %rbx
	vpextrq	$1, %xmm2, %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	movl	$1, %edx
	movl	$99, %ecx
	movl	$78, %r8d
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movb	$1, %r15b
	testb	$1, %al
	jne	.LBB1_102
	movq	%r13, 16(%rsp)
	movq	%r12, 32(%rsp)
	testb	$1, 4(%rsp)
	je	.LBB1_7
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
.LBB1_7:
	movq	$0, 544(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %r12
	leaq	192(%rsp), %r13
	movq	%r12, %rdi
	xorl	%esi, %esi
	movq	%r13, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	208(%rsp), %rsi
	btq	$61, %rsi
	jb	.LBB1_85
	testq	%rsi, %rsi
	js	.LBB1_80
	movq	200(%rsp), %rsi
	jmp	.LBB1_81
.LBB1_10:
	cmpq	$2147483647, %rcx
	jg	.LBB1_28
	cmpq	$2147483647, %rdx
	jg	.LBB1_28
	cmpq	$2147483647, %rdi
	jg	.LBB1_28
	testq	%rdi, %rdi
	jle	.LBB1_28
	testq	%rdx, %rdx
	jle	.LBB1_28
	testq	%rcx, %rcx
	jle	.LBB1_28
	movq	%rsi, 8(%rsp)
	cmpq	$1, %rax
	jne	.LBB1_184
	movq	%rbp, 24(%rsp)
	leaq	31(%rdx), %rax
	movq	%rcx, %rbx
	addq	$31, %rbx
	movq	%rbx, %rcx
	shrq	$5, %rcx
	movl	%ebx, %edx
	andl	$31, %edx
	shrq	$63, %rbx
	testq	%rdx, %rdx
	cmoveq	%rdx, %rbx
	addq	%rcx, %rbx
	movq	%rax, %rcx
	shrq	$5, %rcx
	movl	%eax, %edx
	andl	$31, %edx
	shrq	$63, %rax
	testq	%rdx, %rdx
	cmoveq	%rdx, %rax
	addq	%rcx, %rax
	cmpq	$65535, %rax
	movl	$65535, %ebp
	cmovbq	%rax, %rbp
	leaq	static_string_6928b95969f03113(%rip), %r9
	movl	$1, %edx
	movl	$103, %ecx
	movl	$47, %r8d
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$75
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movb	$1, %r15b
	testb	$1, %al
	jne	.LBB1_102
	movq	%r13, 16(%rsp)
	movq	%r12, 32(%rsp)
	testb	$1, 4(%rsp)
	je	.LBB1_20
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
.LBB1_20:
	movq	$0, 544(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %r13
	leaq	192(%rsp), %r12
	movq	%r13, %rdi
	xorl	%esi, %esi
	movq	%r12, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	208(%rsp), %rsi
	btq	$61, %rsi
	jb	.LBB1_136
	testq	%rsi, %rsi
	js	.LBB1_131
	movq	200(%rsp), %rsi
	jmp	.LBB1_132
.LBB1_28:
	movq	$34, 8(%r10)
	leaq	static_string_83a7e52fb0129882(%rip), %rax
	movq	%rax, (%r10)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 16(%r10)
	xorl	%edi, %edi
	movq	%r10, %r15
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 24(%r15)
	movb	%dl, 32(%r15)
	movb	$1, %r15b
	jmp	.LBB1_247
.LBB1_29:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB1_30:
	incq	%rsi
	leaq	192(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	208(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB1_32
	movq	200(%rsp), %rcx
	jmp	.LBB1_33
.LBB1_32:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB1_33:
	movb	$0, (%rax,%rcx)
	movq	208(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 208(%rsp)
.LBB1_34:
	movq	%r13, 16(%rsp)
	testq	%rsi, %rsi
	js	.LBB1_36
	movq	192(%rsp), %rbp
.LBB1_36:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_ebcf1412899f981b(%rip), %rdx
	leaq	static_string_77e8a444a810659d(%rip), %rcx
	leaq	static_string_66bf81b04b01b855(%rip), %r8
	leaq	552(%rsp), %r13
	movl	$7529, %r9d
	movq	%r13, %rdi
	movq	16(%rsp), %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testb	$64, 215(%rsp)
	je	.LBB1_39
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_39
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %rbp
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%rbp, %rax
.LBB1_39:
	movq	%r12, 192(%rsp)
	movabsq	$4611686018427387904, %rbp
	movq	$0, 200(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 208(%rsp)
	testq	%rax, %rax
	je	.LBB1_46
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	1152(%rsp), %rdi
	leaq	200(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	1184(%rsp), %eax
	vmovdqu	1152(%rsp), %ymm0
	movzbl	1144(%rsp), %r12d
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	testq	%rbp, 208(%rsp)
	movq	24(%rsp), %rbp
	je	.LBB1_43
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_43
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_43:
	testb	$1, %r12b
	je	.LBB1_47
	testb	$1, 4(%rsp)
	movq	32(%rsp), %r12
	je	.LBB1_51
	movq	8(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB1_51
.LBB1_46:
	movq	24(%rsp), %rbp
.LBB1_47:
	movq	544(%rsp), %rax
	movq	%rax, 40(%rsp)
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	je	.LBB1_52
	testb	$1, 4(%rsp)
	movq	32(%rsp), %r12
	je	.LBB1_50
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_release@PLT
.LBB1_50:
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
.LBB1_51:
	movq	16(%rsp), %r13
	movq	1680(%rsp), %rbx
	jmp	.LBB1_247
.LBB1_52:
	leaq	895(%rsp), %rax
	leaq	888(%rsp), %rcx
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	setns	%dl
	sarq	$3, %rax
	movq	%rax, %rsi
	negq	%rsi
	shlq	$3, %rsi
	addq	%rcx, %rsi
	setne	%cl
	andb	%dl, %cl
	movzbl	%cl, %r15d
	addq	%rax, %r15
	vpbroadcastq	%r15, %ymm0
	shlq	$3, %r15
	vpsllq	$3, %ymm0, %ymm0
	vpaddq	.LCPI1_3(%rip), %ymm0, %ymm1
	vmovdqu	%ymm1, 768(%rsp)
	vpaddq	.LCPI1_4(%rip), %ymm0, %ymm0
	vmovdqu	%ymm0, 800(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %r12
	movq	%r12, %rdi
	movq	8(%rsp), %rsi
	vzeroupper
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	movq	200(%rsp), %rdx
	cmpq	$5, %rdx
	movq	1688(%rsp), %r8
	jne	.LBB1_57
	movq	192(%rsp), %rax
	leaq	static_string_561d9efdd15f277f(%rip), %rcx
	cmpq	%rcx, %rax
	je	.LBB1_116
	movq	%rdx, %rsi
	sarq	$63, %rsi
	andnq	%rdx, %rsi, %rdx
	xorl	%esi, %esi
	.p2align	4
.LBB1_55:
	cmpq	%rsi, %rdx
	je	.LBB1_116
	movzbl	(%rax,%rsi), %edi
	cmpb	(%rsi,%rcx), %dil
	leaq	1(%rsi), %rsi
	je	.LBB1_55
.LBB1_57:
	movq	%rbp, (%r15)
	movq	%r15, 544(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r15)
	movq	1624(%rsp), %rax
	movq	%rax, 16(%r15)
	movq	1656(%rsp), %rax
	movq	%rax, 24(%r15)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r15)
	vmovups	800(%rsp), %ymm0
	vmovups	%ymm0, 552(%rsp)
	movl	%r8d, 40(%r15)
	movq	1696(%rsp), %rax
	movl	%eax, 48(%r15)
	movq	1704(%rsp), %rax
	movl	%eax, 56(%r15)
	movl	1712(%rsp), %eax
	movl	%eax, 64(%r15)
	vmovdqu	768(%rsp), %ymm0
	vmovdqu	%ymm0, 584(%rsp)
	movq	$0, 856(%rsp)
	movq	8(%rsp), %r15
	movq	%r15, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$9
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_124
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r15, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 448(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 440(%rsp)
	movq	%rdx, 456(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	448(%rsp), %r11
	leaq	88(%rsp), %r15
	leaq	176(%rsp), %r12
	leaq	56(%rsp), %r13
	leaq	static_string_4f5aebbb4c03edc3(%rip), %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	1448(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$73, %esi
	movl	$58, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$968
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1472(%rsp), %eax
	vmovdqu	1440(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_61
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_61
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_61:
	testq	%r15, 456(%rsp)
	movq	16(%rsp), %r13
	je	.LBB1_64
	movq	440(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_64
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_64:
	testq	%r15, 96(%rsp)
	movq	32(%rsp), %r12
	movq	24(%rsp), %rbp
	movq	1680(%rsp), %rbx
	je	.LBB1_67
	jmp	.LBB1_65
.LBB1_80:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB1_81:
	incq	%rsi
	leaq	192(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	208(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB1_83
	movq	200(%rsp), %rcx
	jmp	.LBB1_84
.LBB1_83:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB1_84:
	movb	$0, (%rax,%rcx)
	movq	208(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 208(%rsp)
.LBB1_85:
	testq	%rsi, %rsi
	js	.LBB1_87
	movq	192(%rsp), %r13
.LBB1_87:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_73c31eed37cdc470(%rip), %rdx
	leaq	static_string_2838b8f3ca24fc26(%rip), %rcx
	leaq	static_string_e07c7279604e36e8(%rip), %r8
	leaq	552(%rsp), %rdi
	movl	$112793, %r9d
	movq	16(%rsp), %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testb	$64, 215(%rsp)
	je	.LBB1_90
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_90
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r13
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r13, %rax
.LBB1_90:
	movq	%r12, 192(%rsp)
	movabsq	$4611686018427387904, %r13
	movq	$0, 200(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 208(%rsp)
	testq	%rax, %rax
	je	.LBB1_97
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	1200(%rsp), %rdi
	leaq	200(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	1232(%rsp), %eax
	vmovdqu	1200(%rsp), %ymm0
	movzbl	1192(%rsp), %r12d
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	testq	%r13, 208(%rsp)
	movq	16(%rsp), %r13
	je	.LBB1_94
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_94
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_94:
	testb	$1, %r12b
	je	.LBB1_98
.LBB1_95:
	testb	$1, 4(%rsp)
	movq	32(%rsp), %r12
	je	.LBB1_102
	movq	8(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB1_102
.LBB1_97:
	movq	16(%rsp), %r13
.LBB1_98:
	movq	544(%rsp), %rax
	movq	%rax, 40(%rsp)
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	je	.LBB1_103
.LBB1_99:
	testb	$1, 4(%rsp)
	movq	32(%rsp), %r12
	je	.LBB1_101
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_release@PLT
.LBB1_101:
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
.LBB1_102:
	movq	24(%rsp), %rbp
	movq	1680(%rsp), %rbx
	jmp	.LBB1_247
.LBB1_103:
	leaq	895(%rsp), %rax
	leaq	888(%rsp), %rcx
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	setns	%dl
	sarq	$3, %rax
	movq	%rax, %rsi
	negq	%rsi
	shlq	$3, %rsi
	addq	%rcx, %rsi
	setne	%cl
	andb	%dl, %cl
	movzbl	%cl, %ecx
	addq	%rax, %rcx
	leaq	(,%rcx,8), %r13
	leaq	88(%r13), %r15
	vpbroadcastq	%rcx, %ymm0
	vpsllq	$3, %ymm0, %ymm0
	vpaddq	.LCPI1_3(%rip), %ymm0, %ymm1
	vmovdqu	%ymm1, 768(%rsp)
	vpaddq	.LCPI1_4(%rip), %ymm0, %ymm0
	vmovdqu	%ymm0, 800(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %r12
	movq	%r12, %rdi
	movq	8(%rsp), %rsi
	vzeroupper
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	movq	200(%rsp), %rdx
	cmpq	$5, %rdx
	movq	1688(%rsp), %r8
	jne	.LBB1_108
	movq	192(%rsp), %rax
	leaq	static_string_561d9efdd15f277f(%rip), %rcx
	cmpq	%rcx, %rax
	je	.LBB1_125
	movq	%rdx, %rsi
	sarq	$63, %rsi
	andnq	%rdx, %rsi, %rdx
	xorl	%esi, %esi
	.p2align	4
.LBB1_106:
	cmpq	%rsi, %rdx
	je	.LBB1_125
	movzbl	(%rax,%rsi), %edi
	cmpb	(%rsi,%rcx), %dil
	leaq	1(%rsi), %rsi
	je	.LBB1_106
.LBB1_108:
	movq	24(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 544(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r13)
	movq	1640(%rsp), %rax
	movq	%rax, 16(%r13)
	movq	1656(%rsp), %rcx
	movq	%rcx, 24(%r13)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r13)
	vmovups	800(%rsp), %ymm0
	vmovups	%ymm0, 552(%rsp)
	movq	%rcx, 40(%r13)
	movq	%rax, 48(%r13)
	movl	%r8d, 56(%r13)
	movq	1696(%rsp), %rax
	movl	%eax, 64(%r13)
	vmovdqu	768(%rsp), %ymm0
	vmovdqu	%ymm0, 584(%rsp)
	movl	%eax, 72(%r13)
	leaq	72(%r13), %rax
	movq	%rax, 616(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 80(%r13)
	leaq	80(%r13), %rax
	movq	%rax, 624(%rsp)
	movl	1712(%rsp), %eax
	movl	%eax, 88(%r13)
	movq	%r15, 632(%rsp)
	movq	$0, 840(%rsp)
	movq	8(%rsp), %r15
	movq	%r15, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	%ebp, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$12
	.cfi_adjust_cfa_offset 8
	leaq	560(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_242
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r15, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 448(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 440(%rsp)
	movq	%rdx, 456(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	448(%rsp), %r11
	leaq	88(%rsp), %r15
	leaq	176(%rsp), %r12
	leaq	56(%rsp), %r13
	leaq	static_string_1ac8d80efaa5b430(%rip), %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	1528(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$99, %esi
	movl	$78, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$1293
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1552(%rsp), %eax
	vmovdqu	1520(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_112
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_112
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_112:
	testq	%r15, 456(%rsp)
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	je	.LBB1_115
	movq	440(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_115
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_115:
	testq	%r15, 96(%rsp)
	movq	32(%rsp), %r12
	movq	1680(%rsp), %rbx
	jne	.LBB1_65
	jmp	.LBB1_67
.LBB1_116:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 360(%rsp)
	vmovdqu	%ymm0, 328(%rsp)
	vmovdqu	%ymm0, 296(%rsp)
	vmovdqu	%ymm0, 264(%rsp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 89(%rsp)
	movq	%rbp, (%r15)
	movq	%r15, 544(%rsp)
	movb	$0, 80(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r15)
	movb	$0, 81(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 16(%r15)
	movb	$0, 82(%rsp)
	movq	1656(%rsp), %rax
	movq	%rax, 24(%r15)
	vbroadcastsd	.LCPI1_5(%rip), %ymm0
	vmovups	%ymm0, 192(%rsp)
	movb	$0, 83(%rsp)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r15)
	vmovups	800(%rsp), %ymm0
	vmovups	%ymm0, 552(%rsp)
	movb	$0, 84(%rsp)
	movl	%r8d, 40(%r15)
	movb	$0, 85(%rsp)
	movq	1696(%rsp), %rax
	movl	%eax, 48(%r15)
	movb	$0, 86(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 56(%r15)
	vmovaps	.LCPI1_8(%rip), %ymm0
	vmovups	%ymm0, 224(%rsp)
	movb	$0, 87(%rsp)
	movl	1712(%rsp), %eax
	movl	%eax, 64(%r15)
	vmovdqu	768(%rsp), %ymm0
	vmovdqu	%ymm0, 584(%rsp)
	movq	$4, 256(%rsp)
	movb	$0, 88(%rsp)
	movq	%r13, 440(%rsp)
	movq	%r12, 448(%rsp)
	leaq	80(%rsp), %r13
	movq	%r13, 456(%rsp)
	movq	$8, 464(%rsp)
	movl	$0, 472(%rsp)
	leaq	440(%rsp), %r12
	movq	%r12, 416(%rsp)
	movq	$0, 864(%rsp)
	leaq	416(%rsp), %rax
	movq	8(%rsp), %r15
	movq	%r15, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$9
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_124
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r15, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 448(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 440(%rsp)
	movq	%rdx, 456(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	176(%rsp), %r11
	leaq	56(%rsp), %r15
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	1408(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$73, %esi
	movl	$58, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$968
	.cfi_adjust_cfa_offset 8
	leaq	static_string_4f5aebbb4c03edc3(%rip), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1432(%rsp), %eax
	vmovdqu	1400(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_120
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_120
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_120:
	testq	%r15, 456(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	1680(%rsp), %rbx
	je	.LBB1_123
	jmp	.LBB1_121
.LBB1_124:
	xorl	%r15d, %r15d
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	jmp	.LBB1_243
.LBB1_125:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 384(%rsp)
	vmovdqu	%ymm0, 352(%rsp)
	vmovdqu	%ymm0, 320(%rsp)
	vmovdqu	%ymm0, 288(%rsp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 92(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 544(%rsp)
	movb	$0, 80(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r13)
	movb	$0, 81(%rsp)
	movq	1640(%rsp), %rax
	movq	%rax, 16(%r13)
	movb	$0, 82(%rsp)
	movq	1656(%rsp), %rcx
	movq	%rcx, 24(%r13)
	vbroadcastsd	.LCPI1_5(%rip), %ymm0
	vmovups	%ymm0, 192(%rsp)
	movb	$0, 83(%rsp)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r13)
	vmovups	800(%rsp), %ymm0
	vmovups	%ymm0, 552(%rsp)
	movb	$0, 84(%rsp)
	movq	%rcx, 40(%r13)
	movb	$0, 85(%rsp)
	movq	%rax, 48(%r13)
	movb	$0, 86(%rsp)
	movl	%r8d, 56(%r13)
	vmovaps	.LCPI1_6(%rip), %ymm0
	vmovups	%ymm0, 224(%rsp)
	movb	$0, 87(%rsp)
	movq	1696(%rsp), %rax
	movl	%eax, 64(%r13)
	vmovups	768(%rsp), %ymm0
	vmovups	%ymm0, 584(%rsp)
	movb	$0, 88(%rsp)
	movl	%eax, 72(%r13)
	leaq	72(%r13), %rax
	movq	%rax, 616(%rsp)
	movb	$0, 89(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 80(%r13)
	leaq	80(%r13), %rax
	movq	%rax, 624(%rsp)
	movb	$0, 90(%rsp)
	movl	1712(%rsp), %eax
	movl	%eax, 88(%r13)
	movq	%r15, 632(%rsp)
	vpbroadcastq	.LCPI1_7(%rip), %ymm0
	vmovdqu	%ymm0, 256(%rsp)
	movb	$0, 91(%rsp)
	leaq	544(%rsp), %rax
	movq	%rax, 440(%rsp)
	movq	%r12, 448(%rsp)
	leaq	80(%rsp), %r15
	movq	%r15, 456(%rsp)
	movq	$8, 464(%rsp)
	movl	$0, 472(%rsp)
	leaq	440(%rsp), %r12
	movq	%r12, 416(%rsp)
	movq	$0, 848(%rsp)
	leaq	416(%rsp), %rax
	movq	8(%rsp), %r13
	movq	%r13, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	%ebp, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_242
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r13, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 448(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 440(%rsp)
	movq	%rdx, 456(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	176(%rsp), %r11
	leaq	56(%rsp), %r13
	leaq	static_string_1ac8d80efaa5b430(%rip), %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	1488(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$99, %esi
	movl	$78, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$1293
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1512(%rsp), %eax
	vmovdqu	1480(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_129
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_129
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_129:
	testq	%r15, 456(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	movq	1680(%rsp), %rbx
	je	.LBB1_123
.LBB1_121:
	movq	440(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_123
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_123:
	testq	%r15, 96(%rsp)
	je	.LBB1_67
.LBB1_65:
	movq	80(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_67
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_67:
	testq	%r15, 64(%rsp)
	je	.LBB1_70
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_70
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_70:
	testq	%r15, 136(%rsp)
	je	.LBB1_73
	movq	120(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_73
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_73:
	testq	%r15, 184(%rsp)
	je	.LBB1_76
	movq	168(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_76
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_76:
	testq	%r15, 160(%rsp)
	je	.LBB1_79
	movq	144(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_79
.LBB1_78:
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_79:
	movb	$1, %r15b
	testb	$1, 4(%rsp)
	je	.LBB1_246
.LBB1_245:
	movq	8(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
.LBB1_246:
	movq	40(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceFunction_release@PLT
	jmp	.LBB1_247
.LBB1_131:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB1_132:
	incq	%rsi
	leaq	192(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	208(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB1_134
	movq	200(%rsp), %rcx
	jmp	.LBB1_135
.LBB1_134:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB1_135:
	movb	$0, (%rax,%rcx)
	movq	208(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 208(%rsp)
.LBB1_136:
	testq	%rsi, %rsi
	js	.LBB1_138
	movq	192(%rsp), %r12
.LBB1_138:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_fa0e29d972eecbd4(%rip), %rdx
	leaq	static_string_047bc43de4256ef8(%rip), %rcx
	leaq	static_string_5aef0422996201bd(%rip), %r8
	leaq	552(%rsp), %rdi
	movl	$3504, %r9d
	movq	16(%rsp), %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testb	$64, 215(%rsp)
	je	.LBB1_141
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_141
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r12
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r12, %rax
.LBB1_141:
	movq	%r13, 192(%rsp)
	movabsq	$4611686018427387904, %r13
	movq	$0, 200(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 208(%rsp)
	testq	%rax, %rax
	je	.LBB1_146
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	1104(%rsp), %rdi
	leaq	200(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	1136(%rsp), %eax
	vmovdqu	1104(%rsp), %ymm0
	movzbl	1096(%rsp), %r12d
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	testq	%r13, 208(%rsp)
	movq	16(%rsp), %r13
	je	.LBB1_145
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_145
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_145:
	testb	$1, %r12b
	jne	.LBB1_95
	jmp	.LBB1_147
.LBB1_146:
	movq	16(%rsp), %r13
.LBB1_147:
	movq	544(%rsp), %rax
	movq	%rax, 40(%rsp)
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	jne	.LBB1_99
	leaq	447(%rsp), %rax
	leaq	440(%rsp), %rcx
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	setns	%dl
	sarq	$3, %rax
	movq	%rax, %rsi
	negq	%rsi
	shlq	$3, %rsi
	addq	%rcx, %rsi
	setne	%cl
	andb	%dl, %cl
	movzbl	%cl, %r13d
	addq	%rax, %r13
	shlq	$3, %r13
	leaq	24(%r13), %rax
	movq	%rax, 768(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rdi
	movq	8(%rsp), %r12
	movq	%r12, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovdqu	192(%rsp), %xmm0
	vmovdqu	%xmm0, 544(%rsp)
	movq	$0, 560(%rsp)
	movq	$5, 200(%rsp)
	leaq	static_string_561d9efdd15f277f(%rip), %rax
	movq	%rax, 192(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 208(%rsp)
	leaq	544(%rsp), %rdi
	leaq	192(%rsp), %rsi
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	testb	$1, %al
	je	.LBB1_172
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 320(%rsp)
	vmovdqu	%ymm0, 288(%rsp)
	vmovdqu	%ymm0, 256(%rsp)
	vmovdqu	%ymm0, 224(%rsp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 84(%rsp)
	movq	1640(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 888(%rsp)
	movb	$0, 80(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 8(%r13)
	leaq	8(%r13), %rax
	movq	%rax, 896(%rsp)
	movb	$0, 81(%rsp)
	movq	1696(%rsp), %rax
	movl	%eax, 16(%r13)
	leaq	16(%r13), %rax
	movq	%rax, 904(%rsp)
	movb	$0, 82(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 24(%r13)
	movq	768(%rsp), %rax
	movq	%rax, 912(%rsp)
	vmovdqa	.LCPI1_9(%rip), %ymm0
	vmovdqu	%ymm0, 192(%rsp)
	movb	$0, 83(%rsp)
	leaq	888(%rsp), %rax
	movq	%rax, 544(%rsp)
	leaq	192(%rsp), %rax
	movq	%rax, 552(%rsp)
	leaq	80(%rsp), %rax
	movq	%rax, 560(%rsp)
	movq	$8, 568(%rsp)
	movl	$0, 576(%rsp)
	leaq	544(%rsp), %r13
	movq	%r13, 528(%rsp)
	movq	$0, 880(%rsp)
	leaq	528(%rsp), %rax
	movq	%r12, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	%ebp, %ecx
	movl	$1, %r8d
	movl	$32, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$32
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_180
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r12, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r12, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 552(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 544(%rsp)
	movq	%rdx, 560(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	176(%rsp), %r11
	movq	%r13, %r12
	leaq	56(%rsp), %r13
	leaq	static_string_a0cb3684e599879d(%rip), %rbp
	leaq	static_string_6928b95969f03113(%rip), %rcx
	leaq	1328(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$103, %esi
	movl	$47, %edx
	movl	$75, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	120(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$469
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1352(%rsp), %eax
	vmovdqu	1320(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %rbx
	testq	%rbx, 208(%rsp)
	je	.LBB1_153
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_153
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_153:
	testq	%rbx, 560(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	je	.LBB1_156
	movq	544(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_156
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_156:
	testq	%rbx, 96(%rsp)
	je	.LBB1_159
	jmp	.LBB1_157
.LBB1_172:
	movq	1640(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 888(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 8(%r13)
	leaq	8(%r13), %rax
	movq	%rax, 896(%rsp)
	movq	1696(%rsp), %rax
	movl	%eax, 16(%r13)
	leaq	16(%r13), %rax
	movq	%rax, 904(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 24(%r13)
	movq	768(%rsp), %rax
	movq	%rax, 912(%rsp)
	movq	$0, 528(%rsp)
	leaq	888(%rsp), %rax
	movq	%r12, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	%ebp, %ecx
	movl	$1, %r8d
	movl	$32, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$32
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_180
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	8(%rsp), %r12
	movq	%r12, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 168(%rsp)
	movq	$0, 184(%rsp)
	movq	%r12, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 128(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 136(%rsp)
	movq	$12, 56(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$1, 88(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$13, 552(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 544(%rsp)
	movq	%rdx, 560(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	152(%rsp), %r10
	leaq	88(%rsp), %r11
	leaq	176(%rsp), %r12
	leaq	56(%rsp), %r13
	leaq	static_string_a0cb3684e599879d(%rip), %rbp
	leaq	static_string_6928b95969f03113(%rip), %rcx
	leaq	1368(%rsp), %rdi
	leaq	128(%rsp), %r9
	movl	$103, %esi
	movl	$47, %edx
	movl	$75, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	leaq	568(%rsp), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$469
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1392(%rsp), %eax
	vmovdqu	1360(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %rbx
	testq	%rbx, 208(%rsp)
	je	.LBB1_176
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_176
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_176:
	testq	%rbx, 560(%rsp)
	je	.LBB1_179
	movq	544(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_179
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_179:
	testq	%rbx, 96(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	je	.LBB1_159
.LBB1_157:
	movq	80(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_159
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_159:
	testq	%rbx, 64(%rsp)
	je	.LBB1_162
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_162
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_162:
	testq	%rbx, 136(%rsp)
	je	.LBB1_165
	movq	120(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_165
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_165:
	testq	%rbx, 184(%rsp)
	je	.LBB1_168
	movq	168(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_168
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_168:
	testq	%rbx, 160(%rsp)
	je	.LBB1_171
	movq	144(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_171
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_171:
	movb	$1, %bl
	jmp	.LBB1_181
.LBB1_180:
	xorl	%ebx, %ebx
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
.LBB1_181:
	testb	$1, 4(%rsp)
	je	.LBB1_183
	movq	8(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
.LBB1_183:
	movq	40(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceFunction_release@PLT
	testb	%bl, %bl
	movq	1680(%rsp), %rbx
	movq	1728(%rsp), %r10
	movq	1696(%rsp), %rdx
	movq	1688(%rsp), %rdi
	jne	.LBB1_247
.LBB1_184:
	movq	%rdx, %rax
	imulq	%rdi, %rax
	addq	$255, %rax
	leaq	255(%rax), %rcx
	testq	%rax, %rax
	cmovnsq	%rax, %rcx
	movq	%rcx, %rdx
	sarq	$8, %rdx
	andq	$-256, %rcx
	movq	%rax, %rsi
	sarq	$63, %rsi
	xorl	%ebx, %ebx
	cmpq	%rax, %rcx
	cmovneq	%rsi, %rbx
	addq	%rdx, %rbx
	leaq	static_string_6928b95969f03113(%rip), %r9
	movl	$1, %esi
	movl	$1, %edx
	movl	$109, %ecx
	movl	$59, %r8d
	movq	%rbx, %rdi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$75
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movb	$1, %r15b
	testb	$1, %al
	je	.LBB1_185
.LBB1_3:
	movq	1680(%rsp), %rbx
.LBB1_247:
	movq	1664(%rsp), %rax
	movq	1648(%rsp), %rcx
	movq	1632(%rsp), %rdx
	movq	1616(%rsp), %rsi
	movq	1672(%rsp), %rdi
	movq	%rdi, 88(%r14)
	movq	1656(%rsp), %rdi
	movq	%rdi, 72(%r14)
	movq	1640(%rsp), %rdi
	movq	%rdi, 56(%r14)
	movq	1624(%rsp), %rdi
	movq	%rdi, 40(%r14)
	movq	%r13, 24(%r14)
	movq	%rbp, 8(%r14)
	movb	%r15b, (%r14)
	movq	%rbx, 96(%r14)
	movq	%rax, 80(%r14)
	movq	%rcx, 64(%r14)
	movq	%rdx, 48(%r14)
	movq	%rsi, 32(%r14)
	movq	%r12, 16(%r14)
	movq	%r14, %rax
	addq	$1560, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB1_185:
	.cfi_def_cfa_offset 1616
	movq	%r13, 16(%rsp)
	movq	%r12, 32(%rsp)
	testb	$1, 4(%rsp)
	je	.LBB1_187
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
.LBB1_187:
	movq	$0, 544(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %r13
	leaq	192(%rsp), %r12
	movq	%r13, %rdi
	xorl	%esi, %esi
	movq	%r12, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	208(%rsp), %rsi
	btq	$61, %rsi
	jb	.LBB1_195
	testq	%rsi, %rsi
	js	.LBB1_190
	movq	200(%rsp), %rsi
	jmp	.LBB1_191
.LBB1_190:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB1_191:
	incq	%rsi
	leaq	192(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	208(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB1_193
	movq	200(%rsp), %rcx
	jmp	.LBB1_194
.LBB1_193:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB1_194:
	movb	$0, (%rax,%rcx)
	movq	208(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 208(%rsp)
.LBB1_195:
	testq	%rsi, %rsi
	js	.LBB1_197
	movq	192(%rsp), %r12
.LBB1_197:
	movq	%rbp, 24(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f055329ebaf6eb0b(%rip), %rdx
	leaq	static_string_501a9b65d3141c0b(%rip), %rcx
	leaq	static_string_16654fb8ec1a054b(%rip), %r8
	leaq	552(%rsp), %rdi
	movl	$7671, %r9d
	movq	16(%rsp), %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testb	$64, 215(%rsp)
	je	.LBB1_200
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_200
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r12
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r12, %rax
.LBB1_200:
	movq	%r13, 192(%rsp)
	movabsq	$4611686018427387904, %r12
	movq	$0, 200(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 208(%rsp)
	testq	%rax, %rax
	je	.LBB1_207
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	1056(%rsp), %rdi
	leaq	200(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	1088(%rsp), %eax
	vmovdqu	1056(%rsp), %ymm0
	movzbl	1048(%rsp), %ebp
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	testq	%r12, 208(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	je	.LBB1_204
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_204
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_204:
	testb	$1, %bpl
	je	.LBB1_208
	testb	$1, 4(%rsp)
	movq	24(%rsp), %rbp
	je	.LBB1_3
	movq	8(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB1_3
.LBB1_207:
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
.LBB1_208:
	movq	544(%rsp), %rax
	movq	%rax, 40(%rsp)
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	je	.LBB1_212
	testb	$1, 4(%rsp)
	movq	24(%rsp), %rbp
	je	.LBB1_211
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceContext_release@PLT
.LBB1_211:
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
	movq	1680(%rsp), %rbx
	jmp	.LBB1_247
.LBB1_212:
	leaq	447(%rsp), %rax
	leaq	440(%rsp), %rcx
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	setns	%dl
	sarq	$3, %rax
	movq	%rax, %rsi
	negq	%rsi
	shlq	$3, %rsi
	addq	%rcx, %rsi
	setne	%cl
	andb	%dl, %cl
	movzbl	%cl, %r13d
	addq	%rax, %r13
	shlq	$3, %r13
	leaq	72(%r13), %rbp
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rdi
	movq	8(%rsp), %r15
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 544(%rsp)
	movq	$0, 560(%rsp)
	movq	$5, 200(%rsp)
	leaq	static_string_561d9efdd15f277f(%rip), %rax
	movq	%rax, 192(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 208(%rsp)
	leaq	544(%rsp), %rdi
	leaq	192(%rsp), %r12
	movq	%r12, %rsi
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	vpbroadcastq	%r13, %ymm0
	vpaddq	.LCPI1_4(%rip), %ymm0, %ymm1
	vpaddq	.LCPI1_3(%rip), %ymm0, %ymm0
	testb	$1, %al
	je	.LBB1_234
	vxorps	%xmm2, %xmm2, %xmm2
	vmovups	%ymm2, 368(%rsp)
	vmovups	%ymm2, 336(%rsp)
	vmovups	%ymm2, 304(%rsp)
	vmovups	%ymm2, 272(%rsp)
	vxorps	%xmm2, %xmm2, %xmm2
	vmovups	%xmm2, 58(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 544(%rsp)
	movb	$0, 48(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r13)
	movb	$0, 49(%rsp)
	movq	1640(%rsp), %rax
	movq	%rax, 16(%r13)
	movb	$0, 50(%rsp)
	movq	1656(%rsp), %rax
	movq	%rax, 24(%r13)
	vpbroadcastq	.LCPI1_5(%rip), %ymm2
	vmovdqu	%ymm2, 192(%rsp)
	movb	$0, 51(%rsp)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r13)
	vmovdqu	%ymm1, 552(%rsp)
	movb	$0, 52(%rsp)
	movq	1688(%rsp), %rax
	movl	%eax, 40(%r13)
	movb	$0, 53(%rsp)
	movq	1696(%rsp), %rax
	movl	%eax, 48(%r13)
	movb	$0, 54(%rsp)
	movl	%eax, 56(%r13)
	vmovdqa	.LCPI1_8(%rip), %ymm1
	vmovdqu	%ymm1, 224(%rsp)
	movb	$0, 55(%rsp)
	movq	1704(%rsp), %rax
	movl	%eax, 64(%r13)
	vmovdqu	%ymm0, 584(%rsp)
	movq	$4, 256(%rsp)
	movb	$0, 56(%rsp)
	movl	1712(%rsp), %eax
	movl	%eax, 72(%r13)
	movq	%rbp, 616(%rsp)
	movq	$4, 264(%rsp)
	movb	$0, 57(%rsp)
	leaq	544(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	%r12, 88(%rsp)
	leaq	48(%rsp), %r13
	movq	%r13, 96(%rsp)
	movq	$8, 104(%rsp)
	movl	$0, 112(%rsp)
	leaq	80(%rsp), %r12
	movq	%r12, 536(%rsp)
	movq	$0, 872(%rsp)
	leaq	536(%rsp), %rax
	movq	%r15, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_242
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 416(%rsp)
	movq	%rdx, 424(%rsp)
	movq	%rcx, 432(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 144(%rsp)
	movq	$0, 160(%rsp)
	movq	%r15, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 176(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 168(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 184(%rsp)
	movq	$12, 128(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movq	%rdx, 136(%rsp)
	movq	$1, 56(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$13, 88(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	424(%rsp), %r10
	leaq	152(%rsp), %r11
	movq	%r13, %r15
	leaq	128(%rsp), %r13
	leaq	static_string_b10b6afccde6c412(%rip), %rbp
	leaq	static_string_6928b95969f03113(%rip), %rcx
	leaq	1248(%rsp), %rdi
	leaq	176(%rsp), %r9
	movl	$109, %esi
	movl	$59, %edx
	movl	$75, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$1022
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1272(%rsp), %eax
	vmovdqu	1240(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_217
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_217
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_217:
	testq	%r15, 96(%rsp)
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	movq	1680(%rsp), %rbx
	je	.LBB1_220
	movq	80(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_220
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_220:
	testq	%r15, 64(%rsp)
	je	.LBB1_223
	jmp	.LBB1_221
.LBB1_234:
	movq	24(%rsp), %rax
	movq	%rax, (%r13)
	movq	%r13, 544(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 8(%r13)
	movq	1640(%rsp), %rax
	movq	%rax, 16(%r13)
	movq	1656(%rsp), %rax
	movq	%rax, 24(%r13)
	movq	1672(%rsp), %rax
	movq	%rax, 32(%r13)
	vmovdqu	%ymm1, 552(%rsp)
	movq	1688(%rsp), %rax
	movl	%eax, 40(%r13)
	movq	1696(%rsp), %rax
	movl	%eax, 48(%r13)
	movl	%eax, 56(%r13)
	movq	1704(%rsp), %rax
	movl	%eax, 64(%r13)
	vmovdqu	%ymm0, 584(%rsp)
	movl	1712(%rsp), %eax
	movl	%eax, 72(%r13)
	movq	%rbp, 616(%rsp)
	movq	$0, 536(%rsp)
	movq	%r15, %rdi
	movq	40(%rsp), %rsi
	movl	%ebx, %edx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$10
	.cfi_adjust_cfa_offset 8
	leaq	560(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB1_242
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 416(%rsp)
	movq	%rdx, 424(%rsp)
	movq	%rcx, 432(%rsp)
	movq	$1, 192(%rsp)
	movq	$0, 200(%rsp)
	leaq	192(%rsp), %rbx
	movq	%rbx, %rdi
	movq	8(%rsp), %r15
	movq	%r15, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	192(%rsp), %xmm0
	vmovups	%xmm0, 144(%rsp)
	movq	$0, 160(%rsp)
	movq	%r15, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 176(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 168(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 184(%rsp)
	movq	$12, 128(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 120(%rsp)
	movq	%rdx, 136(%rsp)
	movq	$1, 56(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$13, 88(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rdx, 96(%rsp)
	movq	$1, 200(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	%rdx, 208(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	424(%rsp), %r10
	leaq	88(%rsp), %r11
	leaq	56(%rsp), %r15
	leaq	152(%rsp), %r12
	leaq	128(%rsp), %r13
	leaq	static_string_b10b6afccde6c412(%rip), %rbp
	leaq	static_string_6928b95969f03113(%rip), %rcx
	leaq	1288(%rsp), %rdi
	leaq	176(%rsp), %r9
	movl	$109, %esi
	movl	$59, %edx
	movl	$75, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$1022
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	1312(%rsp), %eax
	vmovdqu	1280(%rsp), %ymm0
	movq	1728(%rsp), %rcx
	vmovdqu	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %r15
	testq	%r15, 208(%rsp)
	je	.LBB1_238
	movq	192(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_238
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_238:
	testq	%r15, 96(%rsp)
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
	je	.LBB1_241
	movq	80(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_241
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_241:
	testq	%r15, 64(%rsp)
	movq	32(%rsp), %r12
	movq	1680(%rsp), %rbx
	je	.LBB1_223
.LBB1_221:
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_223
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_223:
	testq	%r15, 136(%rsp)
	je	.LBB1_226
	movq	120(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_226
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_226:
	testq	%r15, 184(%rsp)
	je	.LBB1_229
	movq	168(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_229
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_229:
	testq	%r15, 160(%rsp)
	je	.LBB1_232
	movq	144(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB1_232
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB1_232:
	testq	%r15, 432(%rsp)
	je	.LBB1_79
	movq	416(%rsp), %rdi
	lock		decq	-8(%rdi)
	je	.LBB1_78
	jmp	.LBB1_79
.LBB1_242:
	xorl	%r15d, %r15d
	movq	32(%rsp), %r12
	movq	16(%rsp), %r13
	movq	24(%rsp), %rbp
.LBB1_243:
	movq	1680(%rsp), %rbx
	testb	$1, 4(%rsp)
	je	.LBB1_246
	jmp	.LBB1_245
.Lfunc_end1:
	.size	"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end1-"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI2_0:
	.quad	40
	.quad	48
	.quad	56
	.quad	64
.LCPI2_1:
	.quad	8
	.quad	16
	.quad	24
	.quad	32
.LCPI2_3:
	.quad	8
	.quad	4
	.quad	4
	.quad	4
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI2_2:
	.quad	8
	.text
	.prefalign	4, .Lfunc_end2, nop
	.type	"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])",@function
"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$904, %rsp
	.cfi_def_cfa_offset 960
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, %rbp
	movq	%r8, %r15
	movq	%rcx, 56(%rsp)
	movl	%edx, %ebx
	movq	%rsi, %r13
	movq	%rdi, %r14
	movq	1016(%rsp), %rdi
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	movl	$1, %esi
	movl	$1, %edx
	movl	$116, %ecx
	movl	$68, %r8d
	pushq	1040(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movb	$1, %r12b
	testb	$1, %al
	jne	.LBB2_63
	movq	%rbp, 8(%rsp)
	movq	%r15, 48(%rsp)
	movl	%ebx, 4(%rsp)
	testb	$1, %bl
	je	.LBB2_3
	movq	%r13, %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
.LBB2_3:
	movq	$0, 624(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %rbp
	leaq	216(%rsp), %r15
	movq	%rbp, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	232(%rsp), %rsi
	btq	$61, %rsi
	jb	.LBB2_11
	testq	%rsi, %rsi
	js	.LBB2_6
	movq	224(%rsp), %rsi
	jmp	.LBB2_7
.LBB2_6:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB2_7:
	incq	%rsi
	leaq	216(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	232(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB2_9
	movq	224(%rsp), %rcx
	jmp	.LBB2_10
.LBB2_9:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB2_10:
	movb	$0, (%rax,%rcx)
	movq	232(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 232(%rsp)
.LBB2_11:
	testq	%rsi, %rsi
	js	.LBB2_13
	movq	216(%rsp), %r15
.LBB2_13:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_7ca086bb03b09a35(%rip), %rdx
	leaq	static_string_3648de856b228127(%rip), %rcx
	leaq	static_string_d28ef84eb1c678f9(%rip), %r8
	leaq	632(%rsp), %rdi
	movl	$16368, %r9d
	movq	%r13, %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testb	$64, 239(%rsp)
	je	.LBB2_16
	movq	216(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_16
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r15
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r15, %rax
.LBB2_16:
	movq	%rbp, 216(%rsp)
	movabsq	$4611686018427387904, %rbx
	movq	$0, 224(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 232(%rsp)
	testq	%rax, %rax
	je	.LBB2_23
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	504(%rsp), %rdi
	leaq	224(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	536(%rsp), %eax
	vmovups	504(%rsp), %ymm0
	movzbl	496(%rsp), %ebp
	movq	1040(%rsp), %rcx
	vmovups	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	testq	%rbx, 232(%rsp)
	je	.LBB2_20
	movq	216(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_20
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_20:
	testb	$1, %bpl
	je	.LBB2_23
	testb	$1, 4(%rsp)
	movq	48(%rsp), %r15
	movq	8(%rsp), %rbp
	je	.LBB2_63
	movq	%r13, %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB2_63
.LBB2_23:
	movq	624(%rsp), %rbx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	je	.LBB2_27
	testb	$1, 4(%rsp)
	movq	48(%rsp), %r15
	movq	8(%rsp), %rbp
	je	.LBB2_26
	movq	%r13, %rdi
	callq	AsyncRT_DeviceContext_release@PLT
.LBB2_26:
	movq	%rbx, %rdi
	jmp	.LBB2_62
.LBB2_27:
	movl	1024(%rsp), %r12d
	leaq	831(%rsp), %rax
	leaq	824(%rsp), %rcx
	testq	%rcx, %rcx
	cmovnsq	%rcx, %rax
	setns	%dl
	sarq	$3, %rax
	movq	%rax, %rsi
	negq	%rsi
	shlq	$3, %rsi
	addq	%rcx, %rsi
	setne	%cl
	andb	%dl, %cl
	movzbl	%cl, %ebp
	addq	%rax, %rbp
	vpbroadcastq	%rbp, %ymm0
	shlq	$3, %rbp
	vpsllq	$3, %ymm0, %ymm0
	vpaddq	.LCPI2_0(%rip), %ymm0, %ymm1
	vmovdqu	%ymm1, 464(%rsp)
	vpaddq	.LCPI2_1(%rip), %ymm0, %ymm0
	vmovdqu	%ymm0, 432(%rsp)
	movq	$1, 216(%rsp)
	movq	$0, 224(%rsp)
	leaq	216(%rsp), %r15
	movq	%r15, %rdi
	movq	%r13, %rsi
	vzeroupper
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	movq	224(%rsp), %rdx
	cmpq	$5, %rdx
	movq	%rbx, 200(%rsp)
	jne	.LBB2_32
	movq	216(%rsp), %rax
	leaq	static_string_561d9efdd15f277f(%rip), %rcx
	cmpq	%rcx, %rax
	je	.LBB2_56
	movq	%rdx, %rsi
	sarq	$63, %rsi
	andnq	%rdx, %rsi, %rdx
	xorl	%esi, %esi
	.p2align	4
.LBB2_30:
	cmpq	%rsi, %rdx
	je	.LBB2_56
	movzbl	(%rax,%rsi), %edi
	cmpb	(%rsi,%rcx), %dil
	leaq	1(%rsi), %rsi
	je	.LBB2_30
.LBB2_32:
	movq	56(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 624(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 8(%rbp)
	movq	968(%rsp), %rax
	movq	%rax, 16(%rbp)
	movq	984(%rsp), %rax
	movq	%rax, 24(%rbp)
	movq	1000(%rsp), %rax
	movq	%rax, 32(%rbp)
	vmovups	432(%rsp), %ymm0
	vmovups	%ymm0, 632(%rsp)
	movl	%r12d, 40(%rbp)
	movl	1032(%rsp), %eax
	movl	%eax, 48(%rbp)
	movl	%r12d, 56(%rbp)
	movl	$1, 64(%rbp)
	vmovups	464(%rsp), %ymm0
	vmovups	%ymm0, 664(%rsp)
	movq	$0, 416(%rsp)
	movq	%r13, %rdi
	movq	%rbx, %rsi
	movq	1016(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$9
	.cfi_adjust_cfa_offset 8
	leaq	640(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB2_58
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 64(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	$1, 216(%rsp)
	movq	$0, 224(%rsp)
	leaq	216(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	216(%rsp), %xmm0
	vmovups	%xmm0, 176(%rsp)
	movq	$0, 192(%rsp)
	movq	%r13, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 96(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 88(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 104(%rsp)
	movq	$12, 120(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rdx, 128(%rsp)
	movq	$1, 24(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 16(%rsp)
	movq	%rdx, 32(%rsp)
	movq	$13, 144(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 136(%rsp)
	movq	%rdx, 152(%rsp)
	movq	$1, 224(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 216(%rsp)
	movq	%rdx, 232(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	72(%rsp), %r10
	leaq	144(%rsp), %r11
	leaq	24(%rsp), %r15
	leaq	184(%rsp), %r12
	leaq	120(%rsp), %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	592(%rsp), %rdi
	leaq	96(%rsp), %r9
	movl	$116, %esi
	movl	$68, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	$977
	.cfi_adjust_cfa_offset 8
	leaq	static_string_c07f9321ecc43ab0(%rip), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	616(%rsp), %eax
	vmovups	584(%rsp), %ymm0
	jmp	.LBB2_34
.LBB2_56:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 384(%rsp)
	vmovdqu	%ymm0, 352(%rsp)
	vmovdqu	%ymm0, 320(%rsp)
	vmovdqu	%ymm0, 288(%rsp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 25(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 624(%rsp)
	movb	$0, 16(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 8(%rbp)
	movb	$0, 17(%rsp)
	movq	968(%rsp), %rax
	movq	%rax, 16(%rbp)
	movb	$0, 18(%rsp)
	movq	984(%rsp), %rax
	movq	%rax, 24(%rbp)
	vbroadcastsd	.LCPI2_2(%rip), %ymm0
	vmovups	%ymm0, 216(%rsp)
	movb	$0, 19(%rsp)
	movq	1000(%rsp), %rax
	movq	%rax, 32(%rbp)
	vmovups	432(%rsp), %ymm0
	vmovups	%ymm0, 632(%rsp)
	movb	$0, 20(%rsp)
	movl	%r12d, 40(%rbp)
	movb	$0, 21(%rsp)
	movl	1032(%rsp), %eax
	movl	%eax, 48(%rbp)
	movb	$0, 22(%rsp)
	movl	%r12d, 56(%rbp)
	vmovaps	.LCPI2_3(%rip), %ymm0
	vmovups	%ymm0, 248(%rsp)
	movb	$0, 23(%rsp)
	movl	$1, 64(%rbp)
	vmovups	464(%rsp), %ymm0
	vmovups	%ymm0, 664(%rsp)
	movq	$4, 280(%rsp)
	movb	$0, 24(%rsp)
	leaq	624(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	%r15, 144(%rsp)
	leaq	16(%rsp), %r15
	movq	%r15, 152(%rsp)
	movq	$8, 160(%rsp)
	movl	$0, 168(%rsp)
	leaq	136(%rsp), %r12
	movq	%r12, 208(%rsp)
	movq	$0, 424(%rsp)
	leaq	208(%rsp), %rax
	movq	%r13, %rdi
	movq	%rbx, %rsi
	movq	1016(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$256, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$9
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB2_58
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 64(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	$1, 216(%rsp)
	movq	$0, 224(%rsp)
	leaq	216(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	216(%rsp), %xmm0
	vmovups	%xmm0, 176(%rsp)
	movq	$0, 192(%rsp)
	movq	%r13, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 96(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 88(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 104(%rsp)
	movq	$12, 120(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rdx, 128(%rsp)
	movq	$1, 24(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 16(%rsp)
	movq	%rdx, 32(%rsp)
	movq	$13, 144(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 136(%rsp)
	movq	%rdx, 152(%rsp)
	movq	$1, 224(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 216(%rsp)
	movq	%rdx, 232(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	72(%rsp), %r10
	leaq	184(%rsp), %r11
	leaq	120(%rsp), %rbp
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	552(%rsp), %rdi
	leaq	96(%rsp), %r9
	movl	$116, %esi
	movl	$68, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	$977
	.cfi_adjust_cfa_offset 8
	leaq	static_string_c07f9321ecc43ab0(%rip), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	576(%rsp), %eax
	vmovups	544(%rsp), %ymm0
.LBB2_34:
	movq	1040(%rsp), %rcx
	vmovups	%ymm0, (%rcx)
	movb	%al, 32(%rcx)
	movabsq	$4611686018427387904, %rbx
	testq	%rbx, 232(%rsp)
	je	.LBB2_37
	movq	216(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_37
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_37:
	testq	%rbx, 152(%rsp)
	movq	8(%rsp), %rbp
	je	.LBB2_40
	movq	136(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_40
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_40:
	testq	%rbx, 32(%rsp)
	movq	48(%rsp), %r15
	movl	4(%rsp), %ebx
	je	.LBB2_43
	movq	16(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_43
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_43:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 128(%rsp)
	je	.LBB2_46
	movq	112(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_46
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_46:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 104(%rsp)
	je	.LBB2_49
	movq	88(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_49
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_49:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 192(%rsp)
	je	.LBB2_52
	movq	176(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_52
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_52:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 80(%rsp)
	je	.LBB2_55
	movq	64(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB2_55
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB2_55:
	movb	$1, %r12b
	testb	$1, %bl
	je	.LBB2_61
.LBB2_60:
	movq	%r13, %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
.LBB2_61:
	movq	200(%rsp), %rdi
.LBB2_62:
	vzeroupper
	callq	AsyncRT_DeviceFunction_release@PLT
.LBB2_63:
	movq	1000(%rsp), %rax
	movq	%rax, 72(%r14)
	movq	984(%rsp), %rax
	movq	%rax, 56(%r14)
	movq	968(%rsp), %rax
	movq	%rax, 40(%r14)
	movq	%rbp, 24(%r14)
	movq	56(%rsp), %rax
	movq	%rax, 8(%r14)
	movb	%r12b, (%r14)
	movq	1008(%rsp), %rax
	movq	%rax, 80(%r14)
	movq	992(%rsp), %rax
	movq	%rax, 64(%r14)
	movq	976(%rsp), %rax
	movq	%rax, 48(%r14)
	movq	960(%rsp), %rax
	movq	%rax, 32(%r14)
	movq	%r15, 16(%r14)
	movq	%r14, %rax
	addq	$904, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB2_58:
	.cfi_def_cfa_offset 960
	xorl	%r12d, %r12d
	movq	48(%rsp), %r15
	movq	8(%rsp), %rbp
	movl	4(%rsp), %ebx
	testb	$1, %bl
	je	.LBB2_61
	jmp	.LBB2_60
.Lfunc_end2:
	.size	"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end2-"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI3_0:
	.quad	8
	.quad	8
	.quad	4
	.quad	4
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI3_1:
	.long	0xc9712060
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI3_2:
	.quad	0x412e848000000000
	.text
	.prefalign	4, .Lfunc_end3, nop
	.type	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])",@function
"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$5608, %rsp
	.cfi_def_cfa_offset 5664
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%r9d, 780(%rsp)
	movq	%r8, 552(%rsp)
	movq	%rcx, %rbp
	movq	%rdx, %r12
	movq	%rsi, %rbx
	movabsq	$2305843009213693952, %r14
	movl	$5, %ecx
	movq	%rdi, 248(%rsp)
	movq	%rdx, %rsi
	movq	%rbp, %rdx
	callq	"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, %r15
	movq	%rdx, 392(%rsp)
	movq	%rcx, %r13
	movl	$3, %ecx
	movq	%rbx, %rdi
	movq	%r12, 304(%rsp)
	movq	%r12, %rsi
	movq	%rbp, 760(%rsp)
	movq	%rbp, %rdx
	callq	"knn_index_layout_main::_values(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 56(%rsp)
	movq	%rdx, 384(%rsp)
	movq	%rcx, 64(%rsp)
	cmpq	$8, %rbx
	movl	$8, %eax
	cmovlq	%rbx, %rax
	xorl	%ecx, %ecx
	testq	%rbx, %rbx
	cmovgq	%rbx, %rcx
	movq	%rcx, 840(%rsp)
	movl	$1, %ecx
	movq	%rax, 560(%rsp)
	cmovneq	%rax, %rcx
	movq	%rcx, 144(%rsp)
	leaq	static_string_263b3a2b28ad4c61(%rip), %rax
	movq	%rax, 584(%rsp)
	movq	$4, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 256(%rsp)
	leaq	584(%rsp), %rbp
	movl	$5, %esi
	movq	%rbp, %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	600(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB3_2
	movq	592(%rsp), %rcx
	jmp	.LBB3_3
.LBB3_2:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB3_3:
	movb	$0, (%rax,%rcx)
	movq	600(%rsp), %rax
	movq	%rax, %rcx
	orq	%r14, %rcx
	movq	%rcx, 600(%rsp)
	testq	%rax, %rax
	js	.LBB3_5
	movq	584(%rsp), %rbp
.LBB3_5:
	movq	%r15, 8(%rsp)
	leaq	256(%rsp), %rdi
	movq	%rbp, %rsi
	xorl	%edx, %edx
	callq	AsyncRT_DeviceContext_create@PLT
	movq	%rax, %rbp
	testb	$64, 607(%rsp)
	je	.LBB3_8
	movq	584(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_8
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_8:
	movq	5672(%rsp), %r15
	leaq	static_string_2d06800538d394c2(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$4611686018427387904, %r12
	movq	$0, 1944(%rsp)
	movq	%r14, 1952(%rsp)
	testq	%rbp, %rbp
	je	.LBB3_17
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	5368(%rsp), %rdi
	leaq	1944(%rsp), %rdx
	movl	$3825, %ecx
	movl	$17, %r8d
	movq	%rbp, %rsi
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5400(%rsp), %eax
	vmovups	5368(%rsp), %ymm0
	movzbl	5360(%rsp), %ebp
	vmovups	%ymm0, (%r15)
	movb	%al, 32(%r15)
	movq	%r12, %r14
	testq	%r12, 1952(%rsp)
	je	.LBB3_12
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_12
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_12:
	testb	$1, %bpl
	movq	8(%rsp), %r15
	movq	248(%rsp), %r12
	je	.LBB3_18
	cmpq	$0, 64(%rsp)
	jle	.LBB3_15
	movq	56(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_15:
	movb	$1, %al
	testq	%r13, %r13
	jle	.LBB3_37
	movq	%r15, %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB3_36
.LBB3_17:
	movq	%r12, %r14
	movq	8(%rsp), %r15
	movq	248(%rsp), %r12
.LBB3_18:
	movq	256(%rsp), %rbp
	leaq	4720(%rsp), %rdi
	movq	%rbp, %rsi
	movl	$1, %edx
	movq	%r15, %rcx
	movq	392(%rsp), %r8
	movq	%r13, %r9
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])"@PLT
	movq	4768(%rsp), %rsi
	movq	4776(%rsp), %rdx
	movzbl	4720(%rsp), %eax
	movzbl	4760(%rsp), %ecx
	vmovups	4728(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	jne	.LBB3_22
	cmpq	$0, 64(%rsp)
	jle	.LBB3_21
	movq	56(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_21:
	testq	%r13, %r13
	movq	5672(%rsp), %rbx
	jg	.LBB3_30
	jmp	.LBB3_32
.LBB3_22:
	movq	%rsi, 544(%rsp)
	movq	%rbx, 232(%rsp)
	movq	%rdx, 120(%rsp)
	movq	%r13, 40(%rsp)
	movb	$1, %al
	movzbl	%al, %ebx
	leaq	4656(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%ebx, %edx
	movq	56(%rsp), %rcx
	movq	384(%rsp), %r8
	movq	64(%rsp), %r13
	movq	%r13, %r9
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])"@PLT
	movq	4704(%rsp), %rsi
	movq	4712(%rsp), %rdx
	movzbl	4656(%rsp), %eax
	movzbl	4696(%rsp), %ecx
	vmovups	4664(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	jne	.LBB3_26
	movq	120(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	testq	%r13, %r13
	jle	.LBB3_25
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_25:
	cmpq	$0, 40(%rsp)
	movq	5672(%rsp), %rbx
	jg	.LBB3_30
	jmp	.LBB3_32
.LBB3_26:
	movq	%rsi, 536(%rsp)
	movq	%rdx, 136(%rsp)
	movq	304(%rsp), %r13
	imulq	232(%rsp), %r13
	leaq	4592(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%ebx, %edx
	movq	%r13, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4640(%rsp), %rsi
	movq	4648(%rsp), %rdx
	movzbl	4592(%rsp), %eax
	movzbl	4632(%rsp), %ecx
	vmovups	4600(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	jne	.LBB3_38
	movq	136(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	movq	40(%rsp), %rbx
	jle	.LBB3_29
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_29:
	testq	%rbx, %rbx
	movq	5672(%rsp), %rbx
	jle	.LBB3_32
.LBB3_30:
	movq	%r15, %rdi
.LBB3_31:
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_32:
	movzbl	192(%rsp), %edx
.LBB3_33:
	movq	160(%rsp), %rax
	movq	%rax, (%rbx)
	vmovups	168(%rsp), %xmm0
	vmovups	%xmm0, 8(%rbx)
	movb	%dl, 32(%rbx)
	cmpb	$1, %dl
	jne	.LBB3_35
	movq	184(%rsp), %rax
	movq	%rax, 24(%rbx)
.LBB3_35:
	movq	%rbp, %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
.LBB3_36:
	movb	$1, %al
.LBB3_37:
	addq	$5608, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB3_38:
	.cfi_def_cfa_offset 5664
	movq	%rsi, 752(%rsp)
	movq	%r13, 832(%rsp)
	movq	%rdx, 128(%rsp)
	leaq	4528(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%ebx, %edx
	movq	%r12, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4576(%rsp), %rdx
	movq	4584(%rsp), %rsi
	movzbl	4528(%rsp), %eax
	movzbl	4568(%rsp), %ecx
	vmovups	4536(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	movq	40(%rsp), %r13
	je	.LBB3_43
	movl	%ebx, %r15d
	movq	%rsi, 24(%rsp)
	movq	%rdx, 360(%rsp)
	leaq	4464(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%ebx, %edx
	movq	232(%rsp), %rbx
	movq	%rbx, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4512(%rsp), %rsi
	movq	4520(%rsp), %rdx
	movzbl	4464(%rsp), %eax
	movzbl	4504(%rsp), %ecx
	vmovups	4472(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	je	.LBB3_42
	movq	%rsi, 352(%rsp)
	movq	%rdx, 32(%rsp)
	imulq	%r12, %rbx
	leaq	4400(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, %edx
	movq	%rbx, 528(%rsp)
	movq	%rbx, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4448(%rsp), %rbx
	movq	4456(%rsp), %rdx
	movzbl	4400(%rsp), %eax
	movzbl	4440(%rsp), %ecx
	vmovups	4408(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	jne	.LBB3_47
	movq	32(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_42:
	movq	24(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_43:
	movq	128(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_45
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_45:
	testq	%r13, %r13
.LBB3_46:
	movq	5672(%rsp), %rbx
	movq	8(%rsp), %rdi
	jg	.LBB3_31
	jmp	.LBB3_32
.LBB3_47:
	movq	%rdx, 16(%rsp)
	movq	560(%rsp), %r13
	imulq	%r12, %r13
	leaq	4336(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, %edx
	movq	%r13, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4384(%rsp), %rsi
	movq	4392(%rsp), %rdx
	movzbl	4336(%rsp), %eax
	movzbl	4376(%rsp), %ecx
	vmovups	4344(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	je	.LBB3_110
	movq	%rbx, 296(%rsp)
	movq	%rsi, 376(%rsp)
	movq	%rdx, 72(%rsp)
	leaq	4272(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, %edx
	movq	%r13, 520(%rsp)
	movq	%r13, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32"@PLT
	movq	4320(%rsp), %rbx
	movq	4328(%rsp), %rdx
	movzbl	4272(%rsp), %eax
	movzbl	4312(%rsp), %ecx
	vmovups	4280(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	jne	.LBB3_52
	movq	72(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	movq	40(%rsp), %rbx
	jle	.LBB3_51
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_51:
	testq	%rbx, %rbx
	jmp	.LBB3_46
.LBB3_52:
	movq	%rdx, 48(%rsp)
	movq	528(%rsp), %rax
	leaq	(%rax,%rax), %rcx
	leaq	4208(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, %edx
	movq	%rcx, %r13
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	4256(%rsp), %rsi
	movq	4264(%rsp), %rdx
	movzbl	4208(%rsp), %eax
	movzbl	4248(%rsp), %ecx
	vmovups	4216(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	je	.LBB3_109
	movq	%rsi, 480(%rsp)
	movq	%rdx, 80(%rsp)
	leaq	4144(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, %edx
	movq	%r13, %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32"@PLT
	movq	4192(%rsp), %rsi
	movq	4200(%rsp), %rdx
	movzbl	4144(%rsp), %eax
	movzbl	4184(%rsp), %ecx
	vmovups	4152(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	je	.LBB3_108
	movq	%rsi, 472(%rsp)
	movq	%rdx, 88(%rsp)
	leaq	4080(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r15d, 156(%rsp)
	movl	%r15d, %edx
	movq	520(%rsp), %rcx
	vzeroupper
	callq	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32"@PLT
	movq	4128(%rsp), %r15
	movq	4136(%rsp), %r13
	movzbl	4080(%rsp), %eax
	movzbl	4120(%rsp), %ecx
	vmovups	4088(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%cl, 192(%rsp)
	cmpb	$1, %al
	je	.LBB3_107
	movq	%r15, 744(%rsp)
	movq	%rbx, 368(%rsp)
	leaq	160(%rsp), %rax
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	movl	$1, %esi
	movl	$1, %edx
	movl	$139, %ecx
	movl	$46, %r8d
	movq	%r12, %rdi
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$50
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testb	$1, %al
	jne	.LBB3_106
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
	movq	$0, 584(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %rbx
	leaq	1936(%rsp), %rdx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%rdx, %r15
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	1952(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	testq	%rax, %rsi
	movq	%r13, 104(%rsp)
	jne	.LBB3_64
	testq	%rsi, %rsi
	js	.LBB3_59
	movq	1944(%rsp), %rsi
	jmp	.LBB3_60
.LBB3_59:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB3_60:
	incq	%rsi
	leaq	1936(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	1952(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB3_62
	movq	1944(%rsp), %rcx
	jmp	.LBB3_63
.LBB3_62:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB3_63:
	movb	$0, (%rax,%rcx)
	movq	1952(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 1952(%rsp)
.LBB3_64:
	testq	%rsi, %rsi
	movq	%r14, %r12
	js	.LBB3_66
	movq	1936(%rsp), %r15
.LBB3_66:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_91afa7b607590f5d(%rip), %rdx
	leaq	static_string_510d7aabfd7afaf5(%rip), %rcx
	leaq	static_string_ba51a876e4c062cc(%rip), %r8
	leaq	592(%rsp), %rdi
	movl	$7729, %r9d
	movq	%rbp, 8(%rsp)
	movq	%rbp, %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	testq	%r12, 1952(%rsp)
	movabsq	$2305843009213693952, %r14
	je	.LBB3_69
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_69
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %rbp
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%rbp, %rax
.LBB3_69:
	movq	%rbx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movq	%r14, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_75
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	5320(%rsp), %rdi
	leaq	1944(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5352(%rsp), %eax
	vmovups	5320(%rsp), %ymm0
	movzbl	5312(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	testq	%r12, 1952(%rsp)
	je	.LBB3_73
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_73
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_73:
	testb	$1, %bpl
	je	.LBB3_75
	movq	(%rsp), %rbp
	movq	%rbp, %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB3_105
.LBB3_75:
	movq	584(%rsp), %r13
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"@PLT
	testb	$1, %al
	je	.LBB3_77
	movq	(%rsp), %rbp
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_release@PLT
	movq	%r13, %rdi
	jmp	.LBB3_104
.LBB3_77:
	movq	%r13, 240(%rsp)
	leaq	5575(%rsp), %r14
	leaq	5568(%rsp), %r12
	testq	%r12, %r12
	movq	%r12, %rax
	cmovsq	%r14, %rax
	setns	%cl
	sarq	$3, %rax
	movq	%rax, %rdx
	negq	%rdx
	shlq	$3, %rdx
	addq	%r12, %rdx
	setne	%dl
	andb	%cl, %dl
	movzbl	%dl, %ebp
	addq	%rax, %rbp
	shlq	$3, %rbp
	leaq	24(%rbp), %r15
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rdi
	movq	(%rsp), %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 584(%rsp)
	movq	$0, 600(%rsp)
	movq	$5, 1944(%rsp)
	leaq	static_string_561d9efdd15f277f(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	leaq	584(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	movq	%rdi, %rbx
	movq	%rsi, %r13
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	testb	$1, %al
	je	.LBB3_80
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 2064(%rsp)
	vmovups	%ymm0, 2032(%rsp)
	vmovups	%ymm0, 2000(%rsp)
	vmovups	%ymm0, 1968(%rsp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 324(%rsp)
	movq	360(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 584(%rsp)
	movb	$0, 320(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 8(%rbp)
	leaq	8(%rbp), %rax
	movq	%rax, 592(%rsp)
	movb	$0, 321(%rsp)
	movq	304(%rsp), %rax
	movl	%eax, 16(%rbp)
	leaq	16(%rbp), %rax
	movq	%rax, 600(%rsp)
	movb	$0, 322(%rsp)
	movl	$0, 24(%rbp)
	movq	%r15, 608(%rsp)
	vmovaps	.LCPI3_0(%rip), %ymm0
	vmovups	%ymm0, 1936(%rsp)
	movb	$0, 323(%rsp)
	movq	%rbx, 256(%rsp)
	movq	%r13, 264(%rsp)
	leaq	320(%rsp), %rbp
	movq	%rbp, 272(%rsp)
	movq	$8, 280(%rsp)
	movl	$0, 288(%rsp)
	leaq	256(%rsp), %rax
	movq	%rax, 768(%rsp)
	movq	$0, 1928(%rsp)
	leaq	768(%rsp), %rax
	movq	(%rsp), %rdi
	movq	240(%rsp), %rsi
	movq	248(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB3_113
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 400(%rsp)
	movq	%rdx, 408(%rsp)
	movq	%rcx, 416(%rsp)
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rbx
	movq	%rbx, %rdi
	movq	(%rsp), %r14
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 488(%rsp)
	movq	$0, 504(%rsp)
	movq	%r14, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 432(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 424(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 440(%rsp)
	movq	$12, 456(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 448(%rsp)
	movq	%rdx, 464(%rsp)
	movq	$1, 328(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 320(%rsp)
	movq	%rdx, 336(%rsp)
	movq	$13, 264(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movq	%rdx, 272(%rsp)
	movq	$1, 1944(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	%rdx, 1952(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	408(%rsp), %r10
	leaq	496(%rsp), %r11
	leaq	456(%rsp), %r14
	leaq	static_string_5f81310f9d7e8c41(%rip), %r15
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	5496(%rsp), %rdi
	leaq	432(%rsp), %r9
	movl	$139, %esi
	movl	$46, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	leaq	280(%rsp), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	$475
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	5520(%rsp), %eax
	vmovups	5488(%rsp), %ymm0
	jmp	.LBB3_82
.LBB3_80:
	movq	360(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 584(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 8(%rbp)
	leaq	8(%rbp), %rax
	movq	%rax, 592(%rsp)
	movq	304(%rsp), %rax
	movl	%eax, 16(%rbp)
	leaq	16(%rbp), %rax
	movq	%rax, 600(%rsp)
	movl	$0, 24(%rbp)
	movq	%r15, 608(%rsp)
	movq	$0, 1920(%rsp)
	movq	(%rsp), %rdi
	movq	240(%rsp), %rsi
	movq	248(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB3_113
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 400(%rsp)
	movq	%rdx, 408(%rsp)
	movq	%rcx, 416(%rsp)
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rbx
	movq	%rbx, %rdi
	movq	(%rsp), %r14
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 488(%rsp)
	movq	$0, 504(%rsp)
	movq	%r14, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 432(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 424(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 440(%rsp)
	movq	$12, 456(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 448(%rsp)
	movq	%rdx, 464(%rsp)
	movq	$1, 328(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 320(%rsp)
	movq	%rdx, 336(%rsp)
	movq	$13, 264(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movq	%rdx, 272(%rsp)
	movq	$1, 1944(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	%rdx, 1952(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	408(%rsp), %r10
	leaq	328(%rsp), %r11
	leaq	496(%rsp), %r14
	leaq	456(%rsp), %r15
	leaq	static_string_5f81310f9d7e8c41(%rip), %r12
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	5536(%rsp), %rdi
	leaq	432(%rsp), %r9
	movl	$139, %esi
	movl	$46, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	leaq	280(%rsp), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$475
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	5560(%rsp), %eax
	vmovups	5528(%rsp), %ymm0
.LBB3_82:
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_85
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_85
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_85:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 272(%rsp)
	je	.LBB3_88
	movq	256(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_88
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_88:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 336(%rsp)
	je	.LBB3_91
	movq	320(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_91
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_91:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 464(%rsp)
	je	.LBB3_94
	movq	448(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_94
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_94:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 440(%rsp)
	je	.LBB3_97
	movq	424(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_97
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_97:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 504(%rsp)
	je	.LBB3_100
	movq	488(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_100
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_100:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 416(%rsp)
	je	.LBB3_103
	movq	400(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_103
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_103:
	movq	(%rsp), %rbp
	movq	%rbp, %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	movq	240(%rsp), %rdi
.LBB3_104:
	callq	AsyncRT_DeviceFunction_release@PLT
.LBB3_105:
	movq	104(%rsp), %r13
.LBB3_106:
	movq	%r13, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_107:
	movq	88(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_108:
	movq	80(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_109:
	movq	48(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
.LBB3_110:
	movq	16(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_112
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_112:
	cmpq	$0, 40(%rsp)
	jmp	.LBB3_46
.LBB3_113:
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_release@PLT
	movq	240(%rsp), %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	movl	$1, %esi
	movl	$1, %edx
	movl	$141, %ecx
	movl	$46, %r8d
	movq	232(%rsp), %rdi
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testb	$1, %al
	jne	.LBB3_160
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_retain@PLT
	movq	$0, 584(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %rdi
	leaq	1936(%rsp), %r15
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"@PLT
	movq	1952(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	testq	%rax, %rsi
	jne	.LBB3_122
	testq	%rsi, %rsi
	js	.LBB3_117
	movq	1944(%rsp), %rsi
	jmp	.LBB3_118
.LBB3_117:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB3_118:
	incq	%rsi
	leaq	1936(%rsp), %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	1952(%rsp), %rcx
	testq	%rcx, %rcx
	js	.LBB3_120
	movq	1944(%rsp), %rcx
	jmp	.LBB3_121
.LBB3_120:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB3_121:
	movb	$0, (%rax,%rcx)
	movq	1952(%rsp), %rsi
	movabsq	$2305843009213693952, %rax
	orq	%rax, %rsi
	movq	%rsi, 1952(%rsp)
.LBB3_122:
	testq	%rsi, %rsi
	js	.LBB3_124
	movq	1936(%rsp), %r15
.LBB3_124:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_91afa7b607590f5d(%rip), %rdx
	leaq	static_string_510d7aabfd7afaf5(%rip), %rcx
	leaq	static_string_ba51a876e4c062cc(%rip), %r8
	leaq	592(%rsp), %rdi
	movl	$7729, %r9d
	movq	8(%rsp), %rsi
	pushq	$3
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$-1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_loadFunction@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	movq	%rax, %rbp
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_127
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_127
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_127:
	leaq	static_string_2d06800538d394c2(%rip), %rax
	movq	%rax, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	testq	%rbp, %rbp
	je	.LBB3_133
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_f6c401c515dc2a68(%rip), %r9
	leaq	5272(%rsp), %rdi
	leaq	1944(%rsp), %rdx
	movl	$168, %ecx
	movl	$17, %r8d
	movq	%rbp, %rsi
	pushq	$49
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5304(%rsp), %eax
	vmovups	5272(%rsp), %ymm0
	movzbl	5264(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_131
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_131
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_131:
	testb	$1, %bpl
	je	.LBB3_133
	movq	(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	jmp	.LBB3_160
.LBB3_133:
	testq	%r12, %r12
	cmovnsq	%r12, %r14
	setns	%al
	sarq	$3, %r14
	movq	%r14, %rcx
	negq	%rcx
	shlq	$3, %rcx
	addq	%r12, %rcx
	setne	%cl
	movq	584(%rsp), %r13
	andb	%al, %cl
	movzbl	%cl, %ebp
	addq	%r14, %rbp
	shlq	$3, %rbp
	leaq	24(%rbp), %r14
	leaq	16(%rbp), %rbx
	leaq	8(%rbp), %r15
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rdi
	movq	(%rsp), %rsi
	vzeroupper
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 584(%rsp)
	movq	$0, 600(%rsp)
	movq	$5, 1944(%rsp)
	leaq	static_string_561d9efdd15f277f(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	leaq	584(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	testb	$1, %al
	je	.LBB3_136
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 2064(%rsp)
	vmovups	%ymm0, 2032(%rsp)
	vmovups	%ymm0, 2000(%rsp)
	vmovups	%ymm0, 1968(%rsp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 324(%rsp)
	movq	352(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 584(%rsp)
	movb	$0, 320(%rsp)
	movq	536(%rsp), %rax
	movq	%rax, 8(%rbp)
	movq	%r15, 592(%rsp)
	movb	$0, 321(%rsp)
	movq	304(%rsp), %rax
	movl	%eax, 16(%rbp)
	movq	%rbx, 600(%rsp)
	movb	$0, 322(%rsp)
	movl	$0, 24(%rbp)
	movq	%r14, 608(%rsp)
	vmovaps	.LCPI3_0(%rip), %ymm0
	vmovups	%ymm0, 1936(%rsp)
	movb	$0, 323(%rsp)
	leaq	584(%rsp), %rax
	movq	%rax, 256(%rsp)
	leaq	1936(%rsp), %rax
	movq	%rax, 264(%rsp)
	leaq	320(%rsp), %rbp
	movq	%rbp, 272(%rsp)
	movq	$8, 280(%rsp)
	movl	$0, 288(%rsp)
	leaq	256(%rsp), %rax
	movq	%rax, 768(%rsp)
	movq	$0, 1912(%rsp)
	leaq	768(%rsp), %rax
	movq	(%rsp), %rdi
	movq	%r13, %rsi
	movq	232(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB3_165
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 400(%rsp)
	movq	%rdx, 408(%rsp)
	movq	%rcx, 416(%rsp)
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rbx
	movq	%rbx, %rdi
	movq	(%rsp), %r14
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 488(%rsp)
	movq	$0, 504(%rsp)
	movq	%r14, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 432(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 424(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 440(%rsp)
	movq	$12, 456(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 448(%rsp)
	movq	%rdx, 464(%rsp)
	movq	$1, 328(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 320(%rsp)
	movq	%rdx, 336(%rsp)
	movq	$13, 264(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movq	%rdx, 272(%rsp)
	movq	$1, 1944(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	%rdx, 1952(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	408(%rsp), %r10
	leaq	496(%rsp), %r11
	leaq	456(%rsp), %r14
	leaq	static_string_5f81310f9d7e8c41(%rip), %r15
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	5416(%rsp), %rdi
	leaq	432(%rsp), %r9
	movl	$141, %esi
	movl	$46, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	leaq	280(%rsp), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	$475
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	5440(%rsp), %eax
	vmovups	5408(%rsp), %ymm0
	jmp	.LBB3_138
.LBB3_136:
	movq	352(%rsp), %rax
	movq	%rax, (%rbp)
	movq	%rbp, 584(%rsp)
	movq	536(%rsp), %rax
	movq	%rax, 8(%rbp)
	movq	%r15, 592(%rsp)
	movq	304(%rsp), %rax
	movl	%eax, 16(%rbp)
	movq	%rbx, 600(%rsp)
	movl	$0, 24(%rbp)
	movq	%r14, 608(%rsp)
	movq	$0, 1904(%rsp)
	movq	(%rsp), %rdi
	movq	%r13, %rsi
	movq	232(%rsp), %rdx
	movl	$1, %ecx
	movl	$1, %r8d
	movl	$128, %r9d
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	leaq	600(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$4
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	callq	AsyncRT_DeviceContext_enqueueFunctionDirect@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	testq	%rax, %rax
	je	.LBB3_165
	movq	%rax, %rdi
	callq	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"@PLT
	movq	%rax, 400(%rsp)
	movq	%rdx, 408(%rsp)
	movq	%rcx, 416(%rsp)
	movq	$1, 1936(%rsp)
	movq	$0, 1944(%rsp)
	leaq	1936(%rsp), %rbx
	movq	%rbx, %rdi
	movq	(%rsp), %r14
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_deviceApi@PLT
	vmovups	1936(%rsp), %xmm0
	vmovups	%xmm0, 488(%rsp)
	movq	$0, 504(%rsp)
	movq	%r14, %rdi
	callq	AsyncRT_DeviceContext_id@PLT
	movq	$17, 432(%rsp)
	leaq	static_string_aaccaef1399538c1(%rip), %rcx
	movq	%rcx, 424(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 440(%rsp)
	movq	$12, 456(%rsp)
	leaq	static_string_d8f96e4c39e045bb(%rip), %rcx
	movq	%rcx, 448(%rsp)
	movq	%rdx, 464(%rsp)
	movq	$1, 328(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rcx
	movq	%rcx, 320(%rsp)
	movq	%rdx, 336(%rsp)
	movq	$13, 264(%rsp)
	leaq	static_string_fe95cf738c304de4(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movq	%rdx, 272(%rsp)
	movq	$1, 1944(%rsp)
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	%rdx, 1952(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	408(%rsp), %r10
	leaq	328(%rsp), %r11
	leaq	496(%rsp), %r14
	leaq	456(%rsp), %r15
	leaq	static_string_5f81310f9d7e8c41(%rip), %r12
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	leaq	5456(%rsp), %rdi
	leaq	432(%rsp), %r9
	movl	$141, %esi
	movl	$46, %edx
	movl	$50, %r8d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	leaq	280(%rsp), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	$475
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	callq	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movzbl	5480(%rsp), %eax
	vmovups	5448(%rsp), %ymm0
.LBB3_138:
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_141
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_141
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_141:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 272(%rsp)
	je	.LBB3_144
	movq	256(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_144
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_144:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 336(%rsp)
	je	.LBB3_147
	movq	320(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_147
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_147:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 464(%rsp)
	je	.LBB3_150
	movq	448(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_150
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_150:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 440(%rsp)
	je	.LBB3_153
	movq	424(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_153
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_153:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 504(%rsp)
	je	.LBB3_156
	movq	488(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_156
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_156:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 416(%rsp)
	je	.LBB3_159
	movq	400(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_159
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_159:
	movq	(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_release@PLT
	movq	%r13, %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
.LBB3_160:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
.LBB3_161:
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
.LBB3_162:
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_164
.LBB3_163:
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_164:
	cmpq	$0, 40(%rsp)
	movq	(%rsp), %rbp
	jmp	.LBB3_46
.LBB3_165:
	movq	(%rsp), %rbp
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_release@PLT
	movq	%r13, %rdi
	callq	AsyncRT_DeviceFunction_release@PLT
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_170
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	leaq	5224(%rsp), %rdi
	leaq	1944(%rsp), %rdx
	movl	$143, %ecx
	movl	$24, %r8d
	movq	%rax, %rsi
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5256(%rsp), %eax
	vmovups	5224(%rsp), %ymm0
	movzbl	5216(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_169
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_169
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_169:
	testb	$1, %bpl
	jne	.LBB3_160
.LBB3_170:
	movq	5664(%rsp), %r10
	movq	%r10, %rax
	sarq	$63, %rax
	movq	528(%rsp), %r8
	movq	%r8, %rcx
	sarq	$63, %rcx
	movq	304(%rsp), %rdi
	movq	%rdi, %rdx
	sarq	$63, %rdx
	movq	520(%rsp), %r9
	movq	%r9, %rsi
	sarq	$63, %rsi
	andnq	%r10, %rax, %rax
	movq	%rax, 784(%rsp)
	andnq	%r8, %rcx, %rax
	movq	%rax, 848(%rsp)
	andnq	%rdi, %rdx, %rax
	movq	%rax, 792(%rsp)
	shlq	$2, 832(%rsp)
	andnq	%r9, %rsi, %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 880(%rsp)
	xorl	%esi, %esi
	movq	%rax, %rcx
	subq	$1, %rcx
	movl	$0, %edx
	movq	%rdx, 800(%rsp)
	cmovbq	%rsi, %rcx
	movq	%rcx, 856(%rsp)
	movl	$1, %ecx
	movq	%rax, 824(%rsp)
	cmovbq	%rax, %rcx
	movq	%rcx, 864(%rsp)
	movb	$1, %al
	movl	%eax, 572(%rsp)
	movl	$4, %eax
	movq	%rax, 200(%rsp)
	movl	$0, %eax
	movq	%rax, 224(%rsp)
	movl	$0, %r14d
	movl	$0, %eax
	movq	%rax, 216(%rsp)
	movl	$0, %eax
	movq	%rax, 808(%rsp)
	movl	$4, %eax
	movq	%rax, 208(%rsp)
	movl	$0, %eax
	movq	%rax, 112(%rsp)
	movl	$0, %eax
	movq	%rax, 512(%rsp)
	movl	$4, %eax
	movq	%rax, 96(%rsp)
.LBB3_171:
	movl	$3, %eax
	xorl	%ebx, %ebx
	movl	$4, %ecx
	movq	%rcx, 816(%rsp)
.LBB3_172:
	movq	%rax, 872(%rsp)
	movq	296(%rsp), %rdi
	movq	16(%rsp), %rsi
	vmovss	.LCPI3_1(%rip), %xmm0
	leaq	160(%rsp), %rdx
	vzeroupper
	callq	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32"@PLT
	testb	$1, %al
	jne	.LBB3_326
	movq	376(%rsp), %rdi
	movq	72(%rsp), %rsi
	vmovss	.LCPI3_1(%rip), %xmm0
	leaq	160(%rsp), %rdx
	callq	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32"@PLT
	testb	$1, %al
	jne	.LBB3_326
	movq	368(%rsp), %rdi
	movq	48(%rsp), %rsi
	movl	$-1, %edx
	leaq	160(%rsp), %rcx
	callq	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=ui32"@PLT
	testb	$1, %al
	jne	.LBB3_326
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_180
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$152, %ecx
	movl	$32, %r8d
	leaq	5176(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5208(%rsp), %eax
	vmovups	5176(%rsp), %ymm0
	movzbl	5168(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_179
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_179
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_179:
	testb	$1, %bpl
	jne	.LBB3_326
.LBB3_180:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	1720(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	304(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	552(%rsp), %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	336(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	272(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	296(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	88(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	416(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	96(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	440(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	216(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	848(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	240(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	648(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	240(%rsp)
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$128, %rsp
	.cfi_adjust_cfa_offset -128
	movq	1808(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	1792(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	1776(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	1760(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	1744(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	1728(%rsp), %rbx
	cmpb	$1, 1712(%rsp)
	je	.LBB3_290
	movq	1800(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	1784(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	1768(%rsp), %rax
	movq	%rax, 752(%rsp)
	movq	1752(%rsp), %rax
	movq	%rax, 536(%rsp)
	movq	1736(%rsp), %rax
	movq	%rax, 544(%rsp)
	movq	1720(%rsp), %r15
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_186
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$154, %ecx
	movl	$32, %r8d
	leaq	5128(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5160(%rsp), %eax
	vmovups	5128(%rsp), %ymm0
	movzbl	5120(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_185
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_185
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_185:
	testb	$1, %bpl
	jne	.LBB3_290
.LBB3_186:
	leaq	1416(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	%r15, %rcx
	movq	%rbx, %r8
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	1496(%rsp), %r13
	movq	1488(%rsp), %r12
	movq	1480(%rsp), %rax
	movq	%rax, 240(%rsp)
	movzbl	1472(%rsp), %eax
	movq	1464(%rsp), %rdx
	movq	1456(%rsp), %rsi
	movq	1448(%rsp), %rdi
	movq	1440(%rsp), %r8
	movq	1432(%rsp), %rbx
	movq	1424(%rsp), %rcx
	movzbl	1416(%rsp), %r9d
	movq	%r8, 160(%rsp)
	movq	%rdi, 168(%rsp)
	movq	%rsi, 176(%rsp)
	movq	%rdx, 184(%rsp)
	movb	%al, 192(%rsp)
	cmpb	$1, %r9b
	je	.LBB3_290
	movq	%r12, %rax
	sarq	$63, %rax
	andnq	%r12, %rax, %rax
	movq	%rax, %rdx
.LBB3_188:
	movq	%rdx, %rdi
	subq	$1, %rdi
	movl	$0, %esi
	cmovaeq	%rdi, %rsi
	testq	%rdx, %rdx
	je	.LBB3_191
	movq	%rax, %rbp
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rdi
	movq	%rdi, 256(%rsp)
	movabsq	$2305843009213693952, %rdi
	movq	%rdi, 272(%rsp)
	movq	$39, 592(%rsp)
	subq	%rdx, %rbp
	leaq	static_string_a0fcf35b7349c924(%rip), %rdx
	movq	%rdx, 584(%rsp)
	movq	%rdi, 600(%rsp)
	cmpq	%r12, %rbp
	jae	.LBB3_360
	movq	240(%rsp), %rdx
	vmovss	(%rdx,%rbp,4), %xmm0
	vucomiss	.LCPI3_1(%rip), %xmm0
	movq	%rsi, %rdx
	jne	.LBB3_188
	jp	.LBB3_188
	jmp	.LBB3_263
.LBB3_191:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	1336(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	%rbx, %r8
	movq	384(%rsp), %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	256(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	280(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	128(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	520(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	136(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	544(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	120(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	448(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	160(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$96, %rsp
	.cfi_adjust_cfa_offset -96
	movq	1408(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	1392(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	1376(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	1360(%rsp), %rbx
	movq	1344(%rsp), %rax
	movq	%rax, 16(%rsp)
	cmpb	$1, 1328(%rsp)
	je	.LBB3_310
	movq	1400(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	1384(%rsp), %rax
	movq	%rax, 480(%rsp)
	movq	1368(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	1352(%rsp), %r15
	movq	1336(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_197
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$160, %ecx
	movl	$32, %r8d
	leaq	5080(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5112(%rsp), %eax
	vmovups	5080(%rsp), %ymm0
	movzbl	5072(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_196
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_196
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_196:
	testb	$1, %bpl
	jne	.LBB3_310
.LBB3_197:
	leaq	1240(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	%r15, %rcx
	movq	%rbx, %r8
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	1320(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	1312(%rsp), %rax
	movq	%rax, 576(%rsp)
	movq	1304(%rsp), %rax
	movq	%rax, 344(%rsp)
	movzbl	1296(%rsp), %eax
	movq	1288(%rsp), %rcx
	movq	1280(%rsp), %rdx
	movq	1272(%rsp), %rsi
	movq	1264(%rsp), %rdi
	movq	1256(%rsp), %r8
	movq	%r8, 72(%rsp)
	movq	1248(%rsp), %r8
	movq	%r8, 376(%rsp)
	movzbl	1240(%rsp), %r8d
	movq	%rdi, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rcx, 184(%rsp)
	movb	%al, 192(%rsp)
	cmpb	$1, %r8b
	je	.LBB3_321
	movq	(%rsp), %rdi
	movq	744(%rsp), %rsi
	movq	48(%rsp), %rdx
	callq	AsyncRT_DeviceContext_DtoH_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_203
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$5241, %ecx
	movl	$17, %r8d
	leaq	5032(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5064(%rsp), %eax
	vmovups	5032(%rsp), %ymm0
	movzbl	5024(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_202
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_202
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_202:
	testb	$1, %bpl
	jne	.LBB3_319
.LBB3_203:
	movq	(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_208
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$163, %ecx
	movl	$32, %r8d
	leaq	4984(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	5016(%rsp), %eax
	vmovups	4984(%rsp), %ymm0
	movzbl	4976(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_207
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_207
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_207:
	testb	$1, %bpl
	jne	.LBB3_319
.LBB3_208:
	cmpq	$4, 816(%rsp)
	sete	%al
	andb	572(%rsp), %al
	cmpb	$1, %al
	jne	.LBB3_215
	cmpq	$0, 216(%rsp)
	jle	.LBB3_211
	movq	208(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_211:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_213
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_213:
	testq	%r13, %r13
	je	.LBB3_240
	leaq	(,%r13,4), %rdi
	movl	$4, %esi
	vzeroupper
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	%rax, %rdi
	jmp	.LBB3_241
.LBB3_215:
	movq	$8, 1944(%rsp)
	leaq	static_string_77c62120cb28fcc2(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	movq	96(%rsp), %rdi
	movq	512(%rsp), %rsi
	movq	112(%rsp), %rdx
	movq	240(%rsp), %rcx
	movq	%r12, %r8
	movq	%r13, %r9
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	1944(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movl	%eax, %ebp
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_218
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_218
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_218:
	testq	%r13, %r13
	jle	.LBB3_220
	movq	240(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_220:
	testb	$1, %bpl
	jne	.LBB3_323
	movq	$17, 1944(%rsp)
	leaq	static_string_96fcc284d4fc120e(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	movq	208(%rsp), %rdi
	movq	808(%rsp), %rsi
	movq	216(%rsp), %rdx
	movq	344(%rsp), %rcx
	movq	576(%rsp), %r8
	movq	312(%rsp), %r9
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	1944(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movl	%eax, %ebp
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_224
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_224
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_224:
	testb	$1, %bpl
	jne	.LBB3_323
.LBB3_225:
	cmpq	$0, 520(%rsp)
	jle	.LBB3_251
	movq	864(%rsp), %rax
	xorl	%ebp, %ebp
	jmp	.LBB3_229
.LBB3_227:
	movq	%rbp, %r8
	movq	232(%rsp), %r9
	xorq	%r9, %r8
	subl	%eax, %ebp
	sarq	$63, %r8
	andl	%edi, %r8d
	addl	%ebp, %r8d
	testq	%r9, %r9
	cmovel	%edx, %r8d
	cmpl	%r8d, %esi
	jne	.LBB3_297
.LBB3_228:
	leaq	1(%rcx), %rax
	movq	%rcx, %rbp
	cmpq	%rax, 880(%rsp)
	je	.LBB3_251
.LBB3_229:
	movq	744(%rsp), %rcx
	movl	(%rcx,%rbp,4), %esi
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movabsq	$2305843009213693952, %rdx
	movq	%rdx, 272(%rsp)
	movq	$39, 592(%rsp)
	movq	%rax, %rcx
	leaq	static_string_a0fcf35b7349c924(%rip), %rax
	movq	%rax, 584(%rsp)
	movq	%rdx, 600(%rsp)
	cmpq	%r14, %rbp
	jae	.LBB3_384
	cmpl	232(%rsp), %esi
	jae	.LBB3_276
	movq	200(%rsp), %rax
	cmpl	(%rax,%rbp,4), %esi
	jne	.LBB3_276
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, 256(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 272(%rsp)
	movq	$39, 592(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rdx
	movq	%rdx, 584(%rsp)
	movq	%rax, 600(%rsp)
	cmpq	576(%rsp), %rbp
	jae	.LBB3_386
	movq	344(%rsp), %rax
	vmovss	(%rax,%rbp,4), %xmm0
	vucomiss	.LCPI3_1(%rip), %xmm0
	jne	.LBB3_234
	jnp	.LBB3_276
.LBB3_234:
	cmpq	$2, 760(%rsp)
	jne	.LBB3_228
	movq	%rbp, %rax
	orq	144(%rsp), %rax
	shrq	$32, %rax
	je	.LBB3_237
	movq	%rbp, %rax
	cqto
	idivq	144(%rsp)
	jmp	.LBB3_238
.LBB3_237:
	movl	%ebp, %eax
	xorl	%edx, %edx
	divl	144(%rsp)
.LBB3_238:
	movq	560(%rsp), %rdi
	imulq	%rdi, %rax
	xorl	%edx, %edx
	cmpq	%rax, %rbp
	jne	.LBB3_227
	xorl	%edi, %edi
	jmp	.LBB3_227
.LBB3_240:
	movl	$4, %edi
.LBB3_241:
	xorl	%esi, %esi
	movq	%r13, %rdx
	movq	240(%rsp), %rcx
	movq	%r12, %r8
	vzeroupper
	callq	"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"@PLT
	movq	%rax, 96(%rsp)
	movq	%rdx, 512(%rsp)
	movq	%rcx, 112(%rsp)
	testq	%r13, %r13
	jle	.LBB3_243
	movq	240(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_243:
	cmpq	$0, 312(%rsp)
	je	.LBB3_245
	movq	312(%rsp), %rax
	leaq	(,%rax,4), %rdi
	movl	$4, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	%rax, %rdi
	jmp	.LBB3_246
.LBB3_245:
	movl	$4, %edi
.LBB3_246:
	xorl	%esi, %esi
	movq	312(%rsp), %rdx
	movq	344(%rsp), %rcx
	movq	576(%rsp), %r8
	callq	"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"@PLT
	movq	%rax, 208(%rsp)
	movq	%rdx, 808(%rsp)
	movq	%rcx, 216(%rsp)
	cmpq	$0, 520(%rsp)
	jle	.LBB3_251
	movq	856(%rsp), %rax
	movq	824(%rsp), %rbp
	jmp	.LBB3_249
.LBB3_248:
	movq	200(%rsp), %rax
	movl	%ebx, (%rax,%r14,4)
	incq	%r14
	movq	%rbp, %rax
	addq	$-1, %rax
	jae	.LBB3_225
.LBB3_249:
	movq	824(%rsp), %rcx
	subq	%rbp, %rcx
	movq	%rax, %rbp
	movq	744(%rsp), %rax
	movl	(%rax,%rcx,4), %ebx
	cmpq	224(%rsp), %r14
	jl	.LBB3_248
	xorl	%eax, %eax
	movq	224(%rsp), %rdx
	testq	%rdx, %rdx
	sete	%al
	leaq	(%rax,%rdx,2), %rcx
	movq	200(%rsp), %rdi
	movq	%r14, %rsi
	callq	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]"@PLT
	movq	%rax, 200(%rsp)
	movq	%rdx, %r14
	movq	%rcx, 224(%rsp)
	jmp	.LBB3_248
.LBB3_251:
	cmpq	$0, 312(%rsp)
	jle	.LBB3_253
	movq	344(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_253:
	movl	$4, %ebx
	movq	872(%rsp), %rcx
	subq	%rcx, %rbx
	movq	%rcx, %rax
	movq	%rcx, 816(%rsp)
	subq	$1, %rax
	jae	.LBB3_172
	movl	$0, 572(%rsp)
	testb	$1, 800(%rsp)
	movb	$1, %al
	movq	%rax, 800(%rsp)
	je	.LBB3_171
	cmpq	$0, 224(%rsp)
	jle	.LBB3_257
	movq	200(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_257:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_259
	movq	208(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_259:
	leaq	1152(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	544(%rsp), %rcx
	movq	120(%rsp), %r8
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	1232(%rsp), %rbp
	movq	1224(%rsp), %r8
	movq	1216(%rsp), %rbx
	movzbl	1208(%rsp), %eax
	movq	1200(%rsp), %rcx
	movq	1192(%rsp), %rdx
	movq	1184(%rsp), %rsi
	movq	1176(%rsp), %rdi
	movq	1168(%rsp), %r9
	movq	%r9, 144(%rsp)
	movq	1160(%rsp), %r15
	movzbl	1152(%rsp), %r9d
	movq	%rdi, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rcx, 184(%rsp)
	movb	%al, 192(%rsp)
	testb	%r9b, %r9b
	je	.LBB3_332
	cmpq	$0, 112(%rsp)
	jle	.LBB3_262
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_262:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	144(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jg	.LBB3_163
	jmp	.LBB3_164
.LBB3_263:
	testq	%r13, %r13
	jle	.LBB3_265
	movq	240(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_265:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_267
	movq	200(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_267:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_269
	movq	208(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_269:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_271
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_271:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	%rbx, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_273
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_273:
	cmpq	$0, 40(%rsp)
	jle	.LBB3_275
	movq	8(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_275:
	movq	$24, 168(%rsp)
	leaq	static_string_894406302c64c97c(%rip), %rax
	jmp	.LBB3_289
.LBB3_276:
	cmpq	$0, 312(%rsp)
	jle	.LBB3_278
	movq	344(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_278:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_280
	movq	200(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_280:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_282
	movq	208(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_282:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_284
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_284:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_286
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_286:
	cmpq	$0, 40(%rsp)
	jle	.LBB3_288
	movq	8(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_288:
	movq	$33, 168(%rsp)
	leaq	static_string_d302bded2ba36da2(%rip), %rax
.LBB3_289:
	movq	%rax, 160(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 176(%rsp)
	xorl	%edi, %edi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 184(%rsp)
	movb	%dl, 192(%rsp)
	movq	(%rsp), %rbp
	movq	5672(%rsp), %rbx
	jmp	.LBB3_33
.LBB3_290:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_292
	movq	200(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_292:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_294
	movq	208(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_294:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_296
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_296:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	%rbx, %rdi
	jmp	.LBB3_162
.LBB3_297:
	cmpq	$0, 312(%rsp)
	jle	.LBB3_299
	movq	344(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_299:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_301
	movq	200(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_301:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_303
	movq	208(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_303:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_305
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_305:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	120(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_307
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_307:
	cmpq	$0, 40(%rsp)
	jle	.LBB3_309
	movq	8(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_309:
	movq	$45, 168(%rsp)
	leaq	static_string_ba2ac5804aa058eb(%rip), %rax
	jmp	.LBB3_289
.LBB3_310:
	testq	%r13, %r13
	jle	.LBB3_312
	movq	240(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_312:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_314
	movq	200(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_314:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_316
	movq	208(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_316:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_318
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_318:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	%rbx, %rdi
	jmp	.LBB3_161
.LBB3_319:
	cmpq	$0, 312(%rsp)
	jle	.LBB3_321
	movq	344(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_321:
	testq	%r13, %r13
	jle	.LBB3_326
	movq	240(%rsp), %rdi
	jmp	.LBB3_325
.LBB3_323:
	cmpq	$0, 312(%rsp)
	jle	.LBB3_326
	movq	344(%rsp), %rdi
.LBB3_325:
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_326:
	cmpq	$0, 224(%rsp)
	jle	.LBB3_328
	movq	200(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_328:
	cmpq	$0, 216(%rsp)
	jle	.LBB3_330
	movq	208(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_330:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_160
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB3_160
.LBB3_332:
	movq	$13, 1944(%rsp)
	leaq	static_string_3893ea46334eb8c6(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	movq	8(%rsp), %rdi
	movq	392(%rsp), %rsi
	movq	40(%rsp), %rdx
	movq	%rbx, %rcx
	movq	%rbp, %r9
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	1944(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movl	%eax, %r14d
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_335
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_335
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_335:
	testq	%rbp, %rbp
	jle	.LBB3_337
	movq	%rbx, %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_337:
	cmpq	$0, 40(%rsp)
	jle	.LBB3_339
	movq	8(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_339:
	testb	$1, %r14b
	je	.LBB3_343
	cmpq	$0, 112(%rsp)
	jle	.LBB3_342
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_342:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	136(%rsp), %rdi
	jmp	.LBB3_354
.LBB3_343:
	leaq	1064(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	536(%rsp), %rcx
	movq	136(%rsp), %r8
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	1144(%rsp), %rbp
	movq	1136(%rsp), %r8
	movq	1128(%rsp), %rbx
	movzbl	1120(%rsp), %eax
	movq	1112(%rsp), %rcx
	movq	1104(%rsp), %rdx
	movq	1096(%rsp), %rsi
	movq	1088(%rsp), %rdi
	movq	1080(%rsp), %r9
	movq	%r9, 8(%rsp)
	movq	1072(%rsp), %r9
	movq	%r9, 392(%rsp)
	movzbl	1064(%rsp), %r9d
	movq	%rdi, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rcx, 184(%rsp)
	movb	%al, 192(%rsp)
	cmpb	$1, %r9b
	je	.LBB3_350
	movq	$13, 1944(%rsp)
	leaq	static_string_5a65be5ae798a7df(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	movq	56(%rsp), %rdi
	movq	384(%rsp), %rsi
	movq	64(%rsp), %rdx
	movq	%rbx, %rcx
	movq	%rbp, %r9
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	leaq	1944(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movl	%eax, %r14d
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_347
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_347
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_347:
	testq	%rbp, %rbp
	jle	.LBB3_349
	movq	%rbx, %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_349:
	testb	$1, %r14b
	je	.LBB3_356
.LBB3_350:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_352
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_352:
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	128(%rsp), %rdi
.LBB3_353:
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	8(%rsp), %rdi
.LBB3_354:
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	144(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	movq	(%rsp), %rbp
	movq	5672(%rsp), %rbx
	jle	.LBB3_32
	movq	56(%rsp), %rdi
	jmp	.LBB3_31
.LBB3_356:
	leaq	3992(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	752(%rsp), %rcx
	movq	128(%rsp), %r8
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	4000(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	4008(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	4056(%rsp), %rdi
	movq	4064(%rsp), %rbx
	movq	4072(%rsp), %rax
	movzbl	3992(%rsp), %ecx
	movzbl	4048(%rsp), %edx
	vmovups	4016(%rsp), %ymm0
	vmovups	%ymm0, 160(%rsp)
	movb	%dl, 192(%rsp)
	cmpb	$1, %cl
	jne	.LBB3_362
	cmpq	$0, 112(%rsp)
	jle	.LBB3_359
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_359:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	40(%rsp), %rdi
	jmp	.LBB3_353
.LBB3_360:
	decq	%r12
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r12, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB3_376
.LBB3_361:
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB3_362:
	cmpq	$0, 232(%rsp)
	jle	.LBB3_370
	xorl	%edx, %edx
	movq	840(%rsp), %rcx
	subq	$1, %rcx
	cmovbq	%rdx, %rcx
	leaq	static_string_a0fcf35b7349c924(%rip), %r11
.LBB3_364:
	movq	%rdx, %rsi
	imulq	304(%rsp), %rsi
	movq	792(%rsp), %r10
.LBB3_365:
	movq	%r10, %r9
	subq	$1, %r9
	movl	$0, %r8d
	cmovaeq	%r9, %r8
	testq	%r10, %r10
	je	.LBB3_369
	movq	792(%rsp), %rbp
	subq	%r10, %rbp
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %r9
	movq	%r9, 256(%rsp)
	movabsq	$2305843009213693952, %r9
	movq	%r9, 272(%rsp)
	movq	$39, 592(%rsp)
	leaq	(%rbp,%rsi), %r14
	leaq	static_string_a0fcf35b7349c924(%rip), %r10
	movq	%r10, 584(%rsp)
	movq	%r9, 600(%rsp)
	cmpq	384(%rsp), %r14
	jae	.LBB3_473
	movq	56(%rsp), %r9
	movl	(%r9,%r14,4), %r9d
	imulq	232(%rsp), %rbp
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %r10
	movq	%r10, 256(%rsp)
	movabsq	$2305843009213693952, %r10
	movq	%r10, 272(%rsp)
	movq	$39, 592(%rsp)
	addq	%rdx, %rbp
	movq	%r11, 584(%rsp)
	movq	%r10, 600(%rsp)
	cmpq	%rbx, %rbp
	jae	.LBB3_475
	movq	%r8, %r10
	cmpl	(%rdi,%rbp,4), %r9d
	je	.LBB3_365
	jmp	.LBB3_377
.LBB3_369:
	movq	840(%rsp), %rdx
	subq	%rcx, %rdx
	subq	$1, %rcx
	jae	.LBB3_364
.LBB3_370:
	testq	%rax, %rax
	jle	.LBB3_372
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_372:
	cmpq	$0, 64(%rsp)
	jle	.LBB3_374
	movq	56(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_374:
	cmpq	$4097, 528(%rsp)
	jge	.LBB3_388
	cmpq	$0, 528(%rsp)
	jg	.LBB3_395
	jmp	.LBB3_401
.LBB3_376:
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$157, %esi
	movl	$27, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB3_377:
	testq	%rax, %rax
	jle	.LBB3_379
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_379:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_381
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_381:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	144(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	cmpq	$0, 64(%rsp)
	jle	.LBB3_383
	movq	56(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_383:
	movq	$28, 168(%rsp)
	leaq	static_string_8d2be8d385cdccef(%rip), %rax
	jmp	.LBB3_289
.LBB3_384:
	decq	%r14
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB3_361
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$174, %esi
	movl	$42, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB3_386:
	movq	576(%rsp), %r13
	decq	%r13
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r13, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB3_361
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$174, %esi
	movl	$72, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB3_388:
	movq	$25, 592(%rsp)
	leaq	static_string_66d118ae2d66e30c(%rip), %rax
	movq	%rax, 584(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 600(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %rbx
	leaq	584(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	leaq	1936(%rsp), %rbp
	movq	%rbx, %rsi
	xorl	%edx, %edx
	movq	%rbp, %r8
	vzeroupper
	callq	"std::os::env::getenv(::String$,::String)"@PLT
	leaq	584(%rsp), %rcx
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_391
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_391
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_391:
	movq	$1, 1944(%rsp)
	leaq	static_string_fdc4d37c65200cd0(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	leaq	584(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	movl	%eax, %ebp
	movabsq	$4611686018427387904, %rax
	testq	%rax, 600(%rsp)
	je	.LBB3_394
	movq	584(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_394
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_394:
	testb	$1, %bpl
	je	.LBB3_401
.LBB3_395:
	movq	848(%rsp), %rcx
	leaq	1(%rcx), %rbx
	cmpq	$1, %rcx
	movl	$1, %eax
	cmovbq	%rcx, %rax
	xorl	%r14d, %r14d
	leaq	static_string_56c10b529cd986fa(%rip), %r12
	leaq	static_string_bbe01a6a523daf15(%rip), %r13
	jmp	.LBB3_397
.LBB3_396:
	leaq	1(%r14), %rax
	cmpq	%rax, %rbx
	je	.LBB3_401
.LBB3_397:
	movq	$6, 264(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rcx
	movq	%rcx, 256(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 272(%rsp)
	movq	$39, 592(%rsp)
	movq	%r14, %rbp
	movq	%rax, %r14
	leaq	static_string_a0fcf35b7349c924(%rip), %rax
	movq	%rax, 584(%rsp)
	movq	%rcx, 600(%rsp)
	cmpq	512(%rsp), %rbp
	jae	.LBB3_477
	movq	96(%rsp), %rax
	movl	(%rax,%rbp,4), %eax
	movq	$4, 1944(%rsp)
	movq	%r12, 1936(%rsp)
	movq	%rcx, 1952(%rsp)
	leaq	1936(%rsp), %rdi
	movq	248(%rsp), %rsi
	movq	232(%rsp), %rdx
	movq	304(%rsp), %rcx
	movq	760(%rsp), %r8
	movq	552(%rsp), %r9
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	leaq	static_string_a8d4ace0dc8d360e(%rip), %r10
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]]"@PLT
	addq	$64, %rsp
	.cfi_adjust_cfa_offset -64
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_396
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_396
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB3_396
.LBB3_401:
	movq	$12, 264(%rsp)
	leaq	static_string_caf946eb805bcec1(%rip), %rax
	movq	%rax, 256(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 272(%rsp)
	movq	$14, 592(%rsp)
	leaq	static_string_9188e23ae65af2ff(%rip), %rax
	movq	%rax, 584(%rsp)
	movq	%rcx, 600(%rsp)
	movq	$14, 1944(%rsp)
	leaq	static_string_499a369ebb9323d7(%rip), %rax
	movq	%rax, 1936(%rsp)
	movq	%rcx, 1952(%rsp)
	leaq	static_string_bbe01a6a523daf15(%rip), %rax
	leaq	static_string_a8d4ace0dc8d360e(%rip), %r10
	leaq	256(%rsp), %rdi
	movq	248(%rsp), %rsi
	movq	232(%rsp), %rdx
	movq	304(%rsp), %rcx
	movq	760(%rsp), %r8
	movq	552(%rsp), %r9
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	568(%rsp)
	.cfi_adjust_cfa_offset 8
	leaq	1992(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	592(%rsp)
	.cfi_adjust_cfa_offset 8
	leaq	656(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_404
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_404
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_404:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 600(%rsp)
	je	.LBB3_407
	movq	584(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_407
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_407:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 272(%rsp)
	je	.LBB3_410
	movq	256(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_410
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_410:
	testb	$1, 780(%rsp)
	je	.LBB3_462
	movq	$67, 1944(%rsp)
	leaq	static_string_d7230136ba2f387c(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rdx
	leaq	static_string_bbe01a6a523daf15(%rip), %r8
	leaq	1936(%rsp), %rdi
	movl	$1, %ecx
	movl	$1, %r9d
	movq	832(%rsp), %rsi
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_414
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_414
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_414:
	xorl	%ebx, %ebx
	leaq	1608(%rsp), %r13
	leaq	976(%rsp), %r14
	leaq	1936(%rsp), %r12
.LBB3_415:
	xorl	%ebp, %ebp
	jmp	.LBB3_418
.LBB3_416:
	testb	$1, 64(%rsp)
	jne	.LBB3_459
.LBB3_417:
	incq	%rbp
	cmpq	$3, %rbp
	je	.LBB3_423
.LBB3_418:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movq	%r13, %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	304(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	%r15, %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbp
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	336(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	272(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	296(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	88(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	416(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	96(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	440(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	128(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	216(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	112(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	504(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	264(%rsp)
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$128, %rsp
	.cfi_adjust_cfa_offset -128
	movq	1704(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	1688(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	1672(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	1656(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	1640(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	1624(%rsp), %rax
	movq	%rax, 16(%rsp)
	cmpb	$1, 1608(%rsp)
	je	.LBB3_459
	movq	1696(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	1680(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	1664(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	1648(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	1632(%rsp), %r15
	movq	1616(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_417
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$194, %ecx
	movl	$36, %r8d
	leaq	4936(%rsp), %rdi
	movq	%rax, %rsi
	movq	%r12, %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	4968(%rsp), %eax
	vmovups	4936(%rsp), %ymm0
	movzbl	4928(%rsp), %ecx
	movb	%cl, 64(%rsp)
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_416
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_416
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB3_416
.LBB3_423:
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movq	%r14, %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	304(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	384(%rsp), %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	256(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	280(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	128(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	520(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	136(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	544(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	120(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	448(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	160(%rsp)
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$96, %rsp
	.cfi_adjust_cfa_offset -96
	movq	1056(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	1040(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	1024(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	1008(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	992(%rsp), %rax
	movq	%rax, 16(%rsp)
	cmpb	$1, 976(%rsp)
	je	.LBB3_459
	movq	1048(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	1032(%rsp), %rax
	movq	%rax, 480(%rsp)
	movq	1016(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	1000(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	984(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_429
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$196, %ecx
	movl	$32, %r8d
	leaq	4888(%rsp), %rdi
	movq	%rax, %rsi
	movq	%r12, %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	4920(%rsp), %eax
	vmovups	4888(%rsp), %ymm0
	movzbl	4880(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_428
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_428
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_428:
	testb	$1, %bpl
	jne	.LBB3_459
.LBB3_429:
	testb	$1, %bl
	movb	$1, %bl
	je	.LBB3_415
	cmpq	$0, 5664(%rsp)
	jle	.LBB3_458
	xorl	%eax, %eax
	movq	784(%rsp), %rcx
	subq	$1, %rcx
	movl	$0, %r14d
	cmovbq	%rax, %rcx
	movq	%rcx, 384(%rsp)
.LBB3_432:
	xorl	%r13d, %r13d
	jmp	.LBB3_434
.LBB3_433:
	movq	%r13, %rax
	incq	%rax
	movq	%rax, %r13
	cmpq	$4, %rax
	je	.LBB3_457
.LBB3_434:
	movq	%r14, %rbp
	addq	%r13, %rbp
	leaq	3(%r14,%r13), %rax
	cmovnsq	%rbp, %rax
	sets	%bl
	andq	$-4, %rax
	subq	%rax, %rbp
	setne	64(%rsp)
	movq	(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_439
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$200, %ecx
	movl	$36, %r8d
	leaq	4840(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	4872(%rsp), %eax
	vmovups	4840(%rsp), %ymm0
	movzbl	4832(%rsp), %ecx
	movb	%cl, 56(%rsp)
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_438
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_438
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_438:
	testb	$1, 56(%rsp)
	jne	.LBB3_459
.LBB3_439:
	andb	64(%rsp), %bl
	movzbl	%bl, %eax
	leaq	(%rbp,%rax,4), %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 1936(%rsp)
	movl	$1, %edi
	leaq	1936(%rsp), %rsi
	vzeroupper
	callq	clock_gettime@PLT
	movq	1936(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	1944(%rsp), %rax
	movq	%rax, 64(%rsp)
	subq	$8, %rsp
	cmpq	$2, %rbx
	jg	.LBB3_442
	.cfi_adjust_cfa_offset 8
	leaq	1512(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	304(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	%r15, %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	336(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	272(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	296(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	88(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	416(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	96(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	440(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	128(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	216(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	112(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	504(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	264(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	"knn_index_layout_main::_distance(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$128, %rsp
	.cfi_adjust_cfa_offset -128
	movq	1600(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	1584(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	1568(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	1552(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	1536(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	1520(%rsp), %rax
	movq	%rax, 16(%rsp)
	cmpb	$1, 1504(%rsp)
	je	.LBB3_459
	movq	1592(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	1576(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	1560(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	1544(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	1528(%rsp), %r15
	movq	1512(%rsp), %rax
	jmp	.LBB3_444
.LBB3_442:
	.cfi_adjust_cfa_offset 8
	leaq	896(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	164(%rsp), %edx
	movq	304(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	384(%rsp), %r9
	leaq	168(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	576(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	256(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	280(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	128(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	520(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	136(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	544(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	120(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	448(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	160(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	"knn_index_layout_main::_select(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],max::gpu::host::device_context::DeviceBuffer[::DType(float32)],max::gpu::host::device_context::DeviceBuffer[::DType(uint32)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	addq	$96, %rsp
	.cfi_adjust_cfa_offset -96
	movq	968(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	952(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	936(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	920(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	904(%rsp), %rax
	movq	%rax, 16(%rsp)
	cmpb	$1, 888(%rsp)
	je	.LBB3_459
	movq	960(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	944(%rsp), %rax
	movq	%rax, 480(%rsp)
	movq	928(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	912(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	896(%rsp), %rax
.LBB3_444:
	movq	%rax, 296(%rsp)
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 1936(%rsp)
	movq	$0, 1944(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 1952(%rsp)
	testq	%rax, %rax
	je	.LBB3_449
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$206, %ecx
	movl	$36, %r8d
	leaq	4792(%rsp), %rdi
	movq	%rax, %rsi
	leaq	1944(%rsp), %rdx
	leaq	static_string_7b5f0d71131768e3(%rip), %r9
	pushq	$50
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	4824(%rsp), %eax
	vmovups	4792(%rsp), %ymm0
	movzbl	4784(%rsp), %ebp
	vmovups	%ymm0, 160(%rsp)
	movb	%al, 192(%rsp)
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_448
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_448
	addq	$-8, %rdi
	#MEMBARRIER
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_448:
	testb	$1, %bpl
	jne	.LBB3_459
.LBB3_449:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 1936(%rsp)
	movl	$1, %edi
	leaq	1936(%rsp), %rsi
	vzeroupper
	callq	clock_gettime@PLT
	movq	1936(%rsp), %rax
	subq	56(%rsp), %rax
	movq	1944(%rsp), %rcx
	subq	64(%rsp), %rcx
	imulq	$1000000000, %rax, %rax
	addq	%rcx, %rax
	vcvtsi2sd	%rax, %xmm15, %xmm0
	movq	$15, 592(%rsp)
	vdivsd	.LCPI3_2(%rip), %xmm0, %xmm0
	leaq	static_string_0bb90f8e145278cc(%rip), %rax
	movq	%rax, 584(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 600(%rsp)
	decq	%rbx
	cmpq	$2, %rbx
	ja	.LBB3_451
	leaq	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"(%rip), %rax
	movzbl	(%rbx,%rax), %eax
	leaq	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel"(%rip), %rdx
	movslq	(%rdx,%rbx,4), %rcx
	addq	%rdx, %rcx
	movq	%rax, 592(%rsp)
	movq	%rcx, 584(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 600(%rsp)
.LBB3_451:
	movq	$6, 1944(%rsp)
	leaq	static_string_1a02af91e8b4e009(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	movl	$1, %r8d
	leaq	1944(%rsp), %rdi
	movq	%r14, %rsi
	leaq	592(%rsp), %rdx
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rcx
	leaq	static_string_bbe01a6a523daf15(%rip), %r9
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f64,length=1\">>, scalar<f64>]]"@PLT
	addq	$32, %rsp
	.cfi_adjust_cfa_offset -32
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_454
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_454
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_454:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 600(%rsp)
	je	.LBB3_433
	movq	584(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_433
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB3_433
.LBB3_457:
	movq	784(%rsp), %r14
	movq	384(%rsp), %rax
	subq	%rax, %r14
	subq	$1, %rax
	movq	%rax, 384(%rsp)
	jae	.LBB3_432
.LBB3_458:
	leaq	1816(%rsp), %rdi
	movq	(%rsp), %rsi
	movl	156(%rsp), %edx
	movq	296(%rsp), %rcx
	movq	16(%rsp), %r8
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"@PLT
	movq	1896(%rsp), %r14
	movq	1888(%rsp), %r8
	movq	1880(%rsp), %r15
	movzbl	1872(%rsp), %eax
	movq	1864(%rsp), %rcx
	movq	1856(%rsp), %rdx
	movq	1848(%rsp), %rsi
	movq	1840(%rsp), %rdi
	movq	1832(%rsp), %r9
	movq	%r9, 16(%rsp)
	movzbl	1816(%rsp), %r9d
	movq	%rdi, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rcx, 184(%rsp)
	movb	%al, 192(%rsp)
	cmpb	$1, %r9b
	jne	.LBB3_465
.LBB3_459:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_461
	movq	96(%rsp), %rdi
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_461:
	movq	104(%rsp), %rdi
	vzeroupper
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	144(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	(%rsp), %rbp
	movq	5672(%rsp), %rbx
	jmp	.LBB3_32
.LBB3_462:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_464
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_464:
	movq	144(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	8(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	32(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	16(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	72(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	88(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	104(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	(%rsp), %rdi
	callq	AsyncRT_DeviceContext_release@PLT
	xorl	%eax, %eax
	jmp	.LBB3_37
.LBB3_465:
	movq	$20, 1944(%rsp)
	leaq	static_string_1c530a05b12890aa(%rip), %rax
	movq	%rax, 1936(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 1952(%rsp)
	movq	96(%rsp), %rdi
	movq	512(%rsp), %rsi
	movq	112(%rsp), %rdx
	movq	%r15, %rcx
	movq	%r14, %r9
	leaq	160(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	callq	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movl	%eax, %ebp
	movabsq	$4611686018427387904, %rax
	testq	%rax, 1952(%rsp)
	je	.LBB3_468
	movq	1936(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB3_468
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_468:
	testq	%r14, %r14
	jle	.LBB3_470
	movq	%r15, %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_470:
	cmpq	$0, 112(%rsp)
	jle	.LBB3_472
	movq	96(%rsp), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB3_472:
	testb	$1, %bpl
	jne	.LBB3_461
	jmp	.LBB3_464
.LBB3_473:
	movq	384(%rsp), %rbx
	decq	%rbx
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	vzeroupper
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB3_361
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$183, %esi
	movl	$44, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB3_475:
	decq	%rbx
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	vzeroupper
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB3_361
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$183, %esi
	movl	$84, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB3_477:
	movq	512(%rsp), %r12
	decq	%r12
	leaq	256(%rsp), %rdi
	leaq	1936(%rsp), %rsi
	xorl	%edx, %edx
	vzeroupper
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	584(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r12, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB3_361
	movb	$0, (%rax,%rdx)
	leaq	static_string_7b5f0d71131768e3(%rip), %rcx
	movl	$187, %esi
	movl	$88, %edx
	movl	$50, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end3:
	.size	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end3-"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.globl	main
	.prefalign	4, .Lfunc_end4, nop
	.type	main,@function
main:
.Lmain$local:
	.type	.Lmain$local,@function
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4504, %rsp
	.cfi_def_cfa_offset 4560
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r14
	movl	%edi, %ebp
	callq	KGEN_CompilerRT_AsyncRT_GetCurrentCPUDevice@PLT
	testq	%rax, %rax
	jne	.LBB4_2
	leaq	static_string_a61c3395ab9379d9(%rip), %rdi
	movq	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_0"@GOTPCREL(%rip), %rdx
	movq	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_1"@GOTPCREL(%rip), %rcx
	movl	$7, %esi
	callq	KGEN_CompilerRT_GetOrCreateGlobal@PLT
.LBB4_2:
	movabsq	$4611686018427387904, %r13
	movabsq	$2305843009213693952, %rax
	movl	%ebp, %edi
	movq	%rax, %rbp
	movq	%r14, %rsi
	callq	KGEN_CompilerRT_SetArgV@PLT
	callq	KGEN_CompilerRT_PrintStackTraceOnFault@PLT
	leaq	static_string_f94463e33bca9e65(%rip), %rsi
	leaq	336(%rsp), %rdi
	movl	$28, %edx
	movl	$9, %r8d
	movq	%rbp, %rcx
	callq	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movzbl	336(%rsp), %ecx
	movq	344(%rsp), %r12
	movzbl	384(%rsp), %edx
	vmovups	352(%rsp), %ymm0
	vmovups	%ymm0, 16(%rsp)
	movb	%dl, 48(%rsp)
	cmpq	$7, %r12
	setl	%al
	testb	%cl, %cl
	jne	.LBB4_14
	cmpq	$7, %r12
	jge	.LBB4_4
	movq	$31, 24(%rsp)
	leaq	static_string_89492c12f76adff2(%rip), %rax
.LBB4_6:
	movq	%rax, 16(%rsp)
	movq	%rbp, 32(%rsp)
	xorl	%edi, %edi
	vzeroupper
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 40(%rsp)
	movb	%dl, 48(%rsp)
	testb	%dl, %dl
	jne	.LBB4_15
	jmp	.LBB4_63
.LBB4_4:
	orb	%al, %cl
	movb	%cl, 15(%rsp)
	movl	$3, %r13d
	xorl	%r14d, %r14d
	leaq	16(%rsp), %rbx
.LBB4_8:
	movl	$2, %ecx
	.p2align	4
.LBB4_9:
	movq	%rcx, %rax
	subq	$1, %rax
	movl	$0, %ebp
	cmovaeq	%rax, %rbp
	testq	%rcx, %rcx
	je	.LBB4_7
	movl	$2, %r15d
	subq	%rcx, %r15
	movl	$1, %edi
	movl	$1, %esi
	movl	$1, %edx
	movq	%r14, %rcx
	movq	%r15, %r8
	xorl	%r9d, %r9d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testb	$1, %al
	jne	.LBB4_13
	movl	$3, %edi
	movl	$33, %esi
	movl	$31, %edx
	movq	%r14, %rcx
	movq	%r15, %r8
	xorl	%r9d, %r9d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	callq	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testb	$1, %al
	jne	.LBB4_13
	movl	$5, %edi
	movl	$65, %esi
	movl	$129, %edx
	movq	%r14, %rcx
	movq	%r15, %r8
	xorl	%r9d, %r9d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	callq	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movq	%rbp, %rcx
	testb	$1, %al
	je	.LBB4_9
	jmp	.LBB4_13
.LBB4_7:
	movl	$4, %r14d
	subq	%r13, %r14
	subq	$1, %r13
	jae	.LBB4_8
	movq	$26, 64(%rsp)
	leaq	static_string_db528282ff266e15(%rip), %rax
	movq	%rax, 56(%rsp)
	movabsq	$2305843009213693952, %r13
	movq	%r13, 72(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %r14
	leaq	56(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	leaq	392(%rsp), %r15
	movq	%r14, %rsi
	xorl	%edx, %edx
	movq	%r15, %r8
	vzeroupper
	callq	"std::os::env::getenv(::String$,::String)"@PLT
	leaq	56(%rsp), %rcx
	movq	%r15, %rdi
	movq	%r14, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	movabsq	$4611686018427387904, %r14
	testq	%r14, 408(%rsp)
	je	.LBB4_29
	movq	392(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_29
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB4_29:
	movq	$1, 400(%rsp)
	leaq	static_string_fdc4d37c65200cd0(%rip), %rax
	movq	%rax, 392(%rsp)
	movq	%r13, 408(%rsp)
	leaq	56(%rsp), %rdi
	leaq	392(%rsp), %rsi
	callq	"std::collections::string::string::String::__eq__(::String,::String)"@PLT
	testq	%r14, 72(%rsp)
	je	.LBB4_32
	movq	56(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_32
	addq	$-8, %rdi
	#MEMBARRIER
	movl	%eax, %ebp
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movl	%ebp, %eax
.LBB4_32:
	testb	$1, %al
	je	.LBB4_50
	leaq	static_string_e3b932ac05451006(%rip), %rsi
	leaq	280(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	movl	$25, %edx
	movl	$32, %r8d
	callq	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	288(%rsp), %r14
	movzbl	328(%rsp), %edx
	vmovups	296(%rsp), %ymm0
	vmovups	%ymm0, 16(%rsp)
	movb	%dl, 48(%rsp)
	cmpb	$0, 280(%rsp)
	movabsq	$4611686018427387904, %r13
	movabsq	$2305843009213693952, %rbp
	jne	.LBB4_14
	leaq	static_string_65b768cdacbddd0e(%rip), %rsi
	leaq	224(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	movl	$25, %edx
	movl	$100000, %r8d
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	232(%rsp), %r15
	movzbl	272(%rsp), %edx
	vmovups	240(%rsp), %ymm0
	vmovups	%ymm0, 16(%rsp)
	movb	%dl, 48(%rsp)
	cmpb	$0, 224(%rsp)
	jne	.LBB4_14
	leaq	static_string_7c8c647ff852be50(%rip), %rsi
	leaq	168(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	movl	$22, %edx
	movl	$32, %r8d
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	176(%rsp), %rcx
	movzbl	216(%rsp), %edx
	vmovups	184(%rsp), %ymm0
	vmovups	%ymm0, 16(%rsp)
	movb	%dl, 48(%rsp)
	cmpb	$0, 168(%rsp)
	jne	.LBB4_14
	testq	%r14, %r14
	jle	.LBB4_44
	testq	%r15, %r15
	jle	.LBB4_44
	testq	%rcx, %rcx
	jle	.LBB4_44
	cmpq	$1024, %r14
	jg	.LBB4_44
	cmpq	$1000000, %r15
	jg	.LBB4_44
	cmpq	$4096, %rcx
	jg	.LBB4_44
	movq	%r15, %rax
	imulq	%r14, %rax
	cmpq	$16000000, %rax
	jg	.LBB4_44
	movq	%rcx, %rax
	imulq	%r15, %rax
	cmpq	$16000001, %rax
	jge	.LBB4_44
	movq	%rcx, 80(%rsp)
	leaq	static_string_9901187edc54c332(%rip), %rsi
	leaq	112(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	movl	$28, %edx
	movl	$3, %r8d
	vzeroupper
	callq	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	120(%rsp), %rcx
	movzbl	160(%rsp), %edx
	vmovups	128(%rsp), %ymm0
	vmovups	%ymm0, 16(%rsp)
	movb	%dl, 48(%rsp)
	cmpb	$0, 112(%rsp)
	jne	.LBB4_14
	testq	%rcx, %rcx
	je	.LBB4_49
	cmpq	$3, %rcx
	jne	.LBB4_48
.LBB4_49:
	movl	$1, %r8d
	movq	%r14, %rdi
	movq	%r15, %rsi
	movq	80(%rsp), %rdx
	movl	$1, %r9d
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	vzeroupper
	callq	"knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])"
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testb	$1, %al
	jne	.LBB4_13
.LBB4_50:
	movq	$35, 400(%rsp)
	leaq	static_string_df3c90ecf5db28f9(%rip), %rax
	movq	%rax, 392(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 408(%rsp)
	leaq	static_string_bbe01a6a523daf15(%rip), %rsi
	leaq	392(%rsp), %rdi
	movl	$1, %edx
	movl	$1, %r8d
	xorl	%ecx, %ecx
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	movabsq	$4611686018427387904, %rax
	testq	%rax, 408(%rsp)
	je	.LBB4_53
	movq	392(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_53
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB4_53:
	cmpb	$0, 15(%rsp)
	je	.LBB4_54
.LBB4_13:
	movzbl	48(%rsp), %edx
	movabsq	$4611686018427387904, %r13
	movabsq	$2305843009213693952, %rbp
.LBB4_14:
	testb	%dl, %dl
	je	.LBB4_63
.LBB4_15:
	movabsq	$9223372036854775807, %rbx
	movq	40(%rsp), %r14
	movq	16(%r14), %rsi
	xorl	%r15d, %r15d
	.p2align	4
.LBB4_16:
	cmpb	$0, (%rsi,%r15)
	je	.LBB4_55
	incq	%r15
	cmpq	%r15, %rbx
	jne	.LBB4_16
	movq	%rbx, %r15
	jmp	.LBB4_19
.LBB4_55:
	cmpq	$23, %r15
	ja	.LBB4_19
	leaq	1(%rbx), %rax
	movq	%rax, 72(%rsp)
	xorl	%edx, %edx
	.p2align	4
.LBB4_57:
	cmpb	$0, (%rsi,%rdx)
	je	.LBB4_60
	incq	%rdx
	cmpq	%rdx, %rbx
	jne	.LBB4_57
	movq	%rbx, %rdx
.LBB4_60:
	leaq	56(%rsp), %rdi
	jmp	.LBB4_61
.LBB4_19:
	addq	$7, %r15
	movq	%r15, %rdi
	andq	$-8, %rdi
	addq	$8, %rdi
	sarq	$3, %r15
	movl	$1, %esi
	vzeroupper
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, 56(%rsp)
	movq	$0, 64(%rsp)
	orq	%r13, %r15
	movq	%r15, 72(%rsp)
	movq	$0, 4488(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 4496(%rsp)
	movq	16(%r14), %rsi
	xorl	%edx, %edx
	.p2align	4
.LBB4_20:
	cmpb	$0, (%rsi,%rdx)
	je	.LBB4_23
	incq	%rdx
	cmpq	%rdx, %rbx
	jne	.LBB4_20
	movq	%rbx, %rdx
.LBB4_23:
	leaq	392(%rsp), %r14
	movq	%r14, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4488(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB4_25
	movq	4496(%rsp), %rdi
	leaq	392(%rsp), %r14
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4488(%rsp)
	xorl	%edx, %edx
.LBB4_25:
	movq	4496(%rsp), %rdi
	movq	%r14, %rsi
.LBB4_61:
	vzeroupper
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	56(%rsp), %rax
	vmovups	64(%rsp), %xmm0
	movq	%rax, 88(%rsp)
	vmovups	%xmm0, 96(%rsp)
	leaq	static_string_bbe01a6a523daf15(%rip), %rsi
	leaq	88(%rsp), %rdi
	movl	$1, %edx
	movl	$1, %r8d
	xorl	%ecx, %ecx
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	testq	%r13, 104(%rsp)
	je	.LBB4_67
	movq	88(%rsp), %rdi
	lock		decq	-8(%rdi)
	je	.LBB4_66
	jmp	.LBB4_67
.LBB4_54:
	callq	KGEN_CompilerRT_DestroyGlobals@PLT
	xorl	%eax, %eax
	jmp	.LBB4_76
.LBB4_44:
	movq	$51, 24(%rsp)
	leaq	static_string_fbc1a80614d0cd78(%rip), %rax
	jmp	.LBB4_6
.LBB4_48:
	movq	$58, 24(%rsp)
	leaq	static_string_a74d59023276de02(%rip), %rax
	movq	%rax, 16(%rsp)
	movabsq	$2305843009213693952, %rbp
	movq	%rbp, 32(%rsp)
	xorl	%edi, %edi
	vzeroupper
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 40(%rsp)
	movb	%dl, 48(%rsp)
	movabsq	$4611686018427387904, %r13
	testb	%dl, %dl
	jne	.LBB4_15
.LBB4_63:
	movq	$123, 400(%rsp)
	leaq	static_string_fbe1ca471a988c5b(%rip), %rax
	movq	%rax, 392(%rsp)
	movq	%rbp, 408(%rsp)
	leaq	static_string_bbe01a6a523daf15(%rip), %rsi
	leaq	392(%rsp), %rdi
	movl	$1, %edx
	movl	$1, %r8d
	xorl	%ecx, %ecx
	vzeroupper
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	testq	%r13, 408(%rsp)
	je	.LBB4_67
	movq	392(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_67
.LBB4_66:
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB4_67:
	movq	$44, 400(%rsp)
	leaq	static_string_26a85fbdc19bc0a1(%rip), %rax
	movq	%rax, 392(%rsp)
	movq	%rbp, 408(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rdx
	leaq	static_string_bbe01a6a523daf15(%rip), %r8
	leaq	392(%rsp), %rdi
	leaq	16(%rsp), %rsi
	movl	$1, %ecx
	movl	$1, %r9d
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::error::Error\">>, struct<(struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>, struct<(struct<(struct<(variant<struct<()>, struct<(pointer<none>) memoryOnly>>) memoryOnly>) memoryOnly>) memoryOnly>) memoryOnly>]]"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testq	%r13, 408(%rsp)
	je	.LBB4_70
	movq	392(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_70
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB4_70:
	testq	%r13, 32(%rsp)
	je	.LBB4_73
	movq	16(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB4_73
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB4_73:
	cmpb	$1, 48(%rsp)
	jne	.LBB4_75
	movq	40(%rsp), %rdi
	callq	"std::memory::arc_pointer::ArcPointer::__deinit__(::ArcPointer[$0]$),T=[typevalue<#kgen.instref<\"std::memory::owned_pointer::OwnedPointer,T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>]\">>, pointer<none>]"@PLT
.LBB4_75:
	movl	$1, %eax
.LBB4_76:
	addq	$4504, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end4:
	.size	main, .Lfunc_end4-main
	.size	.Lmain$local, .Lfunc_end4-main
	.cfi_endproc

	.prefalign	4, .Lfunc_end5, nop
	.type	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])",@function
"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	testq	%rdi, %rdi
	js	.LBB5_1
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rsi
	movq	$0, 8(%rsp)
	leaq	8(%rsp), %rdi
	callq	KGEN_CompilerRT_GetStackTrace@PLT
	testq	%rax, %rax
	je	.LBB5_4
	movq	8(%rsp), %rbx
	movl	$24, %edi
	movl	$8, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	movq	$1, 8(%rax)
	movq	%rbx, 16(%rax)
	movb	$1, %dl
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.LBB5_1:
	xorl	%edx, %edx
	retq
.LBB5_4:
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	xorl	%edx, %edx
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.Lfunc_end5:
	.size	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end5-"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI6_0:
	.quad	0
	.quad	1
	.quad	2
	.quad	5
.LCPI6_1:
	.quad	0
	.quad	1
	.quad	2
	.quad	4
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI6_2:
	.quad	31
	.text
	.prefalign	4, .Lfunc_end6, nop
	.type	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]",@function
"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4312, %rsp
	.cfi_def_cfa_offset 4368
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, %r14
	movq	%rcx, 56(%rsp)
	movq	%rdx, 32(%rsp)
	movq	%rsi, %rbp
	movq	%rdi, 72(%rsp)
	movq	4432(%rsp), %rax
	movq	4424(%rsp), %rcx
	movq	4416(%rsp), %rdx
	movq	4384(%rsp), %rsi
	movq	16(%rdx), %r12
	movq	16(%rcx), %r15
	vmovups	8(%r9), %xmm0
	vmovups	8(%rsi), %xmm1
	vmovaps	%xmm0, 112(%rsp)
	vmovaps	%xmm1, 96(%rsp)
	vpunpcklqdq	%xmm1, %xmm0, %xmm0
	testq	%r12, %r12
	js	.LBB6_1
	movq	8(%rdx), %r12
	jmp	.LBB6_3
.LBB6_1:
	shrq	$56, %r12
	andl	$31, %r12d
.LBB6_3:
	movq	4400(%rsp), %rdx
	movq	4392(%rsp), %rdi
	movq	16(%rax), %rbx
	testq	%r15, %r15
	js	.LBB6_4
	movq	8(%rcx), %r15
	jmp	.LBB6_6
.LBB6_4:
	shrq	$56, %r15
	andl	$31, %r15d
.LBB6_6:
	leaq	1(%r8), %rsi
	vmovups	8(%rdx), %xmm1
	vmovups	%ymm1, 128(%rsp)
	vmovddup	16(%rdi), %xmm1
	vmovaps	%xmm1, 80(%rsp)
	vinsertf128	$1, 8(%rdi), %ymm0, %ymm0
	vmovups	%ymm0, 160(%rsp)
	testq	%rbx, %rbx
	movq	%r8, 64(%rsp)
	js	.LBB6_7
	movq	8(%rax), %rbx
	jmp	.LBB6_9
.LBB6_7:
	shrq	$56, %rbx
	andl	$31, %ebx
.LBB6_9:
	movq	%rbp, %rdi
	vzeroupper
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rax), %rsi
	movq	32(%rsp), %r13
	movq	%r13, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	vmovdqa	112(%rsp), %xmm0
	vpunpckhqdq	96(%rsp), %xmm0, %xmm0
	vinserti128	$1, 80(%rsp), %ymm0, %ymm0
	vmovdqa	.LCPI6_0(%rip), %ymm1
	vmovdqu	128(%rsp), %ymm3
	vpermi2q	%ymm3, %ymm0, %ymm1
	vpsrlq	$56, %ymm1, %ymm0
	vpmovq2m	%ymm1, %k1
	vmovdqa	.LCPI6_1(%rip), %ymm1
	vmovdqu	160(%rsp), %ymm2
	vpermt2q	%ymm3, %ymm1, %ymm2
	vpandq	.LCPI6_2(%rip){1to4}, %ymm0, %ymm2 {%k1}
	vextracti128	$1, %ymm2, %xmm0
	vpaddq	%xmm0, %xmm2, %xmm0
	vpshufd	$238, %xmm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rsi
	movq	4376(%rsp), %rcx
	addq	%rcx, %rax
	addq	%rax, %rsi
	movq	4408(%rsp), %rdi
	vzeroupper
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	addq	%r12, %r15
	addq	%rbx, %r15
	addq	%rax, %r15
	cmpq	$23, %r15
	jg	.LBB6_32
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 24(%rsp)
	leaq	8(%rsp), %r8
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	56(%rsp), %rdx
	movq	64(%rsp), %rcx
	callq	"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	16(%r14), %rdx
	testq	%rdx, %rdx
	js	.LBB6_11
	movq	8(%r14), %rdx
	movq	(%r14), %r14
	jmp	.LBB6_13
.LBB6_32:
	addq	$7, %r15
	movq	%r15, %rbx
	sarq	$3, %rbx
	andq	$-8, %r15
	addq	$8, %r15
	movl	$1, %esi
	movq	%r15, %rdi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, 8(%rsp)
	movq	$0, 16(%rsp)
	movabsq	$4611686018427387904, %rax
	orq	%rbx, %rax
	movq	%rax, 24(%rsp)
	movq	$0, 4296(%rsp)
	leaq	8(%rsp), %rax
	movq	%rax, 4304(%rsp)
	leaq	200(%rsp), %rdi
	movq	56(%rsp), %rsi
	movq	64(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB6_34
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
	xorl	%edx, %edx
.LBB6_34:
	movq	4392(%rsp), %r13
	movb	$58, 200(%rsp,%rdx)
	incq	4296(%rsp)
	leaq	200(%rsp), %rsi
	movq	%rbp, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4296(%rsp), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB6_36
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
	xorl	%edx, %edx
.LBB6_36:
	movq	32(%rsp), %rdi
	movb	$58, 200(%rsp,%rdx)
	incq	4296(%rsp)
	leaq	200(%rsp), %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_38
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_38:
	movq	16(%r14), %rdx
	testq	%rdx, %rdx
	js	.LBB6_39
	movq	8(%r14), %rdx
	movq	(%r14), %r14
	jmp	.LBB6_41
.LBB6_11:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_13:
	movq	4392(%rsp), %r13
	leaq	8(%rsp), %r15
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r15, %rdi
	movq	4368(%rsp), %rsi
	movq	4376(%rsp), %rdx
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	4384(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_14
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_16
.LBB6_39:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_41:
	leaq	200(%rsp), %rdi
	movq	%r14, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_43
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_43:
	leaq	200(%rsp), %rdi
	movq	4368(%rsp), %rsi
	movq	4376(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_45
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_45:
	movq	4384(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_46
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_48
.LBB6_14:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_16:
	leaq	8(%rsp), %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	16(%r13), %rdx
	testq	%rdx, %rdx
	js	.LBB6_17
	movq	8(%r13), %rdx
	movq	(%r13), %r13
	jmp	.LBB6_19
.LBB6_46:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_48:
	leaq	200(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_50
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_50:
	movq	16(%r13), %rdx
	testq	%rdx, %rdx
	js	.LBB6_51
	movq	8(%r13), %rdx
	movq	(%r13), %r13
	jmp	.LBB6_53
.LBB6_17:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_19:
	leaq	8(%rsp), %rdi
	movq	%r13, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	4400(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_20
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_22
.LBB6_51:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_53:
	leaq	200(%rsp), %rdi
	movq	%r13, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_55
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_55:
	movq	4400(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_56
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_58
.LBB6_20:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_22:
	leaq	8(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	4408(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	4416(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_23
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_25
.LBB6_56:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_58:
	leaq	200(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_60
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_60:
	leaq	200(%rsp), %rsi
	movq	4408(%rsp), %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_62
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_62:
	movq	4416(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_63
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_65
.LBB6_23:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_25:
	leaq	8(%rsp), %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	4424(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_26
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_28
.LBB6_63:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_65:
	leaq	200(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_67
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_67:
	movq	4424(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_68
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_70
.LBB6_26:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_28:
	leaq	8(%rsp), %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	4432(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_29
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	leaq	8(%rsp), %rdi
	jmp	.LBB6_78
.LBB6_68:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_70:
	leaq	200(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB6_72
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
.LBB6_72:
	movq	4432(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB6_73
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB6_75
.LBB6_29:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	8(%rsp), %rdi
	jmp	.LBB6_78
.LBB6_73:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB6_75:
	leaq	200(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4296(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB6_77
	movq	4304(%rsp), %rdi
	leaq	200(%rsp), %rbx
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4296(%rsp)
	xorl	%edx, %edx
.LBB6_77:
	movq	4304(%rsp), %rdi
	movq	%rbx, %rsi
.LBB6_78:
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	8(%rsp), %rbx
	vmovups	16(%rsp), %xmm0
	vmovaps	%xmm0, 32(%rsp)
	xorl	%edi, %edi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	72(%rsp), %rcx
	movb	%dl, 32(%rcx)
	movq	%rax, 24(%rcx)
	vmovaps	32(%rsp), %xmm0
	vmovups	%xmm0, 8(%rcx)
	movq	%rbx, (%rcx)
	movq	%rcx, %rax
	addq	$4312, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]", .Lfunc_end6-"std::builtin::error::Error::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si64,length=1\">>, scalar<si64>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end7, nop
	.type	"std::builtin::error::Error::write_to[::Writer & ::AnyType](::Error,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::error::Error::write_to[::Writer & ::AnyType](::Error,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	movq	%rdi, %rax
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB7_1
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	jmp	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
.LBB7_1:
	shrq	$56, %rdx
	andl	$31, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	jmp	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
.Lfunc_end7:
	.size	"std::builtin::error::Error::write_to[::Writer & ::AnyType](::Error,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end7-"std::builtin::error::Error::write_to[::Writer & ::AnyType](::Error,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end8, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=f64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=f64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2152, %rsp
	.cfi_def_cfa_offset 2208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, 8(%rsp)
	vmovq	%xmm0, %rax
	movb	$52, %cl
	bzhiq	%rcx, %rax, %rcx
	movq	%rax, %r12
	shrq	$52, %r12
	andl	$2047, %r12d
	movb	$63, %dl
	bzhiq	%rdx, %rax, %rsi
	leaq	(%rcx,%rcx), %rdi
	movabsq	$9007199254740992, %rdx
	leaq	(%rdx,%rcx,2), %r10
	testq	%rcx, %rcx
	setne	%r14b
	leaq	-1075(%r12), %r8
	testq	%r12, %r12
	sete	%dl
	cmoveq	%rdi, %r10
	movq	$-1074, %rbp
	cmovneq	%r8, %rbp
	leal	-1079(%r12), %edi
	xorl	%r13d, %r13d
	cmpl	$-2, %edi
	setb	%bl
	movabsq	$9218868437227405312, %rdi
	cmpq	%rdi, %rsi
	jne	.LBB8_8
	testq	%rax, %rax
	js	.LBB8_5
	movq	8(%rsp), %rbx
	movq	4096(%rbx), %rdx
	leaq	3(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_4
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_4:
	movw	$28265, (%rbx,%rdx)
	movb	$102, 2(%rbx,%rdx)
	movl	$3, %eax
	addq	%rax, 4096(%rbx)
	jmp	.LBB8_98
.LBB8_8:
	vucomisd	%xmm0, %xmm0
	jp	.LBB8_119
	orq	%r12, %rcx
	je	.LBB8_10
	orb	%dl, %r14b
	testq	%rax, %rax
	js	.LBB8_18
	leaq	global_constant_0(%rip), %r11
	movl	$2576980378, %r15d
	testb	%r14b, %r14b
	je	.LBB8_22
.LBB8_25:
	imulq	$315653, %rbp, %r14
	sarq	$20, %r14
	movl	$2, %eax
	subq	%r14, %rax
	imulq	$1741647, %rax, %r13
	sarq	$19, %r13
	addq	%rbp, %r13
	leaq	1(%r10), %rax
	movl	$294, %esi
	shlxq	%r13, %rax, %rdx
	subq	%r14, %rsi
	movq	%rsi, %rax
	shlq	$4, %rax
	movl	$63, %r8d
	movl	%edx, %edi
	addq	%rax, %r11
	subq	%r13, %r8
	movq	%rdx, %rcx
	shrq	$32, %rcx
	movq	8(%r11), %rax
	shrxq	%r8, %rax, %rbp
	movl	%eax, %ebx
	shrq	$32, %rax
	movq	%rcx, %r8
	imulq	%rax, %r8
	imulq	%rdi, %rax
	imulq	%rbx, %rcx
	imulq	%rdi, %rbx
	movl	%ecx, %edi
	movl	%eax, %r9d
	addq	%rdi, %r9
	movq	%rbx, %rdi
	shrq	$32, %rdi
	addq	%rdi, %r9
	shrq	$32, %rax
	addq	%r8, %rax
	movl	%ebx, %edi
	shrq	$32, %rcx
	addq	%rcx, %rax
	movq	%r9, %rcx
	shlq	$32, %r9
	orq	%r9, %rdi
	shrq	$32, %rcx
	mulxq	(%r11), %rdx, %rdx
	addq	%rdi, %rdx
	adcq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$32, %rcx
	imulq	$1099511627, %rcx, %rdx
	movl	%eax, %edi
	imulq	$1099511627, %rdi, %r12
	addq	$755914244, %r15
	imulq	%r15, %rcx
	imulq	%rdi, %r15
	shrq	$32, %r15
	movl	%r12d, %r8d
	addq	%r15, %r8
	movl	%ecx, %edi
	andl	$-2, %edi
	addq	%rdi, %r8
	shrq	$32, %r12
	addq	%rdx, %r12
	shrq	$32, %rcx
	addq	%rcx, %r12
	leaq	-1(%r10), %rdi
	shrq	$32, %r8
	addq	%r8, %r12
	shrq	$8, %r12
	imulq	$-1000, %r12, %rbx
	addq	%rax, %rbx
	leaq	1(%r14), %r8
	cmpq	%rbp, %rbx
	jae	.LBB8_27
.LBB8_26:
	movabsq	$28999941890838049, %rax
	imulq	%r12, %rax
	shrq	$8, %rax
	movabsq	$2377900603251621888, %rcx
	imulq	%r12, %rcx
	orq	%rax, %rcx
	movabsq	$184467440738, %rdx
	xorl	%eax, %eax
	cmpq	%rdx, %rcx
	setb	%al
	cmovaeq	%r12, %rcx
	movabsq	$182622766329724561, %rdx
	imulq	%rcx, %rdx
	shrdq	$4, %rcx, %rdx
	movabsq	$1844674407370956, %rsi
	xorl	%edi, %edi
	cmpq	%rsi, %rdx
	setb	%dil
	cmovaeq	%rcx, %rdx
	movabsq	$-8116567392432202711, %rcx
	imulq	%rdx, %rcx
	shrdq	$2, %rdx, %rcx
	movabsq	$184467440737095517, %rsi
	xorl	%r14d, %r14d
	cmpq	%rsi, %rcx
	setb	%r14b
	cmovaeq	%rdx, %rcx
	movabsq	$-3689348814741910323, %r11
	imulq	%rcx, %r11
	shrdq	$1, %rcx, %r11
	shll	$2, %edi
	leal	(%rdi,%rax,8), %eax
	addl	%r14d, %r14d
	addq	%r8, %rax
	movabsq	$1844674407370955162, %rdx
	cmpq	%rdx, %r11
	cmovaeq	%rcx, %r11
	adcq	%rax, %r14
	jmp	.LBB8_31
.LBB8_5:
	movq	8(%rsp), %rbx
	movq	4096(%rbx), %rdx
	leaq	4(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_7
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_7:
	movl	$1718511917, (%rbx,%rdx)
	movl	$4, %eax
	addq	%rax, 4096(%rbx)
	jmp	.LBB8_98
.LBB8_10:
	movq	8(%rsp), %rbx
	movq	4096(%rbx), %rdx
	testq	%rax, %rax
	jns	.LBB8_14
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_13
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_13:
	movb	$45, (%rbx,%rdx)
	movq	4096(%rbx), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rbx)
.LBB8_14:
	leaq	3(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_16
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_16:
	movw	$11824, (%rbx,%rdx)
	movb	$48, 2(%rbx,%rdx)
	addq	$3, 4096(%rbx)
	jmp	.LBB8_98
.LBB8_18:
	movq	8(%rsp), %r15
	movq	4096(%r15), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_20
	movq	4104(%r15), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	movq	%r10, 64(%rsp)
	callq	write@PLT
	movq	64(%rsp), %r10
	movq	$0, 4096(%r15)
	xorl	%edx, %edx
.LBB8_20:
	movb	$45, (%r15,%rdx)
	incq	4096(%r15)
	leaq	global_constant_0(%rip), %r11
	movl	$2576980378, %r15d
	testb	%r14b, %r14b
	jne	.LBB8_25
.LBB8_22:
	imulq	$631305, %r12, %r14
	addq	$-678914538, %r14
	sarq	$21, %r14
	movl	$2576980378, %ebp
	movl	$292, %r15d
	imulq	$-1741647, %r14, %rax
	subq	%r14, %r15
	sarq	$19, %rax
	leaq	-1075(%rax,%r12), %rax
	movb	%bl, %r13b
	movq	%rax, %rbx
	movq	%r15, %rdi
	movq	%rax, %rsi
	movl	$1, %edx
	callq	"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128"@PLT
	movq	%rax, %r12
	movq	%r15, %rdi
	movq	%rbx, %rsi
	xorl	%edx, %edx
	callq	"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128"@PLT
	addq	%r13, %r12
	movl	%eax, %edx
	movq	%rax, %rcx
	shrq	$32, %rcx
	imulq	$429496729, %rcx, %rsi
	imulq	$429496729, %rdx, %rax
	imulq	%rbp, %rcx
	imulq	%rbp, %rdx
	shrq	$32, %rdx
	movl	%ecx, %edi
	andl	$-2, %edi
	movl	%eax, %r8d
	addq	%rdx, %r8
	addq	%rdi, %r8
	shrq	$32, %r8
	shrq	$32, %rcx
	shrq	$32, %rax
	addq	%rsi, %rax
	addq	%rcx, %rax
	addq	%r8, %rax
	leaq	(%rax,%rax), %rcx
	leaq	(%rcx,%rcx,4), %rcx
	cmpq	%r12, %rcx
	jae	.LBB8_23
	shlq	$4, %r15
	movl	$10, %eax
	leaq	global_constant_0(%rip), %rbp
	addq	%r15, %rbp
	subq	%rbx, %rax
	shrxq	%rax, 8(%rbp), %r11
	incq	%r11
	shrq	%r11
	cmpq	%r12, %r11
	adcq	$0, %r11
	jmp	.LBB8_31
.LBB8_27:
	jne	.LBB8_29
	movq	%r13, %rdx
	movq	%rbp, 64(%rsp)
	movq	%rsi, %rbp
	movq	%r10, %r15
	callq	"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64"@PLT
	leaq	1(%r14), %r8
	movq	%r15, %r10
	movq	%rbp, %rsi
	movq	64(%rsp), %rbp
	orb	%al, %dl
	testb	$1, %dl
	jne	.LBB8_26
.LBB8_29:
	leaq	(%r12,%r12,4), %rax
	shrq	%rbp
	subq	%rbp, %rbx
	imull	$656, %ebx, %ecx
	addl	$32800, %ecx
	movzwl	%cx, %edx
	shrl	$16, %ecx
	leaq	(%rcx,%rax,2), %r11
	cmpl	$655, %edx
	ja	.LBB8_31
	movq	%r10, %rdi
	movq	%r13, %rdx
	movq	%r11, %r15
	callq	"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64"@PLT
	movq	%r15, %r11
	xorb	%bl, %al
	movzbl	%al, %eax
	andl	$1, %eax
	subq	%rax, %r11
	jmp	.LBB8_31
.LBB8_23:
	incq	%r14
	movabsq	$28999941890838049, %rcx
	imulq	%rax, %rcx
	shrq	$8, %rcx
	movabsq	$2377900603251621888, %rdx
	imulq	%rax, %rdx
	orq	%rcx, %rdx
	movabsq	$184467440738, %rsi
	xorl	%ecx, %ecx
	cmpq	%rsi, %rdx
	setb	%cl
	cmovaeq	%rax, %rdx
	movabsq	$182622766329724561, %rsi
	imulq	%rdx, %rsi
	shrdq	$4, %rdx, %rsi
	movabsq	$1844674407370956, %rax
	xorl	%edi, %edi
	cmpq	%rax, %rsi
	setb	%dil
	cmovaeq	%rdx, %rsi
	movabsq	$-8116567392432202711, %rax
	imulq	%rsi, %rax
	shrdq	$2, %rsi, %rax
	movabsq	$184467440737095517, %rdx
	xorl	%r8d, %r8d
	cmpq	%rdx, %rax
	setb	%r8b
	cmovaeq	%rsi, %rax
	movabsq	$-3689348814741910323, %r11
	imulq	%rax, %r11
	shrdq	$1, %rax, %r11
	shll	$2, %edi
	leal	(%rdi,%rcx,8), %ecx
	addq	%r14, %rcx
	addl	%r8d, %r8d
	movabsq	$1844674407370955162, %rdx
	cmpq	%rdx, %r11
	cmovaeq	%rax, %r11
	adcq	%rcx, %r8
	movq	%r8, %r14
.LBB8_31:
	movq	8(%rsp), %r12
	movabsq	$2305843009213693952, %r13
	movq	%r14, %r10
	negq	%r10
	cmovsq	%r14, %r10
	xorl	%ebp, %ebp
	testq	%r11, %r11
	je	.LBB8_37
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	leaq	static_string_a0fcf35b7349c924(%rip), %rcx
	movabsq	$-3689348814741910323, %rsi
	movq	%r11, %rdx
	.p2align	4
.LBB8_33:
	movq	$6, 24(%rsp)
	movq	%rax, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r13, 56(%rsp)
	cmpq	$21, %rbp
	je	.LBB8_34
	mulxq	%rsi, %rdi, %rdi
	shrq	$3, %rdi
	leal	(%rdi,%rdi), %r8d
	leal	(%r8,%r8,4), %r8d
	movl	%edx, %r9d
	subl	%r8d, %r9d
	movb	%r9b, 75(%rsp,%rbp)
	incq	%rbp
	cmpq	$10, %rdx
	sbbq	$-1, %r14
	cmpq	$9, %rdx
	movq	%rdi, %rdx
	ja	.LBB8_33
.LBB8_37:
	leaq	-1(%rbp), %r15
	subq	%rbp, %r10
	testq	%r14, %r14
	sets	%al
	cmpq	$4, %r10
	setge	%cl
	cmpq	$15, %r14
	jg	.LBB8_39
	andb	%cl, %al
	jne	.LBB8_39
	testq	%r14, %r14
	sets	%al
	testq	%r10, %r10
	setg	%cl
	testb	%cl, %al
	je	.LBB8_74
	movq	%r10, %rax
	sarq	$63, %rax
	andnq	%r10, %rax, %r14
	movq	4096(%r12), %rdx
	leaq	2(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_101
	movq	4104(%r12), %rax
	movq	(%rax), %rdi
	movq	%r12, %rsi
	callq	write@PLT
	movq	$0, 4096(%r12)
	xorl	%edx, %edx
.LBB8_101:
	movw	$11824, (%r12,%rdx)
	movq	4096(%r12), %rdx
	addq	$2, %rdx
	movq	%rdx, 4096(%r12)
	xorl	%ebx, %ebx
	subq	$1, %r14
	cmovaeq	%r14, %rbx
	incq	%rbx
	jmp	.LBB8_102
	.p2align	4
.LBB8_104:
	movb	$48, (%r12,%rdx)
	movq	4096(%r12), %rdx
	incq	%rdx
	movq	%rdx, 4096(%r12)
	decq	%rbx
	je	.LBB8_105
.LBB8_102:
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_104
	movq	4104(%r12), %rax
	movq	(%rax), %rdi
	movq	%r12, %rsi
	callq	write@PLT
	movq	$0, 4096(%r12)
	xorl	%edx, %edx
	jmp	.LBB8_104
.LBB8_39:
	cmpq	$9, %r11
	ja	.LBB8_41
	movq	%r11, %rdi
	movq	%r12, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	cmpq	$2, %rbp
	jge	.LBB8_50
	jmp	.LBB8_55
.LBB8_41:
	movq	$6, 24(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	%r13, 56(%rsp)
	cmpq	$21, %r15
	jae	.LBB8_42
	movzbl	75(%rsp,%r15), %edi
	movq	%r12, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4096(%r12), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_48
	movq	4104(%r12), %rax
	movq	(%rax), %rdi
	movq	%r12, %rsi
	callq	write@PLT
	movq	$0, 4096(%r12)
	xorl	%edx, %edx
.LBB8_48:
	movb	$46, (%r12,%rdx)
	incq	4096(%r12)
	cmpq	$2, %rbp
	jl	.LBB8_55
.LBB8_50:
	movq	%r15, %rax
	sarq	$63, %rax
	andnq	%r15, %rax, %r15
	decq	%r15
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rbx
	leaq	static_string_a0fcf35b7349c924(%rip), %r12
	.p2align	4
.LBB8_51:
	movq	$6, 24(%rsp)
	movq	%rbx, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	movq	%r12, 40(%rsp)
	movq	%r13, 56(%rsp)
	cmpq	$21, %r15
	jae	.LBB8_52
	movzbl	75(%rsp,%r15), %edi
	movq	8(%rsp), %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	decq	%r15
	jns	.LBB8_51
.LBB8_55:
	testq	%r14, %r14
	js	.LBB8_56
	movq	8(%rsp), %r15
	movq	4096(%r15), %rdx
	leaq	2(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_61
	movq	4104(%r15), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	callq	write@PLT
	movq	$0, 4096(%r15)
	xorl	%edx, %edx
.LBB8_61:
	movw	$11109, (%r15,%rdx)
	movq	4096(%r15), %rdx
	addq	$2, %rdx
	movq	%rdx, 4096(%r15)
	cmpq	$10, %r14
	jl	.LBB8_63
	jmp	.LBB8_66
.LBB8_74:
	testq	%rbp, %rbp
	jle	.LBB8_75
	cmpq	$20, %r15
	ja	.LBB8_110
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	movq	%r10, 64(%rsp)
	jmp	.LBB8_78
	.p2align	4
.LBB8_86:
	movq	8(%rsp), %r15
	movq	4104(%r15), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	callq	write@PLT
	movq	$0, 4096(%r15)
	xorl	%edx, %edx
.LBB8_87:
	movb	$46, (%r15,%rdx)
	incq	4096(%r15)
	movq	96(%rsp), %r15
.LBB8_88:
	orb	%bl, %r13b
	movzbl	75(%rsp,%r15), %edi
	movq	8(%rsp), %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	incq	%r12
	decq	%r15
	movq	64(%rsp), %r10
	js	.LBB8_89
.LBB8_78:
	testq	%r10, %r10
	setle	%al
	leaq	1(%r14), %rcx
	cmpq	%r12, %rcx
	sete	%bl
	andb	%al, %bl
	cmpb	$1, %bl
	jne	.LBB8_88
	movq	8(%rsp), %rax
	movq	4096(%rax), %rdx
	testq	%r12, %r12
	je	.LBB8_80
	movq	%r15, 96(%rsp)
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jge	.LBB8_86
	jmp	.LBB8_85
.LBB8_80:
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_81
	movq	8(%rsp), %rsi
	movq	4104(%rsi), %rax
	movq	(%rax), %rdi
	callq	write@PLT
	movq	8(%rsp), %rax
	movq	$0, 4096(%rax)
	xorl	%edx, %edx
	jmp	.LBB8_83
.LBB8_81:
	movq	8(%rsp), %rax
.LBB8_83:
	movb	$48, (%rax,%rdx)
	movq	4096(%rax), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rax)
	movq	%r15, 96(%rsp)
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jge	.LBB8_86
.LBB8_85:
	movq	8(%rsp), %r15
	jmp	.LBB8_87
.LBB8_105:
	testq	%rbp, %rbp
	jle	.LBB8_98
	cmpq	$20, %r15
	ja	.LBB8_108
	.p2align	4
.LBB8_107:
	movzbl	75(%rsp,%r15), %edi
	movq	%r12, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	decq	%r15
	jns	.LBB8_107
	jmp	.LBB8_98
.LBB8_56:
	movq	8(%rsp), %r15
	movq	4096(%r15), %rdx
	leaq	2(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_58
	movq	4104(%r15), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	callq	write@PLT
	movq	$0, 4096(%r15)
	xorl	%edx, %edx
.LBB8_58:
	movw	$11621, (%r15,%rdx)
	movq	4096(%r15), %rdx
	addq	$2, %rdx
	movq	%rdx, 4096(%r15)
	negq	%r14
	cmpq	$10, %r14
	jge	.LBB8_66
.LBB8_63:
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_65
	movq	4104(%r15), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	callq	write@PLT
	movq	$0, 4096(%r15)
	xorl	%edx, %edx
.LBB8_65:
	movb	$48, (%r15,%rdx)
	incq	4096(%r15)
	testq	%r14, %r14
	jle	.LBB8_98
.LBB8_66:
	xorl	%ebx, %ebx
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	leaq	static_string_a0fcf35b7349c924(%rip), %rcx
	movabsq	$-3689348814741910323, %rsi
	.p2align	4
.LBB8_67:
	movq	$6, 24(%rsp)
	movq	%rax, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r13, 56(%rsp)
	cmpq	$10, %rbx
	je	.LBB8_68
	movq	%r14, %rdx
	mulxq	%rsi, %rdx, %rdx
	shrq	$3, %rdx
	imull	$246, %edx, %edi
	addl	%r14d, %edi
	movb	%dil, 75(%rsp,%rbx)
	incq	%rbx
	cmpq	$9, %r14
	movq	%rdx, %r14
	ja	.LBB8_67
	leaq	-1(%rbx), %r14
	.p2align	4
.LBB8_72:
	movzbl	74(%rsp,%rbx), %edi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	decq	%rbx
	decq	%r14
	jns	.LBB8_72
	jmp	.LBB8_98
.LBB8_75:
	xorl	%r13d, %r13d
.LBB8_89:
	movq	%r14, %rax
	subq	%rbp, %rax
	movabsq	$9223372036854775806, %rcx
	cmpq	%rcx, %rax
	movq	8(%rsp), %rbx
	jbe	.LBB8_90
.LBB8_94:
	testb	$1, %r13b
	jne	.LBB8_98
	movq	4096(%rbx), %rdx
	leaq	2(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_97
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_97:
	movw	$12334, (%rbx,%rdx)
	addq	$2, 4096(%rbx)
.LBB8_98:
	addq	$2152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB8_90:
	.cfi_def_cfa_offset 2208
	movq	4096(%rbx), %rdx
	notq	%r14
	addq	%rbp, %r14
	jmp	.LBB8_91
	.p2align	4
.LBB8_93:
	movb	$48, (%rbx,%rdx)
	movq	4096(%rbx), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rbx)
	incq	%r14
	je	.LBB8_94
.LBB8_91:
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_93
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
	jmp	.LBB8_93
.LBB8_34:
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$21, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$20, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB8_120
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$263, %esi
	movl	$19, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB8_68:
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$10, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$9, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB8_120
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$294, %esi
	movl	$27, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB8_52:
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$20, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB8_53
.LBB8_120:
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB8_53:
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$281, %esi
	movl	$36, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB8_119:
	leaq	static_string_e5411518d45eb182(%rip), %rsi
	movl	$3, %edx
	movq	8(%rsp), %rdi
	addq	$2152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
.LBB8_42:
	.cfi_def_cfa_offset 2208
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$20, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB8_120
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$277, %esi
	movl	$36, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB8_110:
	testq	%r10, %r10
	jg	.LBB8_117
	cmpq	$-1, %r14
	jne	.LBB8_117
	movq	8(%rsp), %rax
	movq	4096(%rax), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB8_114
	movq	8(%rsp), %rbx
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_114:
	movq	8(%rsp), %rcx
	movb	$48, (%rcx,%rdx)
	movq	4096(%rcx), %rax
	leaq	1(%rax), %rdx
	movq	%rdx, 4096(%rcx)
	addq	$2, %rax
	cmpq	$4097, %rax
	jl	.LBB8_116
	movq	8(%rsp), %rbx
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB8_116:
	movq	8(%rsp), %rax
	movb	$46, (%rax,%rdx)
	incq	4096(%rax)
.LBB8_117:
	movq	$6, 24(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	%r13, 56(%rsp)
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$20, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB8_120
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$316, %esi
	movl	$36, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.LBB8_108:
	movq	$6, 24(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, 16(%rsp)
	movq	%r13, 32(%rsp)
	movq	$39, 48(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	%r13, 56(%rsp)
	leaq	16(%rsp), %rdi
	leaq	104(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	40(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$20, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB8_120
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$305, %esi
	movl	$36, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end8:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=f64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end8-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=f64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end9, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$104, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	testq	%rdi, %rdi
	js	.LBB9_1
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	testq	%r14, %r14
	je	.LBB9_9
	movb	$0, 96(%rsp)
	movl	$63, %ecx
	movabsq	$-3689348814741910323, %rax
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB9_11:
	movq	%r14, %rdx
	mulxq	%rax, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %rdi
	leaq	(%rdi,%rdi,4), %rdi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movzbl	(%r8,%r14), %edi
	movb	%dil, 32(%rsp,%rcx)
	decq	%rcx
	cmpq	$10, %r14
	movq	%rdx, %r14
	jae	.LBB9_11
.LBB9_12:
	leaq	1(%rcx), %rax
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	addq	$-64, %rcx
	movl	$64, %edx
	cmpq	$-66, %rcx
	ja	.LBB9_14
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rdi
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
.LBB9_14:
	leaq	32(%rsp,%rax), %rsi
	subq	%rax, %rdx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB9_1:
	.cfi_def_cfa_offset 128
	movq	$1, 40(%rsp)
	leaq	static_string_a8e3dd8c929b6eb8(%rip), %rax
	movq	%rax, 32(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 48(%rsp)
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	testb	$64, 55(%rsp)
	je	.LBB9_4
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB9_4
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB9_4:
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	movb	$0, 96(%rsp)
	movl	$63, %ecx
	movabsq	$-7378697629483820647, %rsi
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	jmp	.LBB9_5
	.p2align	4
.LBB9_7:
	movq	%r8, %r9
	negq	%r9
	cmovsq	%r8, %r9
	movzbl	(%r9,%rdi), %r8d
	movb	%r8b, 32(%rsp,%rcx)
	decq	%rcx
	movzbl	%al, %r14d
	subq	%rdx, %r14
	je	.LBB9_12
.LBB9_5:
	movq	%r14, %rax
	imulq	%rsi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %r8
	testq	%r14, %r14
	setns	%r9b
	addq	%r14, %r8
	setne	%al
	andb	%r9b, %al
	je	.LBB9_7
	addq	$-10, %r8
	jmp	.LBB9_7
.LBB9_9:
	leaq	32(%rsp), %rsi
	movw	$48, 32(%rsp)
	movl	$1, %edx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end9:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]", .Lfunc_end9-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end10, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -16
	movq	%rsi, %rbx
	testq	%rdi, %rdi
	je	.LBB10_1
	movq	%rdi, %rcx
	leaq	24(%rsp), %r10
	leaq	16(%rsp), %rdi
	js	.LBB10_8
	movl	$64, %eax
	movabsq	$-3689348814741910323, %rsi
	.p2align	4
.LBB10_4:
	movq	%rcx, %rdx
	mulxq	%rsi, %rdx, %rdx
	shrq	$3, %rdx
	decq	%rax
	cmpq	$10, %rcx
	movq	%rdx, %rcx
	jae	.LBB10_4
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %ecx
	cmpq	$64, %rax
	jbe	.LBB10_7
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r10, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rcx
.LBB10_7:
	subq	%rax, %rcx
	addq	%rcx, %rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB10_1:
	.cfi_def_cfa_offset 48
	incq	%rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB10_8:
	.cfi_def_cfa_offset 48
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rax, %rbx
	movl	$64, %esi
	movabsq	$-7378697629483820647, %r8
	.p2align	4
.LBB10_9:
	movq	%rcx, %rax
	imulq	%r8
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %rax
	addq	%rcx, %rax
	setne	%al
	testq	%rcx, %rcx
	setns	%cl
	andb	%al, %cl
	movzbl	%cl, %ecx
	decq	%rsi
	subq	%rdx, %rcx
	jne	.LBB10_9
	movq	%rsi, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %eax
	cmpq	$65, %rsi
	jb	.LBB10_12
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r10, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rax
.LBB10_12:
	subq	%rsi, %rax
	addq	%rax, %rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end10:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]", .Lfunc_end10-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end11, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rbx
	testq	%rdi, %rdi
	je	.LBB11_1
	movq	%rdi, %r14
	jns	.LBB11_6
	movq	$1, 40(%rsp)
	leaq	static_string_a8e3dd8c929b6eb8(%rip), %rax
	movq	%rax, 32(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 48(%rsp)
	leaq	32(%rsp), %rdi
	movq	%rbx, %rdx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rax, %rsi
	movq	%rdx, %rbx
.LBB11_6:
	cmpq	$2049, %rbx
	jge	.LBB11_30
	movb	$0, 96(%rsp)
	movl	$63, %ecx
	testq	%r14, %r14
	js	.LBB11_8
	movabsq	$-3689348814741910323, %rax
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	.p2align	4
.LBB11_13:
	movq	%r14, %rdx
	mulxq	%rax, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %r8
	leaq	(%r8,%r8,4), %r8
	movq	%rdi, %r9
	subq	%r8, %r9
	movzbl	(%r9,%r14), %r8d
	movb	%r8b, 32(%rsp,%rcx)
	decq	%rcx
	cmpq	$10, %r14
	movq	%rdx, %r14
	jae	.LBB11_13
.LBB11_14:
	leaq	1(%rcx), %rax
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	addq	$-64, %rcx
	movl	$64, %edi
	cmpq	$-66, %rcx
	ja	.LBB11_16
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rdi
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movq	%rsi, %r14
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	%r14, %rsi
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdi
.LBB11_16:
	movq	%rdi, %r14
	subq	%rax, %r14
	leaq	(%r14,%rbx), %rdx
	cmpq	$2049, %rdx
	jge	.LBB11_30
	cmpq	%rax, %rdi
	je	.LBB11_29
	addq	%rsi, %rbx
	leaq	32(%rsp,%rax), %r15
	cmpq	$4, %r14
	jg	.LBB11_21
	movzbl	(%r15), %eax
	movb	%al, (%rbx)
	movzbl	-1(%r15,%r14), %eax
	movb	%al, -1(%rbx,%r14)
	cmpq	$3, %r14
	jl	.LBB11_29
	movzbl	1(%r15), %eax
	movb	%al, 1(%rbx)
	movzbl	-2(%r15,%r14), %eax
	movb	%al, -2(%rbx,%r14)
	jmp	.LBB11_29
.LBB11_1:
	cmpq	$2048, %rbx
	jg	.LBB11_30
	cmpq	$2048, %rbx
	je	.LBB11_30
	leaq	1(%rbx), %rdx
	movb	$48, (%rsi,%rbx)
.LBB11_29:
	movq	%rsi, %rax
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB11_8:
	.cfi_def_cfa_offset 160
	movabsq	$-7378697629483820647, %rdi
	leaq	static_string_978d8d34847e5196(%rip), %r8
	jmp	.LBB11_9
	.p2align	4
.LBB11_11:
	movq	%r9, %r10
	negq	%r10
	cmovsq	%r9, %r10
	movzbl	(%r10,%r8), %r9d
	movb	%r9b, 32(%rsp,%rcx)
	decq	%rcx
	movzbl	%al, %r14d
	subq	%rdx, %r14
	je	.LBB11_14
.LBB11_9:
	movq	%r14, %rax
	imulq	%rdi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %r9
	testq	%r14, %r14
	setns	%r10b
	addq	%r14, %r9
	setne	%al
	andb	%r10b, %al
	je	.LBB11_11
	addq	$-10, %r9
	jmp	.LBB11_11
.LBB11_21:
	cmpq	$16, %r14
	jg	.LBB11_25
	cmpq	$8, %r14
	jl	.LBB11_24
	movq	(%r15), %rax
	movq	%rax, (%rbx)
	movq	-8(%r15,%r14), %rax
	movq	%rax, -8(%rbx,%r14)
	jmp	.LBB11_29
.LBB11_25:
	movabsq	$9223372036854775776, %r12
	andq	%r14, %r12
	je	.LBB11_27
	movq	%rbx, %rdi
	movq	%rsi, %r13
	movq	%r15, %rsi
	movq	%rdx, %rbp
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	%rbp, %rdx
	movq	%r13, %rsi
.LBB11_27:
	cmpq	%r14, %r12
	je	.LBB11_29
	addq	%r12, %rbx
	addq	%r12, %r15
	andl	$31, %r14d
	movq	%rbx, %rdi
	movq	%rsi, %rbx
	movq	%r15, %rsi
	movq	%rdx, %r15
	movq	%r14, %rdx
	callq	memcpy@PLT
	movq	%r15, %rdx
	movq	%rbx, %rsi
	jmp	.LBB11_29
.LBB11_24:
	movl	(%r15), %eax
	movl	%eax, (%rbx)
	movl	-4(%r15,%r14), %eax
	movl	%eax, -4(%rbx,%r14)
	jmp	.LBB11_29
.LBB11_30:
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.Lfunc_end11:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]", .Lfunc_end11-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end12, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$104, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %rbx
	movq	%rdi, %r12
	leaq	24(%rsp), %r14
	leaq	16(%rsp), %r15
	testq	%rdi, %rdi
	js	.LBB12_1
	movq	4096(%rbx), %rdx
	je	.LBB12_13
	cmpq	$4097, %rdx
	jl	.LBB12_18
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
.LBB12_18:
	movb	$0, 103(%rsp)
	movl	$64, %eax
	movabsq	$-3689348814741910323, %rcx
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB12_19:
	movq	%r12, %rdx
	mulxq	%rcx, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %rdi
	leaq	(%rdi,%rdi,4), %rdi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movzbl	(%r8,%r12), %edi
	movb	%dil, 38(%rsp,%rax)
	decq	%rax
	cmpq	$9, %r12
	movq	%rdx, %r12
	ja	.LBB12_19
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$65, %rax
	jb	.LBB12_22
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
.LBB12_22:
	leaq	39(%rsp,%rax), %rsi
	subq	%rax, %rdx
	jmp	.LBB12_23
.LBB12_1:
	movq	4096(%rbx), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB12_3
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB12_3:
	movb	$45, (%rbx,%rdx)
	movq	4096(%rbx), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rbx)
	cmpq	$4097, %rdx
	jl	.LBB12_5
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
.LBB12_5:
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	movabsq	$-7378697629483820647, %rsi
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	jmp	.LBB12_6
	.p2align	4
.LBB12_8:
	movq	%rax, %r9
	negq	%r9
	cmovsq	%rax, %r9
	movzbl	(%r9,%rdi), %eax
	movb	%al, 38(%rsp,%rcx)
	movzbl	%r8b, %r12d
	decq	%rcx
	subq	%rdx, %r12
	je	.LBB12_9
.LBB12_6:
	movq	%r12, %rax
	imulq	%rsi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %rax
	testq	%r12, %r12
	setns	%r9b
	addq	%r12, %rax
	setne	%r8b
	andb	%r9b, %r8b
	je	.LBB12_8
	addq	$-10, %rax
	jmp	.LBB12_8
.LBB12_9:
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$64, %rcx
	jbe	.LBB12_11
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rdx
.LBB12_11:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rdx
.LBB12_23:
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	jmp	.LBB12_24
.LBB12_13:
	cmpq	$4096, %rdx
	jl	.LBB12_15
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB12_15:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
.LBB12_24:
	addq	$104, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end12:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end12-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end13, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$104, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %rbx
	movq	%rdi, %r12
	leaq	24(%rsp), %r14
	leaq	16(%rsp), %r15
	movq	4096(%rsi), %rdx
	testq	%rdi, %rdi
	js	.LBB13_1
	cmpq	$4096, %rdx
	jle	.LBB13_13
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	testq	%r12, %r12
	jne	.LBB13_19
	jmp	.LBB13_17
.LBB13_1:
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB13_3
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB13_3:
	movb	$45, (%rbx,%rdx)
	movq	4096(%rbx), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rbx)
	cmpq	$4097, %rdx
	jl	.LBB13_5
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
.LBB13_5:
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	movabsq	$-7378697629483820647, %rsi
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	jmp	.LBB13_6
	.p2align	4
.LBB13_8:
	movq	%rax, %r9
	negq	%r9
	cmovsq	%rax, %r9
	movzbl	(%r9,%rdi), %eax
	movb	%al, 38(%rsp,%rcx)
	movzbl	%r8b, %r12d
	decq	%rcx
	subq	%rdx, %r12
	je	.LBB13_9
.LBB13_6:
	movq	%r12, %rax
	imulq	%rsi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %rax
	testq	%r12, %r12
	setns	%r9b
	addq	%r12, %rax
	setne	%r8b
	andb	%r9b, %r8b
	je	.LBB13_8
	addq	$-10, %rax
	jmp	.LBB13_8
.LBB13_9:
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$64, %rcx
	jbe	.LBB13_11
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rdx
.LBB13_11:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rdx
	jmp	.LBB13_24
.LBB13_13:
	testq	%r12, %r12
	je	.LBB13_14
.LBB13_19:
	movb	$0, 103(%rsp)
	movl	$64, %eax
	movabsq	$-3689348814741910323, %rcx
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB13_20:
	movq	%r12, %rdx
	mulxq	%rcx, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %rdi
	leaq	(%rdi,%rdi,4), %rdi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movzbl	(%r8,%r12), %edi
	movb	%dil, 38(%rsp,%rax)
	decq	%rax
	cmpq	$9, %r12
	movq	%rdx, %r12
	ja	.LBB13_20
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$65, %rax
	jb	.LBB13_23
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
.LBB13_23:
	leaq	39(%rsp,%rax), %rsi
	subq	%rax, %rdx
.LBB13_24:
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	jmp	.LBB13_25
.LBB13_14:
	cmpq	$4096, %rdx
	jne	.LBB13_18
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movl	$4096, %edx
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
.LBB13_17:
	xorl	%edx, %edx
.LBB13_18:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
.LBB13_25:
	addq	$104, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end13:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end13-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end14, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$104, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	testq	%rdi, %rdi
	js	.LBB14_1
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	testq	%r14, %r14
	je	.LBB14_9
	movb	$0, 96(%rsp)
	movl	$63, %ecx
	movabsq	$-3689348814741910323, %rax
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB14_11:
	movq	%r14, %rdx
	mulxq	%rax, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %rdi
	leaq	(%rdi,%rdi,4), %rdi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movzbl	(%r8,%r14), %edi
	movb	%dil, 32(%rsp,%rcx)
	decq	%rcx
	cmpq	$10, %r14
	movq	%rdx, %r14
	jae	.LBB14_11
.LBB14_12:
	leaq	1(%rcx), %rax
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	addq	$-64, %rcx
	movl	$64, %edx
	cmpq	$-66, %rcx
	ja	.LBB14_14
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rdi
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
.LBB14_14:
	leaq	32(%rsp,%rax), %rsi
	subq	%rax, %rdx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB14_1:
	.cfi_def_cfa_offset 128
	movq	$1, 40(%rsp)
	leaq	static_string_a8e3dd8c929b6eb8(%rip), %rax
	movq	%rax, 32(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 48(%rsp)
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	testb	$64, 55(%rsp)
	je	.LBB14_4
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB14_4
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB14_4:
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	movb	$0, 96(%rsp)
	movl	$63, %ecx
	movabsq	$-7378697629483820647, %rsi
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	jmp	.LBB14_5
	.p2align	4
.LBB14_7:
	movq	%r8, %r9
	negq	%r9
	cmovsq	%r8, %r9
	movzbl	(%r9,%rdi), %r8d
	movb	%r8b, 32(%rsp,%rcx)
	decq	%rcx
	movzbl	%al, %r14d
	subq	%rdx, %r14
	je	.LBB14_12
.LBB14_5:
	movq	%r14, %rax
	imulq	%rsi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %r8
	testq	%r14, %r14
	setns	%r9b
	addq	%r14, %r8
	setne	%al
	andb	%r9b, %al
	je	.LBB14_7
	addq	$-10, %r8
	jmp	.LBB14_7
.LBB14_9:
	leaq	32(%rsp), %rsi
	movw	$48, 32(%rsp)
	movl	$1, %edx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end14:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]", .Lfunc_end14-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end15, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -16
	movq	%rsi, %rbx
	testq	%rdi, %rdi
	je	.LBB15_1
	movq	%rdi, %rcx
	leaq	24(%rsp), %r10
	leaq	16(%rsp), %rdi
	js	.LBB15_8
	movl	$64, %eax
	movabsq	$-3689348814741910323, %rsi
	.p2align	4
.LBB15_4:
	movq	%rcx, %rdx
	mulxq	%rsi, %rdx, %rdx
	shrq	$3, %rdx
	decq	%rax
	cmpq	$10, %rcx
	movq	%rdx, %rcx
	jae	.LBB15_4
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %ecx
	cmpq	$64, %rax
	jbe	.LBB15_7
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r10, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rcx
.LBB15_7:
	subq	%rax, %rcx
	addq	%rcx, %rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB15_1:
	.cfi_def_cfa_offset 48
	incq	%rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB15_8:
	.cfi_def_cfa_offset 48
	movq	%rcx, %rax
	shrq	$63, %rax
	addq	%rax, %rbx
	movl	$64, %esi
	movabsq	$-7378697629483820647, %r8
	.p2align	4
.LBB15_9:
	movq	%rcx, %rax
	imulq	%r8
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %rax
	addq	%rcx, %rax
	setne	%al
	testq	%rcx, %rcx
	setns	%cl
	andb	%al, %cl
	movzbl	%cl, %ecx
	decq	%rsi
	subq	%rdx, %rcx
	jne	.LBB15_9
	movq	%rsi, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %eax
	cmpq	$65, %rsi
	jb	.LBB15_12
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r10, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rsi
	movq	24(%rsp), %rax
.LBB15_12:
	subq	%rsi, %rax
	addq	%rax, %rbx
	movq	%rbx, %rax
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end15:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]", .Lfunc_end15-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end16, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$104, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %rbx
	movq	%rdi, %r12
	leaq	24(%rsp), %r14
	leaq	16(%rsp), %r15
	testq	%rdi, %rdi
	js	.LBB16_1
	movq	4096(%rbx), %rdx
	je	.LBB16_13
	cmpq	$4097, %rdx
	jl	.LBB16_18
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
.LBB16_18:
	movb	$0, 103(%rsp)
	movl	$64, %eax
	movabsq	$-3689348814741910323, %rcx
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB16_19:
	movq	%r12, %rdx
	mulxq	%rcx, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %rdi
	leaq	(%rdi,%rdi,4), %rdi
	movq	%rsi, %r8
	subq	%rdi, %r8
	movzbl	(%r8,%r12), %edi
	movb	%dil, 38(%rsp,%rax)
	decq	%rax
	cmpq	$9, %r12
	movq	%rdx, %r12
	ja	.LBB16_19
	movq	%rax, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$65, %rax
	jb	.LBB16_22
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rax
	movq	24(%rsp), %rdx
.LBB16_22:
	leaq	39(%rsp,%rax), %rsi
	subq	%rax, %rdx
	jmp	.LBB16_23
.LBB16_1:
	movq	4096(%rbx), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB16_3
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB16_3:
	movb	$45, (%rbx,%rdx)
	movq	4096(%rbx), %rdx
	incq	%rdx
	movq	%rdx, 4096(%rbx)
	cmpq	$4097, %rdx
	jl	.LBB16_5
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
.LBB16_5:
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	movabsq	$-7378697629483820647, %rsi
	leaq	static_string_978d8d34847e5196(%rip), %rdi
	jmp	.LBB16_6
	.p2align	4
.LBB16_8:
	movq	%rax, %r9
	negq	%r9
	cmovsq	%rax, %r9
	movzbl	(%r9,%rdi), %eax
	movb	%al, 38(%rsp,%rcx)
	movzbl	%r8b, %r12d
	decq	%rcx
	subq	%rdx, %r12
	je	.LBB16_9
.LBB16_6:
	movq	%r12, %rax
	imulq	%rsi
	movq	%rdx, %rax
	shrq	$63, %rax
	sarq	$2, %rdx
	addq	%rax, %rdx
	leaq	(%rdx,%rdx), %rax
	leaq	(%rax,%rax,4), %rax
	testq	%r12, %r12
	setns	%r9b
	addq	%r12, %rax
	setne	%r8b
	andb	%r9b, %r8b
	je	.LBB16_8
	addq	$-10, %rax
	jmp	.LBB16_8
.LBB16_9:
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$64, %rcx
	jbe	.LBB16_11
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rdx
.LBB16_11:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rdx
.LBB16_23:
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	jmp	.LBB16_24
.LBB16_13:
	cmpq	$4096, %rdx
	jl	.LBB16_15
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB16_15:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
.LBB16_24:
	addq	$104, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end16:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end16-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=si64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end17, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui32,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui32,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$104, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	movq	4096(%rsi), %rdx
	testl	%edi, %edi
	je	.LBB17_1
	movl	%edi, %eax
	cmpq	$4097, %rdx
	jl	.LBB17_6
	movq	4104(%rbx), %rcx
	movq	(%rcx), %rdi
	movl	%eax, %ebp
	movq	%rbx, %rsi
	callq	write@PLT
	movl	%ebp, %eax
	movq	$0, 4096(%rbx)
.LBB17_6:
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rdi
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	movl	$3435973837, %esi
	leaq	static_string_978d8d34847e5196(%rip), %r8
	.p2align	4
.LBB17_7:
	movl	%eax, %r9d
	imulq	%rsi, %r9
	shrq	$35, %r9
	leal	(%r9,%r9), %r10d
	leal	(%r10,%r10,4), %r10d
	movl	%eax, %r11d
	subl	%r10d, %r11d
	movzbl	(%r11,%r8), %r10d
	movb	%r10b, 38(%rsp,%rcx)
	decq	%rcx
	cmpl	$9, %eax
	movl	%r9d, %eax
	ja	.LBB17_7
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %eax
	cmpq	$65, %rcx
	jb	.LBB17_10
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rax
.LBB17_10:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rax
	movq	%rbx, %rdi
	movq	%rax, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB17_1:
	.cfi_def_cfa_offset 128
	cmpq	$4097, %rdx
	setl	%al
	cmpq	$4096, %rdx
	setne	%cl
	testb	%cl, %al
	jne	.LBB17_3
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB17_3:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end17:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui32,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end17-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui32,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end18, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$104, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	4096(%rsi), %rdx
	testq	%rdi, %rdi
	je	.LBB18_1
	movq	%rdi, %r14
	cmpq	$4097, %rdx
	jl	.LBB18_6
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
.LBB18_6:
	leaq	24(%rsp), %rax
	leaq	16(%rsp), %rdi
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	movabsq	$-3689348814741910323, %r8
	.p2align	4
.LBB18_7:
	movq	%r14, %rdx
	mulxq	%r8, %rdx, %rdx
	shrq	$3, %rdx
	leaq	(%rdx,%rdx), %r9
	leaq	(%r9,%r9,4), %r9
	movq	%r14, %r10
	subq	%r9, %r10
	movzbl	(%rsi,%r10), %r9d
	movb	%r9b, 38(%rsp,%rcx)
	decq	%rcx
	cmpq	$9, %r14
	movq	%rdx, %r14
	ja	.LBB18_7
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %edx
	cmpq	$65, %rcx
	jb	.LBB18_10
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	movq	%rax, %rdx
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rdx
.LBB18_10:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rdx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB18_1:
	.cfi_def_cfa_offset 128
	cmpq	$4097, %rdx
	setl	%al
	cmpq	$4096, %rdx
	setne	%cl
	testb	%cl, %al
	jne	.LBB18_3
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB18_3:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end18:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end18-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end19, nop
	.type	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$104, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movl	%edi, %eax
	movq	4096(%rsi), %rdx
	testb	%al, %al
	je	.LBB19_1
	cmpq	$4097, %rdx
	jl	.LBB19_6
	movq	4104(%rbx), %rcx
	movq	(%rcx), %rdi
	movq	%rax, %r14
	movq	%rbx, %rsi
	callq	write@PLT
	movq	%r14, %rax
	movq	$0, 4096(%rbx)
.LBB19_6:
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rdi
	movb	$0, 103(%rsp)
	movl	$64, %ecx
	leaq	static_string_978d8d34847e5196(%rip), %rsi
	.p2align	4
.LBB19_7:
	movzbl	%al, %r8d
	imull	$205, %r8d, %eax
	shrl	$11, %eax
	leal	(%rax,%rax), %r9d
	leal	(%r9,%r9,4), %r9d
	movl	%r8d, %r10d
	subb	%r9b, %r10b
	movzbl	%r10b, %r9d
	movzbl	(%r9,%rsi), %r9d
	movb	%r9b, 38(%rsp,%rcx)
	decq	%rcx
	cmpb	$9, %r8b
	ja	.LBB19_7
	movq	%rcx, 16(%rsp)
	movq	$64, 24(%rsp)
	movl	$64, %eax
	cmpq	$65, %rcx
	jb	.LBB19_10
	movq	$51, (%rsp)
	leaq	static_string_d9df22dbe27ec153(%rip), %r9
	movl	$65, %esi
	movl	$363, %ecx
	movl	$26, %r8d
	callq	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %rax
.LBB19_10:
	leaq	39(%rsp,%rcx), %rsi
	subq	%rcx, %rax
	movq	%rbx, %rdi
	movq	%rax, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB19_1:
	.cfi_def_cfa_offset 128
	cmpq	$4097, %rdx
	setl	%al
	cmpq	$4096, %rdx
	setne	%cl
	testb	%cl, %al
	jne	.LBB19_3
	movq	4104(%rbx), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB19_3:
	movb	$48, (%rbx,%rdx)
	incq	4096(%rbx)
	addq	$104, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end19:
	.size	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end19-"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui8,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end20, nop
	.type	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]",@function
"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %rbx
	movq	%rdx, %r12
	movq	%rsi, %r14
	movq	%rdi, %r15
	leaq	(,%rcx,4), %rdi
	movl	$4, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	testq	%r14, %r14
	je	.LBB20_14
	leaq	(,%r14,4), %rcx
	cmpq	$4, %rcx
	jg	.LBB20_5
	testq	%rcx, %rcx
	je	.LBB20_14
	movzbl	(%r15), %edx
	movb	%dl, (%rax)
	movzbl	-1(%r15,%rcx), %edx
	movb	%dl, -1(%rax,%rcx)
	cmpq	$3, %rcx
	jl	.LBB20_14
	movzbl	1(%r15), %edx
	movb	%dl, 1(%rax)
	movzbl	-2(%r15,%rcx), %edx
	movb	%dl, -2(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB20_15
	jmp	.LBB20_16
.LBB20_5:
	cmpq	$16, %rcx
	jg	.LBB20_9
	cmpq	$8, %rcx
	jl	.LBB20_8
	movq	(%r15), %rdx
	movq	%rdx, (%rax)
	movq	-8(%r15,%rcx), %rdx
	movq	%rdx, -8(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB20_15
	jmp	.LBB20_16
.LBB20_9:
	movabsq	$9223372036854775776, %rdx
	andq	%rcx, %rdx
	je	.LBB20_12
	xorl	%esi, %esi
	.p2align	4
.LBB20_11:
	vmovups	(%r15,%rsi), %ymm0
	vmovups	%ymm0, (%rax,%rsi)
	addq	$32, %rsi
	cmpq	%rdx, %rsi
	jb	.LBB20_11
.LBB20_12:
	cmpq	%rcx, %rdx
	je	.LBB20_14
	.p2align	4
.LBB20_13:
	movzbl	(%r15,%rdx), %esi
	movb	%sil, (%rax,%rdx)
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB20_13
.LBB20_14:
	testq	%r12, %r12
	jle	.LBB20_16
.LBB20_15:
	movq	%r15, %rdi
	movq	%rax, %r15
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r15, %rax
.LBB20_16:
	movq	%r14, %rdx
	movq	%rbx, %rcx
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB20_8:
	.cfi_def_cfa_offset 48
	movl	(%r15), %edx
	movl	%edx, (%rax)
	movl	-4(%r15,%rcx), %edx
	movl	%edx, -4(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB20_15
	jmp	.LBB20_16
.Lfunc_end20:
	.size	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]", .Lfunc_end20-"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end21, nop
	.type	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]",@function
"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %rbx
	movq	%rdx, %r12
	movq	%rsi, %r14
	movq	%rdi, %r15
	leaq	(,%rcx,4), %rdi
	movl	$4, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	testq	%r14, %r14
	je	.LBB21_14
	leaq	(,%r14,4), %rcx
	cmpq	$4, %rcx
	jg	.LBB21_5
	testq	%rcx, %rcx
	je	.LBB21_14
	movzbl	(%r15), %edx
	movb	%dl, (%rax)
	movzbl	-1(%r15,%rcx), %edx
	movb	%dl, -1(%rax,%rcx)
	cmpq	$3, %rcx
	jl	.LBB21_14
	movzbl	1(%r15), %edx
	movb	%dl, 1(%rax)
	movzbl	-2(%r15,%rcx), %edx
	movb	%dl, -2(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB21_15
	jmp	.LBB21_16
.LBB21_5:
	cmpq	$16, %rcx
	jg	.LBB21_9
	cmpq	$8, %rcx
	jl	.LBB21_8
	movq	(%r15), %rdx
	movq	%rdx, (%rax)
	movq	-8(%r15,%rcx), %rdx
	movq	%rdx, -8(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB21_15
	jmp	.LBB21_16
.LBB21_9:
	movabsq	$9223372036854775776, %rdx
	andq	%rcx, %rdx
	je	.LBB21_12
	xorl	%esi, %esi
	.p2align	4
.LBB21_11:
	vmovups	(%r15,%rsi), %ymm0
	vmovups	%ymm0, (%rax,%rsi)
	addq	$32, %rsi
	cmpq	%rdx, %rsi
	jb	.LBB21_11
.LBB21_12:
	cmpq	%rcx, %rdx
	je	.LBB21_14
	.p2align	4
.LBB21_13:
	movzbl	(%r15,%rdx), %esi
	movb	%sil, (%rax,%rdx)
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB21_13
.LBB21_14:
	testq	%r12, %r12
	jle	.LBB21_16
.LBB21_15:
	movq	%r15, %rdi
	movq	%rax, %r15
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r15, %rax
.LBB21_16:
	movq	%r14, %rdx
	movq	%rbx, %rcx
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB21_8:
	.cfi_def_cfa_offset 48
	movl	(%r15), %edx
	movl	%edx, (%rax)
	movl	-4(%r15,%rcx), %edx
	movl	%edx, -4(%rax,%rcx)
	testq	%r12, %r12
	jg	.LBB21_15
	jmp	.LBB21_16
.Lfunc_end21:
	.size	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]", .Lfunc_end21-"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end22, nop
	.type	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]",@function
"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4120, %rsp
	.cfi_def_cfa_offset 4160
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %r15
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movq	%rdi, %r12
	xorl	%esi, %esi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	addq	%rbx, %rax
	cmpq	$23, %rax
	jg	.LBB22_1
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r15)
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	addq	$4120, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB22_1:
	.cfi_def_cfa_offset 4160
	addq	$7, %rax
	movq	%rax, %rcx
	sarq	$3, %rcx
	andq	$-8, %rax
	addq	$8, %rax
	movq	%rcx, 16(%r15)
	movl	$1, %esi
	movq	%rax, %rdi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
	orb	$64, 23(%r15)
	movq	$0, 4104(%rsp)
	movq	%r15, 4112(%rsp)
	leaq	8(%rsp), %r15
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4104(%rsp), %rdx
	movq	4112(%rsp), %rdi
	movq	%r15, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4120, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end22:
	.size	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]", .Lfunc_end22-"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end23, nop
	.type	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]",@function
"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$4112, %rsp
	.cfi_def_cfa_offset 4160
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %r12
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movq	%rdi, %r15
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB23_3
	movq	8(%r15), %rdx
	movq	%rbx, %r13
	addq	%rdx, %r13
	cmpq	$24, %r13
	jge	.LBB23_6
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r12)
	movq	(%r15), %r15
	jmp	.LBB23_5
.LBB23_3:
	shrq	$56, %rdx
	andl	$31, %edx
	movq	%rbx, %r13
	addq	%rdx, %r13
	cmpq	$23, %r13
	jg	.LBB23_6
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r12)
.LBB23_5:
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	addq	$4112, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB23_6:
	.cfi_def_cfa_offset 4160
	addq	$7, %r13
	movq	%r13, %rdi
	andq	$-8, %rdi
	addq	$8, %rdi
	sarq	$3, %r13
	movq	%r13, 16(%r12)
	movl	$1, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, (%r12)
	movq	$0, 8(%r12)
	movabsq	$4611686018427387904, %rax
	orq	%r13, %rax
	movq	%rax, 16(%r12)
	movq	$0, 4096(%rsp)
	movq	%r12, 4104(%rsp)
	movq	16(%r15), %rdx
	testq	%rdx, %rdx
	js	.LBB23_7
	movq	8(%r15), %rdx
	movq	(%r15), %r15
	jmp	.LBB23_9
.LBB23_7:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB23_9:
	movq	%rsp, %r12
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4096(%rsp), %rdx
	movq	4104(%rsp), %rdi
	movq	%r12, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4112, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end23:
	.size	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]", .Lfunc_end23-"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end24, nop
	.type	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]",@function
"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4120, %rsp
	.cfi_def_cfa_offset 4176
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r15
	movq	%rcx, %rbx
	movq	%rdx, %r14
	movq	%rsi, %r12
	movq	%rdi, %r13
	movq	%rcx, %rbp
	addq	%rsi, %rbp
	cmpq	$23, %rbp
	jg	.LBB24_1
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r15)
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	addq	$4120, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB24_1:
	.cfi_def_cfa_offset 4176
	addq	$7, %rbp
	movq	%rbp, %rdi
	andq	$-8, %rdi
	addq	$8, %rdi
	sarq	$3, %rbp
	movq	%rbp, 16(%r15)
	movl	$1, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
	movabsq	$4611686018427387904, %rax
	orq	%rbp, %rax
	movq	%rax, 16(%r15)
	movq	$0, 4104(%rsp)
	movq	%r15, 4112(%rsp)
	leaq	8(%rsp), %r15
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4104(%rsp), %rdx
	movq	4112(%rsp), %rdi
	movq	%r15, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4120, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end24:
	.size	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]", .Lfunc_end24-"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end25, nop
	.type	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]",@function
"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4112, %rsp
	.cfi_def_cfa_offset 4144
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %r15
	movq	%rsi, %rbx
	movq	%rdi, %r14
	xorl	%edi, %edi
	callq	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	addq	%rbx, %rax
	cmpq	$23, %rax
	jg	.LBB25_1
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r15)
	movq	%r15, %rdi
	callq	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB25_1:
	.cfi_def_cfa_offset 4144
	addq	$7, %rax
	movq	%rax, %rcx
	sarq	$3, %rcx
	andq	$-8, %rax
	addq	$8, %rax
	movq	%rcx, 16(%r15)
	movl	$1, %esi
	movq	%rax, %rdi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
	orb	$64, 23(%r15)
	movq	$0, 4096(%rsp)
	movq	%r15, 4104(%rsp)
	movq	%rsp, %r15
	movq	%r15, %rdi
	callq	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4096(%rsp), %rdx
	movq	4104(%rsp), %rdi
	movq	%r15, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end25:
	.size	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]", .Lfunc_end25-"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::sys::compile::_DebugLevel\">>, struct<() memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end26, nop
	.type	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]",@function
"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]":
	.cfi_startproc
	movq	16(%rdi), %r8
	testq	%r8, %r8
	js	.LBB26_1
	movq	8(%rdi), %rax
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB26_7
.LBB26_4:
	movq	8(%rsi), %rcx
	addq	%rcx, %rax
	cmpq	$24, %rax
	jge	.LBB26_8
	movq	(%rsi), %rsi
	movq	%rcx, %rdx
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB26_1:
	movq	%r8, %rax
	shrq	$56, %rax
	andl	$31, %eax
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	jns	.LBB26_4
.LBB26_7:
	movq	%rdx, %rcx
	shrq	$56, %rcx
	andl	$31, %ecx
	addq	%rcx, %rax
	cmpq	$24, %rax
	jge	.LBB26_8
	movq	%rcx, %rdx
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB26_8:
	testq	%r8, %r8
	js	.LBB26_9
	movq	%r8, %rcx
	shrq	$62, %rcx
	jne	.LBB26_12
	movq	8(%rdi), %r8
	jmp	.LBB26_13
.LBB26_9:
	movl	$23, %r8d
	jmp	.LBB26_13
.LBB26_12:
	shlq	$3, %r8
.LBB26_13:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$4120, %rsp
	.cfi_def_cfa_offset 4144
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	cmpq	%r8, %rax
	jle	.LBB26_15
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	16(%r14), %rdx
.LBB26_15:
	movq	$0, 4104(%rsp)
	movq	%rdi, 4112(%rsp)
	testq	%rdx, %rdx
	js	.LBB26_16
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB26_18
.LBB26_16:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB26_18:
	leaq	8(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4104(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB26_20
	movq	4112(%rsp), %rdi
	leaq	8(%rsp), %rbx
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4104(%rsp)
	xorl	%edx, %edx
.LBB26_20:
	movq	4112(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4120, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end26:
	.size	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]", .Lfunc_end26-"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end27, nop
	.type	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]",@function
"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4112, %rsp
	.cfi_def_cfa_offset 4144
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rax
	movq	16(%rdi), %rcx
	testq	%rcx, %rcx
	js	.LBB27_7
	movq	8(%rdi), %r8
	addq	%r8, %rax
	cmpq	$24, %rax
	jl	.LBB27_8
	movq	%rcx, %r9
	shrq	$62, %r9
	shlq	$3, %rcx
	testq	%r9, %r9
	cmoveq	%r8, %rcx
	cmpq	%rcx, %rax
	jg	.LBB27_3
	jmp	.LBB27_4
.LBB27_7:
	shrq	$56, %rcx
	andl	$31, %ecx
	addq	%rcx, %rax
	cmpq	$23, %rax
	jg	.LBB27_3
.LBB27_8:
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB27_3:
	.cfi_def_cfa_offset 4144
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rax, %rsi
	movq	%rdx, %r15
	callq	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rbx, %rdi
	movq	%r15, %rdx
	movq	%r14, %rsi
.LBB27_4:
	movq	$0, 4096(%rsp)
	movq	%rdi, 4104(%rsp)
	movq	%rsp, %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4096(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB27_6
	movq	4104(%rsp), %rdi
	movq	%rsp, %rbx
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rsp)
	xorl	%edx, %edx
.LBB27_6:
	movq	4104(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end27:
	.size	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]", .Lfunc_end27-"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end28, nop
	.type	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]",@function
"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$4112, %rsp
	.cfi_def_cfa_offset 4144
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rax
	movq	16(%rdi), %rcx
	testq	%rcx, %rcx
	js	.LBB28_7
	movq	8(%rdi), %r8
	addq	%r8, %rax
	cmpq	$24, %rax
	jl	.LBB28_8
	movq	%rcx, %r9
	shrq	$62, %r9
	shlq	$3, %rcx
	testq	%r9, %r9
	cmoveq	%r8, %rcx
	cmpq	%rcx, %rax
	jg	.LBB28_3
	jmp	.LBB28_4
.LBB28_7:
	shrq	$56, %rcx
	andl	$31, %ecx
	addq	%rcx, %rax
	cmpq	$23, %rax
	jg	.LBB28_3
.LBB28_8:
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB28_3:
	.cfi_def_cfa_offset 4144
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rax, %rsi
	movq	%rdx, %r15
	callq	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rbx, %rdi
	movq	%r15, %rdx
	movq	%r14, %rsi
.LBB28_4:
	movq	$0, 4096(%rsp)
	movq	%rdi, 4104(%rsp)
	movq	%rsp, %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	movq	4096(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB28_6
	movq	4104(%rsp), %rdi
	movq	%rsp, %rbx
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rsp)
	xorl	%edx, %edx
.LBB28_6:
	movq	4104(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	addq	$4112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end28:
	.size	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]", .Lfunc_end28-"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=true,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end29, nop
	.type	"std::collections::string::string::String::__eq__(::String,::String)",@function
"std::collections::string::string::String::__eq__(::String,::String)":
	movq	16(%rdi), %rax
	testq	%rax, %rax
	js	.LBB29_1
	movq	8(%rdi), %rcx
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB29_4
.LBB29_5:
	movq	8(%rsi), %r8
	cmpq	%r8, %rcx
	je	.LBB29_9
	jmp	.LBB29_7
.LBB29_1:
	movq	%rax, %rcx
	shrq	$56, %rcx
	andl	$31, %ecx
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	jns	.LBB29_5
.LBB29_4:
	movq	%rdx, %r8
	shrq	$56, %r8
	andl	$31, %r8d
	cmpq	%r8, %rcx
	jne	.LBB29_7
.LBB29_9:
	testq	%rax, %rax
	js	.LBB29_11
	movq	(%rdi), %rdi
.LBB29_11:
	testq	%rdx, %rdx
	js	.LBB29_13
	movq	(%rsi), %rsi
.LBB29_13:
	movb	$1, %al
	testq	%rcx, %rcx
	je	.LBB29_8
	cmpq	%rsi, %rdi
	je	.LBB29_8
	cmpq	$64, %rcx
	jge	.LBB29_16
	movq	%rcx, %rdx
	sarq	$63, %rdx
	andnq	%rcx, %rdx, %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB29_20:
	cmpq	%rdx, %rcx
	je	.LBB29_8
	movzbl	(%rdi,%rdx), %r8d
	cmpb	(%rsi,%rdx), %r8b
	leaq	1(%rdx), %rdx
	je	.LBB29_20
	jmp	.LBB29_7
.LBB29_16:
	addq	$-64, %rcx
	xorl	%eax, %eax
	.p2align	4
.LBB29_17:
	cmpq	%rcx, %rax
	jge	.LBB29_22
	vmovdqu64	(%rdi,%rax), %zmm0
	vpcmpneqd	(%rsi,%rax), %zmm0, %k0
	addq	$64, %rax
	kortestw	%k0, %k0
	je	.LBB29_17
.LBB29_7:
	xorl	%eax, %eax
.LBB29_8:
	vzeroupper
	retq
.LBB29_22:
	vmovdqu64	(%rdi,%rcx), %zmm0
	vpcmpneqd	(%rsi,%rcx), %zmm0, %k0
	kortestw	%k0, %k0
	sete	%al
	vzeroupper
	retq
.Lfunc_end29:
	.size	"std::collections::string::string::String::__eq__(::String,::String)", .Lfunc_end29-"std::collections::string::string::String::__eq__(::String,::String)"

	.prefalign	4, .Lfunc_end30, nop
	.type	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false",@function
"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %rbx
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	movabsq	$9223372036854775776, %r13
	leaq	(%rcx,%rsi), %rbp
	cmpq	$24, %rbp
	jge	.LBB30_2
	leaq	32(%r13), %rax
	jmp	.LBB30_3
.LBB30_2:
	movq	%r14, 32(%rsp)
	leaq	7(%rbp), %r14
	movq	%r14, %rdi
	andq	$-8, %rdi
	addq	$8, %rdi
	sarq	$3, %r14
	movl	$1, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, 8(%rsp)
	movq	$0, 16(%rsp)
	movabsq	$4611686018427387904, %rax
	orq	%r14, %rax
	movq	%rax, 24(%rsp)
	testq	%r14, %r14
	movq	32(%rsp), %r14
	js	.LBB30_3
	movq	%rbp, 16(%rsp)
	jmp	.LBB30_5
.LBB30_3:
	shlq	$56, %rbp
	movabsq	$-2233785415175766017, %rcx
	andq	%rax, %rcx
	orq	%rbp, %rcx
	movq	%rcx, 24(%rsp)
.LBB30_5:
	leaq	8(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	%r15, %rcx
	subq	$1, %rcx
	jae	.LBB30_6
.LBB30_18:
	movq	%rbx, %rcx
	subq	$1, %rcx
	jae	.LBB30_19
.LBB30_31:
	movq	8(%rsp), %rax
	movq	16(%rsp), %rdx
	movq	24(%rsp), %rcx
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB30_6:
	.cfi_def_cfa_offset 96
	cmpq	$4, %r15
	jg	.LBB30_9
	movzbl	(%r12), %edx
	movb	%dl, (%rax)
	movzbl	(%r12,%rcx), %edx
	movb	%dl, (%rax,%rcx)
	cmpq	$3, %r15
	jl	.LBB30_18
	movzbl	1(%r12), %ecx
	movb	%cl, 1(%rax)
	movzbl	-2(%r12,%r15), %ecx
	movb	%cl, -2(%rax,%r15)
	jmp	.LBB30_18
.LBB30_19:
	addq	%r15, %rax
	cmpq	$4, %rbx
	jg	.LBB30_22
	movzbl	(%r14), %edx
	movb	%dl, (%rax)
	movzbl	(%r14,%rcx), %edx
	movb	%dl, (%rax,%rcx)
	cmpq	$3, %rbx
	jl	.LBB30_31
	movzbl	1(%r14), %ecx
	movb	%cl, 1(%rax)
	movzbl	-2(%r14,%rbx), %ecx
	movb	%cl, -2(%rax,%rbx)
	jmp	.LBB30_31
.LBB30_9:
	cmpq	$16, %r15
	jg	.LBB30_13
	cmpq	$8, %r15
	jl	.LBB30_12
	movq	(%r12), %rcx
	movq	%rcx, (%rax)
	movq	-8(%r12,%r15), %rcx
	movq	%rcx, -8(%rax,%r15)
	jmp	.LBB30_18
.LBB30_22:
	cmpq	$16, %rbx
	jg	.LBB30_26
	cmpq	$8, %rbx
	jl	.LBB30_25
	movq	(%r14), %rcx
	movq	%rcx, (%rax)
	movq	-8(%r14,%rbx), %rcx
	movq	%rcx, -8(%rax,%rbx)
	jmp	.LBB30_31
.LBB30_13:
	movq	%r15, %rcx
	andq	%r13, %rcx
	je	.LBB30_16
	xorl	%edx, %edx
	.p2align	4
.LBB30_15:
	vmovups	(%r12,%rdx), %ymm0
	vmovups	%ymm0, (%rax,%rdx)
	addq	$32, %rdx
	cmpq	%rcx, %rdx
	jb	.LBB30_15
.LBB30_16:
	cmpq	%r15, %rcx
	je	.LBB30_18
	.p2align	4
.LBB30_17:
	movzbl	(%r12,%rcx), %edx
	movb	%dl, (%rax,%rcx)
	incq	%rcx
	cmpq	%rcx, %r15
	jne	.LBB30_17
	jmp	.LBB30_18
.LBB30_26:
	andq	%rbx, %r13
	je	.LBB30_29
	xorl	%ecx, %ecx
	.p2align	4
.LBB30_28:
	vmovups	(%r14,%rcx), %ymm0
	vmovups	%ymm0, (%rax,%rcx)
	addq	$32, %rcx
	cmpq	%r13, %rcx
	jb	.LBB30_28
.LBB30_29:
	cmpq	%rbx, %r13
	je	.LBB30_31
	.p2align	4
.LBB30_30:
	movzbl	(%r14,%r13), %ecx
	movb	%cl, (%rax,%r13)
	incq	%r13
	cmpq	%r13, %rbx
	jne	.LBB30_30
	jmp	.LBB30_31
.LBB30_12:
	movl	(%r12), %ecx
	movl	%ecx, (%rax)
	movl	-4(%r12,%r15), %ecx
	movl	%ecx, -4(%rax,%r15)
	jmp	.LBB30_18
.LBB30_25:
	movl	(%r14), %ecx
	movl	%ecx, (%rax)
	movl	-4(%r14,%rbx), %ecx
	movl	%ecx, -4(%rax,%rbx)
	jmp	.LBB30_31
.Lfunc_end30:
	.size	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false", .Lfunc_end30-"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"
	.cfi_endproc

	.prefalign	4, .Lfunc_end31, nop
	.type	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])",@function
"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r13
	subq	$1, %r13
	jb	.LBB31_20
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %rbx
	movq	16(%rdi), %rbp
	testq	%rbp, %rbp
	js	.LBB31_2
	movq	8(%rbx), %rbp
	jmp	.LBB31_4
.LBB31_2:
	shrq	$56, %rbp
	andl	$31, %ebp
.LBB31_4:
	leaq	(%rbp,%r14), %r12
	movq	%rbx, %rdi
	movq	%r12, %rsi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	addq	%rbp, %rax
	cmpq	$4, %r14
	jg	.LBB31_7
	movzbl	(%r15), %ecx
	movb	%cl, (%rax)
	movzbl	(%r15,%r13), %ecx
	movb	%cl, (%rax,%r13)
	cmpq	$3, %r14
	jl	.LBB31_16
	movzbl	1(%r15), %ecx
	movb	%cl, 1(%rax)
	movzbl	-2(%r15,%r14), %ecx
	movb	%cl, -2(%rax,%r14)
	movq	16(%rbx), %rax
	testq	%rax, %rax
	jns	.LBB31_18
	jmp	.LBB31_17
.LBB31_7:
	cmpq	$16, %r14
	jg	.LBB31_11
	cmpq	$8, %r14
	jl	.LBB31_10
	movq	(%r15), %rcx
	movq	%rcx, (%rax)
	movq	-8(%r15,%r14), %rcx
	movq	%rcx, -8(%rax,%r14)
	movq	16(%rbx), %rax
	testq	%rax, %rax
	jns	.LBB31_18
	jmp	.LBB31_17
.LBB31_11:
	movabsq	$9223372036854775776, %rcx
	andq	%r14, %rcx
	je	.LBB31_14
	xorl	%edx, %edx
	.p2align	4
.LBB31_13:
	vmovups	(%r15,%rdx), %ymm0
	vmovups	%ymm0, (%rax,%rdx)
	addq	$32, %rdx
	cmpq	%rcx, %rdx
	jb	.LBB31_13
.LBB31_14:
	cmpq	%r14, %rcx
	je	.LBB31_16
	.p2align	4
.LBB31_15:
	movzbl	(%r15,%rcx), %edx
	movb	%dl, (%rax,%rcx)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	.LBB31_15
.LBB31_16:
	movq	16(%rbx), %rax
	testq	%rax, %rax
	js	.LBB31_17
.LBB31_18:
	movq	%r12, 8(%rbx)
	jmp	.LBB31_19
.LBB31_10:
	movl	(%r15), %ecx
	movl	%ecx, (%rax)
	movl	-4(%r15,%r14), %ecx
	movl	%ecx, -4(%rax,%r14)
	movq	16(%rbx), %rax
	testq	%rax, %rax
	jns	.LBB31_18
.LBB31_17:
	shlq	$56, %r12
	movabsq	$-2233785415175766017, %rcx
	andq	%rcx, %rax
	orq	%r12, %rax
.LBB31_19:
	movabsq	$-2305843009213693953, %rcx
	andq	%rax, %rcx
	movq	%rcx, 16(%rbx)
.LBB31_20:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.Lfunc_end31:
	.size	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])", .Lfunc_end31-"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end32, nop
	.type	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]",@function
"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdx, %rax
	movq	16(%rdi), %rcx
	testq	%rcx, %rcx
	js	.LBB32_1
	movq	8(%rdi), %rcx
	movq	(%rdi), %rdi
	leaq	(%rcx,%rax), %rdx
	cmpq	$2049, %rdx
	jge	.LBB32_18
.LBB32_4:
	movq	%rcx, %r9
	subq	$1, %r9
	jae	.LBB32_5
.LBB32_17:
	movq	%rsi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB32_5:
	.cfi_def_cfa_offset 16
	movq	%rsi, %r8
	addq	%rax, %r8
	cmpq	$4, %rcx
	jg	.LBB32_8
	movzbl	(%rdi), %eax
	movb	%al, (%r8)
	movzbl	(%rdi,%r9), %eax
	movb	%al, (%r8,%r9)
	cmpq	$3, %rcx
	jl	.LBB32_17
	movzbl	1(%rdi), %eax
	movb	%al, 1(%r8)
	movzbl	-2(%rdi,%rcx), %eax
	movb	%al, -2(%r8,%rcx)
	movq	%rsi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB32_1:
	.cfi_def_cfa_offset 16
	shrq	$56, %rcx
	andl	$31, %ecx
	leaq	(%rcx,%rax), %rdx
	cmpq	$2049, %rdx
	jl	.LBB32_4
.LBB32_18:
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB32_8:
	cmpq	$16, %rcx
	jg	.LBB32_12
	cmpq	$8, %rcx
	jl	.LBB32_11
	movq	(%rdi), %rax
	movq	%rax, (%r8)
	movq	-8(%rdi,%rcx), %rax
	movq	%rax, -8(%r8,%rcx)
	movq	%rsi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB32_12:
	.cfi_def_cfa_offset 16
	movabsq	$9223372036854775776, %rax
	andq	%rcx, %rax
	je	.LBB32_15
	xorl	%r9d, %r9d
	.p2align	4
.LBB32_14:
	vmovups	(%rdi,%r9), %ymm0
	vmovups	%ymm0, (%r8,%r9)
	addq	$32, %r9
	cmpq	%rax, %r9
	jb	.LBB32_14
.LBB32_15:
	cmpq	%rcx, %rax
	je	.LBB32_17
	.p2align	4
.LBB32_16:
	movzbl	(%rdi,%rax), %r9d
	movb	%r9b, (%r8,%rax)
	incq	%rax
	cmpq	%rax, %rcx
	jne	.LBB32_16
	jmp	.LBB32_17
.LBB32_11:
	movl	(%rdi), %eax
	movl	%eax, (%r8)
	movl	-4(%rdi,%rcx), %eax
	movl	%eax, -4(%r8,%rcx)
	movq	%rsi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end32:
	.size	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]", .Lfunc_end32-"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end33, nop
	.type	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)",@function
"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	movabsq	$4611686018427387904, %r12
	movq	16(%rdi), %r15
	testq	%r15, %r15
	js	.LBB33_11
	cmpq	%r12, %r15
	jae	.LBB33_3
	movq	8(%rbx), %rax
	cmpq	%rsi, %rax
	cmovgq	%rax, %rsi
	cmpq	$24, %rsi
	jl	.LBB33_5
	jmp	.LBB33_12
.LBB33_11:
	cmpq	$24, %rsi
	jge	.LBB33_12
	jmp	.LBB33_18
.LBB33_3:
	leaq	(,%r15,8), %rax
	cmpq	%rsi, %rax
	cmovgq	%rax, %rsi
	cmpq	$24, %rsi
	jge	.LBB33_12
.LBB33_5:
	movq	8(%rbx), %rdx
	movq	(%rbx), %r14
	movq	%rdx, %rax
	orq	$-128, %rax
	shlq	$56, %rax
	movq	%rax, 16(%rsp)
	testq	%rdx, %rdx
	jle	.LBB33_7
	movq	%rsp, %rdi
	movq	%r14, %rsi
	callq	memcpy@PLT
.LBB33_7:
	cmpq	%r12, %r15
	jb	.LBB33_10
	lock		decq	-8(%r14)
	jne	.LBB33_10
	addq	$-8, %r14
	#MEMBARRIER
	movq	%r14, %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB33_10:
	movq	(%rsp), %rax
	movq	%rax, (%rbx)
	movq	16(%rsp), %r15
	vmovups	8(%rsp), %xmm0
	vmovups	%xmm0, 8(%rbx)
	jmp	.LBB33_16
.LBB33_12:
	testq	%r12, %r15
	je	.LBB33_15
	movq	(%rbx), %rax
	movq	-8(%rax), %rax
	cmpq	$1, %rax
	jne	.LBB33_15
	leaq	(,%r15,8), %rax
	testq	%r15, %r15
	movl	$23, %ecx
	cmovnsq	%rax, %rcx
	cmpq	%rcx, %rsi
	jle	.LBB33_16
.LBB33_15:
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	16(%rbx), %r15
.LBB33_16:
	testq	%r15, %r15
	js	.LBB33_18
	movq	(%rbx), %rbx
.LBB33_18:
	movq	%rbx, %rax
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end33:
	.size	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)", .Lfunc_end33-"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"
	.cfi_endproc

	.prefalign	4, .Lfunc_end34, nop
	.type	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])",@function
"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movabsq	$4611686018427387904, %rax
	movq	16(%rdi), %r13
	testq	%r13, %r13
	js	.LBB34_1
	movq	(%rbx), %rbp
	movq	8(%rbx), %r15
	leaq	(,%r13,8), %r12
	cmpq	%rax, %r13
	cmovbq	%r15, %r12
	addq	%r12, %r12
	jmp	.LBB34_3
.LBB34_1:
	movq	%r13, %r15
	shrq	$56, %r15
	andl	$31, %r15d
	movl	$46, %r12d
	movq	%rbx, %rbp
.LBB34_3:
	cmpq	%r12, %rsi
	cmovgq	%rsi, %r12
	addq	$7, %r12
	movq	%r12, %rdi
	andq	$-8, %rdi
	addq	$8, %rdi
	movl	$1, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	leaq	8(%rax), %r14
	movq	%r15, %rcx
	subq	$1, %rcx
	jae	.LBB34_4
.LBB34_16:
	movabsq	$4611686018427387904, %rax
	testq	%rax, %r13
	je	.LBB34_19
	movq	(%rbx), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB34_19
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r13
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r13, %rax
.LBB34_19:
	movq	%r15, 8(%rbx)
	sarq	$3, %r12
	movq	%r14, (%rbx)
	orq	%rax, %r12
	movq	%r12, 16(%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB34_4:
	.cfi_def_cfa_offset 64
	cmpq	$4, %r15
	jg	.LBB34_7
	movzbl	(%rbp), %edx
	movb	%dl, (%r14)
	movzbl	(%rbp,%rcx), %edx
	movb	%dl, (%r14,%rcx)
	cmpq	$3, %r15
	jl	.LBB34_16
	movzbl	1(%rbp), %ecx
	movb	%cl, 9(%rax)
	movzbl	-2(%rbp,%r15), %ecx
	movb	%cl, 6(%rax,%r15)
	jmp	.LBB34_16
.LBB34_7:
	cmpq	$16, %r15
	jg	.LBB34_11
	cmpq	$8, %r15
	jl	.LBB34_10
	movq	(%rbp), %rcx
	movq	%rcx, 8(%rax)
	movq	-8(%rbp,%r15), %rcx
	movq	%rcx, (%rax,%r15)
	jmp	.LBB34_16
.LBB34_11:
	movabsq	$9223372036854775776, %rax
	andq	%r15, %rax
	je	.LBB34_14
	xorl	%ecx, %ecx
	.p2align	4
.LBB34_13:
	vmovups	(%rbp,%rcx), %ymm0
	vmovups	%ymm0, (%r14,%rcx)
	addq	$32, %rcx
	cmpq	%rax, %rcx
	jb	.LBB34_13
.LBB34_14:
	cmpq	%r15, %rax
	je	.LBB34_16
	.p2align	4
.LBB34_15:
	movzbl	(%rbp,%rax), %ecx
	movb	%cl, (%r14,%rax)
	incq	%rax
	cmpq	%rax, %r15
	jne	.LBB34_15
	jmp	.LBB34_16
.LBB34_10:
	movl	(%rbp), %eax
	movl	%eax, (%r14)
	movl	-4(%rbp,%r15), %eax
	movl	%eax, -4(%r14,%r15)
	jmp	.LBB34_16
.Lfunc_end34:
	.size	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end34-"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end35, nop
	.type	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false",@function
"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	cmpq	$4097, %rdx
	jl	.LBB35_1
	movq	4096(%r14), %rdx
	movq	4104(%r14), %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%r14)
	movq	4104(%r14), %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB35_1:
	.cfi_def_cfa_offset 48
	movq	4096(%r14), %rdx
	leaq	(%rdx,%rbx), %rax
	cmpq	$4097, %rax
	jl	.LBB35_3
	movq	4104(%r14), %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%r14)
	xorl	%edx, %edx
.LBB35_3:
	testq	%rbx, %rbx
	je	.LBB35_15
	addq	%r14, %rdx
	cmpq	$4, %rbx
	jg	.LBB35_7
	movzbl	(%r15), %eax
	movb	%al, (%rdx)
	movzbl	-1(%r15,%rbx), %eax
	movb	%al, -1(%rdx,%rbx)
	cmpq	$3, %rbx
	jl	.LBB35_15
	movzbl	1(%r15), %eax
	movb	%al, 1(%rdx)
	movzbl	-2(%r15,%rbx), %eax
	movb	%al, -2(%rdx,%rbx)
	jmp	.LBB35_15
.LBB35_7:
	cmpq	$16, %rbx
	jg	.LBB35_11
	cmpq	$8, %rbx
	jl	.LBB35_10
	movq	(%r15), %rax
	movq	%rax, (%rdx)
	movq	-8(%r15,%rbx), %rax
	movq	%rax, -8(%rdx,%rbx)
	jmp	.LBB35_15
.LBB35_11:
	movabsq	$9223372036854775776, %r12
	andq	%rbx, %r12
	je	.LBB35_13
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rdx, %r13
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	%r13, %rdx
.LBB35_13:
	cmpq	%rbx, %r12
	je	.LBB35_15
	addq	%r12, %rdx
	addq	%r12, %r15
	movl	%ebx, %eax
	andl	$31, %eax
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rax, %rdx
	callq	memcpy@PLT
	jmp	.LBB35_15
.LBB35_10:
	movl	(%r15), %eax
	movl	%eax, (%rdx)
	movl	-4(%r15,%rbx), %eax
	movl	%eax, -4(%rdx,%rbx)
.LBB35_15:
	addq	%rbx, 4096(%r14)
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end35:
	.size	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false", .Lfunc_end35-"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"
	.cfi_endproc

	.prefalign	4, .Lfunc_end36, nop
	.type	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true",@function
"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	cmpq	$4097, %rdx
	jl	.LBB36_1
	movq	4096(%r14), %rdx
	movq	4104(%r14), %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%r14)
	movq	4104(%r14), %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB36_1:
	.cfi_def_cfa_offset 48
	movq	4096(%r14), %rdx
	leaq	(%rdx,%rbx), %rax
	cmpq	$4097, %rax
	jl	.LBB36_3
	movq	4104(%r14), %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%r14)
	xorl	%edx, %edx
.LBB36_3:
	testq	%rbx, %rbx
	je	.LBB36_15
	addq	%r14, %rdx
	cmpq	$4, %rbx
	jg	.LBB36_7
	movzbl	(%r15), %eax
	movb	%al, (%rdx)
	movzbl	-1(%r15,%rbx), %eax
	movb	%al, -1(%rdx,%rbx)
	cmpq	$3, %rbx
	jl	.LBB36_15
	movzbl	1(%r15), %eax
	movb	%al, 1(%rdx)
	movzbl	-2(%r15,%rbx), %eax
	movb	%al, -2(%rdx,%rbx)
	jmp	.LBB36_15
.LBB36_7:
	cmpq	$16, %rbx
	jg	.LBB36_11
	cmpq	$8, %rbx
	jl	.LBB36_10
	movq	(%r15), %rax
	movq	%rax, (%rdx)
	movq	-8(%r15,%rbx), %rax
	movq	%rax, -8(%rdx,%rbx)
	jmp	.LBB36_15
.LBB36_11:
	movabsq	$9223372036854775776, %r12
	andq	%rbx, %r12
	je	.LBB36_13
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rdx, %r13
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	%r13, %rdx
.LBB36_13:
	cmpq	%rbx, %r12
	je	.LBB36_15
	addq	%r12, %rdx
	addq	%r12, %r15
	movl	%ebx, %eax
	andl	$31, %eax
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rax, %rdx
	callq	memcpy@PLT
	jmp	.LBB36_15
.LBB36_10:
	movl	(%r15), %eax
	movl	%eax, (%rdx)
	movl	-4(%r15,%rbx), %eax
	movl	%eax, -4(%rdx,%rbx)
.LBB36_15:
	addq	%rbx, 4096(%r14)
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end36:
	.size	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true", .Lfunc_end36-"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"
	.cfi_endproc

	.prefalign	4, .Lfunc_end37, nop
	.type	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false",@function
"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	cmpq	$4097, %rdx
	jl	.LBB37_1
	movq	4096(%r14), %rdx
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r14, %rsi
	callq	write@PLT
	movq	$0, 4096(%r14)
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	write@PLT
.LBB37_1:
	.cfi_def_cfa_offset 48
	movq	4096(%r14), %rdx
	leaq	(%rdx,%rbx), %rax
	cmpq	$4097, %rax
	jl	.LBB37_3
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r14, %rsi
	callq	write@PLT
	movq	$0, 4096(%r14)
	xorl	%edx, %edx
.LBB37_3:
	testq	%rbx, %rbx
	je	.LBB37_15
	addq	%r14, %rdx
	cmpq	$4, %rbx
	jg	.LBB37_7
	movzbl	(%r15), %eax
	movb	%al, (%rdx)
	movzbl	-1(%r15,%rbx), %eax
	movb	%al, -1(%rdx,%rbx)
	cmpq	$3, %rbx
	jl	.LBB37_15
	movzbl	1(%r15), %eax
	movb	%al, 1(%rdx)
	movzbl	-2(%r15,%rbx), %eax
	movb	%al, -2(%rdx,%rbx)
	jmp	.LBB37_15
.LBB37_7:
	cmpq	$16, %rbx
	jg	.LBB37_11
	cmpq	$8, %rbx
	jl	.LBB37_10
	movq	(%r15), %rax
	movq	%rax, (%rdx)
	movq	-8(%r15,%rbx), %rax
	movq	%rax, -8(%rdx,%rbx)
	jmp	.LBB37_15
.LBB37_11:
	movabsq	$9223372036854775776, %r12
	andq	%rbx, %r12
	je	.LBB37_13
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rdx, %r13
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	%r13, %rdx
.LBB37_13:
	cmpq	%rbx, %r12
	je	.LBB37_15
	addq	%r12, %rdx
	addq	%r12, %r15
	movl	%ebx, %eax
	andl	$31, %eax
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rax, %rdx
	callq	memcpy@PLT
	jmp	.LBB37_15
.LBB37_10:
	movl	(%r15), %eax
	movl	%eax, (%rdx)
	movl	-4(%r15,%rbx), %eax
	movl	%eax, -4(%rdx,%rbx)
.LBB37_15:
	addq	%rbx, 4096(%r14)
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end37:
	.size	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false", .Lfunc_end37-"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"
	.cfi_endproc

	.prefalign	4, .Lfunc_end38, nop
	.type	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true",@function
"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	cmpq	$4097, %rdx
	jl	.LBB38_1
	movq	4096(%r14), %rdx
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r14, %rsi
	callq	write@PLT
	movq	$0, 4096(%r14)
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	write@PLT
.LBB38_1:
	.cfi_def_cfa_offset 48
	movq	4096(%r14), %rdx
	leaq	(%rdx,%rbx), %rax
	cmpq	$4097, %rax
	jl	.LBB38_3
	movq	4104(%r14), %rax
	movq	(%rax), %rdi
	movq	%r14, %rsi
	callq	write@PLT
	movq	$0, 4096(%r14)
	xorl	%edx, %edx
.LBB38_3:
	testq	%rbx, %rbx
	je	.LBB38_15
	addq	%r14, %rdx
	cmpq	$4, %rbx
	jg	.LBB38_7
	movzbl	(%r15), %eax
	movb	%al, (%rdx)
	movzbl	-1(%r15,%rbx), %eax
	movb	%al, -1(%rdx,%rbx)
	cmpq	$3, %rbx
	jl	.LBB38_15
	movzbl	1(%r15), %eax
	movb	%al, 1(%rdx)
	movzbl	-2(%r15,%rbx), %eax
	movb	%al, -2(%rdx,%rbx)
	jmp	.LBB38_15
.LBB38_7:
	cmpq	$16, %rbx
	jg	.LBB38_11
	cmpq	$8, %rbx
	jl	.LBB38_10
	movq	(%r15), %rax
	movq	%rax, (%rdx)
	movq	-8(%r15,%rbx), %rax
	movq	%rax, -8(%rdx,%rbx)
	jmp	.LBB38_15
.LBB38_11:
	movabsq	$9223372036854775776, %r12
	andq	%rbx, %r12
	je	.LBB38_13
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rdx, %r13
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	%r13, %rdx
.LBB38_13:
	cmpq	%rbx, %r12
	je	.LBB38_15
	addq	%r12, %rdx
	addq	%r12, %r15
	movl	%ebx, %eax
	andl	$31, %eax
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rax, %rdx
	callq	memcpy@PLT
	jmp	.LBB38_15
.LBB38_10:
	movl	(%r15), %eax
	movl	%eax, (%rdx)
	movl	-4(%r15,%rbx), %eax
	movl	%eax, -4(%rdx,%rbx)
.LBB38_15:
	addq	%rbx, 4096(%r14)
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end38:
	.size	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true", .Lfunc_end38-"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=true"
	.cfi_endproc

	.prefalign	4, .Lfunc_end39, nop
	.type	"std::memory::arc_pointer::ArcPointer::__deinit__(::ArcPointer[$0]$),T=[typevalue<#kgen.instref<\"std::memory::owned_pointer::OwnedPointer,T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>]\">>, pointer<none>]",@function
"std::memory::arc_pointer::ArcPointer::__deinit__(::ArcPointer[$0]$),T=[typevalue<#kgen.instref<\"std::memory::owned_pointer::OwnedPointer,T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>]\">>, pointer<none>]":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	lock		decq	(%rdi)
	jne	.LBB39_2
	movq	%rdi, %rbx
	#MEMBARRIER
	movq	16(%rdi), %rdi
	callq	KGEN_CompilerRT_AlignedFree@PLT
	lock		decq	8(%rbx)
	jne	.LBB39_2
	#MEMBARRIER
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	KGEN_CompilerRT_AlignedFree@PLT
.LBB39_2:
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end39:
	.size	"std::memory::arc_pointer::ArcPointer::__deinit__(::ArcPointer[$0]$),T=[typevalue<#kgen.instref<\"std::memory::owned_pointer::OwnedPointer,T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>]\">>, pointer<none>]", .Lfunc_end39-"std::memory::arc_pointer::ArcPointer::__deinit__(::ArcPointer[$0]$),T=[typevalue<#kgen.instref<\"std::memory::owned_pointer::OwnedPointer,T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>]\">>, pointer<none>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end40, nop
	.type	"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]",@function
"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, %rbx
	movq	%r8, %r14
	movq	%rcx, %r15
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %rbp
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r9)
	movl	$3, %esi
	movq	%r9, %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movw	$29761, (%rax)
	movb	$32, 2(%rax)
	movq	16(%rbx), %rax
	testq	%rax, %rax
	js	.LBB40_1
	movq	$3, 8(%rbx)
	jmp	.LBB40_3
.LBB40_1:
	movabsq	$-2233785415175766017, %rcx
	andq	%rcx, %rax
	movabsq	$216172782113783808, %rcx
	orq	%rcx, %rax
.LBB40_3:
	movabsq	$-2305843009213693953, %rcx
	andq	%rcx, %rax
	movq	%rax, 16(%rbx)
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	movq	%r15, %rcx
	movq	%rbx, %r8
	callq	"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	16(%rbx), %r12
	testq	%r12, %r12
	js	.LBB40_4
	movq	8(%rbx), %r12
	jmp	.LBB40_6
.LBB40_4:
	shrq	$56, %r12
	andl	$31, %r12d
.LBB40_6:
	leaq	2(%r12), %r15
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movw	$8250, (%rax,%r12)
	movq	16(%rbx), %rax
	testq	%rax, %rax
	js	.LBB40_7
	movq	%r15, 8(%rbx)
	jmp	.LBB40_9
.LBB40_7:
	shlq	$56, %r15
	movabsq	$-2233785415175766017, %rcx
	andq	%rcx, %rax
	orq	%r15, %rax
.LBB40_9:
	movabsq	$-2305843009213693953, %rcx
	andq	%rcx, %rax
	movq	%rax, 16(%rbx)
	movq	16(%r14), %rdx
	testq	%rdx, %rdx
	js	.LBB40_10
	movq	8(%r14), %rdx
	movq	(%r14), %r14
	jmp	.LBB40_12
.LBB40_10:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB40_12:
	movq	%rbx, %rdi
	movq	%r14, %rsi
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.Lfunc_end40:
	.size	"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]", .Lfunc_end40-"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end41, nop
	.type	"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]",@function
"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4168, %rsp
	.cfi_def_cfa_offset 4224
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	$1, 40(%rsp)
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rax
	movq	%rax, 32(%rsp)
	movq	%r8, %r15
	movq	%rcx, %r12
	movq	%rdx, %r13
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 48(%rsp)
	movq	$1, 16(%rsp)
	movq	%rax, 8(%rsp)
	movq	%rcx, 24(%rsp)
	movq	16(%r8), %rbp
	testq	%rbp, %rbp
	js	.LBB41_1
	movq	8(%r15), %rax
	jmp	.LBB41_3
.LBB41_1:
	movq	%rbp, %rax
	shrq	$56, %rax
	andl	$31, %eax
.LBB41_3:
	leaq	1(%r12,%rax), %rsi
	movq	%r14, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rax), %rsi
	movq	%rbx, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	cmpq	$23, %rax
	jg	.LBB41_8
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	leaq	static_string_fd5c39b3eb3d3242(%rip), %rsi
	movl	$1, %edx
	movq	%r15, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	24(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB41_5
	movq	8(%rsp), %rsi
	movq	16(%rsp), %rdx
	jmp	.LBB41_7
.LBB41_8:
	testq	%rbp, %rbp
	js	.LBB41_13
	movabsq	$4611686018427387904, %rcx
	cmpq	%rcx, %rbp
	jae	.LBB41_11
	movq	8(%r15), %rbp
	cmpq	%rbp, %rax
	jg	.LBB41_13
	jmp	.LBB41_14
.LBB41_5:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	8(%rsp), %rsi
.LBB41_7:
	movq	%r15, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movabsq	$4611686018427387904, %rbx
	testq	%rbx, 24(%rsp)
	jne	.LBB41_32
	jmp	.LBB41_34
.LBB41_11:
	shlq	$3, %rbp
	cmpq	%rbp, %rax
	jle	.LBB41_14
.LBB41_13:
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::_realloc_mutable(::String,::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
.LBB41_14:
	movq	$0, 4152(%rsp)
	movq	%r15, 4160(%rsp)
	leaq	56(%rsp), %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4152(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB41_16
	movq	4160(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4152(%rsp)
.LBB41_16:
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB41_17
	movq	32(%rsp), %rsi
	movq	40(%rsp), %rdx
	jmp	.LBB41_19
.LBB41_17:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	32(%rsp), %rsi
.LBB41_19:
	leaq	56(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4152(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB41_21
	movq	4160(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4152(%rsp)
.LBB41_21:
	leaq	56(%rsp), %rsi
	movq	%r14, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4152(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB41_23
	movq	4160(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4152(%rsp)
.LBB41_23:
	movq	24(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB41_24
	movq	8(%rsp), %rsi
	movq	16(%rsp), %rdx
	jmp	.LBB41_26
.LBB41_24:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	8(%rsp), %rsi
.LBB41_26:
	leaq	56(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4152(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB41_28
	movq	4160(%rsp), %rdi
	leaq	56(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4152(%rsp)
.LBB41_28:
	leaq	56(%rsp), %r14
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4152(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB41_30
	movq	4160(%rsp), %rdi
	leaq	56(%rsp), %r14
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4152(%rsp)
	xorl	%edx, %edx
.LBB41_30:
	movabsq	$4611686018427387904, %rbx
	movq	4160(%rsp), %rdi
	movq	%r14, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	testq	%rbx, 24(%rsp)
	je	.LBB41_34
.LBB41_32:
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB41_34
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB41_34:
	testq	%rbx, 48(%rsp)
	je	.LBB41_37
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB41_37
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB41_37:
	addq	$4168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end41:
	.size	"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]", .Lfunc_end41-"std::reflection::location::SourceLocation::write_to[::Writer & ::AnyType](::SourceLocation,$0),writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end42, nop
	.type	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]",@function
"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]":
	.cfi_startproc
	leaq	static_string_ba261bf194cae289(%rip), %rsi
	movl	$4, %edx
	jmp	"std::collections::string::string::String::write[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](::String,*$0),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
.Lfunc_end42:
	.size	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]", .Lfunc_end42-"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end43, nop
	.type	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]",@function
"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]":
	leaq	4(%rdi), %rax
	retq
.Lfunc_end43:
	.size	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]", .Lfunc_end43-"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"

	.prefalign	4, .Lfunc_end44, nop
	.type	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]",@function
"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	4096(%rdi), %rdx
	leaq	4(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB44_2
	movq	4104(%rbx), %rdi
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4096(%rbx)
	xorl	%edx, %edx
.LBB44_2:
	movl	$1701736302, (%rbx,%rdx)
	addq	$4, 4096(%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end44:
	.size	"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]", .Lfunc_end44-"std::sys::compile::_DebugLevel::write_to[::Writer & ::AnyType](::_DebugLevel,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end45, nop
	.type	"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128",@function
"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$2096, %rsp
	.cfi_def_cfa_offset 2112
	.cfi_offset %rbx, -16
	movq	$6, 8(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, (%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 16(%rsp)
	movq	$39, 32(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 40(%rsp)
	cmpq	$619, %rdi
	jae	.LBB45_1
	shlq	$4, %rdi
	leaq	global_constant_0(%rip), %rax
	movq	8(%rdi,%rax), %rax
	movq	%rax, %rcx
	shrq	$53, %rcx
	movq	%rax, %rdi
	shrq	$54, %rdi
	negq	%rdi
	testb	$1, %dl
	cmoveq	%rcx, %rdi
	addq	%rax, %rdi
	movb	$11, %al
	subb	%sil, %al
	shrxq	%rax, %rdi, %rax
	addq	$2096, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB45_1:
	.cfi_def_cfa_offset 2112
	movq	%rsp, %rax
	leaq	48(%rsp), %rsi
	movq	%rdi, %rbx
	movq	%rax, %rdi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	24(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$618, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB45_2
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB45_2:
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$477, %esi
	movl	$49, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end45:
	.size	"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128", .Lfunc_end45-"std::builtin::_format_float::_compute_endpoint[::DType,::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]](::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool),CarrierDType=ui64,sig_bits=52,total_bits=64,cache_bits=128"
	.cfi_endproc

	.prefalign	4, .Lfunc_end46, nop
	.type	"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64",@function
"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$2096, %rsp
	.cfi_def_cfa_offset 2112
	.cfi_offset %rbx, -16
	movq	$6, 8(%rsp)
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rax
	movq	%rax, (%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 16(%rsp)
	movq	$39, 32(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 40(%rsp)
	cmpq	$619, %rsi
	jae	.LBB46_1
	shlq	$4, %rsi
	leaq	global_constant_0(%rip), %rax
	movq	(%rsi,%rax), %rcx
	movq	8(%rsi,%rax), %r9
	imulq	%rdi, %r9
	movq	%rdi, %rax
	shrq	$32, %rax
	movl	%ecx, %r8d
	movq	%rcx, %rsi
	shrq	$32, %rsi
	movq	%rsi, %rcx
	imulq	%rax, %rcx
	addq	%r9, %rcx
	movl	%edi, %edi
	imulq	%rdi, %rsi
	imulq	%r8, %rax
	imulq	%rdi, %r8
	movl	%r8d, %edi
	shrq	$32, %r8
	movl	%eax, %r9d
	addq	%r8, %r9
	movl	%esi, %r8d
	addq	%r9, %r8
	movq	%r8, %r9
	shrq	$32, %r9
	shrq	$32, %rax
	addq	%rcx, %rax
	shrq	$32, %rsi
	addq	%rax, %rsi
	addq	%r9, %rsi
	shlq	$32, %r8
	orq	%r8, %rdi
	movb	$64, %al
	subb	%dl, %al
	movzbl	%al, %eax
	btq	%rax, %rsi
	setb	%al
	movl	%edx, %ecx
	shldq	%cl, %rdi, %rsi
	testq	%rsi, %rsi
	sete	%dl
	addq	$2096, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB46_1:
	.cfi_def_cfa_offset 2112
	movq	%rsp, %rdi
	leaq	48(%rsp), %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	24(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movl	$618, %edi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB46_2
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB46_2:
	movb	$0, (%rax,%rdx)
	leaq	static_string_cfa776fe0f373673(%rip), %rcx
	movl	$693, %esi
	movl	$41, %edx
	movl	$54, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end46:
	.size	"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64", .Lfunc_end46-"std::builtin::_format_float::_compute_mul_parity[::DType](::SIMD[$0, ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)]),CarrierDType=ui64"
	.cfi_endproc

	.prefalign	4, .Lfunc_end47, nop
	.type	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_0",@function
"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_0":
	.cfi_startproc
	jmp	KGEN_CompilerRT_AsyncRT_GetOrCreateCPUDevice@PLT
.Lfunc_end47:
	.size	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_0", .Lfunc_end47-"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_0"
	.cfi_endproc

	.prefalign	4, .Lfunc_end48, nop
	.type	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_1",@function
"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_1":
	.cfi_startproc
	jmp	KGEN_CompilerRT_AsyncRT_ReleaseCPUDevice@PLT
.Lfunc_end48:
	.size	"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_1", .Lfunc_end48-"std::builtin::_startup::__wrap_and_execute_raising_main[def() raises thin -> None](::SIMD[::DType(int32), ::SIMDLength(1)],!kgen.pointer<pointer<scalar<ui8>>>),main_func=\"knn_index_layout_main::main()\"_closure_1"
	.cfi_endproc

	.section	.text.unlikely.,"ax",@progbits
	.prefalign	4, .Lfunc_end49, nop
	.type	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)",@function
"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)":
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rdi, %rax
	movl	$1, %r8d
	movq	%rcx, %rdi
	movq	%rax, %rcx
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>]],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"At: %s:%llu:%llu: Assert Error: %s\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 35 }"@PLT
	ud2
.Lfunc_end49:
	.size	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)", .Lfunc_end49-"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"
	.cfi_endproc

	.text
	.prefalign	4, .Lfunc_end50, nop
	.type	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true",@function
"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2104, %rsp
	.cfi_def_cfa_offset 2160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	2160(%rsp), %rbx
	movabsq	$2305843009213693952, %rax
	movq	(%rdi), %r15
	movq	$18, 16(%rsp)
	leaq	static_string_ac6214ef63a1e455(%rip), %rdi
	movq	%rdi, 8(%rsp)
	movq	%rax, 24(%rsp)
	movq	$39, 40(%rsp)
	leaq	static_string_a0fcf35b7349c924(%rip), %r10
	movq	%r10, 32(%rsp)
	movq	%rax, 48(%rsp)
	cmpq	%rsi, %r15
	ja	.LBB50_1
	movq	(%rdx), %r14
	movq	$16, 16(%rsp)
	leaq	static_string_3892d7ebe761439e(%rip), %rdx
	movq	%rdx, 8(%rsp)
	movq	%rax, 24(%rsp)
	movq	$39, 40(%rsp)
	movq	%r10, 32(%rsp)
	movq	%rax, 48(%rsp)
	cmpq	%rsi, %r14
	ja	.LBB50_5
	movq	$18, 16(%rsp)
	movq	%rdi, 8(%rsp)
	movq	%rax, 24(%rsp)
	movq	$33, 40(%rsp)
	leaq	static_string_fb3c88b69992ef11(%rip), %rdx
	movq	%rdx, 32(%rsp)
	movq	%rax, 48(%rsp)
	cmpq	%r14, %r15
	jg	.LBB50_8
	addq	$2104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB50_1:
	.cfi_def_cfa_offset 2160
	movq	%rcx, %rbp
	movq	%r8, %r13
	movq	%r9, %r12
	leaq	8(%rsp), %rdi
	leaq	56(%rsp), %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	32(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB50_11
	movb	$0, (%rax,%rdx)
	cmpq	$-1, %rbp
	movl	$111, %esi
	jmp	.LBB50_3
.LBB50_5:
	movq	%rcx, %rbp
	movq	%r8, %r13
	movq	%r9, %r12
	leaq	8(%rsp), %rdi
	leaq	56(%rsp), %rax
	movq	%rsi, %r15
	movq	%rax, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	32(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jge	.LBB50_11
	movb	$0, (%rax,%rdx)
	cmpq	$-1, %rbp
	movl	$119, %esi
	jmp	.LBB50_3
.LBB50_8:
	movq	%rcx, %rbp
	movq	%r8, %r13
	movq	%r9, %r12
	leaq	8(%rsp), %rdi
	leaq	56(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	32(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB50_9
.LBB50_11:
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB50_9:
	movb	$0, (%rax,%rdx)
	cmpq	$-1, %rbp
	movl	$127, %esi
.LBB50_3:
	cmovneq	%rbp, %rsi
	movl	$39, %ecx
	movq	%r13, %rdx
	cmoveq	%rcx, %rdx
	leaq	static_string_e1c7ba1ec05cb570(%rip), %rdi
	movq	%r12, %rcx
	cmoveq	%rdi, %rcx
	movl	$57, %edi
	cmoveq	%rdi, %rbx
	movq	%rax, %rdi
	movq	%rbx, %r8
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end50:
	.size	"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true", .Lfunc_end50-"std::collections::check_bounds::do_asserts(::SourceLocation)`0x1,cpu_default=true"
	.cfi_endproc

	.prefalign	4, .Lfunc_end51, nop
	.type	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true",@function
"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4184, %rsp
	.cfi_def_cfa_offset 4240
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r15
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movq	%rdi, %r12
	movq	$47, 56(%rsp)
	leaq	static_string_ffbf4d7e5dffbc40(%rip), %rax
	movq	%rax, 48(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 64(%rsp)
	movq	$3, 8(%rsp)
	leaq	static_string_0eb5fc97304e63c7(%rip), %rcx
	movq	%rcx, (%rsp)
	movq	%rax, 16(%rsp)
	movq	$1, 32(%rsp)
	movabsq	$4611686018427387904, %r13
	leaq	static_string_e7661a0566dadf97(%rip), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 40(%rsp)
	movl	$47, %esi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_TotalWritableBytes\">>, struct<(scalar<index>) memoryOnly>]"@PLT
	leaq	4(%rbx,%rax), %rcx
	cmpq	$23, %rcx
	jg	.LBB51_8
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 16(%r15)
	leaq	static_string_ffbf4d7e5dffbc40(%rip), %rsi
	movl	$47, %edx
	movq	%r15, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	movq	16(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB51_2
	movq	(%rsp), %rsi
	movq	8(%rsp), %rdx
	jmp	.LBB51_4
.LBB51_8:
	leaq	3(%rbx,%rax), %rdi
	addq	$8, %rdi
	movq	%rdi, %rbp
	sarq	$3, %rbp
	andq	$-8, %rdi
	addq	$8, %rdi
	movq	%rbp, 16(%r15)
	movl	$1, %esi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, (%r15)
	movq	$0, 8(%r15)
	orq	%r13, %rbp
	movq	%rbp, 16(%r15)
	movq	$0, 4168(%rsp)
	movq	%r15, 4176(%rsp)
	movq	64(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB51_9
	movq	48(%rsp), %rsi
	movq	56(%rsp), %rdx
	jmp	.LBB51_11
.LBB51_2:
	shrq	$56, %rdx
	andl	$31, %edx
	movq	%rsp, %rsi
.LBB51_4:
	movq	%r15, %rdi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	40(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB51_5
	movq	24(%rsp), %rsi
	movq	32(%rsp), %rdx
	movq	%r15, %rdi
	jmp	.LBB51_28
.LBB51_9:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	48(%rsp), %rsi
.LBB51_11:
	leaq	72(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4168(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB51_13
	movq	4176(%rsp), %rdi
	leaq	72(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4168(%rsp)
.LBB51_13:
	leaq	72(%rsp), %rsi
	movq	%r12, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::collections::string::string::String\\22>>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4168(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB51_15
	movq	4176(%rsp), %rdi
	leaq	72(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4168(%rsp)
.LBB51_15:
	movq	16(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB51_16
	movq	(%rsp), %rsi
	movq	8(%rsp), %rdx
	jmp	.LBB51_18
.LBB51_5:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	24(%rsp), %rsi
	movq	%r15, %rdi
	jmp	.LBB51_28
.LBB51_16:
	shrq	$56, %rdx
	andl	$31, %edx
	movq	%rsp, %rsi
.LBB51_18:
	leaq	72(%rsp), %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4168(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB51_20
	movq	4176(%rsp), %rdi
	leaq	72(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4168(%rsp)
.LBB51_20:
	leaq	72(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	movq	4168(%rsp), %rdx
	cmpq	$4097, %rdx
	jl	.LBB51_22
	movq	4176(%rsp), %rdi
	leaq	72(%rsp), %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4168(%rsp)
.LBB51_22:
	movq	40(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB51_23
	movq	24(%rsp), %rsi
	movq	32(%rsp), %rdx
	jmp	.LBB51_25
.LBB51_23:
	shrq	$56, %rdx
	andl	$31, %edx
	leaq	24(%rsp), %rsi
.LBB51_25:
	leaq	72(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4168(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB51_27
	movq	4176(%rsp), %rdi
	leaq	72(%rsp), %rbx
	movq	%rbx, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4168(%rsp)
	xorl	%edx, %edx
.LBB51_27:
	movq	4176(%rsp), %rdi
	movq	%rbx, %rsi
.LBB51_28:
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	testq	%r13, 40(%rsp)
	je	.LBB51_31
	movq	24(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB51_31
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB51_31:
	testq	%r13, 16(%rsp)
	je	.LBB51_34
	movq	(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB51_34
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB51_34:
	testq	%r13, 64(%rsp)
	je	.LBB51_37
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB51_37
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB51_37:
	addq	$4184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end51:
	.size	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true", .Lfunc_end51-"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true"
	.cfi_endproc

	.prefalign	4, .Lfunc_end52, nop
	.type	"std::io::io::_flush(::FileDescriptor)",@function
"std::io::io::_flush(::FileDescriptor)":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	callq	dup@PLT
	leaq	static_string_0d78baac08237ddb(%rip), %rsi
	movl	%eax, %edi
	callq	fdopen@PLT
	movq	%rax, %rbx
	movq	%rax, %rdi
	callq	fflush@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	fclose@PLT
.Lfunc_end52:
	.size	"std::io::io::_flush(::FileDescriptor)", .Lfunc_end52-"std::io::io::_flush(::FileDescriptor)"
	.cfi_endproc

	.prefalign	4, .Lfunc_end53, nop
	.type	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }",@function
"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	callq	dup@PLT
	leaq	static_string_0d78baac08237ddb(%rip), %rsi
	movl	%eax, %edi
	callq	fdopen@PLT
	movq	%rax, %rbx
	leaq	static_string_98e090712d66312f(%rip), %rsi
	movq	%rax, %rdi
	xorl	%eax, %eax
	callq	KGEN_CompilerRT_fprintf@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	fclose@PLT
.Lfunc_end53:
	.size	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }", .Lfunc_end53-"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"
	.cfi_endproc

	.prefalign	4, .Lfunc_end54, nop
	.type	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>]],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"At: %s:%llu:%llu: Assert Error: %s\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 35 }",@function
"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>]],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"At: %s:%llu:%llu: Assert Error: %s\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 35 }":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %rbx
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	movl	%r8d, %edi
	callq	dup@PLT
	leaq	static_string_0d78baac08237ddb(%rip), %rsi
	movl	%eax, %edi
	callq	fdopen@PLT
	movq	%rax, %r13
	leaq	static_string_0dcb71a55f79a509(%rip), %rsi
	movq	%rax, %rdi
	movq	%r12, %rdx
	movq	%r15, %rcx
	movq	%r14, %r8
	movq	%rbx, %r9
	xorl	%eax, %eax
	callq	KGEN_CompilerRT_fprintf@PLT
	movq	%r13, %rdi
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	fclose@PLT
.Lfunc_end54:
	.size	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>]],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"At: %s:%llu:%llu: Assert Error: %s\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 35 }", .Lfunc_end54-"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=false,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=ui8,length=1\\22>>, scalar<ui8>],origin={  },address_space=0\">>, pointer<none>]],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"At: %s:%llu:%llu: Assert Error: %s\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 35 }"
	.cfi_endproc

	.prefalign	4, .Lfunc_end55, nop
	.type	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])",@function
"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$72, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	callq	KGEN_CompilerRT_AlignedAlloc@PLT
	testq	%rax, %rax
	je	.LBB55_1
	addq	$72, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB55_1:
	.cfi_def_cfa_offset 96
	movq	$37, 56(%rsp)
	leaq	static_string_09e773a88105e290(%rip), %rax
	movq	%rax, 48(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%rax, 64(%rsp)
	movq	$1, 8(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rcx
	movq	%rcx, (%rsp)
	movq	%rax, 16(%rsp)
	movq	$2, 32(%rsp)
	movabsq	$4611686018427387904, %rbx
	leaq	static_string_7f1562353e292282(%rip), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rax, 40(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_bbe01a6a523daf15(%rip), %rax
	leaq	static_string_c44bdff4074eecdb(%rip), %r10
	leaq	56(%rsp), %r11
	leaq	32(%rsp), %r14
	leaq	static_string_31203c1a2bdb78cc(%rip), %rdi
	leaq	static_string_e167731b2f840751(%rip), %r9
	leaq	8(%rsp), %rdx
	movl	$6, %esi
	movl	$602, %ecx
	movl	$14, %r8d
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	$45
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	testb	$64, 47(%rsp)
	je	.LBB55_4
	movq	24(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB55_4
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB55_4:
	testq	%rbx, 16(%rsp)
	je	.LBB55_7
	movq	(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB55_7
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB55_7:
	ud2
.Lfunc_end55:
	.size	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])", .Lfunc_end55-"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end56, nop
	.type	"std::os::env::getenv(::String$,::String)",@function
"std::os::env::getenv(::String$,::String)":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rbx
	movq	%rcx, %r15
	movq	%rdx, %r12
	movq	%rsi, %r14
	movq	%rdi, %r13
	movq	16(%rdi), %rbp
	btq	$61, %rbp
	jb	.LBB56_8
	testq	%rbp, %rbp
	js	.LBB56_2
	movq	8(%r13), %rsi
	jmp	.LBB56_4
.LBB56_2:
	shrq	$56, %rbp
	andl	$31, %ebp
	movq	%rbp, %rsi
.LBB56_4:
	movabsq	$2305843009213693952, %rbp
	incq	%rsi
	movq	%r13, %rdi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	16(%r13), %rcx
	testq	%rcx, %rcx
	js	.LBB56_5
	movq	8(%r13), %rcx
	jmp	.LBB56_7
.LBB56_5:
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB56_7:
	movb	$0, (%rax,%rcx)
	orq	16(%r13), %rbp
	movq	%rbp, 16(%r13)
.LBB56_8:
	movq	%r13, %rdi
	testq	%rbp, %rbp
	js	.LBB56_10
	movq	(%r13), %rdi
.LBB56_10:
	callq	getenv@PLT
	testb	$64, 23(%r13)
	je	.LBB56_13
	movq	(%r13), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB56_13
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rax, %r13
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r13, %rax
.LBB56_13:
	testq	%rax, %rax
	je	.LBB56_19
	movabsq	$9223372036854775807, %rcx
	xorl	%esi, %esi
	.p2align	4
.LBB56_15:
	cmpb	$0, (%rax,%rsi)
	je	.LBB56_18
	incq	%rsi
	cmpq	%rsi, %rcx
	jne	.LBB56_15
	movq	%rcx, %rsi
.LBB56_18:
	leaq	static_string_2d06800538d394c2(%rip), %rdx
	movq	%rax, %rdi
	xorl	%ecx, %ecx
	movq	%rbx, %r8
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
.LBB56_19:
	.cfi_def_cfa_offset 64
	movq	%r14, (%rbx)
	movabsq	$4611686018427387904, %rax
	movq	%r12, 8(%rbx)
	movq	%r15, 16(%rbx)
	testq	%rax, %r15
	je	.LBB56_21
	lock		incq	-8(%r14)
.LBB56_21:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end56:
	.size	"std::os::env::getenv(::String$,::String)", .Lfunc_end56-"std::os::env::getenv(::String$,::String)"
	.cfi_endproc

	.prefalign	4, .Lfunc_end57, nop
	.type	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32",@function
"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	leaq	8(%rsp), %rdi
	leaq	16(%rsp), %rsi
	movl	$4, %r8d
	callq	AsyncRT_DeviceContext_createHostBuffer@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	$0, 40(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 48(%rsp)
	testq	%rax, %rax
	je	.LBB57_1
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	56(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$376, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	64(%rsp), %rsi
	movq	72(%rsp), %r15
	movq	80(%rsp), %r12
	movq	88(%rsp), %r13
	movzbl	96(%rsp), %ebp
	movzbl	56(%rsp), %r14d
	testb	$64, 55(%rsp)
	je	.LBB57_6
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB57_6
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rsi, 24(%rsp)
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	24(%rsp), %rsi
.LBB57_6:
	testb	$1, %r14b
	je	.LBB57_2
	movb	$1, %al
	jmp	.LBB57_8
.LBB57_1:
.LBB57_2:
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rdx
	xorl	%eax, %eax
.LBB57_8:
	movq	%rdx, 56(%rbx)
	movq	%rcx, 48(%rbx)
	movb	%bpl, 40(%rbx)
	movq	%r13, 32(%rbx)
	movq	%r12, 24(%rbx)
	movq	%r15, 16(%rbx)
	movq	%rsi, 8(%rbx)
	movb	%al, (%rbx)
	movq	%rbx, %rax
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end57:
	.size	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32", .Lfunc_end57-"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end58, nop
	.type	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32",@function
"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	leaq	8(%rsp), %rdi
	leaq	16(%rsp), %rsi
	movl	$4, %r8d
	callq	AsyncRT_DeviceContext_createHostBuffer@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	$0, 40(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 48(%rsp)
	testq	%rax, %rax
	je	.LBB58_1
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	56(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$376, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	64(%rsp), %rsi
	movq	72(%rsp), %r15
	movq	80(%rsp), %r12
	movq	88(%rsp), %r13
	movzbl	96(%rsp), %ebp
	movzbl	56(%rsp), %r14d
	testb	$64, 55(%rsp)
	je	.LBB58_6
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB58_6
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rsi, 24(%rsp)
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	24(%rsp), %rsi
.LBB58_6:
	testb	$1, %r14b
	je	.LBB58_2
	movb	$1, %al
	jmp	.LBB58_8
.LBB58_1:
.LBB58_2:
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rdx
	xorl	%eax, %eax
.LBB58_8:
	movq	%rdx, 56(%rbx)
	movq	%rcx, 48(%rbx)
	movb	%bpl, 40(%rbx)
	movq	%r13, 32(%rbx)
	movq	%r12, 24(%rbx)
	movq	%r15, 16(%rbx)
	movq	%rsi, 8(%rbx)
	movb	%al, (%rbx)
	movq	%rbx, %rax
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end58:
	.size	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32", .Lfunc_end58-"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end59, nop
	.type	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32",@function
"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32":
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$88, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdx, %rbx
	vmovss	%xmm0, 12(%rsp)
	movq	%rsi, %r14
	movq	%rsi, %rdi
	callq	AsyncRT_DeviceBuffer_context@PLT
	vmovd	12(%rsp), %xmm0
	vmovd	%xmm0, %edx
	movl	$4, %ecx
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_setMemory_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 16(%rsp)
	movq	$0, 24(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 32(%rsp)
	testq	%rax, %rax
	je	.LBB59_5
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	40(%rsp), %rdi
	leaq	16(%rsp), %rdx
	movl	$5649, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movzbl	80(%rsp), %ecx
	vmovups	48(%rsp), %ymm0
	movzbl	40(%rsp), %eax
	vmovups	%ymm0, (%rbx)
	movb	%cl, 32(%rbx)
	testb	$64, 39(%rsp)
	je	.LBB59_4
	movq	16(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB59_4
	addq	$-8, %rdi
	#MEMBARRIER
	movl	%eax, %ebx
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movl	%ebx, %eax
.LBB59_4:
	addq	$88, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB59_5:
	.cfi_def_cfa_offset 112
	xorl	%eax, %eax
	addq	$88, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end59:
	.size	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32", .Lfunc_end59-"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=f32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end60, nop
	.type	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=ui32",@function
"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=ui32":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$80, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %rbx
	movl	%edx, %ebp
	movq	%rsi, %r14
	movq	%rsi, %rdi
	callq	AsyncRT_DeviceBuffer_context@PLT
	movl	%ebp, %edx
	movl	$4, %ecx
	movq	%rax, %rdi
	movq	%r14, %rsi
	callq	AsyncRT_DeviceContext_setMemory_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 8(%rsp)
	movq	$0, 16(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 24(%rsp)
	testq	%rax, %rax
	je	.LBB60_1
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	32(%rsp), %rdi
	leaq	8(%rsp), %rdx
	movl	$5649, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movzbl	72(%rsp), %ecx
	vmovups	40(%rsp), %ymm0
	movzbl	32(%rsp), %eax
	vmovups	%ymm0, (%rbx)
	movb	%cl, 32(%rbx)
	testb	$64, 31(%rsp)
	je	.LBB60_5
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB60_5
	addq	$-8, %rdi
	#MEMBARRIER
	movl	%eax, %ebx
	vzeroupper
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movl	%ebx, %eax
	jmp	.LBB60_5
.LBB60_1:
	xorl	%eax, %eax
.LBB60_5:
	addq	$80, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.Lfunc_end60:
	.size	"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=ui32", .Lfunc_end60-"max::gpu::host::device_context::DeviceBuffer::enqueue_fill(max::gpu::host::device_context::DeviceBuffer[$0],::SIMD[$0, ::SIMDLength(1)]),dtype=ui32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end61, nop
	.type	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }",@function
"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }":
	xorl	%eax, %eax
	retq
.Lfunc_end61:
	.size	"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }", .Lfunc_end61-"max::gpu::host::device_context::DeviceFunction::dump_rep[::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?],::Variant[::Bool, ::Path, ::StringSpan[::Bool(False), ImmStaticOrigin, *?], def() capturing thin -> ::Path, *?]](max::gpu::host::device_context::DeviceFunction[$0, $1, $2, $3, $4, $5, $6, $7]),func_type=[typevalue<#kgen.instref<\"std::builtin::_stubs::__MLIRType,T=[(!kgen.pointer<typevalue<#kgen.instref<\\1B\\22std::builtin::variadics::VariadicPack,elt_is_mutable=false,origin._mlir_origin`={  },origin={  },element_trait=[typevalue<#kgen.trait_ref<\\\\1B\\\\22std::traits::anytype::AnyType\\\\22>>, type],element_types.values`2=[[typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\\\\\\\1B\\\\\\\\22std::builtin::simd::SIMD,dtype=f32,length=1\\\\\\\\22>>, scalar<f32>],origin={  },address_space=0\\\\22>>, pointer<none>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>], [typevalue<#kgen.instref<\\\\1B\\\\22std::builtin::simd::SIMD,dtype=si32,length=1\\\\22>>, scalar<si32>]],is_owned=false,element_types={  }\\22>>> read_mem) -> !kgen.none, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none]\">>, (!kgen.pointer<struct<(pointer<pointer<none>>, pointer<pointer<none>>, pointer<scalar<si32>>, pointer<scalar<si32>>) isParamPack>> read_mem) -> !kgen.none],declared_arg_types.values`=[[typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::memory::pointer::Pointer,mut=true,origin._mlir_origin`={  },T=[typevalue<#kgen.instref<\\1B\\22std::builtin::simd::SIMD,dtype=f32,length=1\\22>>, scalar<f32>],origin={  },address_space=0\">>, pointer<none>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=si32,length=1\">>, scalar<si32>]],func=\"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604[LITImmOrigin,::Origin[::Bool(False), $0],def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None](::VariadicPack[::Bool(False), $0, $1, ::AnyType, ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], ::SIMD[::DType(int32), ::SIMDLength(1)], ::SIMD[::DType(int32), ::SIMDLength(1)], ::Bool(False), *?])\"<:(!kgen.pointer<none>, !kgen.pointer<none>, !kgen.scalar<si32>, !kgen.scalar<si32>) -> !kgen.none \"core::column_stats::transpose_kernel(::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int32), ::SIMDLength(1)],::SIMD[::DType(int32), ::SIMDLength(1)])\">,target=#kgen.target<triple = \"nvptx64-nvidia-cuda\", arch = \"sm_90a\", stdlib_plugin = \"cuda\", features = \"+ptx85,+sm_90a\", data_layout = \"e-p3:32:32-p4:32:32-p5:32:32-p6:32:32-p7:32:32-p101:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64\", simd_bit_width = 128, index_bit_width = 64, tune_cpu = \"sm_90a\">,compile_options={ #interp.memref<{[(#interp.memory_handle<16, \"nvptx-short-ptr=true\\00\" string>, const_global, [], [])], []}, 0, 0>, 20 },link_options={ #interp.memref<{[(#interp.memory_handle<16, \"\" string>, const_global, [], [])], []}, 0, 0>, 0 },_ptxas_info_verbose=false,dump_asm={ { {:scalar<bool> false, 0} } },dump_llvm={ { {:scalar<bool> false, 0} } },_dump_sass={ { {:scalar<bool> false, 0} } }"

	.prefalign	4, .Lfunc_end62, nop
	.type	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32",@function
"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	movabsq	$2305843009213693952, %r15
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	leaq	32(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$4, %r8d
	callq	AsyncRT_DeviceContext_createBuffer_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	%r15, 24(%rsp)
	testq	%rax, %rax
	je	.LBB62_1
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	112(%rsp), %rdi
	leaq	16(%rsp), %rdx
	movl	$4073, %ecx
	movl	$35, %r8d
	movq	%rax, %rsi
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movq	112(%rsp), %rsi
	movq	120(%rsp), %r12
	movq	128(%rsp), %r13
	movq	136(%rsp), %rbp
	movzbl	144(%rsp), %r14d
	movzbl	104(%rsp), %r15d
	testb	$64, 31(%rsp)
	je	.LBB62_5
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB62_5
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rsi, 48(%rsp)
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	48(%rsp), %rsi
.LBB62_5:
	testb	$1, %r15b
	je	.LBB62_7
	movb	$1, %al
	jmp	.LBB62_17
.LBB62_1:
	movq	40(%rsp), %rcx
	testq	%rcx, %rcx
	je	.LBB62_9
.LBB62_16:
	movq	32(%rsp), %rdx
	xorl	%eax, %eax
.LBB62_17:
	movq	%rdx, 56(%rbx)
	movq	%rcx, 48(%rbx)
	movb	%r14b, 40(%rbx)
	movq	%rbp, 32(%rbx)
	movq	%r13, 24(%rbx)
	movq	%r12, 16(%rbx)
	movq	%rsi, 8(%rbx)
	movb	%al, (%rbx)
	movq	%rbx, %rax
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB62_7:
	.cfi_def_cfa_offset 208
	movabsq	$2305843009213693952, %r15
	movq	40(%rsp), %rcx
	testq	%rcx, %rcx
	jne	.LBB62_16
.LBB62_9:
	movq	$192, 88(%rsp)
	leaq	static_string_f9c5d72f244f07d1(%rip), %rax
	movq	%rax, 80(%rsp)
	movq	%r15, 96(%rsp)
	movq	$1, 64(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 72(%rsp)
	movq	$2, 16(%rsp)
	movabsq	$4611686018427387904, %rbx
	leaq	static_string_7f1562353e292282(%rip), %rax
	movq	%rax, 8(%rsp)
	movq	%r15, 24(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_bbe01a6a523daf15(%rip), %rax
	leaq	static_string_c44bdff4074eecdb(%rip), %r10
	leaq	88(%rsp), %r11
	leaq	16(%rsp), %r14
	leaq	static_string_31203c1a2bdb78cc(%rip), %rdi
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	64(%rsp), %rdx
	movl	$6, %esi
	movl	$1416, %ecx
	movl	$44, %r8d
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	testb	$64, 31(%rsp)
	je	.LBB62_12
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB62_12
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB62_12:
	testq	%rbx, 72(%rsp)
	je	.LBB62_15
	movq	56(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB62_15
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB62_15:
	ud2
.Lfunc_end62:
	.size	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32", .Lfunc_end62-"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end63, nop
	.type	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32",@function
"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	movabsq	$2305843009213693952, %r15
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	leaq	32(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movl	$4, %r8d
	callq	AsyncRT_DeviceContext_createBuffer_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	%r15, 24(%rsp)
	testq	%rax, %rax
	je	.LBB63_1
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	112(%rsp), %rdi
	leaq	16(%rsp), %rdx
	movl	$4073, %ecx
	movl	$35, %r8d
	movq	%rax, %rsi
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movq	112(%rsp), %rsi
	movq	120(%rsp), %r12
	movq	128(%rsp), %r13
	movq	136(%rsp), %rbp
	movzbl	144(%rsp), %r14d
	movzbl	104(%rsp), %r15d
	testb	$64, 31(%rsp)
	je	.LBB63_5
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB63_5
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rsi, 48(%rsp)
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	48(%rsp), %rsi
.LBB63_5:
	testb	$1, %r15b
	je	.LBB63_7
	movb	$1, %al
	jmp	.LBB63_17
.LBB63_1:
	movq	40(%rsp), %rcx
	testq	%rcx, %rcx
	je	.LBB63_9
.LBB63_16:
	movq	32(%rsp), %rdx
	xorl	%eax, %eax
.LBB63_17:
	movq	%rdx, 56(%rbx)
	movq	%rcx, 48(%rbx)
	movb	%r14b, 40(%rbx)
	movq	%rbp, 32(%rbx)
	movq	%r13, 24(%rbx)
	movq	%r12, 16(%rbx)
	movq	%rsi, 8(%rbx)
	movb	%al, (%rbx)
	movq	%rbx, %rax
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB63_7:
	.cfi_def_cfa_offset 208
	movabsq	$2305843009213693952, %r15
	movq	40(%rsp), %rcx
	testq	%rcx, %rcx
	jne	.LBB63_16
.LBB63_9:
	movq	$192, 88(%rsp)
	leaq	static_string_f9c5d72f244f07d1(%rip), %rax
	movq	%rax, 80(%rsp)
	movq	%r15, 96(%rsp)
	movq	$1, 64(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rax
	movq	%rax, 56(%rsp)
	movq	%r15, 72(%rsp)
	movq	$2, 16(%rsp)
	movabsq	$4611686018427387904, %rbx
	leaq	static_string_7f1562353e292282(%rip), %rax
	movq	%rax, 8(%rsp)
	movq	%r15, 24(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_bbe01a6a523daf15(%rip), %rax
	leaq	static_string_c44bdff4074eecdb(%rip), %r10
	leaq	88(%rsp), %r11
	leaq	16(%rsp), %r14
	leaq	static_string_31203c1a2bdb78cc(%rip), %rdi
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	64(%rsp), %rdx
	movl	$6, %esi
	movl	$1416, %ecx
	movl	$44, %r8d
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	$41
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	testb	$64, 31(%rsp)
	je	.LBB63_12
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB63_12
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB63_12:
	testq	%rbx, 72(%rsp)
	je	.LBB63_15
	movq	56(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB63_15
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB63_15:
	ud2
.Lfunc_end63:
	.size	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32", .Lfunc_end63-"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=ui32"
	.cfi_endproc

	.prefalign	4, .Lfunc_end64, nop
	.type	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])",@function
"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])":
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -16
	movabsq	$9223372036854775807, %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 24(%rsp)
	testq	%rdi, %rdi
	je	.LBB64_6
	xorl	%esi, %esi
	.p2align	4
.LBB64_2:
	cmpb	$0, (%rdi,%rsi)
	je	.LBB64_5
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB64_2
	movq	%rax, %rsi
.LBB64_5:
	leaq	static_string_2d06800538d394c2(%rip), %rdx
	leaq	8(%rsp), %r8
	movq	%rdi, %rbx
	xorl	%ecx, %ecx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
	movq	%rbx, %rdi
.LBB64_6:
	callq	AsyncRT_DeviceContext_strfree@PLT
	movq	8(%rsp), %rax
	movq	16(%rsp), %rdx
	movq	24(%rsp), %rcx
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end64:
	.size	"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])", .Lfunc_end64-"max::gpu::host::device_context::_string_from_owned_charptr[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]])"
	.cfi_endproc

	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
.LCPI65_0:
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	68
	.byte	101
	.byte	118
	.byte	105
	.byte	99
	.byte	101
	.byte	67
	.byte	111
	.byte	110
	.byte	116
	.byte	101
	.byte	120
	.byte	116
	.byte	46
	.byte	101
	.byte	110
	.byte	113
	.byte	117
	.byte	101
	.byte	117
	.byte	101
	.byte	95
	.byte	102
	.byte	117
	.byte	110
	.byte	99
	.byte	116
	.byte	105
	.byte	111
	.byte	110
	.byte	58
	.byte	32
	.byte	68
	.byte	105
	.byte	109
	.byte	32
	.byte	118
	.byte	97
	.byte	108
	.byte	117
	.byte	101
	.byte	32
	.byte	103
	.byte	114
	.byte	105
	.byte	100
	.byte	95
	.byte	100
	.byte	105
	.byte	109
	.byte	46
	.byte	122
	.byte	32
	.byte	109
	.byte	117
	.byte	115
.LCPI65_2:
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	68
	.byte	101
	.byte	118
	.byte	105
	.byte	99
	.byte	101
	.byte	67
	.byte	111
	.byte	110
	.byte	116
	.byte	101
	.byte	120
	.byte	116
	.byte	46
	.byte	101
	.byte	110
	.byte	113
	.byte	117
	.byte	101
	.byte	117
	.byte	101
	.byte	95
	.byte	102
	.byte	117
	.byte	110
	.byte	99
	.byte	116
	.byte	105
	.byte	111
	.byte	110
	.byte	58
	.byte	32
	.byte	68
	.byte	105
	.byte	109
	.byte	32
	.byte	118
	.byte	97
	.byte	108
	.byte	117
	.byte	101
	.byte	32
	.byte	103
	.byte	114
	.byte	105
	.byte	100
	.byte	95
	.byte	100
	.byte	105
	.byte	109
	.byte	46
	.byte	121
	.byte	32
	.byte	109
	.byte	117
	.byte	115
.LCPI65_3:
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	68
	.byte	101
	.byte	118
	.byte	105
	.byte	99
	.byte	101
	.byte	67
	.byte	111
	.byte	110
	.byte	116
	.byte	101
	.byte	120
	.byte	116
	.byte	46
	.byte	101
	.byte	110
	.byte	113
	.byte	117
	.byte	101
	.byte	117
	.byte	101
	.byte	95
	.byte	102
	.byte	117
	.byte	110
	.byte	99
	.byte	116
	.byte	105
	.byte	111
	.byte	110
	.byte	58
	.byte	32
	.byte	68
	.byte	105
	.byte	109
	.byte	32
	.byte	118
	.byte	97
	.byte	108
	.byte	117
	.byte	101
	.byte	32
	.byte	103
	.byte	114
	.byte	105
	.byte	100
	.byte	95
	.byte	100
	.byte	105
	.byte	109
	.byte	46
	.byte	120
	.byte	32
	.byte	109
	.byte	117
	.byte	115
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI65_1:
	.byte	116
	.byte	32
	.byte	98
	.byte	101
	.byte	32
	.byte	97
	.byte	32
	.byte	112
	.byte	111
	.byte	115
	.byte	105
	.byte	116
	.byte	105
	.byte	118
	.byte	101
	.byte	32
	.text
	.prefalign	4, .Lfunc_end65, nop
	.type	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\"",@function
"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\"":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$48, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r9, %rbx
	movq	%r8, %r15
	movq	%rcx, %r12
	movq	96(%rsp), %r14
	movq	104(%rsp), %r13
	testq	%rdi, %rdi
	jle	.LBB65_1
	testq	%rsi, %rsi
	jle	.LBB65_3
	testq	%rdx, %rdx
	jle	.LBB65_6
	xorl	%eax, %eax
	jmp	.LBB65_11
.LBB65_1:
	movl	$1, %edi
	movl	$88, %esi
	callq	KGEN_CompilerRT_AlignedAlloc@PLT
	vmovaps	.LCPI65_3(%rip), %zmm0
	jmp	.LBB65_7
.LBB65_3:
	movl	$1, %edi
	movl	$88, %esi
	callq	KGEN_CompilerRT_AlignedAlloc@PLT
	vmovaps	.LCPI65_2(%rip), %zmm0
	jmp	.LBB65_7
.LBB65_6:
	movl	$1, %edi
	movl	$88, %esi
	callq	KGEN_CompilerRT_AlignedAlloc@PLT
	vmovaps	.LCPI65_0(%rip), %zmm0
.LBB65_7:
	vmovups	%zmm0, (%rax)
	vmovaps	.LCPI65_1(%rip), %xmm0
	vmovups	%xmm0, 64(%rax)
	movabsq	$13073628697294190, %rcx
	movq	%rcx, 80(%rax)
	addq	$8, %rax
	movq	%rax, (%rsp)
	movq	$79, 8(%rsp)
	movabsq	$4611686018427387904, %rax
	orq	$10, %rax
	movq	%rax, 16(%rsp)
	movq	%rsp, %r8
	leaq	24(%rsp), %r9
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	movq	%r14, %rcx
	vzeroupper
	callq	"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	testb	$64, 23(%rsp)
	je	.LBB65_10
	movq	(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB65_10
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB65_10:
	movq	24(%rsp), %rax
	movq	%rax, (%r13)
	vmovups	32(%rsp), %xmm0
	vmovups	%xmm0, 8(%r13)
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 24(%r13)
	movb	%dl, 32(%r13)
	movb	$1, %al
.LBB65_11:
	addq	$48, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end65:
	.size	"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\"", .Lfunc_end65-"max::gpu::host::device_context::_check_dim[!kgen.string,!kgen.string,::StringLiteral[$0],::StringLiteral[$1]](max::gpu::host::dim::Dim,location:::SourceLocation),func_name_for_msg.value`=\"DeviceContext.enqueue_function\",dim_name_for_msg.value`1=\"grid_dim\""
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI66_0:
	.long	0
	.long	128
	.long	2048
	.long	65536
	.text
	.prefalign	4, .Lfunc_end66, nop
	.type	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])",@function
"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4264, %rsp
	.cfi_def_cfa_offset 4320
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rbp
	movq	%rdi, %rbx
	movq	%rsi, 48(%rsp)
	movabsq	$4611686018427387904, %r15
	movq	%rdx, 56(%rsp)
	movq	%rcx, 64(%rsp)
	btq	$62, %rcx
	jae	.LBB66_2
	lock		incq	-8(%rsi)
.LBB66_2:
	leaq	static_string_2d06800538d394c2(%rip), %r14
	leaq	48(%rsp), %rdi
	movabsq	$2305843009213693952, %rcx
	leaq	152(%rsp), %r12
	movq	%r14, %rsi
	xorl	%edx, %edx
	movq	%r12, %r8
	callq	"std::os::env::getenv(::String$,::String)"@PLT
	leaq	104(%rsp), %rcx
	movq	%r12, %rdi
	movq	%r14, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	testq	%r15, 168(%rsp)
	je	.LBB66_5
	movq	152(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_5
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_5:
	movq	120(%rsp), %rax
	testq	%rax, %rax
	js	.LBB66_9
	cmpq	$0, 112(%rsp)
	je	.LBB66_10
.LBB66_7:
	leaq	104(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	%rax, %r15
	movq	120(%rsp), %r13
	testq	%r13, %r13
	js	.LBB66_12
	movq	112(%rsp), %r13
	testq	%r13, %r13
	jg	.LBB66_13
	jmp	.LBB66_84
.LBB66_9:
	movabsq	$2233785415175766016, %rcx
	testq	%rcx, %rax
	jne	.LBB66_7
.LBB66_10:
	testq	%r15, %rax
	jne	.LBB66_21
	xorl	%r15d, %r15d
	jmp	.LBB66_23
.LBB66_12:
	shrq	$56, %r13
	andl	$31, %r13d
	testq	%r13, %r13
	jle	.LBB66_84
.LBB66_13:
	xorl	%r14d, %r14d
	.p2align	4
.LBB66_14:
	movzbl	(%r15,%r14), %r12d
	cmpb	$32, %r12b
	sete	%al
	leal	-9(%r12), %ecx
	cmpb	$5, %cl
	setb	%cl
	leal	-28(%r12), %edx
	cmpb	$3, %dl
	setb	%dl
	testb	%r12b, %r12b
	js	.LBB66_18
	orb	%dl, %cl
	orb	%al, %cl
	je	.LBB66_18
	incq	%r14
	cmpq	%r14, %r13
	jne	.LBB66_14
	movzbl	(%r15,%r13), %r12d
	movq	%r13, %r14
.LBB66_18:
	leal	-43(%r12), %eax
	andb	$-3, %al
	cmpb	$1, %al
	adcq	$0, %r14
	leaq	1(%r14), %rax
	cmpq	%r13, %rax
	movq	%rbx, 40(%rsp)
	jge	.LBB66_52
	movzbl	1(%r15,%r14), %ebp
	testb	%bpl, %bpl
	js	.LBB66_24
	movabsq	$-9151314442816847872, %rax
	movq	%rax, 88(%rsp)
	leaq	72(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movb	%bpl, (%rax)
	jmp	.LBB66_49
.LBB66_21:
	movq	104(%rsp), %rdi
	xorl	%r15d, %r15d
	lock		decq	-8(%rdi)
	jne	.LBB66_23
	addq	$-8, %rdi
	jmp	.LBB66_89
.LBB66_23:
	jmp	.LBB66_91
.LBB66_24:
	movzbl	%bpl, %eax
	vpbroadcastd	%eax, %xmm0
	vpcmpnltud	.LCPI66_0(%rip), %xmm0, %k0
	kmovb	%k0, %eax
	popcntl	%eax, %eax
	movq	%rax, 8(%rsp)
	orq	$-128, %rax
	shlq	$56, %rax
	movq	%rax, 24(%rsp)
	movq	%rax, 168(%rsp)
	leaq	152(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movl	%ebp, %ecx
	andb	$-65, %cl
	movb	%cl, 6(%rsp)
	movl	%ebp, %ecx
	shrb	$6, %cl
	movq	%rcx, 96(%rsp)
	addl	$-128, %ecx
	movl	%ecx, 20(%rsp)
	cmpb	$1, 8(%rsp)
	movb	%bpl, 7(%rsp)
	jne	.LBB66_93
	movb	%bpl, (%rax)
.LBB66_26:
	leaq	152(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	160(%rsp), %rbp
	movq	168(%rsp), %rbx
	movabsq	$4611686018427387904, %rax
	testq	%rax, %rbx
	je	.LBB66_29
	movq	152(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_29
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_29:
	movq	%rbx, %rax
	shrq	$56, %rax
	andl	$31, %eax
	testq	%rbx, %rbx
	cmovsq	%rax, %rbp
	movq	8(%rsp), %rbx
	movzbl	%bl, %eax
	movl	%eax, 36(%rsp)
	cmpq	$23, %rbp
	jg	.LBB66_34
	movabsq	$-9223372036854775808, %rax
	movq	%rax, 88(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 168(%rsp)
	leaq	152(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	cmpb	$1, %bl
	jne	.LBB66_95
	movzbl	7(%rsp), %ecx
	movb	%cl, (%rax)
.LBB66_32:
	leaq	152(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	168(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB66_38
	movq	160(%rsp), %rdx
	jmp	.LBB66_39
.LBB66_34:
	addq	$7, %rbp
	movq	%rbp, %rbx
	sarq	$3, %rbx
	andq	$-8, %rbp
	addq	$8, %rbp
	movl	$1, %esi
	movq	%rbp, %rdi
	callq	"std::memory::alloc::_alloc_bytes(::Layout[::SIMD[::DType(uint8), ::SIMDLength(1)]])"@PLT
	movq	$1, (%rax)
	addq	$8, %rax
	movq	%rax, 72(%rsp)
	movq	$0, 80(%rsp)
	movabsq	$4611686018427387904, %rax
	orq	%rax, %rbx
	movq	%rbx, 88(%rsp)
	movq	$0, 4248(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, 4256(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	cmpb	$1, 8(%rsp)
	jne	.LBB66_97
	movzbl	7(%rsp), %ecx
	movb	%cl, (%rax)
.LBB66_36:
	leaq	48(%rsp), %rdi
	xorl	%esi, %esi
	callq	"std::collections::string::string::String::unsafe_ptr_mut(::String,::SIMD[::DType(int), ::SIMDLength(1)]$)"@PLT
	movq	64(%rsp), %rdx
	testq	%rdx, %rdx
	js	.LBB66_42
	movq	56(%rsp), %rdx
	jmp	.LBB66_43
.LBB66_38:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB66_39:
	leaq	72(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movabsq	$4611686018427387904, %rax
	testq	%rax, 168(%rsp)
	je	.LBB66_49
	movq	152(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_49
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB66_49
.LBB66_42:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB66_43:
	leaq	152(%rsp), %rbp
	movq	%rbp, %rdi
	movq	%rax, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>],stack_buffer_bytes=4096,string.mut`2x1=true"@PLT
	movabsq	$4611686018427387904, %rax
	testq	%rax, 64(%rsp)
	je	.LBB66_46
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_46
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_46:
	movq	4248(%rsp), %rdx
	cmpq	$4096, %rdx
	jle	.LBB66_48
	movq	4256(%rsp), %rdi
	leaq	152(%rsp), %rbp
	movq	%rbp, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
	movq	$0, 4248(%rsp)
	xorl	%edx, %edx
.LBB66_48:
	movq	4256(%rsp), %rdi
	movq	%rbp, %rsi
	callq	"std::collections::string::string::String::_iadd[LITImmOrigin,::Origin[::Bool(False), $0]](::String,::Span[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))])"@PLT
.LBB66_49:
	cmpb	$48, (%r15,%r14)
	movq	88(%rsp), %rax
	movabsq	$4611686018427387904, %rcx
	testq	%rcx, %rax
	je	.LBB66_52
	movq	72(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_52
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_52:
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	leaq	128(%rsp), %rbp
	movl	$9, %edi
	xorl	%edx, %edx
	movq	%rbp, %rcx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"@PLT
	movq	128(%rsp), %rdi
	movq	144(%rsp), %rax
	movq	%rax, %rcx
	shrq	$56, %rcx
	andl	$31, %ecx
	testq	%rax, %rax
	cmovnsq	%rdi, %rbp
	cmovnsq	136(%rsp), %rcx
	testq	%rcx, %rcx
	je	.LBB66_108
	movsbl	(%rbp), %ebx
	testl	%ebx, %ebx
	jns	.LBB66_57
	movl	%ebx, %esi
	shll	$24, %ebx
	notl	%ebx
	lzcntl	%ebx, %ecx
	leal	(%rcx,%rcx), %edx
	leal	(%rdx,%rdx,2), %edx
	addb	$-6, %dl
	movb	$127, %r8b
	shrb	%cl, %r8b
	andb	%sil, %r8b
	movzbl	%r8b, %esi
	shlxq	%rdx, %rsi, %rbx
	cmpb	$1, %cl
	je	.LBB66_57
	movzbl	%dl, %edx
	addq	$-6, %rdx
	movl	$1, %esi
	.p2align	4
.LBB66_56:
	movzbl	(%rbp,%rsi), %r8d
	incq	%rsi
	andl	$63, %r8d
	shlxq	%rdx, %r8, %r8
	orq	%r8, %rbx
	addq	$-6, %rdx
	cmpq	%rsi, %rcx
	jne	.LBB66_56
.LBB66_57:
	movabsq	$4611686018427387904, %rcx
	testq	%rcx, %rax
	je	.LBB66_60
	lock		decq	-8(%rdi)
	jne	.LBB66_60
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_60:
	cmpq	%r13, %r14
	movq	%r13, %rcx
	cmovgq	%r14, %rcx
	negq	%rcx
	movb	$1, %sil
	xorl	%eax, %eax
	xorl	%edx, %edx
.LBB66_61:
	incq	%r14
	.p2align	4
.LBB66_62:
	leaq	(%rcx,%r14), %rdi
	cmpq	$1, %rdi
	je	.LBB66_73
	movzbl	-1(%r15,%r14), %edi
	cmpl	$95, %edi
	jne	.LBB66_65
	incq	%r14
	testb	$1, %sil
	movb	$1, %sil
	je	.LBB66_62
	jmp	.LBB66_86
.LBB66_65:
	cmpb	$48, %dil
	jb	.LBB66_77
	cmpl	%edi, %ebx
	jb	.LBB66_77
	movl	%edi, %eax
	leaq	-48(%rdx,%rax), %rdi
	movb	$1, %al
	xorl	%esi, %esi
	movq	%rdi, %rdx
	cmpq	%r13, %r14
	jge	.LBB66_61
	leaq	(%rdi,%rdi), %rdx
	leaq	(%rdx,%rdx,4), %r8
	movzbl	(%r15,%r14), %edx
	movl	%edx, %esi
	subb	$11, %sil
	setne	%r9b
	cmpb	$32, %dl
	setne	%r10b
	cmpb	$-2, %sil
	setb	%sil
	movl	%edx, %r11d
	andb	$-2, %r11b
	cmpb	$12, %r11b
	setne	%r11b
	andb	%r10b, %sil
	andb	%r11b, %sil
	leal	-31(%rdx), %r10d
	cmpb	$-3, %r10b
	setb	%r10b
	andb	%r9b, %r10b
	andb	%sil, %r10b
	testb	%dl, %dl
	sets	%r9b
	orb	%r10b, %r9b
	movq	%rdi, %rdx
	cmovneq	%r8, %rdx
	xorl	%esi, %esi
	cmpb	$1, %r9b
	jne	.LBB66_61
	cmpq	%rdi, %r8
	jge	.LBB66_61
	movl	$10, %edi
	movq	%r15, %rsi
	movq	%r13, %rdx
	leaq	152(%rsp), %rbx
	movq	%rbx, %rcx
	callq	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true"@PLT
	movq	168(%rsp), %rax
	movq	%rax, %rsi
	shrq	$56, %rsi
	andl	$31, %esi
	testq	%rax, %rax
	cmovnsq	152(%rsp), %rbx
	cmovnsq	160(%rsp), %rsi
	leaq	static_string_e19fed3f50227db6(%rip), %rdx
	movl	$55, %ecx
	movq	%rbx, %rdi
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rax, 8(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%rcx, %r12
	movabsq	$4611686018427387904, %rax
	testq	%rax, 168(%rsp)
	movq	40(%rsp), %rbx
	je	.LBB66_85
	movq	152(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_85
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
	jmp	.LBB66_85
.LBB66_73:
	movq	%rdx, %rbp
	negq	%rbp
	cmpb	$45, %r12b
	cmovneq	%rdx, %rbp
	notb	%al
	orb	%al, %sil
	testb	$1, %sil
	je	.LBB66_76
	movq	40(%rsp), %rbx
.LBB66_75:
	leaq	152(%rsp), %rcx
	movl	$10, %edi
	movq	%r15, %rsi
	movq	%r13, %rdx
	callq	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true"@PLT
	movq	152(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	168(%rsp), %r12
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, %r13
	movl	%edx, %r14d
	movb	$1, %r15b
	movabsq	$4611686018427387904, %rax
	testq	%rax, 120(%rsp)
	jne	.LBB66_87
	jmp	.LBB66_90
.LBB66_76:
	xorl	%r15d, %r15d
	movq	40(%rsp), %rbx
	movabsq	$4611686018427387904, %rax
	testq	%rax, 120(%rsp)
	jne	.LBB66_87
	jmp	.LBB66_90
.LBB66_77:
	cmpl	$11, %edi
	sete	%cl
	cmpl	$32, %edi
	sete	%sil
	leal	-9(%rdi), %r8d
	cmpb	$2, %r8b
	setb	%r8b
	movl	%edi, %r9d
	andb	$-2, %r9b
	cmpb	$12, %r9b
	sete	%r9b
	leal	-28(%rdi), %r10d
	cmpb	$3, %r10b
	setb	%r10b
	testb	%dil, %dil
	js	.LBB66_86
	orb	%r8b, %sil
	orb	%r9b, %sil
	orb	%r10b, %cl
	orb	%sil, %cl
	je	.LBB66_86
	movq	%rdx, %rbp
	negq	%rbp
	cmpb	$45, %r12b
	cmovneq	%rdx, %rbp
	testb	$1, %al
	movq	40(%rsp), %rbx
	je	.LBB66_75
	cmpq	%r14, %r13
	movq	%r13, %rax
	cmovleq	%r14, %rax
.LBB66_81:
	cmpq	%r14, %rax
	je	.LBB66_92
	movzbl	(%r15,%r14), %edi
	cmpb	$32, %dil
	setne	%cl
	leal	-14(%rdi), %edx
	cmpb	$-5, %dl
	setb	%dl
	leal	-31(%rdi), %esi
	cmpb	$-3, %sil
	setb	%sil
	testb	%dil, %dil
	js	.LBB66_84
	incq	%r14
	andb	%sil, %dl
	andb	%cl, %dl
	je	.LBB66_81
.LBB66_84:
	leaq	152(%rsp), %rcx
	movl	$10, %edi
	movq	%r15, %rsi
	movq	%r13, %rdx
	callq	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true"@PLT
	movq	152(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	168(%rsp), %r12
.LBB66_85:
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, %r13
	movl	%edx, %r14d
	movb	$1, %r15b
	movabsq	$4611686018427387904, %rax
	testq	%rax, 120(%rsp)
	je	.LBB66_90
	jmp	.LBB66_87
.LBB66_86:
	leaq	152(%rsp), %rcx
	movl	$10, %edi
	movq	%r15, %rsi
	movq	%r13, %rdx
	callq	"std::collections::string::string::_str_to_base_error[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1]](::SIMD[::DType(int), ::SIMDLength(1)],::StringSpan[$0, $1, $2]),str_slice.mut`=true"@PLT
	movq	152(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	168(%rsp), %r12
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, %r13
	movl	%edx, %r14d
	movb	$1, %r15b
	movq	40(%rsp), %rbx
	movabsq	$4611686018427387904, %rax
	testq	%rax, 120(%rsp)
	je	.LBB66_90
.LBB66_87:
	movq	104(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_90
	addq	$-8, %rdi
.LBB66_89:
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_90:
	movq	8(%rsp), %rax
	movq	24(%rsp), %rcx
.LBB66_91:
	movb	%r14b, 48(%rbx)
	movq	%r13, 40(%rbx)
	movq	%r12, 32(%rbx)
	movq	%rcx, 24(%rbx)
	movq	%rax, 16(%rbx)
	movq	%rbp, 8(%rbx)
	andb	$1, %r15b
	movb	%r15b, (%rbx)
	movq	%rbx, %rax
	addq	$4264, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB66_92:
	.cfi_def_cfa_offset 4320
	xorl	%r15d, %r15d
	movabsq	$4611686018427387904, %rax
	testq	%rax, 120(%rsp)
	jne	.LBB66_87
	jmp	.LBB66_90
.LBB66_93:
	cmpl	$2, 8(%rsp)
	jne	.LBB66_99
	movq	96(%rsp), %rcx
	addl	$-64, %ecx
	movb	%cl, (%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 1(%rax)
	jmp	.LBB66_26
.LBB66_95:
	cmpl	$2, 36(%rsp)
	jne	.LBB66_101
	movq	96(%rsp), %rcx
	orb	$-64, %cl
	movb	%cl, (%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 1(%rax)
	jmp	.LBB66_32
.LBB66_97:
	cmpl	$2, 36(%rsp)
	jne	.LBB66_103
	movq	96(%rsp), %rcx
	orb	$-64, %cl
	movb	%cl, (%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 1(%rax)
	jmp	.LBB66_36
.LBB66_99:
	cmpl	$3, 8(%rsp)
	jne	.LBB66_105
	movb	$-32, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 1(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 2(%rax)
	jmp	.LBB66_26
.LBB66_101:
	cmpl	$3, 36(%rsp)
	jne	.LBB66_106
	movb	$-32, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 1(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 2(%rax)
	jmp	.LBB66_32
.LBB66_103:
	cmpl	$3, 36(%rsp)
	jne	.LBB66_107
	movb	$-32, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 1(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 2(%rax)
	jmp	.LBB66_36
.LBB66_105:
	movw	$-32528, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 2(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 3(%rax)
	jmp	.LBB66_26
.LBB66_106:
	movw	$-32528, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 2(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 3(%rax)
	jmp	.LBB66_32
.LBB66_107:
	movw	$-32528, (%rax)
	movl	20(%rsp), %ecx
	movb	%cl, 2(%rax)
	movzbl	6(%rsp), %ecx
	movb	%cl, 3(%rax)
	jmp	.LBB66_36
.LBB66_108:
	movq	$45, 80(%rsp)
	leaq	static_string_d02c1546a6049ede(%rip), %rax
	movq	%rax, 72(%rsp)
	movabsq	$2305843009213693952, %rcx
	movq	%rcx, 88(%rsp)
	movq	$1, 56(%rsp)
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rax
	movq	%rax, 48(%rsp)
	movq	%rcx, 64(%rsp)
	movq	$2, 160(%rsp)
	leaq	static_string_7f1562353e292282(%rip), %rax
	movq	%rax, 152(%rsp)
	movq	%rcx, 168(%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	static_string_bbe01a6a523daf15(%rip), %rax
	leaq	static_string_c44bdff4074eecdb(%rip), %r10
	leaq	80(%rsp), %r11
	leaq	static_string_31203c1a2bdb78cc(%rip), %rdi
	leaq	static_string_1e19992a0a485e4d(%rip), %r9
	leaq	56(%rsp), %rdx
	movl	$6, %esi
	movl	$181, %ecx
	movl	$18, %r8d
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	$1
	.cfi_adjust_cfa_offset 8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$0
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	leaq	216(%rsp), %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	$61
	.cfi_adjust_cfa_offset 8
	callq	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"@PLT
	addq	$80, %rsp
	.cfi_adjust_cfa_offset -80
	movabsq	$4611686018427387904, %rax
	testq	%rax, 168(%rsp)
	je	.LBB66_111
	movq	152(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_111
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_111:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 64(%rsp)
	je	.LBB66_114
	movq	48(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB66_114
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB66_114:
	ud2
.Lfunc_end66:
	.size	"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])", .Lfunc_end66-"bench::gemv_serial_layout_main::_env_int(::String,::SIMD[::DType(int), ::SIMDLength(1)])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end67, nop
	.type	"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])",@function
"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2456, %rsp
	.cfi_def_cfa_offset 2512
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r13
	movq	%rcx, %rbp
	movl	%edx, %r14d
	movq	%rsi, %r12
	movq	%rdi, %rbx
	leaq	344(%rsp), %rdi
	movq	%r8, %rcx
	callq	"max::gpu::host::device_context::DeviceContext::enqueue_create_buffer[::DType](max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	400(%rsp), %r15
	movq	392(%rsp), %rdi
	movb	$1, %al
	cmpb	$0, 344(%rsp)
	je	.LBB67_2
	movzbl	384(%rsp), %esi
	movq	376(%rsp), %rdx
	movq	368(%rsp), %rcx
	movq	360(%rsp), %r13
	movq	352(%rsp), %r14
	jmp	.LBB67_34
.LBB67_2:
	movq	%rdi, 56(%rsp)
	movzbl	%r14b, %edx
	leaq	280(%rsp), %rdi
	movq	%r12, %rsi
	movq	%r13, %rcx
	callq	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	288(%rsp), %r14
	movq	296(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	304(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	312(%rsp), %rax
	movq	%rax, 24(%rsp)
	movzbl	320(%rsp), %eax
	movb	%al, 23(%rsp)
	cmpb	$1, 280(%rsp)
	jne	.LBB67_4
	movq	%r15, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movb	$1, %al
	movq	64(%rsp), %r13
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movzbl	23(%rsp), %esi
	movq	56(%rsp), %rdi
	jmp	.LBB67_34
.LBB67_4:
	movq	%r15, 48(%rsp)
	movq	328(%rsp), %r15
	movq	336(%rsp), %rax
	movq	%rax, 40(%rsp)
	movabsq	$2305843009213693952, %rax
	movq	%r12, 80(%rsp)
	movq	%r12, %rdi
	movq	%rax, %r12
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	%r12, 424(%rsp)
	testq	%rax, %rax
	je	.LBB67_10
	movq	$52, (%rsp)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %r9
	leaq	232(%rsp), %rdi
	leaq	408(%rsp), %rdx
	movl	$41, %ecx
	movl	$20, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	240(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	248(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	256(%rsp), %rax
	movq	264(%rsp), %rcx
	movzbl	272(%rsp), %edx
	movzbl	232(%rsp), %r14d
	movabsq	$4611686018427387904, %rsi
	testq	%rsi, 424(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movb	%dl, 23(%rsp)
	je	.LBB67_8
	movq	408(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB67_8
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB67_8:
	testb	$1, %r14b
	je	.LBB67_11
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %r15
	movq	%r15, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	56(%rsp), %rdi
	movb	$1, %al
	movq	72(%rsp), %r14
	movq	64(%rsp), %r13
	jmp	.LBB67_22
.LBB67_10:
	movq	%r14, 72(%rsp)
.LBB67_11:
	xorl	%ecx, %ecx
	testq	%r13, %r13
	cmovgq	%r13, %rcx
	jle	.LBB67_15
	leaq	1(%rcx), %rax
	cmpq	$1, %rcx
	movl	$1, %esi
	cmovbq	%rcx, %rsi
	xorl	%r14d, %r14d
	leaq	static_string_ffe5c571af8dd3fc(%rip), %rcx
	leaq	static_string_a0fcf35b7349c924(%rip), %rdx
	.p2align	4
.LBB67_13:
	movq	$6, 96(%rsp)
	movq	%rcx, 88(%rsp)
	movq	%r12, 104(%rsp)
	movq	$39, 120(%rsp)
	movq	%rdx, 112(%rsp)
	movq	%r12, 128(%rsp)
	cmpq	%r13, %r14
	jae	.LBB67_35
	movq	%rsi, %rdi
	vmovss	(%rbp,%r14,4), %xmm0
	vmovss	%xmm0, (%r15,%r14,4)
	incq	%rsi
	movq	%rdi, %r14
	cmpq	%rsi, %rax
	jne	.LBB67_13
.LBB67_15:
	movq	%r12, %r14
	movq	80(%rsp), %r12
	movq	%r12, %rdi
	movq	48(%rsp), %rsi
	movq	%r15, %rdx
	callq	AsyncRT_DeviceContext_HtoD_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	%r14, %r15
	movq	%r14, 424(%rsp)
	testq	%rax, %rax
	je	.LBB67_23
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	184(%rsp), %rdi
	leaq	408(%rsp), %rdx
	movl	$5174, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	192(%rsp), %r14
	movq	200(%rsp), %r13
	movq	208(%rsp), %rax
	movq	216(%rsp), %rcx
	movzbl	224(%rsp), %edx
	movzbl	184(%rsp), %ebp
	movabsq	$4611686018427387904, %rsi
	testq	%rsi, 424(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movb	%dl, 23(%rsp)
	je	.LBB67_20
	movq	408(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB67_20
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
	testb	$1, %bpl
	jne	.LBB67_21
.LBB67_24:
	movq	80(%rsp), %r12
	jmp	.LBB67_25
.LBB67_20:
	testb	$1, %bpl
	je	.LBB67_24
.LBB67_21:
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	48(%rsp), %r15
	movq	%r15, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	56(%rsp), %rdi
	movb	$1, %al
.LBB67_22:
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movzbl	23(%rsp), %esi
	jmp	.LBB67_34
.LBB67_23:
	movq	72(%rsp), %r14
	movq	64(%rsp), %r13
.LBB67_25:
	movq	%r12, %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	%r15, 424(%rsp)
	testq	%rax, %rax
	je	.LBB67_31
	movq	$52, (%rsp)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %r9
	leaq	136(%rsp), %rdi
	leaq	408(%rsp), %rdx
	movl	$45, %ecx
	movl	$20, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	144(%rsp), %r14
	movq	152(%rsp), %r13
	movq	160(%rsp), %rax
	movq	168(%rsp), %rcx
	movzbl	176(%rsp), %edx
	movzbl	136(%rsp), %ebp
	movabsq	$4611686018427387904, %rsi
	testq	%rsi, 424(%rsp)
	movq	48(%rsp), %r15
	movq	56(%rsp), %r12
	movq	%rax, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movb	%dl, 23(%rsp)
	je	.LBB67_29
	movq	408(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB67_29
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB67_29:
	testb	$1, %bpl
	je	.LBB67_32
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	%r15, %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movb	$1, %al
	jmp	.LBB67_33
.LBB67_31:
	movq	48(%rsp), %r15
	movq	56(%rsp), %r12
.LBB67_32:
	movq	40(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	xorl	%eax, %eax
.LBB67_33:
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movzbl	23(%rsp), %esi
	movq	%r12, %rdi
.LBB67_34:
	movb	%sil, 40(%rbx)
	movq	%rdx, 32(%rbx)
	movq	%rcx, 24(%rbx)
	movq	%r13, 16(%rbx)
	movq	%r14, 8(%rbx)
	movb	%al, (%rbx)
	movq	%rdi, 48(%rbx)
	movq	%r15, 56(%rbx)
	movq	%rbx, %rax
	addq	$2456, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB67_35:
	.cfi_def_cfa_offset 2512
	decq	%r13
	leaq	88(%rsp), %rdi
	leaq	408(%rsp), %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	112(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r13, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB67_37
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB67_37:
	movb	$0, (%rax,%rdx)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %rcx
	movl	$43, %esi
	movl	$49, %edx
	movl	$52, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end67:
	.size	"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])", .Lfunc_end67-"bench::gemv_serial_layout_main::_upload(max::gpu::host::device_context::DeviceContext,::List[::SIMD[::DType(float32), ::SIMDLength(1)]])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end68, nop
	.type	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])",@function
"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$312, %rsp
	.cfi_def_cfa_offset 368
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rbx
	movq	%rcx, 96(%rsp)
	movl	%edx, %r12d
	movq	%rsi, %rbp
	movq	%rdi, %r14
	movq	%r8, %rdi
	callq	AsyncRT_DeviceBuffer_bytesize@PLT
	leaq	3(%rax), %rdx
	testq	%rax, %rax
	cmovnsq	%rax, %rdx
	movq	%rdx, %rsi
	sarq	$2, %rsi
	andq	$-4, %rdx
	movq	%rax, %rdi
	sarq	$63, %rdi
	xorl	%ecx, %ecx
	cmpq	%rax, %rdx
	cmovneq	%rdi, %rcx
	addq	%rsi, %rcx
	leaq	248(%rsp), %rdi
	movq	%rbp, %rsi
	movl	%r12d, %edx
	callq	"max::gpu::host::device_context::HostBuffer::__init__(max::gpu::host::device_context::DeviceContext,::SIMD[::DType(int), ::SIMDLength(1)]),dtype=f32"@PLT
	movq	256(%rsp), %rax
	movq	264(%rsp), %rcx
	movq	272(%rsp), %rdx
	movq	280(%rsp), %rsi
	movzbl	288(%rsp), %edi
	cmpb	$0, 248(%rsp)
	je	.LBB68_2
	movb	$1, %r13b
	jmp	.LBB68_28
.LBB68_2:
	movb	%dil, 23(%rsp)
	movq	%rsi, 56(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	movq	296(%rsp), %r13
	movq	304(%rsp), %rax
	movq	%rax, 24(%rsp)
	movabsq	$4611686018427387904, %r12
	movabsq	$2305843009213693952, %r15
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	%r15, 48(%rsp)
	testq	%rax, %rax
	je	.LBB68_9
	movq	$52, (%rsp)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %r9
	leaq	200(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$52, %ecx
	movl	$20, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	208(%rsp), %rax
	movq	216(%rsp), %rcx
	movq	224(%rsp), %rdx
	movq	232(%rsp), %rsi
	movzbl	240(%rsp), %r8d
	movzbl	200(%rsp), %r15d
	testq	%r12, 48(%rsp)
	movq	%rax, 80(%rsp)
	movq	%rcx, 72(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movb	%r8b, 23(%rsp)
	je	.LBB68_6
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB68_6
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB68_6:
	testb	$1, %r15b
	jne	.LBB68_7
	movabsq	$2305843009213693952, %r15
.LBB68_9:
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%rbx, %rdx
	callq	AsyncRT_DeviceContext_DtoH_async@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	%r15, 48(%rsp)
	testq	%rax, %rax
	je	.LBB68_15
	movq	$41, (%rsp)
	leaq	static_string_69b8ed51c73424d7(%rip), %r9
	leaq	152(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$5241, %ecx
	movl	$17, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	160(%rsp), %rax
	movq	168(%rsp), %rcx
	movq	176(%rsp), %rdx
	movq	184(%rsp), %rsi
	movzbl	192(%rsp), %r8d
	movzbl	152(%rsp), %r15d
	testq	%r12, 48(%rsp)
	movq	%rax, 80(%rsp)
	movq	%rcx, 72(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movb	%r8b, 23(%rsp)
	je	.LBB68_13
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB68_13
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB68_13:
	testb	$1, %r15b
	jne	.LBB68_7
	movabsq	$2305843009213693952, %r15
.LBB68_15:
	movq	%rbp, %rdi
	callq	AsyncRT_DeviceContext_synchronize@PLT
	leaq	static_string_2d06800538d394c2(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	%r15, 48(%rsp)
	testq	%rax, %rax
	je	.LBB68_20
	movq	$52, (%rsp)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %r9
	leaq	104(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$54, %ecx
	movl	$20, %r8d
	movq	%rax, %rsi
	callq	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"@PLT
	movq	112(%rsp), %rax
	movq	120(%rsp), %rcx
	movq	128(%rsp), %rdx
	movq	136(%rsp), %rsi
	movzbl	144(%rsp), %r8d
	movzbl	104(%rsp), %ebp
	testq	%r12, 48(%rsp)
	movq	%rax, 80(%rsp)
	movq	%rcx, 72(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movb	%r8b, 23(%rsp)
	je	.LBB68_19
	movq	32(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB68_19
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB68_19:
	testb	$1, %bpl
	je	.LBB68_20
.LBB68_7:
	movb	$1, %r13b
	jmp	.LBB68_27
.LBB68_20:
	movq	%rbx, %rdi
	callq	AsyncRT_DeviceBuffer_bytesize@PLT
	leaq	3(%rax), %rcx
	testq	%rax, %rax
	cmovnsq	%rax, %rcx
	movq	%rcx, %rdx
	sarq	$2, %rdx
	andq	$-4, %rcx
	movq	%rax, %rbp
	sarq	$63, %rbp
	xorl	%esi, %esi
	cmpq	%rax, %rcx
	cmoveq	%rsi, %rbp
	addq	%rdx, %rbp
	testq	%rbp, %rbp
	cmovleq	%rsi, %rbp
	jle	.LBB68_21
	xorl	%ecx, %ecx
	movq	%rbp, %rsi
	subq	$1, %rsi
	cmovbq	%rcx, %rsi
	movl	$4, %eax
	xorl	%edx, %edx
	movq	%rbp, %r15
	jmp	.LBB68_23
	.p2align	4
.LBB68_25:
	vmovss	%xmm0, (%rax,%rdx,4)
	incq	%rdx
	movq	%r15, %rsi
	addq	$-1, %rsi
	jae	.LBB68_26
.LBB68_23:
	movq	%rbp, %rdi
	subq	%r15, %rdi
	movq	%rsi, %r15
	vmovss	(%r13,%rdi,4), %xmm0
	cmpq	%rcx, %rdx
	jl	.LBB68_25
	xorl	%esi, %esi
	testq	%rcx, %rcx
	sete	%sil
	leaq	(%rsi,%rcx,2), %r8
	movq	%rax, %rdi
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	movq	%r8, %rcx
	vmovss	%xmm0, 92(%rsp)
	callq	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"@PLT
	vmovss	92(%rsp), %xmm0
	jmp	.LBB68_25
.LBB68_26:
	movq	%rcx, %r12
	movq	%rax, %rbp
	movq	%rdx, %r15
	xorl	%r13d, %r13d
	jmp	.LBB68_27
.LBB68_21:
	xorl	%r15d, %r15d
	movl	$4, %ebp
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
.LBB68_27:
	movq	24(%rsp), %rdi
	callq	AsyncRT_DeviceBuffer_release@PLT
	movq	80(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	64(%rsp), %rdx
	movq	56(%rsp), %rsi
	movzbl	23(%rsp), %edi
.LBB68_28:
	movq	%r12, 80(%r14)
	movq	%r15, 72(%r14)
	movq	%rbp, 64(%r14)
	movb	%dil, 56(%r14)
	movq	%rsi, 48(%r14)
	movq	%rdx, 40(%r14)
	movq	%rcx, 32(%r14)
	movq	%rax, 24(%r14)
	movq	96(%rsp), %rax
	movq	%rax, 8(%r14)
	movb	%r13b, (%r14)
	movq	%rbx, 16(%r14)
	movq	%r14, %rax
	addq	$312, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end68:
	.size	"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])", .Lfunc_end68-"bench::gemv_serial_layout_main::_read(max::gpu::host::device_context::DeviceContext,max::gpu::host::device_context::DeviceBuffer[::DType(float32)])"
	.cfi_endproc

	.prefalign	4, .Lfunc_end69, nop
	.type	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)",@function
"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2104, %rsp
	.cfi_def_cfa_offset 2160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rdx
	movq	2168(%rsp), %rbp
	movq	2160(%rsp), %rdi
	cmpq	%r8, %rsi
	jne	.LBB69_1
	movabsq	$2305843009213693952, %r8
	movq	%rsi, %rax
	sarq	$63, %rax
	andnq	%rsi, %rax, %r9
	leaq	static_string_ffe5c571af8dd3fc(%rip), %r10
	leaq	static_string_a0fcf35b7349c924(%rip), %r11
	movq	%r9, %r14
	.p2align	4
.LBB69_6:
	xorl	%eax, %eax
	movq	%r14, %rbx
	subq	$1, %rbx
	movl	$0, %r15d
	cmovaeq	%rbx, %r15
	testq	%r14, %r14
	je	.LBB69_22
	movq	%r9, %rbx
	movq	$6, 40(%rsp)
	movq	%r10, 32(%rsp)
	movq	%r8, 48(%rsp)
	movq	$39, 16(%rsp)
	subq	%r14, %rbx
	movq	%r11, 8(%rsp)
	movq	%r8, 24(%rsp)
	cmpq	%rsi, %rbx
	jae	.LBB69_8
	movl	(%rdx,%rbx,4), %eax
	movq	%r15, %r14
	cmpl	(%rcx,%rbx,4), %eax
	je	.LBB69_6
	movq	16(%rdi), %rsi
	testq	%rsi, %rsi
	js	.LBB69_12
	movq	8(%rdi), %rsi
	movq	(%rdi), %rdi
	jmp	.LBB69_14
.LBB69_1:
	movq	16(%rdi), %rsi
	testq	%rsi, %rsi
	js	.LBB69_2
	movq	8(%rdi), %rsi
	movq	(%rdi), %rdi
	jmp	.LBB69_4
.LBB69_2:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB69_4:
	leaq	static_string_9f98073b08f39257(%rip), %rdx
	movl	$14, %ecx
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rax, (%rbp)
	movq	%rdx, 8(%rbp)
	movq	%rcx, 16(%rbp)
	jmp	.LBB69_21
.LBB69_12:
	shrq	$56, %rsi
	andl	$31, %esi
.LBB69_14:
	leaq	static_string_18a20bf0a49020c4(%rip), %rdx
	movl	$17, %ecx
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rax, %r15
	movq	%rdx, %r14
	movq	%rcx, %r13
	movq	%rax, 8(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%rcx, 24(%rsp)
	leaq	static_string_2d06800538d394c2(%rip), %rsi
	leaq	56(%rsp), %r12
	movq	%rbx, %rdi
	xorl	%edx, %edx
	movq	%r12, %rcx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"@PLT
	movq	72(%rsp), %rax
	movq	%rax, %rcx
	shrq	$56, %rcx
	andl	$31, %ecx
	testq	%rax, %rax
	cmovnsq	56(%rsp), %r12
	cmovnsq	64(%rsp), %rcx
	movq	%r13, %rsi
	shrq	$56, %rsi
	andl	$31, %esi
	testq	%r13, %r13
	leaq	8(%rsp), %rdi
	cmovnsq	%r15, %rdi
	cmovnsq	%r14, %rsi
	movq	%r12, %rdx
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rax, %rbx
	movq	%rdx, %r14
	movq	%rcx, %r15
	testb	$64, 79(%rsp)
	je	.LBB69_17
	movq	56(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB69_17
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB69_17:
	movabsq	$4611686018427387904, %rax
	testq	%rax, 24(%rsp)
	je	.LBB69_20
	movq	8(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB69_20
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB69_20:
	movq	%rbx, (%rbp)
	movq	%r14, 8(%rbp)
	movq	%r15, 16(%rbp)
.LBB69_21:
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movq	%rax, 24(%rbp)
	movb	%dl, 32(%rbp)
	movb	$1, %al
.LBB69_22:
	addq	$2104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB69_8:
	.cfi_def_cfa_offset 2160
	decq	%rsi
	leaq	32(%rsp), %rdi
	leaq	56(%rsp), %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	xorl	%edx, %edx
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	8(%rsp), %rdi
	movq	%rax, %rsi
	callq	"std::collections::string::string::String::write_to[::Writer & ::AnyType](::String,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferHeap\">>, struct<(pointer<none>, scalar<index>) memoryOnly>]"@PLT
	leaq	1(%rdx), %rcx
	cmpq	$2049, %rcx
	jl	.LBB69_9
	movl	$1, %edi
	callq	"std::io::io::_printf[KGENParamList[::AnyType],::StringSpan[::Bool(False), ImmStaticOrigin, *?],*::AnyType,LITImmOrigin,::Origin[::Bool(False), $3]](*$0,file:::FileDescriptor),types.values`=[],fmt={ #interp.memref<{[(#interp.memory_handle<16, \"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\\0A\\00\" string>, const_global, [], [])], []}, 0, 0>, 76 }"@PLT
	ud2
.LBB69_9:
	movb	$0, (%rax,%rdx)
	leaq	static_string_0c4c4fc91aeab35e(%rip), %rcx
	movl	$66, %esi
	movl	$35, %edx
	movl	$52, %r8d
	movq	%rax, %rdi
	callq	"std::builtin::debug_assert::_debug_assert_msg[LITImmOrigin,::Origin[::Bool(False), $0]](::Pointer[::Bool(False), $0, ::SIMD[::DType(uint8), ::SIMDLength(1)], $1, ::AddressSpace(::SIMDLength(0))],::SIMD[::DType(int), ::SIMDLength(1)],::SourceLocation)"@PLT
.Lfunc_end69:
	.size	"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)", .Lfunc_end69-"bench::gemv_serial_layout_main::_same(::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::List[::SIMD[::DType(float32), ::SIMDLength(1)]],::String)"
	.cfi_endproc

	.prefalign	4, .Lfunc_end70, nop
	.type	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG",@function
"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, 48(%rsp)
	movq	%r8, %r15
	movq	%rcx, %r12
	movq	%rdx, %r13
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movabsq	$9223372036854775807, %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 16(%rsp)
	testq	%rsi, %rsi
	je	.LBB70_6
	xorl	%esi, %esi
	.p2align	4
.LBB70_2:
	cmpb	$0, (%r14,%rsi)
	je	.LBB70_5
	incq	%rsi
	cmpq	%rsi, %rax
	jne	.LBB70_2
	movq	%rax, %rsi
.LBB70_5:
	leaq	static_string_2d06800538d394c2(%rip), %rdx
	movq	%rsp, %r8
	movq	%r14, %rdi
	xorl	%ecx, %ecx
	callq	"std::collections::string::string::String::__init__[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2]](*$0,sep:::StringSpan[::Bool(False), ImmStaticOrigin, *?],end:::StringSpan[::Bool(False), ImmStaticOrigin, *?]),Ts.values`2x=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>]]"@PLT
.LBB70_6:
	movabsq	$2305843009213693952, %rbp
	movq	%r14, %rdi
	callq	AsyncRT_DeviceContext_strfree@PLT
	movq	(%rsp), %rax
	vmovups	8(%rsp), %xmm0
	movq	%rax, 24(%rsp)
	vmovups	%xmm0, 32(%rsp)
	movq	16(%r13), %rcx
	testq	%rcx, %rcx
	js	.LBB70_9
	movq	8(%r13), %rcx
	testq	%rcx, %rcx
	jle	.LBB70_8
	movq	(%r13), %r13
	jmp	.LBB70_12
.LBB70_9:
	movabsq	$2233785415175766016, %rax
	testq	%rax, %rcx
	je	.LBB70_8
	shrq	$56, %rcx
	andl	$31, %ecx
.LBB70_12:
	leaq	static_string_a8d4ace0dc8d360e(%rip), %rdi
	movl	$1, %esi
	movq	%r13, %rdx
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rcx, %rbp
	jmp	.LBB70_13
.LBB70_8:
	xorl	%edx, %edx
	leaq	static_string_c44bdff4074eecdb(%rip), %rax
.LBB70_13:
	movq	%rax, (%rsp)
	movq	%rdx, 8(%rsp)
	movabsq	$4611686018427387904, %r14
	movq	%rbp, 16(%rsp)
	movq	%rbp, %rcx
	shrq	$56, %rcx
	andl	$31, %ecx
	testq	%rbp, %rbp
	movq	%rsp, %r8
	cmovnsq	%rax, %r8
	cmovnsq	%rdx, %rcx
	movq	40(%rsp), %rax
	movq	%rax, %rsi
	shrq	$56, %rsi
	andl	$31, %esi
	testq	%rax, %rax
	leaq	24(%rsp), %rdi
	cmovnsq	24(%rsp), %rdi
	cmovnsq	32(%rsp), %rsi
	movq	%r8, %rdx
	callq	"std::collections::string::string::String::_add[::Bool,LITOrigin[$0._mlir_value],::Origin[$0, $1],::Bool,LITOrigin[$3._mlir_value],::Origin[$3, $4]](::Span[$0, $1, ::SIMD[::DType(uint8), ::SIMDLength(1)], $2, ::AddressSpace(::SIMDLength(0))],::Span[$3, $4, ::SIMD[::DType(uint8), ::SIMDLength(1)], $5, ::AddressSpace(::SIMDLength(0))]),lhs.mut`2x=false,rhs.mut`2x3=false"@PLT
	movq	%rax, 64(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rcx, 80(%rsp)
	testb	$64, 23(%rsp)
	je	.LBB70_16
	movq	(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB70_16
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB70_16:
	movq	144(%rsp), %rcx
	testq	%r14, 40(%rsp)
	je	.LBB70_19
	movq	24(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB70_19
	addq	$-8, %rdi
	#MEMBARRIER
	movq	%rcx, %r13
	callq	KGEN_CompilerRT_AlignedFree@PLT
	movq	%r13, %rcx
.LBB70_19:
	leaq	64(%rsp), %r8
	movq	%rsp, %r9
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	48(%rsp), %rdx
	callq	"std::reflection::location::SourceLocation::prefix[::Writable & ::AnyType](::SourceLocation,$0),T=[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]"@PLT
	testq	%r14, 80(%rsp)
	je	.LBB70_22
	movq	64(%rsp), %rdi
	lock		decq	-8(%rdi)
	jne	.LBB70_22
	addq	$-8, %rdi
	#MEMBARRIER
	callq	KGEN_CompilerRT_AlignedFree@PLT
.LBB70_22:
	movq	(%rsp), %r14
	vmovups	8(%rsp), %xmm0
	vmovaps	%xmm0, 48(%rsp)
	movq	$-1, %rdi
	callq	"std::builtin::error::StackTrace::collect_if_enabled(::SIMD[::DType(int), ::SIMDLength(1)])"@PLT
	movb	%dl, 40(%rbx)
	movq	%rax, 32(%rbx)
	vmovaps	48(%rsp), %xmm0
	vmovups	%xmm0, 16(%rbx)
	movq	%r14, 8(%rbx)
	movb	$1, (%rbx)
	movq	%rbx, %rax
	addq	$88, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end70:
	.size	"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG", .Lfunc_end70-"max::gpu::host::device_context::_raise_checked_impl[LITImmOrigin,::Origin[::Bool(False), $0]](::Optional[::CStringSlice[$0, $1]],::String,::SourceLocation)_REMOVED_ARG"
	.cfi_endproc

	.prefalign	4, .Lfunc_end71, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::error::Error\">>, struct<(struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>, struct<(struct<(struct<(variant<struct<()>, struct<(pointer<none>) memoryOnly>>) memoryOnly>) memoryOnly>) memoryOnly>) memoryOnly>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::error::Error\">>, struct<(struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>, struct<(struct<(struct<(variant<struct<()>, struct<(pointer<none>) memoryOnly>>) memoryOnly>) memoryOnly>) memoryOnly>) memoryOnly>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4136, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movzbl	4192(%rsp), %eax
	movb	%al, 15(%rsp)
	movq	4200(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	$0, 4120(%rsp)
	movq	%r9, %rbx
	movq	%r8, %r14
	movq	%rcx, %r12
	movq	%rdx, %r13
	movq	%rsi, %r15
	movq	%rdi, %rsi
	leaq	16(%rsp), %rax
	movq	%rax, 4128(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB71_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB71_3
.LBB71_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB71_3:
	leaq	24(%rsp), %rbp
	movq	%rbp, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%rbp, %rsi
	callq	"std::builtin::error::Error::write_to[::Writer & ::AnyType](::Error,$0),writer.T`2x1=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4120(%rsp), %rdx
	movq	4128(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbp, %rsi
	callq	write@PLT
	testb	$1, 15(%rsp)
	je	.LBB71_4
	movq	16(%rsp), %rdi
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB71_4:
	.cfi_def_cfa_offset 4192
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end71:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::error::Error\">>, struct<(struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>, struct<(struct<(struct<(variant<struct<()>, struct<(pointer<none>) memoryOnly>>) memoryOnly>) memoryOnly>) memoryOnly>) memoryOnly>]]", .Lfunc_end71-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::error::Error\">>, struct<(struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>, struct<(struct<(struct<(variant<struct<()>, struct<(pointer<none>) memoryOnly>>) memoryOnly>) memoryOnly>) memoryOnly>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end72, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4168, %rsp
	.cfi_def_cfa_offset 4224
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	4264(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	4256(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	4248(%rsp), %r15
	movq	4240(%rsp), %r12
	movzbl	4272(%rsp), %eax
	movb	%al, 3(%rsp)
	movl	4232(%rsp), %eax
	movl	%eax, 4(%rsp)
	movq	4224(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	4280(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	$0, 4152(%rsp)
	movq	%r9, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rsi, %rbp
	movq	%rdi, %rsi
	leaq	8(%rsp), %rax
	movq	%rax, 4160(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB72_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB72_3
.LBB72_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB72_3:
	leaq	56(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r13, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	16(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	24(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	32(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movl	4(%rsp), %edi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=ui32,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	40(%rsp), %rsi
	movq	48(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4152(%rsp), %rdx
	movq	4160(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	testb	$1, 3(%rsp)
	je	.LBB72_4
	movq	8(%rsp), %rdi
	addq	$4168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB72_4:
	.cfi_def_cfa_offset 4224
	addq	$4168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end72:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]]", .Lfunc_end72-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=ui32,length=1\">>, scalar<ui32>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end73, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4200, %rsp
	.cfi_def_cfa_offset 4256
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	4312(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	4304(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	4296(%rsp), %r12
	movq	4288(%rsp), %r13
	movzbl	4320(%rsp), %eax
	movb	%al, 15(%rsp)
	movq	4280(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	4272(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	4264(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	4256(%rsp), %r14
	movq	4328(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	$0, 4184(%rsp)
	movq	%r9, 40(%rsp)
	movq	%r8, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%rdx, %r15
	movq	%rsi, %rbp
	movq	%rdi, %rsi
	leaq	16(%rsp), %rax
	movq	%rax, 4192(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB73_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB73_3
.LBB73_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB73_3:
	leaq	88(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	24(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	32(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	40(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	16(%r14), %rdx
	testq	%rdx, %rdx
	js	.LBB73_4
	movq	8(%r14), %rdx
	movq	(%r14), %r14
	jmp	.LBB73_6
.LBB73_4:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB73_6:
	leaq	88(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	48(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	56(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB73_7
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB73_9
.LBB73_7:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB73_9:
	leaq	88(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	64(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	72(%rsp), %rsi
	movq	80(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4184(%rsp), %rdx
	movq	4192(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	testb	$1, 15(%rsp)
	je	.LBB73_10
	movq	16(%rsp), %rdi
	addq	$4200, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB73_10:
	.cfi_def_cfa_offset 4256
	addq	$4200, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end73:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]", .Lfunc_end73-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end74, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f64,length=1\">>, scalar<f64>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f64,length=1\">>, scalar<f64>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4152, %rsp
	.cfi_def_cfa_offset 4208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movzbl	4216(%rsp), %eax
	movb	%al, 15(%rsp)
	movq	4208(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	4224(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	$0, 4136(%rsp)
	movq	%r9, %r14
	movq	%r8, %r15
	movq	%rcx, %r12
	vmovsd	%xmm0, 24(%rsp)
	movq	%rdx, %r13
	movq	%rsi, %rbp
	movq	%rdi, %rsi
	leaq	16(%rsp), %rax
	movq	%rax, 4144(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB74_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB74_3
.LBB74_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB74_3:
	leaq	40(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	16(%r13), %rdx
	testq	%rdx, %rdx
	js	.LBB74_4
	movq	8(%r13), %rdx
	movq	(%r13), %r13
	jmp	.LBB74_6
.LBB74_4:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB74_6:
	leaq	40(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	vmovsd	24(%rsp), %xmm0
	movq	%rbx, %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=f64,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	32(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4136(%rsp), %rdx
	movq	4144(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	testb	$1, 15(%rsp)
	je	.LBB74_7
	movq	16(%rsp), %rdi
	addq	$4152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB74_7:
	.cfi_def_cfa_offset 4208
	addq	$4152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end74:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f64,length=1\">>, scalar<f64>]]", .Lfunc_end74-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f64,length=1\">>, scalar<f64>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end75, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4136, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movzbl	4192(%rsp), %eax
	movb	%al, 15(%rsp)
	movq	4200(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	$0, 4120(%rsp)
	movq	%r9, %rbx
	movq	%r8, %r14
	movq	%rcx, %r12
	movq	%rdx, %r13
	movq	%rsi, %r15
	movq	%rdi, %rsi
	leaq	16(%rsp), %rax
	movq	%rax, 4128(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB75_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB75_3
.LBB75_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB75_3:
	leaq	24(%rsp), %rbp
	movq	%rbp, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%rbp, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbp, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4120(%rsp), %rdx
	movq	4128(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbp, %rsi
	callq	write@PLT
	testb	$1, 15(%rsp)
	je	.LBB75_4
	movq	16(%rsp), %rdi
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB75_4:
	.cfi_def_cfa_offset 4192
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end75:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]", .Lfunc_end75-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=index,length=1\">>, scalar<index>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end76, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4120, %rsp
	.cfi_def_cfa_offset 4160
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r8, (%rsp)
	movq	$0, 4104(%rsp)
	movl	%ecx, %ebx
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %rsi
	movq	%rsp, %rax
	movq	%rax, 4112(%rsp)
	movq	16(%rdi), %rdx
	testq	%rdx, %rdx
	js	.LBB76_1
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB76_3
.LBB76_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB76_3:
	leaq	8(%rsp), %r12
	movq	%r12, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4104(%rsp), %rdx
	movq	4112(%rsp), %rax
	movq	(%rax), %rdi
	movq	%r12, %rsi
	callq	write@PLT
	testb	$1, %bl
	je	.LBB76_4
	movq	(%rsp), %rdi
	addq	$4120, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB76_4:
	.cfi_def_cfa_offset 4160
	addq	$4120, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end76:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]", .Lfunc_end76-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end77, nop
	.type	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]",@function
"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]":
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4184, %rsp
	.cfi_def_cfa_offset 4240
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	4288(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	4280(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	4272(%rsp), %r12
	movq	4264(%rsp), %r13
	movzbl	4296(%rsp), %eax
	movb	%al, 15(%rsp)
	movq	4240(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	4256(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	4248(%rsp), %rbp
	movq	4304(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	%r9, %r14
	movq	%r8, 40(%rsp)
	movq	%rcx, 32(%rsp)
	movq	%rdx, %rbx
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	movq	$0, 4168(%rsp)
	leaq	16(%rsp), %rax
	movq	%rax, 4176(%rsp)
	leaq	72(%rsp), %r15
	movq	%r15, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	16(%rbx), %rdx
	testq	%rdx, %rdx
	js	.LBB77_1
	movq	8(%rbx), %rdx
	movq	(%rbx), %rbx
	jmp	.LBB77_3
.LBB77_1:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB77_3:
	leaq	72(%rsp), %r15
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	24(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4168(%rsp), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB77_5
	movq	4176(%rsp), %rax
	movq	(%rax), %rdi
	leaq	72(%rsp), %rsi
	callq	write@PLT
	movq	$0, 4168(%rsp)
	xorl	%edx, %edx
.LBB77_5:
	movb	$58, 72(%rsp,%rdx)
	incq	4168(%rsp)
	leaq	72(%rsp), %rsi
	movq	32(%rsp), %rdi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	4168(%rsp), %rdx
	leaq	1(%rdx), %rax
	cmpq	$4097, %rax
	jl	.LBB77_7
	movq	4176(%rsp), %rax
	movq	(%rax), %rdi
	leaq	72(%rsp), %rsi
	callq	write@PLT
	movq	$0, 4168(%rsp)
	xorl	%edx, %edx
.LBB77_7:
	movb	$58, 72(%rsp,%rdx)
	incq	4168(%rsp)
	leaq	72(%rsp), %rbx
	movq	40(%rsp), %rdi
	movq	%rbx, %rsi
	callq	"std::builtin::simd::SIMD::write_to[::Writer & ::AnyType](::SIMD[$0, $1],$2),dtype=index,length=1,writer.T`2x=[typevalue<#kgen.instref<\"std::format::_utils::_WriteBufferStack,origin._mlir_origin`={  },origin={  },W=[typevalue<#kgen.instref<\\1B\\22std::io::file_descriptor::FileDescriptor\\22>>, scalar<index>],stack_buffer_bytes=4096\">>, struct<(struct<(array<4096, scalar<ui8>>) memoryOnly>, scalar<index>, pointer<none>) memoryOnly>]"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	16(%rbp), %rdx
	testq	%rdx, %rdx
	js	.LBB77_8
	movq	8(%rbp), %rdx
	movq	(%rbp), %rbp
	jmp	.LBB77_10
.LBB77_8:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB77_10:
	leaq	72(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	48(%rsp), %rsi
	movq	16(%rsi), %rdx
	testq	%rdx, %rdx
	js	.LBB77_11
	movq	8(%rsi), %rdx
	movq	(%rsi), %rsi
	jmp	.LBB77_13
.LBB77_11:
	shrq	$56, %rdx
	andl	$31, %edx
.LBB77_13:
	leaq	72(%rsp), %rbx
	movq	%rbx, %rdi
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	%rbx, %rdi
	movq	56(%rsp), %rsi
	movq	64(%rsp), %rdx
	callq	"std::format::_utils::_WriteBufferStack::write_string[::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5]](::_WriteBufferStack[$0, $1, $2, $3],::StringSpan[$4, $5, $6]),W=[typevalue<#kgen.instref<\"std::io::file_descriptor::FileDescriptor\">>, scalar<index>],stack_buffer_bytes=4096,string.mut`2x1=false"@PLT
	movq	4168(%rsp), %rdx
	movq	4176(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rbx, %rsi
	callq	write@PLT
	testb	$1, 15(%rsp)
	je	.LBB77_14
	movq	16(%rsp), %rdi
	addq	$4184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	"std::io::io::_flush(::FileDescriptor)"@PLT
.LBB77_14:
	.cfi_def_cfa_offset 4240
	addq	$4184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end77:
	.size	"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]", .Lfunc_end77-"std::io::io::print[KGENParamList[::Writable & ::AnyType],*::Writable & ::AnyType,LITImmOrigin,::Origin[::Bool(False), $2],::Bool,LITOrigin[$4._mlir_value],::Origin[$4, $5],::Bool,LITOrigin[$7._mlir_value],::Origin[$7, $8]](*$0,sep:::StringSpan[$4, $5, $6],end:::StringSpan[$7, $8, $9],flush:::Bool,file:::FileDescriptor$)_REMOVED_ARG,Ts.values`=[[typevalue<#kgen.instref<\"std::collections::string::string_span::StringSpan,mut=false,origin._mlir_origin`={  },origin={  }\">>, struct<(pointer<none>, scalar<index>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::reflection::location::SourceLocation\">>, struct<(scalar<index>, scalar<index>, struct<(pointer<none>, scalar<index>)>)>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>], [typevalue<#kgen.instref<\"std::collections::string::string::String\">>, struct<(pointer<none>, scalar<index>, scalar<index>) memoryOnly>]]"
	.cfi_endproc

	.prefalign	4, .Lfunc_end78, nop
	.type	"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]",@function
"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]":
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r8, %r14
	movq	%rcx, %r15
	movq	%rdx, %rcx
	movq	%rdi, %rax
	leaq	(%r8,%rsi), %rbx
	cmpq	%rdx, %rbx
	jle	.LBB78_2
	movq	%rcx, %r8
	addq	%rcx, %r8
	cmpq	%rbx, %r8
	cmovleq	%rbx, %r8
	movq	%rax, %rdi
	movq	%rcx, %rdx
	movq	%r8, %rcx
	callq	"std::collections::list::List::_realloc(::List[$0],::SIMD[::DType(int), ::SIMDLength(1)]),T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"@PLT
	movq	%rdx, %rsi
.LBB78_2:
	testq	%r14, %r14
	je	.LBB78_16
	leaq	(%rax,%rsi,4), %rdx
	shlq	$2, %r14
	cmpq	$4, %r14
	jg	.LBB78_7
	testq	%r14, %r14
	je	.LBB78_16
	movzbl	(%r15), %esi
	movb	%sil, (%rdx)
	movzbl	-1(%r15,%r14), %esi
	movb	%sil, -1(%rdx,%r14)
	cmpq	$3, %r14
	jl	.LBB78_16
	movzbl	1(%r15), %esi
	movb	%sil, 1(%rdx)
	movzbl	-2(%r15,%r14), %esi
	movb	%sil, -2(%rdx,%r14)
	jmp	.LBB78_16
.LBB78_7:
	cmpq	$16, %r14
	jg	.LBB78_11
	cmpq	$8, %r14
	jl	.LBB78_10
	movq	(%r15), %rsi
	movq	%rsi, (%rdx)
	movq	-8(%r15,%r14), %rsi
	movq	%rsi, -8(%rdx,%r14)
	jmp	.LBB78_16
.LBB78_11:
	movabsq	$9223372036854775776, %rsi
	andq	%r14, %rsi
	je	.LBB78_14
	xorl	%edi, %edi
	.p2align	4
.LBB78_13:
	vmovups	(%r15,%rdi), %ymm0
	vmovups	%ymm0, (%rdx,%rdi)
	addq	$32, %rdi
	cmpq	%rsi, %rdi
	jb	.LBB78_13
.LBB78_14:
	cmpq	%r14, %rsi
	je	.LBB78_16
	.p2align	4
.LBB78_15:
	movzbl	(%r15,%rsi), %edi
	movb	%dil, (%rdx,%rsi)
	incq	%rsi
	cmpq	%rsi, %r14
	jne	.LBB78_15
	jmp	.LBB78_16
.LBB78_10:
	movl	(%r15), %esi
	movl	%esi, (%rdx)
	movl	-4(%r15,%r14), %esi
	movl	%esi, -4(%rdx,%r14)
.LBB78_16:
	movq	%rbx, %rdx
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.Lfunc_end78:
	.size	"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]", .Lfunc_end78-"std::collections::list::List::extend[::Bool,LITOrigin[$1._mlir_value],::Origin[$1, $2]](::List[$0],::Span[$1, $2, $0, $3, ::AddressSpace(::SIMDLength(0))]){conforms_to($0, ::AnyType & ::Copyable & ::Movable)}_REMOVED_ARG,T=[typevalue<#kgen.instref<\"std::builtin::simd::SIMD,dtype=f32,length=1\">>, scalar<f32>]"
	.cfi_endproc

	.type	static_string_66bf81b04b01b855,@object
	.section	.rodata,"a",@progbits
	.p2align	4, 0x0
static_string_66bf81b04b01b855:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tneighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202\n\n.visible .entry neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202(\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_0,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_1,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_2,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_3,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_4,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_5,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_6,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_7,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_8\n)\n{\n\t.reg .pred \t%p<39>;\n\t.reg .b32 \t%r<87>;\n\t.reg .b64 \t%rd<46>;\n\n\tld.param.b32 \t%r3, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_6];\n\tld.param.b32 \t%r6, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_5];\n\tmov.u32 \t%r7, %ctaid.x;\n\tmov.u32 \t%r8, %ntid.x;\n\tmul.wide.u32 \t%rd18, %r7, %r8;\n\tmov.u32 \t%r9, %tid.x;\n\tcvt.u64.u32 \t%rd19, %r9;\n\tadd.s64 \t%rd7, %rd18, %rd19;\n\tmul.wide.s32 \t%rd21, %r3, %r6;\n\tsetp.ge.s64 \t%p1, %rd7, %rd21;\n\t@%p1 bra \t$L__BB0_14;\n\tld.param.b32 \t%r4, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_7];\n\tld.param.b64 \t%rd12, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_0];\n\tld.param.b64 \t%rd16, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_3];\n\tld.param.b64 \t%rd17, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_4];\n\tcvt.s64.s32 \t%rd5, %r3;\n\tsetp.eq.b32 \t%p2, %r3, 0;\n\tselp.b64 \t%rd9, 1, %rd5, %p2;\n\tor.b64 \t%rd22, %rd7, %rd9;\n\tand.b64 \t%rd23, %rd22, -4294967296;\n\tsetp.ne.b64 \t%p3, %rd23, 0;\n\t@!%p3 bra \t$L__BB0_2;\n\tdiv.s64 \t%rd41, %rd7, %rd9;\n\tbra.uni \t$L__BB0_4;\n$L__BB0_2:\n\tcvt.u32.u64 \t%r10, %rd9;\n\tcvt.u32.u64 \t%r11, %rd7;\n\tdiv.u32 \t%r12, %r11, %r10;\n\tcvt.u64.u32 \t%rd41, %r12;\n$L__BB0_4:\n\tcvta.to.global.u64 \t%rd13, %rd12;\n\tshl.b64 \t%rd20, %rd7, 2;\n\tld.param.b32 \t%r5, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_8];\n\tcvta.to.global.u64 \t%rd3, %rd16;\n\tcvta.to.global.u64 \t%rd4, %rd17;\n\tsetp.lt.s32 \t%p4, %r3, 0;\n\tmul.lo.s64 \t%rd24, %rd41, %rd9;\n\tsetp.eq.b64 \t%p5, %rd24, %rd7;\n\tshr.s64 \t%rd25, %rd9, 63;\n\tselp.b64 \t%rd26, 0, %rd25, %p5;\n\tadd.s64 \t%rd27, %rd26, %rd41;\n\tselp.b64 \t%rd10, 0, %rd27, %p2;\n\tmul.lo.s64 \t%rd28, %rd41, %rd5;\n\tsub.s64 \t%rd29, %rd7, %rd28;\n\tsetp.ne.b64 \t%p6, %rd7, %rd28;\n\tselp.b64 \t%rd30, %rd5, 0, %p6;\n\tselp.b64 \t%rd31, %rd30, 0, %p4;\n\tadd.s64 \t%rd32, %rd29, %rd31;\n\tselp.b64 \t%rd11, 0, %rd32, %p2;\n\tsetp.lt.s32 \t%p7, %r4, 1;\n\tmov.b32 \t%r82, 0f00000000;\n\t@%p7 bra \t$L__BB0_7;\n\tld.param.b64 \t%rd14, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_1];\n\tld.param.b64 \t%rd15, [neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202_param_2];\n\tcvt.s64.s32 \t%rd6, %r4;\n\tcvta.to.global.u64 \t%rd1, %rd14;\n\tcvta.to.global.u64 \t%rd2, %rd15;\n\tmax.s64 \t%rd44, %rd6, 0;\n\tmul.lo.s64 \t%rd33, %rd11, %rd6;\n\tmul.lo.s64 \t%rd34, %rd10, %rd6;\n\tshl.b64 \t%rd35, %rd34, 2;\n\tadd.s64 \t%rd43, %rd1, %rd35;\n\tshl.b64 \t%rd36, %rd33, 2;\n\tadd.s64 \t%rd42, %rd2, %rd36;\n\tmov.b32 \t%r82, 0f00000000;\n$L__BB0_6:\n\tadd.s64 \t%rd44, %rd44, -1;\n\tld.global.b32 \t%r13, [%rd43];\n\tand.b32 \t%r14, %r13, -2147483648;\n\tand.b32 \t%r15, %r13, 8388607;\n\tsetp.ne.b32 \t%p8, %r15, 0;\n\tand.b32 \t%r16, %r13, 2139095040;\n\tsetp.eq.b32 \t%p9, %r16, 0;\n\tselp.f32 \t%r17, %r14, %r13, %p8;\n\tselp.f32 \t%r18, %r17, %r13, %p9;\n\tld.global.b32 \t%r19, [%rd42];\n\tand.b32 \t%r20, %r19, -2147483648;\n\tand.b32 \t%r21, %r19, 8388607;\n\tsetp.ne.b32 \t%p10, %r21, 0;\n\tand.b32 \t%r22, %r19, 2139095040;\n\tsetp.eq.b32 \t%p11, %r22, 0;\n\tselp.f32 \t%r23, %r20, %r19, %p10;\n\tselp.f32 \t%r24, %r23, %r19, %p11;\n\tfma.rn.f32 \t%r25, %r18, %r24, %r82;\n\tand.b32 \t%r26, %r25, -2147483648;\n\tand.b32 \t%r27, %r25, 8388607;\n\tsetp.ne.b32 \t%p12, %r27, 0;\n\tand.b32 \t%r28, %r25, 2139095040;\n\tsetp.eq.b32 \t%p13, %r28, 0;\n\tselp.f32 \t%r29, %r26, %r25, %p12;\n\tselp.f32 \t%r82, %r29, %r25, %p13;\n\tadd.s64 \t%rd43, %rd43, 4;\n\tadd.s64 \t%rd42, %rd42, 4;\n\tsetp.ne.b64 \t%p14, %rd44, 0;\n\t@%p14 bra \t$L__BB0_6;\n$L__BB0_7:\n\tadd.s64 \t%rd8, %rd13, %rd20;\n\tsetp.eq.b32 \t%p15, %r5, 0;\n\tshl.b64 \t%rd37, %rd10, 2;\n\tadd.s64 \t%rd38, %rd3, %rd37;\n\tld.global.b32 \t%r30, [%rd38];\n\tand.b32 \t%r31, %r30, -2147483648;\n\tand.b32 \t%r32, %r30, 8388607;\n\tsetp.ne.b32 \t%p16, %r32, 0;\n\tand.b32 \t%r33, %r30, 2139095040;\n\tsetp.eq.b32 \t%p17, %r33, 0;\n\tselp.f32 \t%r34, %r31, %r30, %p16;\n\tselp.f32 \t%r35, %r34, %r30, %p17;\n\tshl.b64 \t%rd39, %rd11, 2;\n\tadd.s64 \t%rd40, %rd4, %rd39;\n\tld.global.b32 \t%r36, [%rd40];\n\tand.b32 \t%r37, %r36, -2147483648;\n\tand.b32 \t%r38, %r36, 8388607;\n\tsetp.ne.b32 \t%p18, %r38, 0;\n\tand.b32 \t%r39, %r36, 2139095040;\n\tsetp.eq.b32 \t%p19, %r39, 0;\n\tselp.f32 \t%r40, %r37, %r36, %p18;\n\tselp.f32 \t%r41, %r40, %r36, %p19;\n\tadd.f32 \t%r42, %r35, %r41;\n\tand.b32 \t%r43, %r42, -2147483648;\n\tand.b32 \t%r44, %r42, 8388607;\n\tsetp.ne.b32 \t%p20, %r44, 0;\n\tand.b32 \t%r45, %r42, 2139095040;\n\tsetp.eq.b32 \t%p21, %r45, 0;\n\tselp.f32 \t%r46, %r43, %r42, %p20;\n\tselp.f32 \t%r47, %r46, %r42, %p21;\n\tfma.rn.f32 \t%r48, %r82, 0fC0000000, %r47;\n\tand.b32 \t%r49, %r48, -2147483648;\n\tand.b32 \t%r50, %r48, 8388607;\n\tsetp.ne.b32 \t%p22, %r50, 0;\n\tand.b32 \t%r51, %r48, 2139095040;\n\tsetp.eq.b32 \t%p23, %r51, 0;\n\tselp.f32 \t%r52, %r49, %r48, %p22;\n\tselp.f32 \t%r53, %r52, %r48, %p23;\n\tsetp.le.f32 \t%p24, %r53, 0f00000000;\n\tselp.f32 \t%r86, 0f00000000, %r53, %p24;\n\t@%p15 bra \t$L__BB0_13;\n\tabs.f32 \t%r54, %r86;\n\tsetp.eq.f32 \t%p26, %r86, 0f7F800000;\n\tsetp.lt.f32 \t%p27, %r54, 0f00800000;\n\tsetp.num.f32 \t%p28, %r86, %r86;\n\tsetp.ltu.f32 \t%p29, %r86, 0f00000000;\n\tor.pred \t%p30, %p29, %p27;\n\tselp.f32 \t%r56, 0f00000000, 0f7FC00000, %p27;\n\tor.pred \t%p31, %p26, %p30;\n\tselp.f32 \t%r57, %r56, %r86, %p30;\n\tselp.f32 \t%r85, %r57, %r86, %p28;\n\t@%p31 bra \t$L__BB0_12;\n\tmul.f32 \t%r55, %r86, 0f5F800000;\n\tsetp.lt.f32 \t%p25, %r86, 0f0F800000;\n\tselp.f32 \t%r1, %r55, %r86, %p25;\n\tshr.u32 \t%r58, %r1, 1;\n\tadd.s32 \t%r59, %r58, 532487669;\n\tdiv.rn.f32 \t%r60, %r1, %r59;\n\tadd.f32 \t%r61, %r60, %r59;\n\tmul.f32 \t%r62, %r61, 0f3F000000;\n\tdiv.rn.f32 \t%r63, %r1, %r62;\n\tfma.rn.f32 \t%r64, %r61, 0f3F000000, %r63;\n\tmul.f32 \t%r65, %r64, 0f3F000000;\n\tdiv.rn.f32 \t%r66, %r1, %r65;\n\tfma.rn.f32 \t%r67, %r64, 0f3F000000, %r66;\n\tmul.f32 \t%r2, %r67, 0f3F000000;\n\tneg.f32 \t%r68, %r2;\n\tfma.rn.f32 \t%r69, %r68, %r2, %r1;\n\tabs.f32 \t%r83, %r69;\n\tmov.b64 \t%rd45, 0;\n\tmov.b32 \t%r84, %r2;\n$L__BB0_10:\n\tsetp.eq.b64 \t%p32, %rd45, 2;\n\tselp.b32 \t%r70, -2, 2, %p32;\n\tsetp.eq.b64 \t%p33, %rd45, 1;\n\tsetp.eq.b64 \t%p34, %rd45, 0;\n\tselp.b32 \t%r71, 1, %r70, %p33;\n\tselp.b32 \t%r72, -1, %r71, %p34;\n\tadd.s32 \t%r73, %r72, %r2;\n\tneg.f32 \t%r74, %r73;\n\tfma.rn.f32 \t%r75, %r74, %r73, %r1;\n\tabs.f32 \t%r76, %r75;\n\tsetp.lt.f32 \t%p35, %r76, %r83;\n\tselp.f32 \t%r84, %r73, %r84, %p35;\n\tselp.f32 \t%r83, %r76, %r83, %p35;\n\tadd.s64 \t%rd45, %rd45, 1;\n\tsetp.ne.b64 \t%p36, %rd45, 4;\n\t@%p36 bra \t$L__BB0_10;\n\tmul.f32 \t%r77, %r84, 0f2F800000;\n\tselp.f32 \t%r85, %r77, %r84, %p25;\n$L__BB0_12:\n\tand.b32 \t%r78, %r85, -2147483648;\n\tand.b32 \t%r79, %r85, 8388607;\n\tsetp.ne.b32 \t%p37, %r79, 0;\n\tand.b32 \t%r80, %r85, 2139095040;\n\tsetp.eq.b32 \t%p38, %r80, 0;\n\tselp.f32 \t%r81, %r78, %r85, %p37;\n\tselp.f32 \t%r86, %r81, %r85, %p38;\n$L__BB0_13:\n\tst.global.b32 \t[%rd8], %r86;\n$L__BB0_14:\n\tret;\n\n}\n"
	.size	static_string_66bf81b04b01b855, 7530

	.type	static_string_ebcf1412899f981b,@object
	.p2align	4, 0x0
static_string_ebcf1412899f981b:
	.asciz	"30b9baa5bb883a84054067267c5d5eb2"
	.size	static_string_ebcf1412899f981b, 33

	.type	static_string_77e8a444a810659d,@object
	.p2align	4, 0x0
static_string_77e8a444a810659d:
	.asciz	"neighbors_checks_pinned_distan6A6A6A6A_5efda74c8afcc202"
	.size	static_string_77e8a444a810659d, 56

	.type	static_string_4f5aebbb4c03edc3,@object
	.p2align	4, 0x0
static_string_4f5aebbb4c03edc3:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(z: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_features_in: ::SIMD[::DType(int32), ::SIMDLength(1)], is_sqrt_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|a39854056ff61b4e"
	.size	static_string_4f5aebbb4c03edc3, 969

	.type	static_string_e07c7279604e36e8,@object
	.p2align	4, 0x0
static_string_e07c7279604e36e8:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tneighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d\n\n.visible .entry neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d(\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_0,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_1,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_2,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_3,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_4,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_5,\n\t.param .u64 .ptr .align 1 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_6,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_7,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_8,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_9,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_10,\n\t.param .u32 neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_11\n)\n{\n\t.reg .pred \t%p<729>;\n\t.reg .b32 \t%r<1859>;\n\t.reg .b64 \t%rd<168>;\n\n\tld.param.b32 \t%r75, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_7];\n\tld.param.b32 \t%r76, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_8];\n\tcvt.s64.s32 \t%rd5, %r76;\n\tmov.u32 \t%r77, %ctaid.x;\n\tmov.u32 \t%r78, %tid.x;\n\tmul.wide.u32 \t%rd56, %r77, 512;\n\tshl.b32 \t%r79, %r78, 2;\n\tcvt.u64.u32 \t%rd57, %r79;\n\tadd.s64 \t%rd10, %rd56, %rd57;\n\tmov.u32 \t%r80, %ctaid.y;\n\tshl.b32 \t%r81, %r80, 3;\n\tsetp.ge.s64 \t%p1, %rd10, %rd5;\n\tsetp.ge.s32 \t%p2, %r81, %r75;\n\tor.pred \t%p3, %p1, %p2;\n\t@%p3 bra \t$L__BB0_251;\n\tld.param.b32 \t%r74, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_11];\n\tld.param.b32 \t%r73, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_10];\n\tld.param.b64 \t%rd48, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_0];\n\tld.param.b64 \t%rd49, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_4];\n\tcvta.to.global.u64 \t%rd50, %rd49;\n\tcvta.to.global.u64 \t%rd52, %rd48;\n\tld.param.b64 \t%rd54, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_3];\n\tcvta.to.global.u64 \t%rd55, %rd54;\n\tcvt.s64.s32 \t%rd3, %r75;\n\tshl.b64 \t%rd58, %rd10, 2;\n\tadd.s64 \t%rd11, %rd50, %rd58;\n\tcvt.u64.u32 \t%rd16, %r81;\n\tmul.lo.s64 \t%rd60, %rd5, %rd16;\n\tshl.b64 \t%rd61, %rd60, 2;\n\tadd.s64 \t%rd62, %rd52, %rd61;\n\tmul.wide.u32 \t%rd63, %r81, 4;\n\tadd.s64 \t%rd18, %rd55, %rd63;\n\tsetp.lt.s32 \t%p4, %r73, 1;\n\tmov.b32 \t%r1699, 0f00000000;\n\tmov.b32 \t%r1700, %r1699;\n\tmov.b32 \t%r1701, %r1699;\n\tmov.b32 \t%r1702, %r1699;\n\tmov.b32 \t%r1703, %r1699;\n\tmov.b32 \t%r1704, %r1699;\n\tmov.b32 \t%r1705, %r1699;\n\tmov.b32 \t%r1706, %r1699;\n\tmov.b32 \t%r1707, %r1699;\n\tmov.b32 \t%r1708, %r1699;\n\tmov.b32 \t%r1709, %r1699;\n\tmov.b32 \t%r1710, %r1699;\n\tmov.b32 \t%r1711, %r1699;\n\tmov.b32 \t%r1712, %r1699;\n\tmov.b32 \t%r1713, %r1699;\n\tmov.b32 \t%r1714, %r1699;\n\tmov.b32 \t%r1715, %r1699;\n\tmov.b32 \t%r1716, %r1699;\n\tmov.b32 \t%r1717, %r1699;\n\tmov.b32 \t%r1718, %r1699;\n\tmov.b32 \t%r1719, %r1699;\n\tmov.b32 \t%r1720, %r1699;\n\tmov.b32 \t%r1721, %r1699;\n\tmov.b32 \t%r1722, %r1699;\n\tmov.b32 \t%r1723, %r1699;\n\tmov.b32 \t%r1724, %r1699;\n\tmov.b32 \t%r1725, %r1699;\n\tmov.b32 \t%r1726, %r1699;\n\tmov.b32 \t%r1727, %r1699;\n\tmov.b32 \t%r1728, %r1699;\n\tmov.b32 \t%r1729, %r1699;\n\tmov.b32 \t%r1730, %r1699;\n\t@%p4 bra \t$L__BB0_4;\n\tld.param.b64 \t%rd51, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_1];\n\tld.param.b64 \t%rd53, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_2];\n\tcvta.to.global.u64 \t%rd1, %rd51;\n\tcvta.to.global.u64 \t%rd2, %rd53;\n\tadd.s64 \t%rd4, %rd3, -1;\n\tadd.s64 \t%rd6, %rd5, -1;\n\tld.param.s32 \t%rd7, [neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d_param_9];\n\tcvt.s64.s32 \t%rd8, %r73;\n\tmax.s64 \t%rd9, %rd8, 0;\n\tmin.s64 \t%rd59, %rd10, %rd6;\n\tshl.b64 \t%rd15, %rd59, 32;\n\tmin.s64 \t%rd71, %rd4, %rd16;\n\tcvt.s64.s32 \t%rd72, %rd71;\n\tmul.lo.s64 \t%rd33, %rd72, %rd8;\n\tshr.s64 \t%rd73, %rd15, 30;\n\tshl.b64 \t%rd74, %rd33, 2;\n\tadd.s64 \t%rd34, %rd1, %rd74;\n\tadd.s64 \t%rd75, %rd16, 1;\n\tmin.s64 \t%rd76, %rd4, %rd75;\n\tcvt.s64.s32 \t%rd77, %rd76;\n\tmul.lo.s64 \t%rd78, %rd8, %rd77;\n\tshl.b64 \t%rd79, %rd78, 2;\n\tadd.s64 \t%rd35, %rd1, %rd79;\n\tadd.s64 \t%rd80, %rd16, 2;\n\tmin.s64 \t%rd81, %rd4, %rd80;\n\tcvt.s64.s32 \t%rd82, %rd81;\n\tmul.lo.s64 \t%rd83, %rd8, %rd82;\n\tshl.b64 \t%rd84, %rd83, 2;\n\tadd.s64 \t%rd36, %rd1, %rd84;\n\tadd.s64 \t%rd85, %rd16, 3;\n\tmin.s64 \t%rd86, %rd4, %rd85;\n\tcvt.s64.s32 \t%rd87, %rd86;\n\tmul.lo.s64 \t%rd88, %rd8, %rd87;\n\tshl.b64 \t%rd89, %rd88, 2;\n\tadd.s64 \t%rd37, %rd1, %rd89;\n\tadd.s64 \t%rd90, %rd16, 4;\n\tmin.s64 \t%rd91, %rd4, %rd90;\n\tcvt.s64.s32 \t%rd92, %rd91;\n\tmul.lo.s64 \t%rd93, %rd8, %rd92;\n\tshl.b64 \t%rd94, %rd93, 2;\n\tadd.s64 \t%rd38, %rd1, %rd94;\n\tadd.s64 \t%rd95, %rd16, 5;\n\tmin.s64 \t%rd96, %rd4, %rd95;\n\tcvt.s64.s32 \t%rd97, %rd96;\n\tmul.lo.s64 \t%rd98, %rd8, %rd97;\n\tshl.b64 \t%rd99, %rd98, 2;\n\tadd.s64 \t%rd39, %rd1, %rd99;\n\tadd.s64 \t%rd100, %rd16, 6;\n\tmin.s64 \t%rd101, %rd4, %rd100;\n\tcvt.s64.s32 \t%rd102, %rd101;\n\tmul.lo.s64 \t%rd103, %rd8, %rd102;\n\tshl.b64 \t%rd104, %rd103, 2;\n\tadd.s64 \t%rd40, %rd1, %rd104;\n\tadd.s64 \t%rd105, %rd16, 7;\n\tmin.s64 \t%rd106, %rd4, %rd105;\n\tcvt.s64.s32 \t%rd107, %rd106;\n\tmul.lo.s64 \t%rd108, %rd8, %rd107;\n\tshl.b64 \t%rd109, %rd108, 2;\n\tadd.s64 \t%rd41, %rd1, %rd109;\n\tadd.s64 \t%rd42, %rd2, %rd73;\n\tshl.b64 \t%rd43, %rd7, 2;\n\tadd.s64 \t%rd110, %rd10, 1;\n\tmin.s64 \t%rd111, %rd110, %rd6;\n\tshl.b64 \t%rd112, %rd111, 32;\n\tshr.s64 \t%rd113, %rd112, 30;\n\tadd.s64 \t%rd44, %rd2, %rd113;\n\tadd.s64 \t%rd114, %rd10, 2;\n\tmin.s64 \t%rd115, %rd114, %rd6;\n\tshl.b64 \t%rd116, %rd115, 32;\n\tshr.s64 \t%rd117, %rd116, 30;\n\tadd.s64 \t%rd45, %rd2, %rd117;\n\tadd.s64 \t%rd118, %rd10, 3;\n\tmin.s64 \t%rd119, %rd118, %rd6;\n\tshl.b64 \t%rd120, %rd119, 32;\n\tshr.s64 \t%rd121, %rd120, 30;\n\tadd.s64 \t%rd46, %rd2, %rd121;\n\tshl.b64 \t%rd47, %rd9, 2;\n\tmov.b32 \t%r1699, 0f00000000;\n\tmov.b64 \t%rd134, 0;\n\tmov.b64 \t%rd135, %rd134;\n\tmov.b32 \t%r1700, %r1699;\n\tmov.b32 \t%r1701, %r1699;\n\tmov.b32 \t%r1702, %r1699;\n\tmov.b32 \t%r1703, %r1699;\n\tmov.b32 \t%r1704, %r1699;\n\tmov.b32 \t%r1705, %r1699;\n\tmov.b32 \t%r1706, %r1699;\n\tmov.b32 \t%r1707, %r1699;\n\tmov.b32 \t%r1708, %r1699;\n\tmov.b32 \t%r1709, %r1699;\n\tmov.b32 \t%r1710, %r1699;\n\tmov.b32 \t%r1711, %r1699;\n\tmov.b32 \t%r1712, %r1699;\n\tmov.b32 \t%r1713, %r1699;\n\tmov.b32 \t%r1714, %r1699;\n\tmov.b32 \t%r1715, %r1699;\n\tmov.b32 \t%r1716, %r1699;\n\tmov.b32 \t%r1717, %r1699;\n\tmov.b32 \t%r1718, %r1699;\n\tmov.b32 \t%r1719, %r1699;\n\tmov.b32 \t%r1720, %r1699;\n\tmov.b32 \t%r1721, %r1699;\n\tmov.b32 \t%r1722, %r1699;\n\tmov.b32 \t%r1723, %r1699;\n\tmov.b32 \t%r1724, %r1699;\n\tmov.b32 \t%r1725, %r1699;\n\tmov.b32 \t%r1726, %r1699;\n\tmov.b32 \t%r1727, %r1699;\n\tmov.b32 \t%r1728, %r1699;\n\tmov.b32 \t%r1729, %r1699;\n\tmov.b32 \t%r1730, %r1699;\n$L__BB0_3:\n\tadd.s64 \t%rd122, %rd42, %rd134;\n\tld.global.b32 \t%r82, [%rd122];\n\tand.b32 \t%r83, %r82, -2147483648;\n\tand.b32 \t%r84, %r82, 8388607;\n\tsetp.ne.b32 \t%p5, %r84, 0;\n\tand.b32 \t%r85, %r82, 2139095040;\n\tsetp.eq.b32 \t%p6, %r85, 0;\n\tselp.f32 \t%r86, %r83, %r82, %p5;\n\tselp.f32 \t%r87, %r86, %r82, %p6;\n\tadd.s64 \t%rd123, %rd44, %rd134;\n\tld.global.b32 \t%r88, [%rd123];\n\tand.b32 \t%r89, %r88, -2147483648;\n\tand.b32 \t%r90, %r88, 8388607;\n\tsetp.ne.b32 \t%p7, %r90, 0;\n\tand.b32 \t%r91, %r88, 2139095040;\n\tsetp.eq.b32 \t%p8, %r91, 0;\n\tselp.f32 \t%r92, %r89, %r88, %p7;\n\tselp.f32 \t%r93, %r92, %r88, %p8;\n\tadd.s64 \t%rd124, %rd45, %rd134;\n\tld.global.b32 \t%r94, [%rd124];\n\tand.b32 \t%r95, %r94, -2147483648;\n\tand.b32 \t%r96, %r94, 8388607;\n\tsetp.ne.b32 \t%p9, %r96, 0;\n\tand.b32 \t%r97, %r94, 2139095040;\n\tsetp.eq.b32 \t%p10, %r97, 0;\n\tselp.f32 \t%r98, %r95, %r94, %p9;\n\tselp.f32 \t%r99, %r98, %r94, %p10;\n\tadd.s64 \t%rd125, %rd46, %rd134;\n\tld.global.b32 \t%r100, [%rd125];\n\tand.b32 \t%r101, %r100, -2147483648;\n\tand.b32 \t%r102, %r100, 8388607;\n\tsetp.ne.b32 \t%p11, %r102, 0;\n\tand.b32 \t%r103, %r100, 2139095040;\n\tsetp.eq.b32 \t%p12, %r103, 0;\n\tselp.f32 \t%r104, %r101, %r100, %p11;\n\tselp.f32 \t%r105, %r104, %r100, %p12;\n\tadd.s64 \t%rd126, %rd34, %rd135;\n\tld.global.b32 \t%r106, [%rd126];\n\tand.b32 \t%r107, %r106, -2147483648;\n\tand.b32 \t%r108, %r106, 8388607;\n\tsetp.ne.b32 \t%p13, %r108, 0;\n\tand.b32 \t%r109, %r106, 2139095040;\n\tsetp.eq.b32 \t%p14, %r109, 0;\n\tselp.f32 \t%r110, %r107, %r106, %p13;\n\tselp.f32 \t%r111, %r110, %r106, %p14;\n\tfma.rn.f32 \t%r112, %r111, %r87, %r1699;\n\tmov.b32 \t%r113, 0f3F800000;\n\tmul.rn.ftz.f32 \t%r1699, %r112, %r113;\n\tfma.rn.f32 \t%r114, %r111, %r93, %r1700;\n\tmul.rn.ftz.f32 \t%r1700, %r114, %r113;\n\tfma.rn.f32 \t%r115, %r111, %r99, %r1701;\n\tmul.rn.ftz.f32 \t%r1701, %r115, %r113;\n\tfma.rn.f32 \t%r116, %r111, %r105, %r1702;\n\tmul.rn.ftz.f32 \t%r1702, %r116, %r113;\n\tadd.s64 \t%rd127, %rd35, %rd135;\n\tld.global.b32 \t%r117, [%rd127];\n\tand.b32 \t%r118, %r117, -2147483648;\n\tand.b32 \t%r119, %r117, 8388607;\n\tsetp.ne.b32 \t%p15, %r119, 0;\n\tand.b32 \t%r120, %r117, 2139095040;\n\tsetp.eq.b32 \t%p16, %r120, 0;\n\tselp.f32 \t%r121, %r118, %r117, %p15;\n\tselp.f32 \t%r122, %r121, %r117, %p16;\n\tfma.rn.f32 \t%r123, %r122, %r87, %r1703;\n\tmul.rn.ftz.f32 \t%r1703, %r123, %r113;\n\tfma.rn.f32 \t%r124, %r122, %r93, %r1704;\n\tmul.rn.ftz.f32 \t%r1704, %r124, %r113;\n\tfma.rn.f32 \t%r125, %r122, %r99, %r1705;\n\tmul.rn.ftz.f32 \t%r1705, %r125, %r113;\n\tfma.rn.f32 \t%r126, %r122, %r105, %r1706;\n\tmul.rn.ftz.f32 \t%r1706, %r126, %r113;\n\tadd.s64 \t%rd128, %rd36, %rd135;\n\tld.global.b32 \t%r127, [%rd128];\n\tand.b32 \t%r128, %r127, -2147483648;\n\tand.b32 \t%r129, %r127, 8388607;\n\tsetp.ne.b32 \t%p17, %r129, 0;\n\tand.b32 \t%r130, %r127, 2139095040;\n\tsetp.eq.b32 \t%p18, %r130, 0;\n\tselp.f32 \t%r131, %r128, %r127, %p17;\n\tselp.f32 \t%r132, %r131, %r127, %p18;\n\tfma.rn.f32 \t%r133, %r132, %r87, %r1707;\n\tmul.rn.ftz.f32 \t%r1707, %r133, %r113;\n\tfma.rn.f32 \t%r134, %r132, %r93, %r1708;\n\tmul.rn.ftz.f32 \t%r1708, %r134, %r113;\n\tfma.rn.f32 \t%r135, %r132, %r99, %r1709;\n\tmul.rn.ftz.f32 \t%r1709, %r135, %r113;\n\tfma.rn.f32 \t%r136, %r132, %r105, %r1710;\n\tmul.rn.ftz.f32 \t%r1710, %r136, %r113;\n\tadd.s64 \t%rd129, %rd37, %rd135;\n\tld.global.b32 \t%r137, [%rd129];\n\tand.b32 \t%r138, %r137, -2147483648;\n\tand.b32 \t%r139, %r137, 8388607;\n\tsetp.ne.b32 \t%p19, %r139, 0;\n\tand.b32 \t%r140, %r137, 2139095040;\n\tsetp.eq.b32 \t%p20, %r140, 0;\n\tselp.f32 \t%r141, %r138, %r137, %p19;\n\tselp.f32 \t%r142, %r141, %r137, %p20;\n\tfma.rn.f32 \t%r143, %r142, %r87, %r1711;\n\tmul.rn.ftz.f32 \t%r1711, %r143, %r113;\n\tfma.rn.f32 \t%r144, %r142, %r93, %r1712;\n\tmul.rn.ftz.f32 \t%r1712, %r144, %r113;\n\tfma.rn.f32 \t%r145, %r142, %r99, %r1713;\n\tmul.rn.ftz.f32 \t%r1713, %r145, %r113;\n\tfma.rn.f32 \t%r146, %r142, %r105, %r1714;\n\tmul.rn.ftz.f32 \t%r1714, %r146, %r113;\n\tadd.s64 \t%rd130, %rd38, %rd135;\n\tld.global.b32 \t%r147, [%rd130];\n\tand.b32 \t%r148, %r147, -2147483648;\n\tand.b32 \t%r149, %r147, 8388607;\n\tsetp.ne.b32 \t%p21, %r149, 0;\n\tand.b32 \t%r150, %r147, 2139095040;\n\tsetp.eq.b32 \t%p22, %r150, 0;\n\tselp.f32 \t%r151, %r148, %r147, %p21;\n\tselp.f32 \t%r152, %r151, %r147, %p22;\n\tfma.rn.f32 \t%r153, %r152, %r87, %r1715;\n\tmul.rn.ftz.f32 \t%r1715, %r153, %r113;\n\tfma.rn.f32 \t%r154, %r152, %r93, %r1716;\n\tmul.rn.ftz.f32 \t%r1716, %r154, %r113;\n\tfma.rn.f32 \t%r155, %r152, %r99, %r1717;\n\tmul.rn.ftz.f32 \t%r1717, %r155, %r113;\n\tfma.rn.f32 \t%r156, %r152, %r105, %r1718;\n\tmul.rn.ftz.f32 \t%r1718, %r156, %r113;\n\tadd.s64 \t%rd131, %rd39, %rd135;\n\tld.global.b32 \t%r157, [%rd131];\n\tand.b32 \t%r158, %r157, -2147483648;\n\tand.b32 \t%r159, %r157, 8388607;\n\tsetp.ne.b32 \t%p23, %r159, 0;\n\tand.b32 \t%r160, %r157, 2139095040;\n\tsetp.eq.b32 \t%p24, %r160, 0;\n\tselp.f32 \t%r161, %r158, %r157, %p23;\n\tselp.f32 \t%r162, %r161, %r157, %p24;\n\tfma.rn.f32 \t%r163, %r162, %r87, %r1719;\n\tmul.rn.ftz.f32 \t%r1719, %r163, %r113;\n\tfma.rn.f32 \t%r164, %r162, %r93, %r1720;\n\tmul.rn.ftz.f32 \t%r1720, %r164, %r113;\n\tfma.rn.f32 \t%r165, %r162, %r99, %r1721;\n\tmul.rn.ftz.f32 \t%r1721, %r165, %r113;\n\tfma.rn.f32 \t%r166, %r162, %r105, %r1722;\n\tmul.rn.ftz.f32 \t%r1722, %r166, %r113;\n\tadd.s64 \t%rd132, %rd40, %rd135;\n\tld.global.b32 \t%r167, [%rd132];\n\tand.b32 \t%r168, %r167, -2147483648;\n\tand.b32 \t%r169, %r167, 8388607;\n\tsetp.ne.b32 \t%p25, %r169, 0;\n\tand.b32 \t%r170, %r167, 2139095040;\n\tsetp.eq.b32 \t%p26, %r170, 0;\n\tselp.f32 \t%r171, %r168, %r167, %p25;\n\tselp.f32 \t%r172, %r171, %r167, %p26;\n\tfma.rn.f32 \t%r173, %r172, %r87, %r1723;\n\tmul.rn.ftz.f32 \t%r1723, %r173, %r113;\n\tfma.rn.f32 \t%r174, %r172, %r93, %r1724;\n\tmul.rn.ftz.f32 \t%r1724, %r174, %r113;\n\tfma.rn.f32 \t%r175, %r172, %r99, %r1725;\n\tmul.rn.ftz.f32 \t%r1725, %r175, %r113;\n\tfma.rn.f32 \t%r176, %r172, %r105, %r1726;\n\tmul.rn.ftz.f32 \t%r1726, %r176, %r113;\n\tadd.s64 \t%rd133, %rd41, %rd135;\n\tld.global.b32 \t%r177, [%rd133];\n\tand.b32 \t%r178, %r177, -2147483648;\n\tand.b32 \t%r179, %r177, 8388607;\n\tsetp.ne.b32 \t%p27, %r179, 0;\n\tand.b32 \t%r180, %r177, 2139095040;\n\tsetp.eq.b32 \t%p28, %r180, 0;\n\tselp.f32 \t%r181, %r178, %r177, %p27;\n\tselp.f32 \t%r182, %r181, %r177, %p28;\n\tfma.rn.f32 \t%r183, %r182, %r87, %r1727;\n\tmul.rn.ftz.f32 \t%r1727, %r183, %r113;\n\tfma.rn.f32 \t%r184, %r182, %r93, %r1728;\n\tmul.rn.ftz.f32 \t%r1728, %r184, %r113;\n\tfma.rn.f32 \t%r185, %r182, %r99, %r1729;\n\tmul.rn.ftz.f32 \t%r1729, %r185, %r113;\n\tfma.rn.f32 \t%r186, %r182, %r105, %r1730;\n\tmul.rn.ftz.f32 \t%r1730, %r186, %r113;\n\tadd.s64 \t%rd135, %rd135, 4;\n\tadd.s64 \t%rd134, %rd134, %rd43;\n\tsetp.ne.b64 \t%p29, %rd47, %rd135;\n\t@%p29 bra \t$L__BB0_3;\n$L__BB0_4:\n\tadd.s64 \t%rd17, %rd62, %rd58;\n\tor.b64 \t%rd14, %rd10, 1;\n\tsetp.eq.b32 \t%p30, %r74, 0;\n\tld.global.b32 \t%r187, [%rd18];\n\tand.b32 \t%r188, %r187, -2147483648;\n\tand.b32 \t%r189, %r187, 8388607;\n\tsetp.ne.b32 \t%p31, %r189, 0;\n\tand.b32 \t%r190, %r187, 2139095040;\n\tsetp.eq.b32 \t%p32, %r190, 0;\n\tselp.f32 \t%r191, %r188, %r187, %p31;\n\tselp.f32 \t%r1, %r191, %r187, %p32;\n\tld.global.b32 \t%r192, [%rd11];\n\tand.b32 \t%r193, %r192, -2147483648;\n\tand.b32 \t%r194, %r192, 8388607;\n\tsetp.ne.b32 \t%p33, %r194, 0;\n\tand.b32 \t%r195, %r192, 2139095040;\n\tsetp.eq.b32 \t%p34, %r195, 0;\n\tselp.f32 \t%r196, %r193, %r192, %p33;\n\tselp.f32 \t%r197, %r196, %r192, %p34;\n\tadd.f32 \t%r198, %r1, %r197;\n\tand.b32 \t%r199, %r198, -2147483648;\n\tand.b32 \t%r200, %r198, 8388607;\n\tsetp.ne.b32 \t%p35, %r200, 0;\n\tand.b32 \t%r201, %r198, 2139095040;\n\tsetp.eq.b32 \t%p36, %r201, 0;\n\tselp.f32 \t%r202, %r199, %r198, %p35;\n\tselp.f32 \t%r203, %r202, %r198, %p36;\n\tfma.rn.f32 \t%r204, %r1699, 0fC0000000, %r203;\n\tand.b32 \t%r205, %r204, -2147483648;\n\tand.b32 \t%r206, %r204, 8388607;\n\tsetp.ne.b32 \t%p37, %r206, 0;\n\tand.b32 \t%r207, %r204, 2139095040;\n\tsetp.eq.b32 \t%p38, %r207, 0;\n\tselp.f32 \t%r208, %r205, %r204, %p37;\n\tselp.f32 \t%r209, %r208, %r204, %p38;\n\tsetp.le.f32 \t%p39, %r209, 0f00000000;\n\tselp.f32 \t%r1734, 0f00000000, %r209, %p39;\n\t@%p30 bra \t$L__BB0_10;\n\tabs.f32 \t%r210, %r1734;\n\tsetp.eq.f32 \t%p41, %r1734, 0f7F800000;\n\tsetp.lt.f32 \t%p42, %r210, 0f00800000;\n\tsetp.num.f32 \t%p43, %r1734, %r1734;\n\tsetp.ltu.f32 \t%p44, %r1734, 0f00000000;\n\tor.pred \t%p45, %p44, %p42;\n\tselp.f32 \t%r212, 0f00000000, 0f7FC00000, %p42;\n\tor.pred \t%p46, %p41, %p45;\n\tselp.f32 \t%r213, %r212, %r1734, %p45;\n\tselp.f32 \t%r1733, %r213, %r1734, %p43;\n\t@%p46 bra \t$L__BB0_9;\n\tmul.f32 \t%r211, %r1734, 0f5F800000;\n\tsetp.lt.f32 \t%p40, %r1734, 0f0F800000;\n\tselp.f32 \t%r2, %r211, %r1734, %p40;\n\tshr.u32 \t%r214, %r2, 1;\n\tadd.s32 \t%r215, %r214, 532487669;\n\tdiv.rn.f32 \t%r216, %r2, %r215;\n\tadd.f32 \t%r217, %r216, %r215;\n\tmul.f32 \t%r218, %r217, 0f3F000000;\n\tdiv.rn.f32 \t%r219, %r2, %r218;\n\tfma.rn.f32 \t%r220, %r217, 0f3F000000, %r219;\n\tmul.f32 \t%r221, %r220, 0f3F000000;\n\tdiv.rn.f32 \t%r222, %r2, %r221;\n\tfma.rn.f32 \t%r223, %r220, 0f3F000000, %r222;\n\tmul.f32 \t%r3, %r223, 0f3F000000;\n\tneg.f32 \t%r224, %r3;\n\tfma.rn.f32 \t%r225, %r224, %r3, %r2;\n\tabs.f32 \t%r1731, %r225;\n\tmov.b64 \t%rd136, 0;\n\tmov.b32 \t%r1732, %r3;\n$L__BB0_7:\n\tsetp.eq.b64 \t%p47, %rd136, 2;\n\tselp.b32 \t%r226, -2, 2, %p47;\n\tsetp.eq.b64 \t%p48, %rd136, 1;\n\tsetp.eq.b64 \t%p49, %rd136, 0;\n\tselp.b32 \t%r227, 1, %r226, %p48;\n\tselp.b32 \t%r228, -1, %r227, %p49;\n\tadd.s32 \t%r229, %r228, %r3;\n\tneg.f32 \t%r230, %r229;\n\tfma.rn.f32 \t%r231, %r230, %r229, %r2;\n\tabs.f32 \t%r232, %r231;\n\tsetp.lt.f32 \t%p50, %r232, %r1731;\n\tselp.f32 \t%r1732, %r229, %r1732, %p50;\n\tselp.f32 \t%r1731, %r232, %r1731, %p50;\n\tadd.s64 \t%rd136, %rd136, 1;\n\tsetp.ne.b64 \t%p51, %rd136, 4;\n\t@%p51 bra \t$L__BB0_7;\n\tmul.f32 \t%r233, %r1732, 0f2F800000;\n\tselp.f32 \t%r1733, %r233, %r1732, %p40;\n$L__BB0_9:\n\tand.b32 \t%r234, %r1733, -2147483648;\n\tand.b32 \t%r235, %r1733, 8388607;\n\tsetp.ne.b32 \t%p52, %r235, 0;\n\tand.b32 \t%r236, %r1733, 2139095040;\n\tsetp.eq.b32 \t%p53, %r236, 0;\n\tselp.f32 \t%r237, %r234, %r1733, %p52;\n\tselp.f32 \t%r1734, %r237, %r1733, %p53;\n$L__BB0_10:\n\tor.b64 \t%rd13, %rd10, 2;\n\tsetp.ge.s64 \t%p54, %rd14, %rd5;\n\tst.global.b32 \t[%rd17], %r1734;\n\t@%p54 bra \t$L__BB0_18;\n\tld.global.b32 \t%r238, [%rd11+4];\n\tand.b32 \t%r239, %r238, -2147483648;\n\tand.b32 \t%r240, %r238, 8388607;\n\tsetp.ne.b32 \t%p55, %r240, 0;\n\tand.b32 \t%r241, %r238, 2139095040;\n\tsetp.eq.b32 \t%p56, %r241, 0;\n\tselp.f32 \t%r242, %r239, %r238, %p55;\n\tselp.f32 \t%r243, %r242, %r238, %p56;\n\tadd.f32 \t%r244, %r1, %r243;\n\tand.b32 \t%r245, %r244, -2147483648;\n\tand.b32 \t%r246, %r244, 8388607;\n\tsetp.ne.b32 \t%p57, %r246, 0;\n\tand.b32 \t%r247, %r244, 2139095040;\n\tsetp.eq.b32 \t%p58, %r247, 0;\n\tselp.f32 \t%r248, %r245, %r244, %p57;\n\tselp.f32 \t%r249, %r248, %r244, %p58;\n\tfma.rn.f32 \t%r250, %r1700, 0fC0000000, %r249;\n\tand.b32 \t%r251, %r250, -2147483648;\n\tand.b32 \t%r252, %r250, 8388607;\n\tsetp.ne.b32 \t%p59, %r252, 0;\n\tand.b32 \t%r253, %r250, 2139095040;\n\tsetp.eq.b32 \t%p60, %r253, 0;\n\tselp.f32 \t%r254, %r251, %r250, %p59;\n\tselp.f32 \t%r255, %r254, %r250, %p60;\n\tsetp.le.f32 \t%p61, %r255, 0f00000000;\n\tselp.f32 \t%r1738, 0f00000000, %r255, %p61;\n\t@%p30 bra \t$L__BB0_17;\n\tabs.f32 \t%r256, %r1738;\n\tsetp.eq.f32 \t%p63, %r1738, 0f7F800000;\n\tsetp.lt.f32 \t%p64, %r256, 0f00800000;\n\tsetp.num.f32 \t%p65, %r1738, %r1738;\n\tsetp.ltu.f32 \t%p66, %r1738, 0f00000000;\n\tor.pred \t%p67, %p66, %p64;\n\tselp.f32 \t%r258, 0f00000000, 0f7FC00000, %p64;\n\tor.pred \t%p68, %p63, %p67;\n\tselp.f32 \t%r259, %r258, %r1738, %p67;\n\tselp.f32 \t%r1737, %r259, %r1738, %p65;\n\t@%p68 bra \t$L__BB0_16;\n\tmul.f32 \t%r257, %r1738, 0f5F800000;\n\tsetp.lt.f32 \t%p62, %r1738, 0f0F800000;\n\tselp.f32 \t%r4, %r257, %r1738, %p62;\n\tshr.u32 \t%r260, %r4, 1;\n\tadd.s32 \t%r261, %r260, 532487669;\n\tdiv.rn.f32 \t%r262, %r4, %r261;\n\tadd.f32 \t%r263, %r262, %r261;\n\tmul.f32 \t%r264, %r263, 0f3F000000;\n\tdiv.rn.f32 \t%r265, %r4, %r264;\n\tfma.rn.f32 \t%r266, %r263, 0f3F000000, %r265;\n\tmul.f32 \t%r267, %r266, 0f3F000000;\n\tdiv.rn.f32 \t%r268, %r4, %r267;\n\tfma.rn.f32 \t%r269, %r266, 0f3F000000, %r268;\n\tmul.f32 \t%r5, %r269, 0f3F000000;\n\tneg.f32 \t%r270, %r5;\n\tfma.rn.f32 \t%r271, %r270, %r5, %r4;\n\tabs.f32 \t%r1735, %r271;\n\tmov.b64 \t%rd137, 0;\n\tmov.b32 \t%r1736, %r5;\n$L__BB0_14:\n\tsetp.eq.b64 \t%p69, %rd137, 2;\n\tselp.b32 \t%r272, -2, 2, %p69;\n\tsetp.eq.b64 \t%p70, %rd137, 1;\n\tsetp.eq.b64 \t%p71, %rd137, 0;\n\tselp.b32 \t%r273, 1, %r272, %p70;\n\tselp.b32 \t%r274, -1, %r273, %p71;\n\tadd.s32 \t%r275, %r274, %r5;\n\tneg.f32 \t%r276, %r275;\n\tfma.rn.f32 \t%r277, %r276, %r275, %r4;\n\tabs.f32 \t%r278, %r277;\n\tsetp.lt.f32 \t%p72, %r278, %r1735;\n\tselp.f32 \t%r1736, %r275, %r1736, %p72;\n\tselp.f32 \t%r1735, %r278, %r1735, %p72;\n\tadd.s64 \t%rd137, %rd137, 1;\n\tsetp.ne.b64 \t%p73, %rd137, 4;\n\t@%p73 bra \t$L__BB0_14;\n\tmul.f32 \t%r279, %r1736, 0f2F800000;\n\tselp.f32 \t%r1737, %r279, %r1736, %p62;\n$L__BB0_16:\n\tand.b32 \t%r280, %r1737, -2147483648;\n\tand.b32 \t%r281, %r1737, 8388607;\n\tsetp.ne.b32 \t%p74, %r281, 0;\n\tand.b32 \t%r282, %r1737, 2139095040;\n\tsetp.eq.b32 \t%p75, %r282, 0;\n\tselp.f32 \t%r283, %r280, %r1737, %p74;\n\tselp.f32 \t%r1738, %r283, %r1737, %p75;\n$L__BB0_17:\n\tst.global.b32 \t[%rd17+4], %r1738;\n$L__BB0_18:\n\tor.b64 \t%rd12, %rd10, 3;\n\tsetp.ge.s64 \t%p76, %rd13, %rd5;\n\t@%p76 bra \t$L__BB0_26;\n\tld.global.b32 \t%r284, [%rd11+8];\n\tand.b32 \t%r285, %r284, -2147483648;\n\tand.b32 \t%r286, %r284, 8388607;\n\tsetp.ne.b32 \t%p77, %r286, 0;\n\tand.b32 \t%r287, %r284, 2139095040;\n\tsetp.eq.b32 \t%p78, %r287, 0;\n\tselp.f32 \t%r288, %r285, %r284, %p77;\n\tselp.f32 \t%r289, %r288, %r284, %p78;\n\tadd.f32 \t%r290, %r1, %r289;\n\tand.b32 \t%r291, %r290, -2147483648;\n\tand.b32 \t%r292, %r290, 8388607;\n\tsetp.ne.b32 \t%p79, %r292, 0;\n\tand.b32 \t%r293, %r290, 2139095040;\n\tsetp.eq.b32 \t%p80, %r293, 0;\n\tselp.f32 \t%r294, %r291, %r290, %p79;\n\tselp.f32 \t%r295, %r294, %r290, %p80;\n\tfma.rn.f32 \t%r296, %r1701, 0fC0000000, %r295;\n\tand.b32 \t%r297, %r296, -2147483648;\n\tand.b32 \t%r298, %r296, 8388607;\n\tsetp.ne.b32 \t%p81, %r298, 0;\n\tand.b32 \t%r299, %r296, 2139095040;\n\tsetp.eq.b32 \t%p82, %r299, 0;\n\tselp.f32 \t%r300, %r297, %r296, %p81;\n\tselp.f32 \t%r301, %r300, %r296, %p82;\n\tsetp.le.f32 \t%p83, %r301, 0f00000000;\n\tselp.f32 \t%r1742, 0f00000000, %r301, %p83;\n\t@%p30 bra \t$L__BB0_25;\n\tabs.f32 \t%r302, %r1742;\n\tsetp.eq.f32 \t%p85, %r1742, 0f7F800000;\n\tsetp.lt.f32 \t%p86, %r302, 0f00800000;\n\tsetp.num.f32 \t%p87, %r1742, %r1742;\n\tsetp.ltu.f32 \t%p88, %r1742, 0f00000000;\n\tor.pred \t%p89, %p88, %p86;\n\tselp.f32 \t%r304, 0f00000000, 0f7FC00000, %p86;\n\tor.pred \t%p90, %p85, %p89;\n\tselp.f32 \t%r305, %r304, %r1742, %p89;\n\tselp.f32 \t%r1741, %r305, %r1742, %p87;\n\t@%p90 bra \t$L__BB0_24;\n\tmul.f32 \t%r303, %r1742, 0f5F800000;\n\tsetp.lt.f32 \t%p84, %r1742, 0f0F800000;\n\tselp.f32 \t%r6, %r303, %r1742, %p84;\n\tshr.u32 \t%r306, %r6, 1;\n\tadd.s32 \t%r307, %r306, 532487669;\n\tdiv.rn.f32 \t%r308, %r6, %r307;\n\tadd.f32 \t%r309, %r308, %r307;\n\tmul.f32 \t%r310, %r309, 0f3F000000;\n\tdiv.rn.f32 \t%r311, %r6, %r310;\n\tfma.rn.f32 \t%r312, %r309, 0f3F000000, %r311;\n\tmul.f32 \t%r313, %r312, 0f3F000000;\n\tdiv.rn.f32 \t%r314, %r6, %r313;\n\tfma.rn.f32 \t%r315, %r312, 0f3F000000, %r314;\n\tmul.f32 \t%r7, %r315, 0f3F000000;\n\tneg.f32 \t%r316, %r7;\n\tfma.rn.f32 \t%r317, %r316, %r7, %r6;\n\tabs.f32 \t%r1739, %r317;\n\tmov.b64 \t%rd138, 0;\n\tmov.b32 \t%r1740, %r7;\n$L__BB0_22:\n\tsetp.eq.b64 \t%p91, %rd138, 2;\n\tselp.b32 \t%r318, -2, 2, %p91;\n\tsetp.eq.b64 \t%p92, %rd138, 1;\n\tsetp.eq.b64 \t%p93, %rd138, 0;\n\tselp.b32 \t%r319, 1, %r318, %p92;\n\tselp.b32 \t%r320, -1, %r319, %p93;\n\tadd.s32 \t%r321, %r320, %r7;\n\tneg.f32 \t%r322, %r321;\n\tfma.rn.f32 \t%r323, %r322, %r321, %r6;\n\tabs.f32 \t%r324, %r323;\n\tsetp.lt.f32 \t%p94, %r324, %r1739;\n\tselp.f32 \t%r1740, %r321, %r1740, %p94;\n\tselp.f32 \t%r1739, %r324, %r1739, %p94;\n\tadd.s64 \t%rd138, %rd138, 1;\n\tsetp.ne.b64 \t%p95, %rd138, 4;\n\t@%p95 bra \t$L__BB0_22;\n\tmul.f32 \t%r325, %r1740, 0f2F800000;\n\tselp.f32 \t%r1741, %r325, %r1740, %p84;\n$L__BB0_24:\n\tand.b32 \t%r326, %r1741, -2147483648;\n\tand.b32 \t%r327, %r1741, 8388607;\n\tsetp.ne.b32 \t%p96, %r327, 0;\n\tand.b32 \t%r328, %r1741, 2139095040;\n\tsetp.eq.b32 \t%p97, %r328, 0;\n\tselp.f32 \t%r329, %r326, %r1741, %p96;\n\tselp.f32 \t%r1742, %r329, %r1741, %p97;\n$L__BB0_25:\n\tst.global.b32 \t[%rd17+8], %r1742;\n$L__BB0_26:\n\tor.b64 \t%rd31, %rd16, 1;\n\tsetp.ge.s64 \t%p98, %rd12, %rd5;\n\t@%p98 bra \t$L__BB0_34;\n\tld.global.b32 \t%r330, [%rd11+12];\n\tand.b32 \t%r331, %r330, -2147483648;\n\tand.b32 \t%r332, %r330, 8388607;\n\tsetp.ne.b32 \t%p99, %r332, 0;\n\tand.b32 \t%r333, %r330, 2139095040;\n\tsetp.eq.b32 \t%p100, %r333, 0;\n\tselp.f32 \t%r334, %r331, %r330, %p99;\n\tselp.f32 \t%r335, %r334, %r330, %p100;\n\tadd.f32 \t%r336, %r1, %r335;\n\tand.b32 \t%r337, %r336, -2147483648;\n\tand.b32 \t%r338, %r336, 8388607;\n\tsetp.ne.b32 \t%p101, %r338, 0;\n\tand.b32 \t%r339, %r336, 2139095040;\n\tsetp.eq.b32 \t%p102, %r339, 0;\n\tselp.f32 \t%r340, %r337, %r336, %p101;\n\tselp.f32 \t%r341, %r340, %r336, %p102;\n\tfma.rn.f32 \t%r342, %r1702, 0fC0000000, %r341;\n\tand.b32 \t%r343, %r342, -2147483648;\n\tand.b32 \t%r344, %r342, 8388607;\n\tsetp.ne.b32 \t%p103, %r344, 0;\n\tand.b32 \t%r345, %r342, 2139095040;\n\tsetp.eq.b32 \t%p104, %r345, 0;\n\tselp.f32 \t%r346, %r343, %r342, %p103;\n\tselp.f32 \t%r347, %r346, %r342, %p104;\n\tsetp.le.f32 \t%p105, %r347, 0f00000000;\n\tselp.f32 \t%r1746, 0f00000000, %r347, %p105;\n\t@%p30 bra \t$L__BB0_33;\n\tabs.f32 \t%r348, %r1746;\n\tsetp.eq.f32 \t%p107, %r1746, 0f7F800000;\n\tsetp.lt.f32 \t%p108, %r348, 0f00800000;\n\tsetp.num.f32 \t%p109, %r1746, %r1746;\n\tsetp.ltu.f32 \t%p110, %r1746, 0f00000000;\n\tor.pred \t%p111, %p110, %p108;\n\tselp.f32 \t%r350, 0f00000000, 0f7FC00000, %p108;\n\tor.pred \t%p112, %p107, %p111;\n\tselp.f32 \t%r351, %r350, %r1746, %p111;\n\tselp.f32 \t%r1745, %r351, %r1746, %p109;\n\t@%p112 bra \t$L__BB0_32;\n\tmul.f32 \t%r349, %r1746, 0f5F800000;\n\tsetp.lt.f32 \t%p106, %r1746, 0f0F800000;\n\tselp.f32 \t%r8, %r349, %r1746, %p106;\n\tshr.u32 \t%r352, %r8, 1;\n\tadd.s32 \t%r353, %r352, 532487669;\n\tdiv.rn.f32 \t%r354, %r8, %r353;\n\tadd.f32 \t%r355, %r354, %r353;\n\tmul.f32 \t%r356, %r355, 0f3F000000;\n\tdiv.rn.f32 \t%r357, %r8, %r356;\n\tfma.rn.f32 \t%r358, %r355, 0f3F000000, %r357;\n\tmul.f32 \t%r359, %r358, 0f3F000000;\n\tdiv.rn.f32 \t%r360, %r8, %r359;\n\tfma.rn.f32 \t%r361, %r358, 0f3F000000, %r360;\n\tmul.f32 \t%r9, %r361, 0f3F000000;\n\tneg.f32 \t%r362, %r9;\n\tfma.rn.f32 \t%r363, %r362, %r9, %r8;\n\tabs.f32 \t%r1743, %r363;\n\tmov.b64 \t%rd139, 0;\n\tmov.b32 \t%r1744, %r9;\n$L__BB0_30:\n\tsetp.eq.b64 \t%p113, %rd139, 2;\n\tselp.b32 \t%r364, -2, 2, %p113;\n\tsetp.eq.b64 \t%p114, %rd139, 1;\n\tsetp.eq.b64 \t%p115, %rd139, 0;\n\tselp.b32 \t%r365, 1, %r364, %p114;\n\tselp.b32 \t%r366, -1, %r365, %p115;\n\tadd.s32 \t%r367, %r366, %r9;\n\tneg.f32 \t%r368, %r367;\n\tfma.rn.f32 \t%r369, %r368, %r367, %r8;\n\tabs.f32 \t%r370, %r369;\n\tsetp.lt.f32 \t%p116, %r370, %r1743;\n\tselp.f32 \t%r1744, %r367, %r1744, %p116;\n\tselp.f32 \t%r1743, %r370, %r1743, %p116;\n\tadd.s64 \t%rd139, %rd139, 1;\n\tsetp.ne.b64 \t%p117, %rd139, 4;\n\t@%p117 bra \t$L__BB0_30;\n\tmul.f32 \t%r371, %r1744, 0f2F800000;\n\tselp.f32 \t%r1745, %r371, %r1744, %p106;\n$L__BB0_32:\n\tand.b32 \t%r372, %r1745, -2147483648;\n\tand.b32 \t%r373, %r1745, 8388607;\n\tsetp.ne.b32 \t%p118, %r373, 0;\n\tand.b32 \t%r374, %r1745, 2139095040;\n\tsetp.eq.b32 \t%p119, %r374, 0;\n\tselp.f32 \t%r375, %r372, %r1745, %p118;\n\tselp.f32 \t%r1746, %r375, %r1745, %p119;\n$L__BB0_33:\n\tst.global.b32 \t[%rd17+12], %r1746;\n$L__BB0_34:\n\tor.b64 \t%rd29, %rd16, 2;\n\tsetp.ge.s64 \t%p120, %rd31, %rd3;\n\t@%p120 bra \t$L__BB0_65;\n\tmul.wide.s32 \t%rd67, %r76, 4;\n\tadd.s64 \t%rd32, %rd17, %rd67;\n\tld.global.b32 \t%r376, [%rd18+4];\n\tand.b32 \t%r377, %r376, -2147483648;\n\tand.b32 \t%r378, %r376, 8388607;\n\tsetp.ne.b32 \t%p121, %r378, 0;\n\tand.b32 \t%r379, %r376, 2139095040;\n\tsetp.eq.b32 \t%p122, %r379, 0;\n\tselp.f32 \t%r380, %r377, %r376, %p121;\n\tselp.f32 \t%r10, %r380, %r376, %p122;\n\tld.global.b32 \t%r381, [%rd11];\n\tand.b32 \t%r382, %r381, -2147483648;\n\tand.b32 \t%r383, %r381, 8388607;\n\tsetp.ne.b32 \t%p123, %r383, 0;\n\tand.b32 \t%r384, %r381, 2139095040;\n\tsetp.eq.b32 \t%p124, %r384, 0;\n\tselp.f32 \t%r385, %r382, %r381, %p123;\n\tselp.f32 \t%r386, %r385, %r381, %p124;\n\tadd.f32 \t%r387, %r10, %r386;\n\tand.b32 \t%r388, %r387, -2147483648;\n\tand.b32 \t%r389, %r387, 8388607;\n\tsetp.ne.b32 \t%p125, %r389, 0;\n\tand.b32 \t%r390, %r387, 2139095040;\n\tsetp.eq.b32 \t%p126, %r390, 0;\n\tselp.f32 \t%r391, %r388, %r387, %p125;\n\tselp.f32 \t%r392, %r391, %r387, %p126;\n\tfma.rn.f32 \t%r393, %r1703, 0fC0000000, %r392;\n\tand.b32 \t%r394, %r393, -2147483648;\n\tand.b32 \t%r395, %r393, 8388607;\n\tsetp.ne.b32 \t%p127, %r395, 0;\n\tand.b32 \t%r396, %r393, 2139095040;\n\tsetp.eq.b32 \t%p128, %r396, 0;\n\tselp.f32 \t%r397, %r394, %r393, %p127;\n\tselp.f32 \t%r398, %r397, %r393, %p128;\n\tsetp.le.f32 \t%p129, %r398, 0f00000000;\n\tselp.f32 \t%r1750, 0f00000000, %r398, %p129;\n\t@%p30 bra \t$L__BB0_41;\n\tabs.f32 \t%r399, %r1750;\n\tsetp.eq.f32 \t%p131, %r1750, 0f7F800000;\n\tsetp.lt.f32 \t%p132, %r399, 0f00800000;\n\tsetp.num.f32 \t%p133, %r1750, %r1750;\n\tsetp.ltu.f32 \t%p134, %r1750, 0f00000000;\n\tor.pred \t%p135, %p134, %p132;\n\tselp.f32 \t%r401, 0f00000000, 0f7FC00000, %p132;\n\tor.pred \t%p136, %p131, %p135;\n\tselp.f32 \t%r402, %r401, %r1750, %p135;\n\tselp.f32 \t%r1749, %r402, %r1750, %p133;\n\t@%p136 bra \t$L__BB0_40;\n\tmul.f32 \t%r400, %r1750, 0f5F800000;\n\tsetp.lt.f32 \t%p130, %r1750, 0f0F800000;\n\tselp.f32 \t%r11, %r400, %r1750, %p130;\n\tshr.u32 \t%r403, %r11, 1;\n\tadd.s32 \t%r404, %r403, 532487669;\n\tdiv.rn.f32 \t%r405, %r11, %r404;\n\tadd.f32 \t%r406, %r405, %r404;\n\tmul.f32 \t%r407, %r406, 0f3F000000;\n\tdiv.rn.f32 \t%r408, %r11, %r407;\n\tfma.rn.f32 \t%r409, %r406, 0f3F000000, %r408;\n\tmul.f32 \t%r410, %r409, 0f3F000000;\n\tdiv.rn.f32 \t%r411, %r11, %r410;\n\tfma.rn.f32 \t%r412, %r409, 0f3F000000, %r411;\n\tmul.f32 \t%r12, %r412, 0f3F000000;\n\tneg.f32 \t%r413, %r12;\n\tfma.rn.f32 \t%r414, %r413, %r12, %r11;\n\tabs.f32 \t%r1747, %r414;\n\tmov.b64 \t%rd140, 0;\n\tmov.b32 \t%r1748, %r12;\n$L__BB0_38:\n\tsetp.eq.b64 \t%p137, %rd140, 2;\n\tselp.b32 \t%r415, -2, 2, %p137;\n\tsetp.eq.b64 \t%p138, %rd140, 1;\n\tsetp.eq.b64 \t%p139, %rd140, 0;\n\tselp.b32 \t%r416, 1, %r415, %p138;\n\tselp.b32 \t%r417, -1, %r416, %p139;\n\tadd.s32 \t%r418, %r417, %r12;\n\tneg.f32 \t%r419, %r418;\n\tfma.rn.f32 \t%r420, %r419, %r418, %r11;\n\tabs.f32 \t%r421, %r420;\n\tsetp.lt.f32 \t%p140, %r421, %r1747;\n\tselp.f32 \t%r1748, %r418, %r1748, %p140;\n\tselp.f32 \t%r1747, %r421, %r1747, %p140;\n\tadd.s64 \t%rd140, %rd140, 1;\n\tsetp.ne.b64 \t%p141, %rd140, 4;\n\t@%p141 bra \t$L__BB0_38;\n\tmul.f32 \t%r422, %r1748, 0f2F800000;\n\tselp.f32 \t%r1749, %r422, %r1748, %p130;\n$L__BB0_40:\n\tand.b32 \t%r423, %r1749, -2147483648;\n\tand.b32 \t%r424, %r1749, 8388607;\n\tsetp.ne.b32 \t%p142, %r424, 0;\n\tand.b32 \t%r425, %r1749, 2139095040;\n\tsetp.eq.b32 \t%p143, %r425, 0;\n\tselp.f32 \t%r426, %r423, %r1749, %p142;\n\tselp.f32 \t%r1750, %r426, %r1749, %p143;\n$L__BB0_41:\n\tst.global.b32 \t[%rd32], %r1750;\n\t@%p54 bra \t$L__BB0_49;\n\tld.global.b32 \t%r427, [%rd11+4];\n\tand.b32 \t%r428, %r427, -2147483648;\n\tand.b32 \t%r429, %r427, 8388607;\n\tsetp.ne.b32 \t%p144, %r429, 0;\n\tand.b32 \t%r430, %r427, 2139095040;\n\tsetp.eq.b32 \t%p145, %r430, 0;\n\tselp.f32 \t%r431, %r428, %r427, %p144;\n\tselp.f32 \t%r432, %r431, %r427, %p145;\n\tadd.f32 \t%r433, %r10, %r432;\n\tand.b32 \t%r434, %r433, -2147483648;\n\tand.b32 \t%r435, %r433, 8388607;\n\tsetp.ne.b32 \t%p146, %r435, 0;\n\tand.b32 \t%r436, %r433, 2139095040;\n\tsetp.eq.b32 \t%p147, %r436, 0;\n\tselp.f32 \t%r437, %r434, %r433, %p146;\n\tselp.f32 \t%r438, %r437, %r433, %p147;\n\tfma.rn.f32 \t%r439, %r1704, 0fC0000000, %r438;\n\tand.b32 \t%r440, %r439, -2147483648;\n\tand.b32 \t%r441, %r439, 8388607;\n\tsetp.ne.b32 \t%p148, %r441, 0;\n\tand.b32 \t%r442, %r439, 2139095040;\n\tsetp.eq.b32 \t%p149, %r442, 0;\n\tselp.f32 \t%r443, %r440, %r439, %p148;\n\tselp.f32 \t%r444, %r443, %r439, %p149;\n\tsetp.le.f32 \t%p150, %r444, 0f00000000;\n\tselp.f32 \t%r1754, 0f00000000, %r444, %p150;\n\t@%p30 bra \t$L__BB0_48;\n\tabs.f32 \t%r445, %r1754;\n\tsetp.eq.f32 \t%p152, %r1754, 0f7F800000;\n\tsetp.lt.f32 \t%p153, %r445, 0f00800000;\n\tsetp.num.f32 \t%p154, %r1754, %r1754;\n\tsetp.ltu.f32 \t%p155, %r1754, 0f00000000;\n\tor.pred \t%p156, %p155, %p153;\n\tselp.f32 \t%r447, 0f00000000, 0f7FC00000, %p153;\n\tor.pred \t%p157, %p152, %p156;\n\tselp.f32 \t%r448, %r447, %r1754, %p156;\n\tselp.f32 \t%r1753, %r448, %r1754, %p154;\n\t@%p157 bra \t$L__BB0_47;\n\tmul.f32 \t%r446, %r1754, 0f5F800000;\n\tsetp.lt.f32 \t%p151, %r1754, 0f0F800000;\n\tselp.f32 \t%r13, %r446, %r1754, %p151;\n\tshr.u32 \t%r449, %r13, 1;\n\tadd.s32 \t%r450, %r449, 532487669;\n\tdiv.rn.f32 \t%r451, %r13, %r450;\n\tadd.f32 \t%r452, %r451, %r450;\n\tmul.f32 \t%r453, %r452, 0f3F000000;\n\tdiv.rn.f32 \t%r454, %r13, %r453;\n\tfma.rn.f32 \t%r455, %r452, 0f3F000000, %r454;\n\tmul.f32 \t%r456, %r455, 0f3F000000;\n\tdiv.rn.f32 \t%r457, %r13, %r456;\n\tfma.rn.f32 \t%r458, %r455, 0f3F000000, %r457;\n\tmul.f32 \t%r14, %r458, 0f3F000000;\n\tneg.f32 \t%r459, %r14;\n\tfma.rn.f32 \t%r460, %r459, %r14, %r13;\n\tabs.f32 \t%r1751, %r460;\n\tmov.b64 \t%rd141, 0;\n\tmov.b32 \t%r1752, %r14;\n$L__BB0_45:\n\tsetp.eq.b64 \t%p158, %rd141, 2;\n\tselp.b32 \t%r461, -2, 2, %p158;\n\tsetp.eq.b64 \t%p159, %rd141, 1;\n\tsetp.eq.b64 \t%p160, %rd141, 0;\n\tselp.b32 \t%r462, 1, %r461, %p159;\n\tselp.b32 \t%r463, -1, %r462, %p160;\n\tadd.s32 \t%r464, %r463, %r14;\n\tneg.f32 \t%r465, %r464;\n\tfma.rn.f32 \t%r466, %r465, %r464, %r13;\n\tabs.f32 \t%r467, %r466;\n\tsetp.lt.f32 \t%p161, %r467, %r1751;\n\tselp.f32 \t%r1752, %r464, %r1752, %p161;\n\tselp.f32 \t%r1751, %r467, %r1751, %p161;\n\tadd.s64 \t%rd141, %rd141, 1;\n\tsetp.ne.b64 \t%p162, %rd141, 4;\n\t@%p162 bra \t$L__BB0_45;\n\tmul.f32 \t%r468, %r1752, 0f2F800000;\n\tselp.f32 \t%r1753, %r468, %r1752, %p151;\n$L__BB0_47:\n\tand.b32 \t%r469, %r1753, -2147483648;\n\tand.b32 \t%r470, %r1753, 8388607;\n\tsetp.ne.b32 \t%p163, %r470, 0;\n\tand.b32 \t%r471, %r1753, 2139095040;\n\tsetp.eq.b32 \t%p164, %r471, 0;\n\tselp.f32 \t%r472, %r469, %r1753, %p163;\n\tselp.f32 \t%r1754, %r472, %r1753, %p164;\n$L__BB0_48:\n\tst.global.b32 \t[%rd32+4], %r1754;\n$L__BB0_49:\n\t@%p76 bra \t$L__BB0_57;\n\tld.global.b32 \t%r473, [%rd11+8];\n\tand.b32 \t%r474, %r473, -2147483648;\n\tand.b32 \t%r475, %r473, 8388607;\n\tsetp.ne.b32 \t%p165, %r475, 0;\n\tand.b32 \t%r476, %r473, 2139095040;\n\tsetp.eq.b32 \t%p166, %r476, 0;\n\tselp.f32 \t%r477, %r474, %r473, %p165;\n\tselp.f32 \t%r478, %r477, %r473, %p166;\n\tadd.f32 \t%r479, %r10, %r478;\n\tand.b32 \t%r480, %r479, -2147483648;\n\tand.b32 \t%r481, %r479, 8388607;\n\tsetp.ne.b32 \t%p167, %r481, 0;\n\tand.b32 \t%r482, %r479, 2139095040;\n\tsetp.eq.b32 \t%p168, %r482, 0;\n\tselp.f32 \t%r483, %r480, %r479, %p167;\n\tselp.f32 \t%r484, %r483, %r479, %p168;\n\tfma.rn.f32 \t%r485, %r1705, 0fC0000000, %r484;\n\tand.b32 \t%r486, %r485, -2147483648;\n\tand.b32 \t%r487, %r485, 8388607;\n\tsetp.ne.b32 \t%p169, %r487, 0;\n\tand.b32 \t%r488, %r485, 2139095040;\n\tsetp.eq.b32 \t%p170, %r488, 0;\n\tselp.f32 \t%r489, %r486, %r485, %p169;\n\tselp.f32 \t%r490, %r489, %r485, %p170;\n\tsetp.le.f32 \t%p171, %r490, 0f00000000;\n\tselp.f32 \t%r1758, 0f00000000, %r490, %p171;\n\t@%p30 bra \t$L__BB0_56;\n\tabs.f32 \t%r491, %r1758;\n\tsetp.eq.f32 \t%p173, %r1758, 0f7F800000;\n\tsetp.lt.f32 \t%p174, %r491, 0f00800000;\n\tsetp.num.f32 \t%p175, %r1758, %r1758;\n\tsetp.ltu.f32 \t%p176, %r1758, 0f00000000;\n\tor.pred \t%p177, %p176, %p174;\n\tselp.f32 \t%r493, 0f00000000, 0f7FC00000, %p174;\n\tor.pred \t%p178, %p173, %p177;\n\tselp.f32 \t%r494, %r493, %r1758, %p177;\n\tselp.f32 \t%r1757, %r494, %r1758, %p175;\n\t@%p178 bra \t$L__BB0_55;\n\tmul.f32 \t%r492, %r1758, 0f5F800000;\n\tsetp.lt.f32 \t%p172, %r1758, 0f0F800000;\n\tselp.f32 \t%r15, %r492, %r1758, %p172;\n\tshr.u32 \t%r495, %r15, 1;\n\tadd.s32 \t%r496, %r495, 532487669;\n\tdiv.rn.f32 \t%r497, %r15, %r496;\n\tadd.f32 \t%r498, %r497, %r496;\n\tmul.f32 \t%r499, %r498, 0f3F000000;\n\tdiv.rn.f32 \t%r500, %r15, %r499;\n\tfma.rn.f32 \t%r501, %r498, 0f3F000000, %r500;\n\tmul.f32 \t%r502, %r501, 0f3F000000;\n\tdiv.rn.f32 \t%r503, %r15, %r502;\n\tfma.rn.f32 \t%r504, %r501, 0f3F000000, %r503;\n\tmul.f32 \t%r16, %r504, 0f3F000000;\n\tneg.f32 \t%r505, %r16;\n\tfma.rn.f32 \t%r506, %r505, %r16, %r15;\n\tabs.f32 \t%r1755, %r506;\n\tmov.b64 \t%rd142, 0;\n\tmov.b32 \t%r1756, %r16;\n$L__BB0_53:\n\tsetp.eq.b64 \t%p179, %rd142, 2;\n\tselp.b32 \t%r507, -2, 2, %p179;\n\tsetp.eq.b64 \t%p180, %rd142, 1;\n\tsetp.eq.b64 \t%p181, %rd142, 0;\n\tselp.b32 \t%r508, 1, %r507, %p180;\n\tselp.b32 \t%r509, -1, %r508, %p181;\n\tadd.s32 \t%r510, %r509, %r16;\n\tneg.f32 \t%r511, %r510;\n\tfma.rn.f32 \t%r512, %r511, %r510, %r15;\n\tabs.f32 \t%r513, %r512;\n\tsetp.lt.f32 \t%p182, %r513, %r1755;\n\tselp.f32 \t%r1756, %r510, %r1756, %p182;\n\tselp.f32 \t%r1755, %r513, %r1755, %p182;\n\tadd.s64 \t%rd142, %rd142, 1;\n\tsetp.ne.b64 \t%p183, %rd142, 4;\n\t@%p183 bra \t$L__BB0_53;\n\tmul.f32 \t%r514, %r1756, 0f2F800000;\n\tselp.f32 \t%r1757, %r514, %r1756, %p172;\n$L__BB0_55:\n\tand.b32 \t%r515, %r1757, -2147483648;\n\tand.b32 \t%r516, %r1757, 8388607;\n\tsetp.ne.b32 \t%p184, %r516, 0;\n\tand.b32 \t%r517, %r1757, 2139095040;\n\tsetp.eq.b32 \t%p185, %r517, 0;\n\tselp.f32 \t%r518, %r515, %r1757, %p184;\n\tselp.f32 \t%r1758, %r518, %r1757, %p185;\n$L__BB0_56:\n\tst.global.b32 \t[%rd32+8], %r1758;\n$L__BB0_57:\n\t@%p98 bra \t$L__BB0_65;\n\tld.global.b32 \t%r519, [%rd11+12];\n\tand.b32 \t%r520, %r519, -2147483648;\n\tand.b32 \t%r521, %r519, 8388607;\n\tsetp.ne.b32 \t%p186, %r521, 0;\n\tand.b32 \t%r522, %r519, 2139095040;\n\tsetp.eq.b32 \t%p187, %r522, 0;\n\tselp.f32 \t%r523, %r520, %r519, %p186;\n\tselp.f32 \t%r524, %r523, %r519, %p187;\n\tadd.f32 \t%r525, %r10, %r524;\n\tand.b32 \t%r526, %r525, -2147483648;\n\tand.b32 \t%r527, %r525, 8388607;\n\tsetp.ne.b32 \t%p188, %r527, 0;\n\tand.b32 \t%r528, %r525, 2139095040;\n\tsetp.eq.b32 \t%p189, %r528, 0;\n\tselp.f32 \t%r529, %r526, %r525, %p188;\n\tselp.f32 \t%r530, %r529, %r525, %p189;\n\tfma.rn.f32 \t%r531, %r1706, 0fC0000000, %r530;\n\tand.b32 \t%r532, %r531, -2147483648;\n\tand.b32 \t%r533, %r531, 8388607;\n\tsetp.ne.b32 \t%p190, %r533, 0;\n\tand.b32 \t%r534, %r531, 2139095040;\n\tsetp.eq.b32 \t%p191, %r534, 0;\n\tselp.f32 \t%r535, %r532, %r531, %p190;\n\tselp.f32 \t%r536, %r535, %r531, %p191;\n\tsetp.le.f32 \t%p192, %r536, 0f00000000;\n\tselp.f32 \t%r1762, 0f00000000, %r536, %p192;\n\t@%p30 bra \t$L__BB0_64;\n\tabs.f32 \t%r537, %r1762;\n\tsetp.eq.f32 \t%p194, %r1762, 0f7F800000;\n\tsetp.lt.f32 \t%p195, %r537, 0f00800000;\n\tsetp.num.f32 \t%p196, %r1762, %r1762;\n\tsetp.ltu.f32 \t%p197, %r1762, 0f00000000;\n\tor.pred \t%p198, %p197, %p195;\n\tselp.f32 \t%r539, 0f00000000, 0f7FC00000, %p195;\n\tor.pred \t%p199, %p194, %p198;\n\tselp.f32 \t%r540, %r539, %r1762, %p198;\n\tselp.f32 \t%r1761, %r540, %r1762, %p196;\n\t@%p199 bra \t$L__BB0_63;\n\tmul.f32 \t%r538, %r1762, 0f5F800000;\n\tsetp.lt.f32 \t%p193, %r1762, 0f0F800000;\n\tselp.f32 \t%r17, %r538, %r1762, %p193;\n\tshr.u32 \t%r541, %r17, 1;\n\tadd.s32 \t%r542, %r541, 532487669;\n\tdiv.rn.f32 \t%r543, %r17, %r542;\n\tadd.f32 \t%r544, %r543, %r542;\n\tmul.f32 \t%r545, %r544, 0f3F000000;\n\tdiv.rn.f32 \t%r546, %r17, %r545;\n\tfma.rn.f32 \t%r547, %r544, 0f3F000000, %r546;\n\tmul.f32 \t%r548, %r547, 0f3F000000;\n\tdiv.rn.f32 \t%r549, %r17, %r548;\n\tfma.rn.f32 \t%r550, %r547, 0f3F000000, %r549;\n\tmul.f32 \t%r18, %r550, 0f3F000000;\n\tneg.f32 \t%r551, %r18;\n\tfma.rn.f32 \t%r552, %r551, %r18, %r17;\n\tabs.f32 \t%r1759, %r552;\n\tmov.b64 \t%rd143, 0;\n\tmov.b32 \t%r1760, %r18;\n$L__BB0_61:\n\tsetp.eq.b64 \t%p200, %rd143, 2;\n\tselp.b32 \t%r553, -2, 2, %p200;\n\tsetp.eq.b64 \t%p201, %rd143, 1;\n\tsetp.eq.b64 \t%p202, %rd143, 0;\n\tselp.b32 \t%r554, 1, %r553, %p201;\n\tselp.b32 \t%r555, -1, %r554, %p202;\n\tadd.s32 \t%r556, %r555, %r18;\n\tneg.f32 \t%r557, %r556;\n\tfma.rn.f32 \t%r558, %r557, %r556, %r17;\n\tabs.f32 \t%r559, %r558;\n\tsetp.lt.f32 \t%p203, %r559, %r1759;\n\tselp.f32 \t%r1760, %r556, %r1760, %p203;\n\tselp.f32 \t%r1759, %r559, %r1759, %p203;\n\tadd.s64 \t%rd143, %rd143, 1;\n\tsetp.ne.b64 \t%p204, %rd143, 4;\n\t@%p204 bra \t$L__BB0_61;\n\tmul.f32 \t%r560, %r1760, 0f2F800000;\n\tselp.f32 \t%r1761, %r560, %r1760, %p193;\n$L__BB0_63:\n\tand.b32 \t%r561, %r1761, -2147483648;\n\tand.b32 \t%r562, %r1761, 8388607;\n\tsetp.ne.b32 \t%p205, %r562, 0;\n\tand.b32 \t%r563, %r1761, 2139095040;\n\tsetp.eq.b32 \t%p206, %r563, 0;\n\tselp.f32 \t%r564, %r561, %r1761, %p205;\n\tselp.f32 \t%r1762, %r564, %r1761, %p206;\n$L__BB0_64:\n\tst.global.b32 \t[%rd32+12], %r1762;\n$L__BB0_65:\n\tor.b64 \t%rd27, %rd16, 3;\n\tsetp.ge.s64 \t%p207, %rd29, %rd3;\n\t@%p207 bra \t$L__BB0_96;\n\tmul.wide.s32 \t%rd70, %r76, 8;\n\tadd.s64 \t%rd30, %rd17, %rd70;\n\tld.global.b32 \t%r565, [%rd18+8];\n\tand.b32 \t%r566, %r565, -2147483648;\n\tand.b32 \t%r567, %r565, 8388607;\n\tsetp.ne.b32 \t%p208, %r567, 0;\n\tand.b32 \t%r568, %r565, 2139095040;\n\tsetp.eq.b32 \t%p209, %r568, 0;\n\tselp.f32 \t%r569, %r566, %r565, %p208;\n\tselp.f32 \t%r19, %r569, %r565, %p209;\n\tld.global.b32 \t%r570, [%rd11];\n\tand.b32 \t%r571, %r570, -2147483648;\n\tand.b32 \t%r572, %r570, 8388607;\n\tsetp.ne.b32 \t%p210, %r572, 0;\n\tand.b32 \t%r573, %r570, 2139095040;\n\tsetp.eq.b32 \t%p211, %r573, 0;\n\tselp.f32 \t%r574, %r571, %r570, %p210;\n\tselp.f32 \t%r575, %r574, %r570, %p211;\n\tadd.f32 \t%r576, %r19, %r575;\n\tand.b32 \t%r577, %r576, -2147483648;\n\tand.b32 \t%r578, %r576, 8388607;\n\tsetp.ne.b32 \t%p212, %r578, 0;\n\tand.b32 \t%r579, %r576, 2139095040;\n\tsetp.eq.b32 \t%p213, %r579, 0;\n\tselp.f32 \t%r580, %r577, %r576, %p212;\n\tselp.f32 \t%r581, %r580, %r576, %p213;\n\tfma.rn.f32 \t%r582, %r1707, 0fC0000000, %r581;\n\tand.b32 \t%r583, %r582, -2147483648;\n\tand.b32 \t%r584, %r582, 8388607;\n\tsetp.ne.b32 \t%p214, %r584, 0;\n\tand.b32 \t%r585, %r582, 2139095040;\n\tsetp.eq.b32 \t%p215, %r585, 0;\n\tselp.f32 \t%r586, %r583, %r582, %p214;\n\tselp.f32 \t%r587, %r586, %r582, %p215;\n\tsetp.le.f32 \t%p216, %r587, 0f00000000;\n\tselp.f32 \t%r1766, 0f00000000, %r587, %p216;\n\t@%p30 bra \t$L__BB0_72;\n\tabs.f32 \t%r588, %r1766;\n\tsetp.eq.f32 \t%p218, %r1766, 0f7F800000;\n\tsetp.lt.f32 \t%p219, %r588, 0f00800000;\n\tsetp.num.f32 \t%p220, %r1766, %r1766;\n\tsetp.ltu.f32 \t%p221, %r1766, 0f00000000;\n\tor.pred \t%p222, %p221, %p219;\n\tselp.f32 \t%r590, 0f00000000, 0f7FC00000, %p219;\n\tor.pred \t%p223, %p218, %p222;\n\tselp.f32 \t%r591, %r590, %r1766, %p222;\n\tselp.f32 \t%r1765, %r591, %r1766, %p220;\n\t@%p223 bra \t$L__BB0_71;\n\tmul.f32 \t%r589, %r1766, 0f5F800000;\n\tsetp.lt.f32 \t%p217, %r1766, 0f0F800000;\n\tselp.f32 \t%r20, %r589, %r1766, %p217;\n\tshr.u32 \t%r592, %r20, 1;\n\tadd.s32 \t%r593, %r592, 532487669;\n\tdiv.rn.f32 \t%r594, %r20, %r593;\n\tadd.f32 \t%r595, %r594, %r593;\n\tmul.f32 \t%r596, %r595, 0f3F000000;\n\tdiv.rn.f32 \t%r597, %r20, %r596;\n\tfma.rn.f32 \t%r598, %r595, 0f3F000000, %r597;\n\tmul.f32 \t%r599, %r598, 0f3F000000;\n\tdiv.rn.f32 \t%r600, %r20, %r599;\n\tfma.rn.f32 \t%r601, %r598, 0f3F000000, %r600;\n\tmul.f32 \t%r21, %r601, 0f3F000000;\n\tneg.f32 \t%r602, %r21;\n\tfma.rn.f32 \t%r603, %r602, %r21, %r20;\n\tabs.f32 \t%r1763, %r603;\n\tmov.b64 \t%rd144, 0;\n\tmov.b32 \t%r1764, %r21;\n$L__BB0_69:\n\tsetp.eq.b64 \t%p224, %rd144, 2;\n\tselp.b32 \t%r604, -2, 2, %p224;\n\tsetp.eq.b64 \t%p225, %rd144, 1;\n\tsetp.eq.b64 \t%p226, %rd144, 0;\n\tselp.b32 \t%r605, 1, %r604, %p225;\n\tselp.b32 \t%r606, -1, %r605, %p226;\n\tadd.s32 \t%r607, %r606, %r21;\n\tneg.f32 \t%r608, %r607;\n\tfma.rn.f32 \t%r609, %r608, %r607, %r20;\n\tabs.f32 \t%r610, %r609;\n\tsetp.lt.f32 \t%p227, %r610, %r1763;\n\tselp.f32 \t%r1764, %r607, %r1764, %p227;\n\tselp.f32 \t%r1763, %r610, %r1763, %p227;\n\tadd.s64 \t%rd144, %rd144, 1;\n\tsetp.ne.b64 \t%p228, %rd144, 4;\n\t@%p228 bra \t$L__BB0_69;\n\tmul.f32 \t%r611, %r1764, 0f2F800000;\n\tselp.f32 \t%r1765, %r611, %r1764, %p217;\n$L__BB0_71:\n\tand.b32 \t%r612, %r1765, -2147483648;\n\tand.b32 \t%r613, %r1765, 8388607;\n\tsetp.ne.b32 \t%p229, %r613, 0;\n\tand.b32 \t%r614, %r1765, 2139095040;\n\tsetp.eq.b32 \t%p230, %r614, 0;\n\tselp.f32 \t%r615, %r612, %r1765, %p229;\n\tselp.f32 \t%r1766, %r615, %r1765, %p230;\n$L__BB0_72:\n\tst.global.b32 \t[%rd30], %r1766;\n\t@%p54 bra \t$L__BB0_80;\n\tld.global.b32 \t%r616, [%rd11+4];\n\tand.b32 \t%r617, %r616, -2147483648;\n\tand.b32 \t%r618, %r616, 8388607;\n\tsetp.ne.b32 \t%p231, %r618, 0;\n\tand.b32 \t%r619, %r616, 2139095040;\n\tsetp.eq.b32 \t%p232, %r619, 0;\n\tselp.f32 \t%r620, %r617, %r616, %p231;\n\tselp.f32 \t%r621, %r620, %r616, %p232;\n\tadd.f32 \t%r622, %r19, %r621;\n\tand.b32 \t%r623, %r622, -2147483648;\n\tand.b32 \t%r624, %r622, 8388607;\n\tsetp.ne.b32 \t%p233, %r624, 0;\n\tand.b32 \t%r625, %r622, 2139095040;\n\tsetp.eq.b32 \t%p234, %r625, 0;\n\tselp.f32 \t%r626, %r623, %r622, %p233;\n\tselp.f32 \t%r627, %r626, %r622, %p234;\n\tfma.rn.f32 \t%r628, %r1708, 0fC0000000, %r627;\n\tand.b32 \t%r629, %r628, -2147483648;\n\tand.b32 \t%r630, %r628, 8388607;\n\tsetp.ne.b32 \t%p235, %r630, 0;\n\tand.b32 \t%r631, %r628, 2139095040;\n\tsetp.eq.b32 \t%p236, %r631, 0;\n\tselp.f32 \t%r632, %r629, %r628, %p235;\n\tselp.f32 \t%r633, %r632, %r628, %p236;\n\tsetp.le.f32 \t%p237, %r633, 0f00000000;\n\tselp.f32 \t%r1770, 0f00000000, %r633, %p237;\n\t@%p30 bra \t$L__BB0_79;\n\tabs.f32 \t%r634, %r1770;\n\tsetp.eq.f32 \t%p239, %r1770, 0f7F800000;\n\tsetp.lt.f32 \t%p240, %r634, 0f00800000;\n\tsetp.num.f32 \t%p241, %r1770, %r1770;\n\tsetp.ltu.f32 \t%p242, %r1770, 0f00000000;\n\tor.pred \t%p243, %p242, %p240;\n\tselp.f32 \t%r636, 0f00000000, 0f7FC00000, %p240;\n\tor.pred \t%p244, %p239, %p243;\n\tselp.f32 \t%r637, %r636, %r1770, %p243;\n\tselp.f32 \t%r1769, %r637, %r1770, %p241;\n\t@%p244 bra \t$L__BB0_78;\n\tmul.f32 \t%r635, %r1770, 0f5F800000;\n\tsetp.lt.f32 \t%p238, %r1770, 0f0F800000;\n\tselp.f32 \t%r22, %r635, %r1770, %p238;\n\tshr.u32 \t%r638, %r22, 1;\n\tadd.s32 \t%r639, %r638, 532487669;\n\tdiv.rn.f32 \t%r640, %r22, %r639;\n\tadd.f32 \t%r641, %r640, %r639;\n\tmul.f32 \t%r642, %r641, 0f3F000000;\n\tdiv.rn.f32 \t%r643, %r22, %r642;\n\tfma.rn.f32 \t%r644, %r641, 0f3F000000, %r643;\n\tmul.f32 \t%r645, %r644, 0f3F000000;\n\tdiv.rn.f32 \t%r646, %r22, %r645;\n\tfma.rn.f32 \t%r647, %r644, 0f3F000000, %r646;\n\tmul.f32 \t%r23, %r647, 0f3F000000;\n\tneg.f32 \t%r648, %r23;\n\tfma.rn.f32 \t%r649, %r648, %r23, %r22;\n\tabs.f32 \t%r1767, %r649;\n\tmov.b64 \t%rd145, 0;\n\tmov.b32 \t%r1768, %r23;\n$L__BB0_76:\n\tsetp.eq.b64 \t%p245, %rd145, 2;\n\tselp.b32 \t%r650, -2, 2, %p245;\n\tsetp.eq.b64 \t%p246, %rd145, 1;\n\tsetp.eq.b64 \t%p247, %rd145, 0;\n\tselp.b32 \t%r651, 1, %r650, %p246;\n\tselp.b32 \t%r652, -1, %r651, %p247;\n\tadd.s32 \t%r653, %r652, %r23;\n\tneg.f32 \t%r654, %r653;\n\tfma.rn.f32 \t%r655, %r654, %r653, %r22;\n\tabs.f32 \t%r656, %r655;\n\tsetp.lt.f32 \t%p248, %r656, %r1767;\n\tselp.f32 \t%r1768, %r653, %r1768, %p248;\n\tselp.f32 \t%r1767, %r656, %r1767, %p248;\n\tadd.s64 \t%rd145, %rd145, 1;\n\tsetp.ne.b64 \t%p249, %rd145, 4;\n\t@%p249 bra \t$L__BB0_76;\n\tmul.f32 \t%r657, %r1768, 0f2F800000;\n\tselp.f32 \t%r1769, %r657, %r1768, %p238;\n$L__BB0_78:\n\tand.b32 \t%r658, %r1769, -2147483648;\n\tand.b32 \t%r659, %r1769, 8388607;\n\tsetp.ne.b32 \t%p250, %r659, 0;\n\tand.b32 \t%r660, %r1769, 2139095040;\n\tsetp.eq.b32 \t%p251, %r660, 0;\n\tselp.f32 \t%r661, %r658, %r1769, %p250;\n\tselp.f32 \t%r1770, %r661, %r1769, %p251;\n$L__BB0_79:\n\tst.global.b32 \t[%rd30+4], %r1770;\n$L__BB0_80:\n\t@%p76 bra \t$L__BB0_88;\n\tld.global.b32 \t%r662, [%rd11+8];\n\tand.b32 \t%r663, %r662, -2147483648;\n\tand.b32 \t%r664, %r662, 8388607;\n\tsetp.ne.b32 \t%p252, %r664, 0;\n\tand.b32 \t%r665, %r662, 2139095040;\n\tsetp.eq.b32 \t%p253, %r665, 0;\n\tselp.f32 \t%r666, %r663, %r662, %p252;\n\tselp.f32 \t%r667, %r666, %r662, %p253;\n\tadd.f32 \t%r668, %r19, %r667;\n\tand.b32 \t%r669, %r668, -2147483648;\n\tand.b32 \t%r670, %r668, 8388607;\n\tsetp.ne.b32 \t%p254, %r670, 0;\n\tand.b32 \t%r671, %r668, 2139095040;\n\tsetp.eq.b32 \t%p255, %r671, 0;\n\tselp.f32 \t%r672, %r669, %r668, %p254;\n\tselp.f32 \t%r673, %r672, %r668, %p255;\n\tfma.rn.f32 \t%r674, %r1709, 0fC0000000, %r673;\n\tand.b32 \t%r675, %r674, -2147483648;\n\tand.b32 \t%r676, %r674, 8388607;\n\tsetp.ne.b32 \t%p256, %r676, 0;\n\tand.b32 \t%r677, %r674, 2139095040;\n\tsetp.eq.b32 \t%p257, %r677, 0;\n\tselp.f32 \t%r678, %r675, %r674, %p256;\n\tselp.f32 \t%r679, %r678, %r674, %p257;\n\tsetp.le.f32 \t%p258, %r679, 0f00000000;\n\tselp.f32 \t%r1774, 0f00000000, %r679, %p258;\n\t@%p30 bra \t$L__BB0_87;\n\tabs.f32 \t%r680, %r1774;\n\tsetp.eq.f32 \t%p260, %r1774, 0f7F800000;\n\tsetp.lt.f32 \t%p261, %r680, 0f00800000;\n\tsetp.num.f32 \t%p262, %r1774, %r1774;\n\tsetp.ltu.f32 \t%p263, %r1774, 0f00000000;\n\tor.pred \t%p264, %p263, %p261;\n\tselp.f32 \t%r682, 0f00000000, 0f7FC00000, %p261;\n\tor.pred \t%p265, %p260, %p264;\n\tselp.f32 \t%r683, %r682, %r1774, %p264;\n\tselp.f32 \t%r1773, %r683, %r1774, %p262;\n\t@%p265 bra \t$L__BB0_86;\n\tmul.f32 \t%r681, %r1774, 0f5F800000;\n\tsetp.lt.f32 \t%p259, %r1774, 0f0F800000;\n\tselp.f32 \t%r24, %r681, %r1774, %p259;\n\tshr.u32 \t%r684, %r24, 1;\n\tadd.s32 \t%r685, %r684, 532487669;\n\tdiv.rn.f32 \t%r686, %r24, %r685;\n\tadd.f32 \t%r687, %r686, %r685;\n\tmul.f32 \t%r688, %r687, 0f3F000000;\n\tdiv.rn.f32 \t%r689, %r24, %r688;\n\tfma.rn.f32 \t%r690, %r687, 0f3F000000, %r689;\n\tmul.f32 \t%r691, %r690, 0f3F000000;\n\tdiv.rn.f32 \t%r692, %r24, %r691;\n\tfma.rn.f32 \t%r693, %r690, 0f3F000000, %r692;\n\tmul.f32 \t%r25, %r693, 0f3F000000;\n\tneg.f32 \t%r694, %r25;\n\tfma.rn.f32 \t%r695, %r694, %r25, %r24;\n\tabs.f32 \t%r1771, %r695;\n\tmov.b64 \t%rd146, 0;\n\tmov.b32 \t%r1772, %r25;\n$L__BB0_84:\n\tsetp.eq.b64 \t%p266, %rd146, 2;\n\tselp.b32 \t%r696, -2, 2, %p266;\n\tsetp.eq.b64 \t%p267, %rd146, 1;\n\tsetp.eq.b64 \t%p268, %rd146, 0;\n\tselp.b32 \t%r697, 1, %r696, %p267;\n\tselp.b32 \t%r698, -1, %r697, %p268;\n\tadd.s32 \t%r699, %r698, %r25;\n\tneg.f32 \t%r700, %r699;\n\tfma.rn.f32 \t%r701, %r700, %r699, %r24;\n\tabs.f32 \t%r702, %r701;\n\tsetp.lt.f32 \t%p269, %r702, %r1771;\n\tselp.f32 \t%r1772, %r699, %r1772, %p269;\n\tselp.f32 \t%r1771, %r702, %r1771, %p269;\n\tadd.s64 \t%rd146, %rd146, 1;\n\tsetp.ne.b64 \t%p270, %rd146, 4;\n\t@%p270 bra \t$L__BB0_84;\n\tmul.f32 \t%r703, %r1772, 0f2F800000;\n\tselp.f32 \t%r1773, %r703, %r1772, %p259;\n$L__BB0_86:\n\tand.b32 \t%r704, %r1773, -2147483648;\n\tand.b32 \t%r705, %r1773, 8388607;\n\tsetp.ne.b32 \t%p271, %r705, 0;\n\tand.b32 \t%r706, %r1773, 2139095040;\n\tsetp.eq.b32 \t%p272, %r706, 0;\n\tselp.f32 \t%r707, %r704, %r1773, %p271;\n\tselp.f32 \t%r1774, %r707, %r1773, %p272;\n$L__BB0_87:\n\tst.global.b32 \t[%rd30+8], %r1774;\n$L__BB0_88:\n\t@%p98 bra \t$L__BB0_96;\n\tld.global.b32 \t%r708, [%rd11+12];\n\tand.b32 \t%r709, %r708, -2147483648;\n\tand.b32 \t%r710, %r708, 8388607;\n\tsetp.ne.b32 \t%p273, %r710, 0;\n\tand.b32 \t%r711, %r708, 2139095040;\n\tsetp.eq.b32 \t%p274, %r711, 0;\n\tselp.f32 \t%r712, %r709, %r708, %p273;\n\tselp.f32 \t%r713, %r712, %r708, %p274;\n\tadd.f32 \t%r714, %r19, %r713;\n\tand.b32 \t%r715, %r714, -2147483648;\n\tand.b32 \t%r716, %r714, 8388607;\n\tsetp.ne.b32 \t%p275, %r716, 0;\n\tand.b32 \t%r717, %r714, 2139095040;\n\tsetp.eq.b32 \t%p276, %r717, 0;\n\tselp.f32 \t%r718, %r715, %r714, %p275;\n\tselp.f32 \t%r719, %r718, %r714, %p276;\n\tfma.rn.f32 \t%r720, %r1710, 0fC0000000, %r719;\n\tand.b32 \t%r721, %r720, -2147483648;\n\tand.b32 \t%r722, %r720, 8388607;\n\tsetp.ne.b32 \t%p277, %r722, 0;\n\tand.b32 \t%r723, %r720, 2139095040;\n\tsetp.eq.b32 \t%p278, %r723, 0;\n\tselp.f32 \t%r724, %r721, %r720, %p277;\n\tselp.f32 \t%r725, %r724, %r720, %p278;\n\tsetp.le.f32 \t%p279, %r725, 0f00000000;\n\tselp.f32 \t%r1778, 0f00000000, %r725, %p279;\n\t@%p30 bra \t$L__BB0_95;\n\tabs.f32 \t%r726, %r1778;\n\tsetp.eq.f32 \t%p281, %r1778, 0f7F800000;\n\tsetp.lt.f32 \t%p282, %r726, 0f00800000;\n\tsetp.num.f32 \t%p283, %r1778, %r1778;\n\tsetp.ltu.f32 \t%p284, %r1778, 0f00000000;\n\tor.pred \t%p285, %p284, %p282;\n\tselp.f32 \t%r728, 0f00000000, 0f7FC00000, %p282;\n\tor.pred \t%p286, %p281, %p285;\n\tselp.f32 \t%r729, %r728, %r1778, %p285;\n\tselp.f32 \t%r1777, %r729, %r1778, %p283;\n\t@%p286 bra \t$L__BB0_94;\n\tmul.f32 \t%r727, %r1778, 0f5F800000;\n\tsetp.lt.f32 \t%p280, %r1778, 0f0F800000;\n\tselp.f32 \t%r26, %r727, %r1778, %p280;\n\tshr.u32 \t%r730, %r26, 1;\n\tadd.s32 \t%r731, %r730, 532487669;\n\tdiv.rn.f32 \t%r732, %r26, %r731;\n\tadd.f32 \t%r733, %r732, %r731;\n\tmul.f32 \t%r734, %r733, 0f3F000000;\n\tdiv.rn.f32 \t%r735, %r26, %r734;\n\tfma.rn.f32 \t%r736, %r733, 0f3F000000, %r735;\n\tmul.f32 \t%r737, %r736, 0f3F000000;\n\tdiv.rn.f32 \t%r738, %r26, %r737;\n\tfma.rn.f32 \t%r739, %r736, 0f3F000000, %r738;\n\tmul.f32 \t%r27, %r739, 0f3F000000;\n\tneg.f32 \t%r740, %r27;\n\tfma.rn.f32 \t%r741, %r740, %r27, %r26;\n\tabs.f32 \t%r1775, %r741;\n\tmov.b64 \t%rd147, 0;\n\tmov.b32 \t%r1776, %r27;\n$L__BB0_92:\n\tsetp.eq.b64 \t%p287, %rd147, 2;\n\tselp.b32 \t%r742, -2, 2, %p287;\n\tsetp.eq.b64 \t%p288, %rd147, 1;\n\tsetp.eq.b64 \t%p289, %rd147, 0;\n\tselp.b32 \t%r743, 1, %r742, %p288;\n\tselp.b32 \t%r744, -1, %r743, %p289;\n\tadd.s32 \t%r745, %r744, %r27;\n\tneg.f32 \t%r746, %r745;\n\tfma.rn.f32 \t%r747, %r746, %r745, %r26;\n\tabs.f32 \t%r748, %r747;\n\tsetp.lt.f32 \t%p290, %r748, %r1775;\n\tselp.f32 \t%r1776, %r745, %r1776, %p290;\n\tselp.f32 \t%r1775, %r748, %r1775, %p290;\n\tadd.s64 \t%rd147, %rd147, 1;\n\tsetp.ne.b64 \t%p291, %rd147, 4;\n\t@%p291 bra \t$L__BB0_92;\n\tmul.f32 \t%r749, %r1776, 0f2F800000;\n\tselp.f32 \t%r1777, %r749, %r1776, %p280;\n$L__BB0_94:\n\tand.b32 \t%r750, %r1777, -2147483648;\n\tand.b32 \t%r751, %r1777, 8388607;\n\tsetp.ne.b32 \t%p292, %r751, 0;\n\tand.b32 \t%r752, %r1777, 2139095040;\n\tsetp.eq.b32 \t%p293, %r752, 0;\n\tselp.f32 \t%r753, %r750, %r1777, %p292;\n\tselp.f32 \t%r1778, %r753, %r1777, %p293;\n$L__BB0_95:\n\tst.global.b32 \t[%rd30+12], %r1778;\n$L__BB0_96:\n\tor.b64 \t%rd25, %rd16, 4;\n\tsetp.ge.s64 \t%p294, %rd27, %rd3;\n\t@%p294 bra \t$L__BB0_127;\n\tmul.wide.s32 \t%rd69, %r76, 12;\n\tadd.s64 \t%rd28, %rd17, %rd69;\n\tld.global.b32 \t%r754, [%rd18+12];\n\tand.b32 \t%r755, %r754, -2147483648;\n\tand.b32 \t%r756, %r754, 8388607;\n\tsetp.ne.b32 \t%p295, %r756, 0;\n\tand.b32 \t%r757, %r754, 2139095040;\n\tsetp.eq.b32 \t%p296, %r757, 0;\n\tselp.f32 \t%r758, %r755, %r754, %p295;\n\tselp.f32 \t%r28, %r758, %r754, %p296;\n\tld.global.b32 \t%r759, [%rd11];\n\tand.b32 \t%r760, %r759, -2147483648;\n\tand.b32 \t%r761, %r759, 8388607;\n\tsetp.ne.b32 \t%p297, %r761, 0;\n\tand.b32 \t%r762, %r759, 2139095040;\n\tsetp.eq.b32 \t%p298, %r762, 0;\n\tselp.f32 \t%r763, %r760, %r759, %p297;\n\tselp.f32 \t%r764, %r763, %r759, %p298;\n\tadd.f32 \t%r765, %r28, %r764;\n\tand.b32 \t%r766, %r765, -2147483648;\n\tand.b32 \t%r767, %r765, 8388607;\n\tsetp.ne.b32 \t%p299, %r767, 0;\n\tand.b32 \t%r768, %r765, 2139095040;\n\tsetp.eq.b32 \t%p300, %r768, 0;\n\tselp.f32 \t%r769, %r766, %r765, %p299;\n\tselp.f32 \t%r770, %r769, %r765, %p300;\n\tfma.rn.f32 \t%r771, %r1711, 0fC0000000, %r770;\n\tand.b32 \t%r772, %r771, -2147483648;\n\tand.b32 \t%r773, %r771, 8388607;\n\tsetp.ne.b32 \t%p301, %r773, 0;\n\tand.b32 \t%r774, %r771, 2139095040;\n\tsetp.eq.b32 \t%p302, %r774, 0;\n\tselp.f32 \t%r775, %r772, %r771, %p301;\n\tselp.f32 \t%r776, %r775, %r771, %p302;\n\tsetp.le.f32 \t%p303, %r776, 0f00000000;\n\tselp.f32 \t%r1782, 0f00000000, %r776, %p303;\n\t@%p30 bra \t$L__BB0_103;\n\tabs.f32 \t%r777, %r1782;\n\tsetp.eq.f32 \t%p305, %r1782, 0f7F800000;\n\tsetp.lt.f32 \t%p306, %r777, 0f00800000;\n\tsetp.num.f32 \t%p307, %r1782, %r1782;\n\tsetp.ltu.f32 \t%p308, %r1782, 0f00000000;\n\tor.pred \t%p309, %p308, %p306;\n\tselp.f32 \t%r779, 0f00000000, 0f7FC00000, %p306;\n\tor.pred \t%p310, %p305, %p309;\n\tselp.f32 \t%r780, %r779, %r1782, %p309;\n\tselp.f32 \t%r1781, %r780, %r1782, %p307;\n\t@%p310 bra \t$L__BB0_102;\n\tmul.f32 \t%r778, %r1782, 0f5F800000;\n\tsetp.lt.f32 \t%p304, %r1782, 0f0F800000;\n\tselp.f32 \t%r29, %r778, %r1782, %p304;\n\tshr.u32 \t%r781, %r29, 1;\n\tadd.s32 \t%r782, %r781, 532487669;\n\tdiv.rn.f32 \t%r783, %r29, %r782;\n\tadd.f32 \t%r784, %r783, %r782;\n\tmul.f32 \t%r785, %r784, 0f3F000000;\n\tdiv.rn.f32 \t%r786, %r29, %r785;\n\tfma.rn.f32 \t%r787, %r784, 0f3F000000, %r786;\n\tmul.f32 \t%r788, %r787, 0f3F000000;\n\tdiv.rn.f32 \t%r789, %r29, %r788;\n\tfma.rn.f32 \t%r790, %r787, 0f3F000000, %r789;\n\tmul.f32 \t%r30, %r790, 0f3F000000;\n\tneg.f32 \t%r791, %r30;\n\tfma.rn.f32 \t%r792, %r791, %r30, %r29;\n\tabs.f32 \t%r1779, %r792;\n\tmov.b64 \t%rd148, 0;\n\tmov.b32 \t%r1780, %r30;\n$L__BB0_100:\n\tsetp.eq.b64 \t%p311, %rd148, 2;\n\tselp.b32 \t%r793, -2, 2, %p311;\n\tsetp.eq.b64 \t%p312, %rd148, 1;\n\tsetp.eq.b64 \t%p313, %rd148, 0;\n\tselp.b32 \t%r794, 1, %r793, %p312;\n\tselp.b32 \t%r795, -1, %r794, %p313;\n\tadd.s32 \t%r796, %r795, %r30;\n\tneg.f32 \t%r797, %r796;\n\tfma.rn.f32 \t%r798, %r797, %r796, %r29;\n\tabs.f32 \t%r799, %r798;\n\tsetp.lt.f32 \t%p314, %r799, %r1779;\n\tselp.f32 \t%r1780, %r796, %r1780, %p314;\n\tselp.f32 \t%r1779, %r799, %r1779, %p314;\n\tadd.s64 \t%rd148, %rd148, 1;\n\tsetp.ne.b64 \t%p315, %rd148, 4;\n\t@%p315 bra \t$L__BB0_100;\n\tmul.f32 \t%r800, %r1780, 0f2F800000;\n\tselp.f32 \t%r1781, %r800, %r1780, %p304;\n$L__BB0_102:\n\tand.b32 \t%r801, %r1781, -2147483648;\n\tand.b32 \t%r802, %r1781, 8388607;\n\tsetp.ne.b32 \t%p316, %r802, 0;\n\tand.b32 \t%r803, %r1781, 2139095040;\n\tsetp.eq.b32 \t%p317, %r803, 0;\n\tselp.f32 \t%r804, %r801, %r1781, %p316;\n\tselp.f32 \t%r1782, %r804, %r1781, %p317;\n$L__BB0_103:\n\tst.global.b32 \t[%rd28], %r1782;\n\t@%p54 bra \t$L__BB0_111;\n\tld.global.b32 \t%r805, [%rd11+4];\n\tand.b32 \t%r806, %r805, -2147483648;\n\tand.b32 \t%r807, %r805, 8388607;\n\tsetp.ne.b32 \t%p318, %r807, 0;\n\tand.b32 \t%r808, %r805, 2139095040;\n\tsetp.eq.b32 \t%p319, %r808, 0;\n\tselp.f32 \t%r809, %r806, %r805, %p318;\n\tselp.f32 \t%r810, %r809, %r805, %p319;\n\tadd.f32 \t%r811, %r28, %r810;\n\tand.b32 \t%r812, %r811, -2147483648;\n\tand.b32 \t%r813, %r811, 8388607;\n\tsetp.ne.b32 \t%p320, %r813, 0;\n\tand.b32 \t%r814, %r811, 2139095040;\n\tsetp.eq.b32 \t%p321, %r814, 0;\n\tselp.f32 \t%r815, %r812, %r811, %p320;\n\tselp.f32 \t%r816, %r815, %r811, %p321;\n\tfma.rn.f32 \t%r817, %r1712, 0fC0000000, %r816;\n\tand.b32 \t%r818, %r817, -2147483648;\n\tand.b32 \t%r819, %r817, 8388607;\n\tsetp.ne.b32 \t%p322, %r819, 0;\n\tand.b32 \t%r820, %r817, 2139095040;\n\tsetp.eq.b32 \t%p323, %r820, 0;\n\tselp.f32 \t%r821, %r818, %r817, %p322;\n\tselp.f32 \t%r822, %r821, %r817, %p323;\n\tsetp.le.f32 \t%p324, %r822, 0f00000000;\n\tselp.f32 \t%r1786, 0f00000000, %r822, %p324;\n\t@%p30 bra \t$L__BB0_110;\n\tabs.f32 \t%r823, %r1786;\n\tsetp.eq.f32 \t%p326, %r1786, 0f7F800000;\n\tsetp.lt.f32 \t%p327, %r823, 0f00800000;\n\tsetp.num.f32 \t%p328, %r1786, %r1786;\n\tsetp.ltu.f32 \t%p329, %r1786, 0f00000000;\n\tor.pred \t%p330, %p329, %p327;\n\tselp.f32 \t%r825, 0f00000000, 0f7FC00000, %p327;\n\tor.pred \t%p331, %p326, %p330;\n\tselp.f32 \t%r826, %r825, %r1786, %p330;\n\tselp.f32 \t%r1785, %r826, %r1786, %p328;\n\t@%p331 bra \t$L__BB0_109;\n\tmul.f32 \t%r824, %r1786, 0f5F800000;\n\tsetp.lt.f32 \t%p325, %r1786, 0f0F800000;\n\tselp.f32 \t%r31, %r824, %r1786, %p325;\n\tshr.u32 \t%r827, %r31, 1;\n\tadd.s32 \t%r828, %r827, 532487669;\n\tdiv.rn.f32 \t%r829, %r31, %r828;\n\tadd.f32 \t%r830, %r829, %r828;\n\tmul.f32 \t%r831, %r830, 0f3F000000;\n\tdiv.rn.f32 \t%r832, %r31, %r831;\n\tfma.rn.f32 \t%r833, %r830, 0f3F000000, %r832;\n\tmul.f32 \t%r834, %r833, 0f3F000000;\n\tdiv.rn.f32 \t%r835, %r31, %r834;\n\tfma.rn.f32 \t%r836, %r833, 0f3F000000, %r835;\n\tmul.f32 \t%r32, %r836, 0f3F000000;\n\tneg.f32 \t%r837, %r32;\n\tfma.rn.f32 \t%r838, %r837, %r32, %r31;\n\tabs.f32 \t%r1783, %r838;\n\tmov.b64 \t%rd149, 0;\n\tmov.b32 \t%r1784, %r32;\n$L__BB0_107:\n\tsetp.eq.b64 \t%p332, %rd149, 2;\n\tselp.b32 \t%r839, -2, 2, %p332;\n\tsetp.eq.b64 \t%p333, %rd149, 1;\n\tsetp.eq.b64 \t%p334, %rd149, 0;\n\tselp.b32 \t%r840, 1, %r839, %p333;\n\tselp.b32 \t%r841, -1, %r840, %p334;\n\tadd.s32 \t%r842, %r841, %r32;\n\tneg.f32 \t%r843, %r842;\n\tfma.rn.f32 \t%r844, %r843, %r842, %r31;\n\tabs.f32 \t%r845, %r844;\n\tsetp.lt.f32 \t%p335, %r845, %r1783;\n\tselp.f32 \t%r1784, %r842, %r1784, %p335;\n\tselp.f32 \t%r1783, %r845, %r1783, %p335;\n\tadd.s64 \t%rd149, %rd149, 1;\n\tsetp.ne.b64 \t%p336, %rd149, 4;\n\t@%p336 bra \t$L__BB0_107;\n\tmul.f32 \t%r846, %r1784, 0f2F800000;\n\tselp.f32 \t%r1785, %r846, %r1784, %p325;\n$L__BB0_109:\n\tand.b32 \t%r847, %r1785, -2147483648;\n\tand.b32 \t%r848, %r1785, 8388607;\n\tsetp.ne.b32 \t%p337, %r848, 0;\n\tand.b32 \t%r849, %r1785, 2139095040;\n\tsetp.eq.b32 \t%p338, %r849, 0;\n\tselp.f32 \t%r850, %r847, %r1785, %p337;\n\tselp.f32 \t%r1786, %r850, %r1785, %p338;\n$L__BB0_110:\n\tst.global.b32 \t[%rd28+4], %r1786;\n$L__BB0_111:\n\t@%p76 bra \t$L__BB0_119;\n\tld.global.b32 \t%r851, [%rd11+8];\n\tand.b32 \t%r852, %r851, -2147483648;\n\tand.b32 \t%r853, %r851, 8388607;\n\tsetp.ne.b32 \t%p339, %r853, 0;\n\tand.b32 \t%r854, %r851, 2139095040;\n\tsetp.eq.b32 \t%p340, %r854, 0;\n\tselp.f32 \t%r855, %r852, %r851, %p339;\n\tselp.f32 \t%r856, %r855, %r851, %p340;\n\tadd.f32 \t%r857, %r28, %r856;\n\tand.b32 \t%r858, %r857, -2147483648;\n\tand.b32 \t%r859, %r857, 8388607;\n\tsetp.ne.b32 \t%p341, %r859, 0;\n\tand.b32 \t%r860, %r857, 2139095040;\n\tsetp.eq.b32 \t%p342, %r860, 0;\n\tselp.f32 \t%r861, %r858, %r857, %p341;\n\tselp.f32 \t%r862, %r861, %r857, %p342;\n\tfma.rn.f32 \t%r863, %r1713, 0fC0000000, %r862;\n\tand.b32 \t%r864, %r863, -2147483648;\n\tand.b32 \t%r865, %r863, 8388607;\n\tsetp.ne.b32 \t%p343, %r865, 0;\n\tand.b32 \t%r866, %r863, 2139095040;\n\tsetp.eq.b32 \t%p344, %r866, 0;\n\tselp.f32 \t%r867, %r864, %r863, %p343;\n\tselp.f32 \t%r868, %r867, %r863, %p344;\n\tsetp.le.f32 \t%p345, %r868, 0f00000000;\n\tselp.f32 \t%r1790, 0f00000000, %r868, %p345;\n\t@%p30 bra \t$L__BB0_118;\n\tabs.f32 \t%r869, %r1790;\n\tsetp.eq.f32 \t%p347, %r1790, 0f7F800000;\n\tsetp.lt.f32 \t%p348, %r869, 0f00800000;\n\tsetp.num.f32 \t%p349, %r1790, %r1790;\n\tsetp.ltu.f32 \t%p350, %r1790, 0f00000000;\n\tor.pred \t%p351, %p350, %p348;\n\tselp.f32 \t%r871, 0f00000000, 0f7FC00000, %p348;\n\tor.pred \t%p352, %p347, %p351;\n\tselp.f32 \t%r872, %r871, %r1790, %p351;\n\tselp.f32 \t%r1789, %r872, %r1790, %p349;\n\t@%p352 bra \t$L__BB0_117;\n\tmul.f32 \t%r870, %r1790, 0f5F800000;\n\tsetp.lt.f32 \t%p346, %r1790, 0f0F800000;\n\tselp.f32 \t%r33, %r870, %r1790, %p346;\n\tshr.u32 \t%r873, %r33, 1;\n\tadd.s32 \t%r874, %r873, 532487669;\n\tdiv.rn.f32 \t%r875, %r33, %r874;\n\tadd.f32 \t%r876, %r875, %r874;\n\tmul.f32 \t%r877, %r876, 0f3F000000;\n\tdiv.rn.f32 \t%r878, %r33, %r877;\n\tfma.rn.f32 \t%r879, %r876, 0f3F000000, %r878;\n\tmul.f32 \t%r880, %r879, 0f3F000000;\n\tdiv.rn.f32 \t%r881, %r33, %r880;\n\tfma.rn.f32 \t%r882, %r879, 0f3F000000, %r881;\n\tmul.f32 \t%r34, %r882, 0f3F000000;\n\tneg.f32 \t%r883, %r34;\n\tfma.rn.f32 \t%r884, %r883, %r34, %r33;\n\tabs.f32 \t%r1787, %r884;\n\tmov.b64 \t%rd150, 0;\n\tmov.b32 \t%r1788, %r34;\n$L__BB0_115:\n\tsetp.eq.b64 \t%p353, %rd150, 2;\n\tselp.b32 \t%r885, -2, 2, %p353;\n\tsetp.eq.b64 \t%p354, %rd150, 1;\n\tsetp.eq.b64 \t%p355, %rd150, 0;\n\tselp.b32 \t%r886, 1, %r885, %p354;\n\tselp.b32 \t%r887, -1, %r886, %p355;\n\tadd.s32 \t%r888, %r887, %r34;\n\tneg.f32 \t%r889, %r888;\n\tfma.rn.f32 \t%r890, %r889, %r888, %r33;\n\tabs.f32 \t%r891, %r890;\n\tsetp.lt.f32 \t%p356, %r891, %r1787;\n\tselp.f32 \t%r1788, %r888, %r1788, %p356;\n\tselp.f32 \t%r1787, %r891, %r1787, %p356;\n\tadd.s64 \t%rd150, %rd150, 1;\n\tsetp.ne.b64 \t%p357, %rd150, 4;\n\t@%p357 bra \t$L__BB0_115;\n\tmul.f32 \t%r892, %r1788, 0f2F800000;\n\tselp.f32 \t%r1789, %r892, %r1788, %p346;\n$L__BB0_117:\n\tand.b32 \t%r893, %r1789, -2147483648;\n\tand.b32 \t%r894, %r1789, 8388607;\n\tsetp.ne.b32 \t%p358, %r894, 0;\n\tand.b32 \t%r895, %r1789, 2139095040;\n\tsetp.eq.b32 \t%p359, %r895, 0;\n\tselp.f32 \t%r896, %r893, %r1789, %p358;\n\tselp.f32 \t%r1790, %r896, %r1789, %p359;\n$L__BB0_118:\n\tst.global.b32 \t[%rd28+8], %r1790;\n$L__BB0_119:\n\t@%p98 bra \t$L__BB0_127;\n\tld.global.b32 \t%r897, [%rd11+12];\n\tand.b32 \t%r898, %r897, -2147483648;\n\tand.b32 \t%r899, %r897, 8388607;\n\tsetp.ne.b32 \t%p360, %r899, 0;\n\tand.b32 \t%r900, %r897, 2139095040;\n\tsetp.eq.b32 \t%p361, %r900, 0;\n\tselp.f32 \t%r901, %r898, %r897, %p360;\n\tselp.f32 \t%r902, %r901, %r897, %p361;\n\tadd.f32 \t%r903, %r28, %r902;\n\tand.b32 \t%r904, %r903, -2147483648;\n\tand.b32 \t%r905, %r903, 8388607;\n\tsetp.ne.b32 \t%p362, %r905, 0;\n\tand.b32 \t%r906, %r903, 2139095040;\n\tsetp.eq.b32 \t%p363, %r906, 0;\n\tselp.f32 \t%r907, %r904, %r903, %p362;\n\tselp.f32 \t%r908, %r907, %r903, %p363;\n\tfma.rn.f32 \t%r909, %r1714, 0fC0000000, %r908;\n\tand.b32 \t%r910, %r909, -2147483648;\n\tand.b32 \t%r911, %r909, 8388607;\n\tsetp.ne.b32 \t%p364, %r911, 0;\n\tand.b32 \t%r912, %r909, 2139095040;\n\tsetp.eq.b32 \t%p365, %r912, 0;\n\tselp.f32 \t%r913, %r910, %r909, %p364;\n\tselp.f32 \t%r914, %r913, %r909, %p365;\n\tsetp.le.f32 \t%p366, %r914, 0f00000000;\n\tselp.f32 \t%r1794, 0f00000000, %r914, %p366;\n\t@%p30 bra \t$L__BB0_126;\n\tabs.f32 \t%r915, %r1794;\n\tsetp.eq.f32 \t%p368, %r1794, 0f7F800000;\n\tsetp.lt.f32 \t%p369, %r915, 0f00800000;\n\tsetp.num.f32 \t%p370, %r1794, %r1794;\n\tsetp.ltu.f32 \t%p371, %r1794, 0f00000000;\n\tor.pred \t%p372, %p371, %p369;\n\tselp.f32 \t%r917, 0f00000000, 0f7FC00000, %p369;\n\tor.pred \t%p373, %p368, %p372;\n\tselp.f32 \t%r918, %r917, %r1794, %p372;\n\tselp.f32 \t%r1793, %r918, %r1794, %p370;\n\t@%p373 bra \t$L__BB0_125;\n\tmul.f32 \t%r916, %r1794, 0f5F800000;\n\tsetp.lt.f32 \t%p367, %r1794, 0f0F800000;\n\tselp.f32 \t%r35, %r916, %r1794, %p367;\n\tshr.u32 \t%r919, %r35, 1;\n\tadd.s32 \t%r920, %r919, 532487669;\n\tdiv.rn.f32 \t%r921, %r35, %r920;\n\tadd.f32 \t%r922, %r921, %r920;\n\tmul.f32 \t%r923, %r922, 0f3F000000;\n\tdiv.rn.f32 \t%r924, %r35, %r923;\n\tfma.rn.f32 \t%r925, %r922, 0f3F000000, %r924;\n\tmul.f32 \t%r926, %r925, 0f3F000000;\n\tdiv.rn.f32 \t%r927, %r35, %r926;\n\tfma.rn.f32 \t%r928, %r925, 0f3F000000, %r927;\n\tmul.f32 \t%r36, %r928, 0f3F000000;\n\tneg.f32 \t%r929, %r36;\n\tfma.rn.f32 \t%r930, %r929, %r36, %r35;\n\tabs.f32 \t%r1791, %r930;\n\tmov.b64 \t%rd151, 0;\n\tmov.b32 \t%r1792, %r36;\n$L__BB0_123:\n\tsetp.eq.b64 \t%p374, %rd151, 2;\n\tselp.b32 \t%r931, -2, 2, %p374;\n\tsetp.eq.b64 \t%p375, %rd151, 1;\n\tsetp.eq.b64 \t%p376, %rd151, 0;\n\tselp.b32 \t%r932, 1, %r931, %p375;\n\tselp.b32 \t%r933, -1, %r932, %p376;\n\tadd.s32 \t%r934, %r933, %r36;\n\tneg.f32 \t%r935, %r934;\n\tfma.rn.f32 \t%r936, %r935, %r934, %r35;\n\tabs.f32 \t%r937, %r936;\n\tsetp.lt.f32 \t%p377, %r937, %r1791;\n\tselp.f32 \t%r1792, %r934, %r1792, %p377;\n\tselp.f32 \t%r1791, %r937, %r1791, %p377;\n\tadd.s64 \t%rd151, %rd151, 1;\n\tsetp.ne.b64 \t%p378, %rd151, 4;\n\t@%p378 bra \t$L__BB0_123;\n\tmul.f32 \t%r938, %r1792, 0f2F800000;\n\tselp.f32 \t%r1793, %r938, %r1792, %p367;\n$L__BB0_125:\n\tand.b32 \t%r939, %r1793, -2147483648;\n\tand.b32 \t%r940, %r1793, 8388607;\n\tsetp.ne.b32 \t%p379, %r940, 0;\n\tand.b32 \t%r941, %r1793, 2139095040;\n\tsetp.eq.b32 \t%p380, %r941, 0;\n\tselp.f32 \t%r942, %r939, %r1793, %p379;\n\tselp.f32 \t%r1794, %r942, %r1793, %p380;\n$L__BB0_126:\n\tst.global.b32 \t[%rd28+12], %r1794;\n$L__BB0_127:\n\tor.b64 \t%rd23, %rd16, 5;\n\tsetp.ge.s64 \t%p381, %rd25, %rd3;\n\t@%p381 bra \t$L__BB0_158;\n\tmul.wide.s32 \t%rd68, %r76, 16;\n\tadd.s64 \t%rd26, %rd17, %rd68;\n\tld.global.b32 \t%r943, [%rd18+16];\n\tand.b32 \t%r944, %r943, -2147483648;\n\tand.b32 \t%r945, %r943, 8388607;\n\tsetp.ne.b32 \t%p382, %r945, 0;\n\tand.b32 \t%r946, %r943, 2139095040;\n\tsetp.eq.b32 \t%p383, %r946, 0;\n\tselp.f32 \t%r947, %r944, %r943, %p382;\n\tselp.f32 \t%r37, %r947, %r943, %p383;\n\tld.global.b32 \t%r948, [%rd11];\n\tand.b32 \t%r949, %r948, -2147483648;\n\tand.b32 \t%r950, %r948, 8388607;\n\tsetp.ne.b32 \t%p384, %r950, 0;\n\tand.b32 \t%r951, %r948, 2139095040;\n\tsetp.eq.b32 \t%p385, %r951, 0;\n\tselp.f32 \t%r952, %r949, %r948, %p384;\n\tselp.f32 \t%r953, %r952, %r948, %p385;\n\tadd.f32 \t%r954, %r37, %r953;\n\tand.b32 \t%r955, %r954, -2147483648;\n\tand.b32 \t%r956, %r954, 8388607;\n\tsetp.ne.b32 \t%p386, %r956, 0;\n\tand.b32 \t%r957, %r954, 2139095040;\n\tsetp.eq.b32 \t%p387, %r957, 0;\n\tselp.f32 \t%r958, %r955, %r954, %p386;\n\tselp.f32 \t%r959, %r958, %r954, %p387;\n\tfma.rn.f32 \t%r960, %r1715, 0fC0000000, %r959;\n\tand.b32 \t%r961, %r960, -2147483648;\n\tand.b32 \t%r962, %r960, 8388607;\n\tsetp.ne.b32 \t%p388, %r962, 0;\n\tand.b32 \t%r963, %r960, 2139095040;\n\tsetp.eq.b32 \t%p389, %r963, 0;\n\tselp.f32 \t%r964, %r961, %r960, %p388;\n\tselp.f32 \t%r965, %r964, %r960, %p389;\n\tsetp.le.f32 \t%p390, %r965, 0f00000000;\n\tselp.f32 \t%r1798, 0f00000000, %r965, %p390;\n\t@%p30 bra \t$L__BB0_134;\n\tabs.f32 \t%r966, %r1798;\n\tsetp.eq.f32 \t%p392, %r1798, 0f7F800000;\n\tsetp.lt.f32 \t%p393, %r966, 0f00800000;\n\tsetp.num.f32 \t%p394, %r1798, %r1798;\n\tsetp.ltu.f32 \t%p395, %r1798, 0f00000000;\n\tor.pred \t%p396, %p395, %p393;\n\tselp.f32 \t%r968, 0f00000000, 0f7FC00000, %p393;\n\tor.pred \t%p397, %p392, %p396;\n\tselp.f32 \t%r969, %r968, %r1798, %p396;\n\tselp.f32 \t%r1797, %r969, %r1798, %p394;\n\t@%p397 bra \t$L__BB0_133;\n\tmul.f32 \t%r967, %r1798, 0f5F800000;\n\tsetp.lt.f32 \t%p391, %r1798, 0f0F800000;\n\tselp.f32 \t%r38, %r967, %r1798, %p391;\n\tshr.u32 \t%r970, %r38, 1;\n\tadd.s32 \t%r971, %r970, 532487669;\n\tdiv.rn.f32 \t%r972, %r38, %r971;\n\tadd.f32 \t%r973, %r972, %r971;\n\tmul.f32 \t%r974, %r973, 0f3F000000;\n\tdiv.rn.f32 \t%r975, %r38, %r974;\n\tfma.rn.f32 \t%r976, %r973, 0f3F000000, %r975;\n\tmul.f32 \t%r977, %r976, 0f3F000000;\n\tdiv.rn.f32 \t%r978, %r38, %r977;\n\tfma.rn.f32 \t%r979, %r976, 0f3F000000, %r978;\n\tmul.f32 \t%r39, %r979, 0f3F000000;\n\tneg.f32 \t%r980, %r39;\n\tfma.rn.f32 \t%r981, %r980, %r39, %r38;\n\tabs.f32 \t%r1795, %r981;\n\tmov.b64 \t%rd152, 0;\n\tmov.b32 \t%r1796, %r39;\n$L__BB0_131:\n\tsetp.eq.b64 \t%p398, %rd152, 2;\n\tselp.b32 \t%r982, -2, 2, %p398;\n\tsetp.eq.b64 \t%p399, %rd152, 1;\n\tsetp.eq.b64 \t%p400, %rd152, 0;\n\tselp.b32 \t%r983, 1, %r982, %p399;\n\tselp.b32 \t%r984, -1, %r983, %p400;\n\tadd.s32 \t%r985, %r984, %r39;\n\tneg.f32 \t%r986, %r985;\n\tfma.rn.f32 \t%r987, %r986, %r985, %r38;\n\tabs.f32 \t%r988, %r987;\n\tsetp.lt.f32 \t%p401, %r988, %r1795;\n\tselp.f32 \t%r1796, %r985, %r1796, %p401;\n\tselp.f32 \t%r1795, %r988, %r1795, %p401;\n\tadd.s64 \t%rd152, %rd152, 1;\n\tsetp.ne.b64 \t%p402, %rd152, 4;\n\t@%p402 bra \t$L__BB0_131;\n\tmul.f32 \t%r989, %r1796, 0f2F800000;\n\tselp.f32 \t%r1797, %r989, %r1796, %p391;\n$L__BB0_133:\n\tand.b32 \t%r990, %r1797, -2147483648;\n\tand.b32 \t%r991, %r1797, 8388607;\n\tsetp.ne.b32 \t%p403, %r991, 0;\n\tand.b32 \t%r992, %r1797, 2139095040;\n\tsetp.eq.b32 \t%p404, %r992, 0;\n\tselp.f32 \t%r993, %r990, %r1797, %p403;\n\tselp.f32 \t%r1798, %r993, %r1797, %p404;\n$L__BB0_134:\n\tst.global.b32 \t[%rd26], %r1798;\n\t@%p54 bra \t$L__BB0_142;\n\tld.global.b32 \t%r994, [%rd11+4];\n\tand.b32 \t%r995, %r994, -2147483648;\n\tand.b32 \t%r996, %r994, 8388607;\n\tsetp.ne.b32 \t%p405, %r996, 0;\n\tand.b32 \t%r997, %r994, 2139095040;\n\tsetp.eq.b32 \t%p406, %r997, 0;\n\tselp.f32 \t%r998, %r995, %r994, %p405;\n\tselp.f32 \t%r999, %r998, %r994, %p406;\n\tadd.f32 \t%r1000, %r37, %r999;\n\tand.b32 \t%r1001, %r1000, -2147483648;\n\tand.b32 \t%r1002, %r1000, 8388607;\n\tsetp.ne.b32 \t%p407, %r1002, 0;\n\tand.b32 \t%r1003, %r1000, 2139095040;\n\tsetp.eq.b32 \t%p408, %r1003, 0;\n\tselp.f32 \t%r1004, %r1001, %r1000, %p407;\n\tselp.f32 \t%r1005, %r1004, %r1000, %p408;\n\tfma.rn.f32 \t%r1006, %r1716, 0fC0000000, %r1005;\n\tand.b32 \t%r1007, %r1006, -2147483648;\n\tand.b32 \t%r1008, %r1006, 8388607;\n\tsetp.ne.b32 \t%p409, %r1008, 0;\n\tand.b32 \t%r1009, %r1006, 2139095040;\n\tsetp.eq.b32 \t%p410, %r1009, 0;\n\tselp.f32 \t%r1010, %r1007, %r1006, %p409;\n\tselp.f32 \t%r1011, %r1010, %r1006, %p410;\n\tsetp.le.f32 \t%p411, %r1011, 0f00000000;\n\tselp.f32 \t%r1802, 0f00000000, %r1011, %p411;\n\t@%p30 bra \t$L__BB0_141;\n\tabs.f32 \t%r1012, %r1802;\n\tsetp.eq.f32 \t%p413, %r1802, 0f7F800000;\n\tsetp.lt.f32 \t%p414, %r1012, 0f00800000;\n\tsetp.num.f32 \t%p415, %r1802, %r1802;\n\tsetp.ltu.f32 \t%p416, %r1802, 0f00000000;\n\tor.pred \t%p417, %p416, %p414;\n\tselp.f32 \t%r1014, 0f00000000, 0f7FC00000, %p414;\n\tor.pred \t%p418, %p413, %p417;\n\tselp.f32 \t%r1015, %r1014, %r1802, %p417;\n\tselp.f32 \t%r1801, %r1015, %r1802, %p415;\n\t@%p418 bra \t$L__BB0_140;\n\tmul.f32 \t%r1013, %r1802, 0f5F800000;\n\tsetp.lt.f32 \t%p412, %r1802, 0f0F800000;\n\tselp.f32 \t%r40, %r1013, %r1802, %p412;\n\tshr.u32 \t%r1016, %r40, 1;\n\tadd.s32 \t%r1017, %r1016, 532487669;\n\tdiv.rn.f32 \t%r1018, %r40, %r1017;\n\tadd.f32 \t%r1019, %r1018, %r1017;\n\tmul.f32 \t%r1020, %r1019, 0f3F000000;\n\tdiv.rn.f32 \t%r1021, %r40, %r1020;\n\tfma.rn.f32 \t%r1022, %r1019, 0f3F000000, %r1021;\n\tmul.f32 \t%r1023, %r1022, 0f3F000000;\n\tdiv.rn.f32 \t%r1024, %r40, %r1023;\n\tfma.rn.f32 \t%r1025, %r1022, 0f3F000000, %r1024;\n\tmul.f32 \t%r41, %r1025, 0f3F000000;\n\tneg.f32 \t%r1026, %r41;\n\tfma.rn.f32 \t%r1027, %r1026, %r41, %r40;\n\tabs.f32 \t%r1799, %r1027;\n\tmov.b64 \t%rd153, 0;\n\tmov.b32 \t%r1800, %r41;\n$L__BB0_138:\n\tsetp.eq.b64 \t%p419, %rd153, 2;\n\tselp.b32 \t%r1028, -2, 2, %p419;\n\tsetp.eq.b64 \t%p420, %rd153, 1;\n\tsetp.eq.b64 \t%p421, %rd153, 0;\n\tselp.b32 \t%r1029, 1, %r1028, %p420;\n\tselp.b32 \t%r1030, -1, %r1029, %p421;\n\tadd.s32 \t%r1031, %r1030, %r41;\n\tneg.f32 \t%r1032, %r1031;\n\tfma.rn.f32 \t%r1033, %r1032, %r1031, %r40;\n\tabs.f32 \t%r1034, %r1033;\n\tsetp.lt.f32 \t%p422, %r1034, %r1799;\n\tselp.f32 \t%r1800, %r1031, %r1800, %p422;\n\tselp.f32 \t%r1799, %r1034, %r1799, %p422;\n\tadd.s64 \t%rd153, %rd153, 1;\n\tsetp.ne.b64 \t%p423, %rd153, 4;\n\t@%p423 bra \t$L__BB0_138;\n\tmul.f32 \t%r1035, %r1800, 0f2F800000;\n\tselp.f32 \t%r1801, %r1035, %r1800, %p412;\n$L__BB0_140:\n\tand.b32 \t%r1036, %r1801, -2147483648;\n\tand.b32 \t%r1037, %r1801, 8388607;\n\tsetp.ne.b32 \t%p424, %r1037, 0;\n\tand.b32 \t%r1038, %r1801, 2139095040;\n\tsetp.eq.b32 \t%p425, %r1038, 0;\n\tselp.f32 \t%r1039, %r1036, %r1801, %p424;\n\tselp.f32 \t%r1802, %r1039, %r1801, %p425;\n$L__BB0_141:\n\tst.global.b32 \t[%rd26+4], %r1802;\n$L__BB0_142:\n\t@%p76 bra \t$L__BB0_150;\n\tld.global.b32 \t%r1040, [%rd11+8];\n\tand.b32 \t%r1041, %r1040, -2147483648;\n\tand.b32 \t%r1042, %r1040, 8388607;\n\tsetp.ne.b32 \t%p426, %r1042, 0;\n\tand.b32 \t%r1043, %r1040, 2139095040;\n\tsetp.eq.b32 \t%p427, %r1043, 0;\n\tselp.f32 \t%r1044, %r1041, %r1040, %p426;\n\tselp.f32 \t%r1045, %r1044, %r1040, %p427;\n\tadd.f32 \t%r1046, %r37, %r1045;\n\tand.b32 \t%r1047, %r1046, -2147483648;\n\tand.b32 \t%r1048, %r1046, 8388607;\n\tsetp.ne.b32 \t%p428, %r1048, 0;\n\tand.b32 \t%r1049, %r1046, 2139095040;\n\tsetp.eq.b32 \t%p429, %r1049, 0;\n\tselp.f32 \t%r1050, %r1047, %r1046, %p428;\n\tselp.f32 \t%r1051, %r1050, %r1046, %p429;\n\tfma.rn.f32 \t%r1052, %r1717, 0fC0000000, %r1051;\n\tand.b32 \t%r1053, %r1052, -2147483648;\n\tand.b32 \t%r1054, %r1052, 8388607;\n\tsetp.ne.b32 \t%p430, %r1054, 0;\n\tand.b32 \t%r1055, %r1052, 2139095040;\n\tsetp.eq.b32 \t%p431, %r1055, 0;\n\tselp.f32 \t%r1056, %r1053, %r1052, %p430;\n\tselp.f32 \t%r1057, %r1056, %r1052, %p431;\n\tsetp.le.f32 \t%p432, %r1057, 0f00000000;\n\tselp.f32 \t%r1806, 0f00000000, %r1057, %p432;\n\t@%p30 bra \t$L__BB0_149;\n\tabs.f32 \t%r1058, %r1806;\n\tsetp.eq.f32 \t%p434, %r1806, 0f7F800000;\n\tsetp.lt.f32 \t%p435, %r1058, 0f00800000;\n\tsetp.num.f32 \t%p436, %r1806, %r1806;\n\tsetp.ltu.f32 \t%p437, %r1806, 0f00000000;\n\tor.pred \t%p438, %p437, %p435;\n\tselp.f32 \t%r1060, 0f00000000, 0f7FC00000, %p435;\n\tor.pred \t%p439, %p434, %p438;\n\tselp.f32 \t%r1061, %r1060, %r1806, %p438;\n\tselp.f32 \t%r1805, %r1061, %r1806, %p436;\n\t@%p439 bra \t$L__BB0_148;\n\tmul.f32 \t%r1059, %r1806, 0f5F800000;\n\tsetp.lt.f32 \t%p433, %r1806, 0f0F800000;\n\tselp.f32 \t%r42, %r1059, %r1806, %p433;\n\tshr.u32 \t%r1062, %r42, 1;\n\tadd.s32 \t%r1063, %r1062, 532487669;\n\tdiv.rn.f32 \t%r1064, %r42, %r1063;\n\tadd.f32 \t%r1065, %r1064, %r1063;\n\tmul.f32 \t%r1066, %r1065, 0f3F000000;\n\tdiv.rn.f32 \t%r1067, %r42, %r1066;\n\tfma.rn.f32 \t%r1068, %r1065, 0f3F000000, %r1067;\n\tmul.f32 \t%r1069, %r1068, 0f3F000000;\n\tdiv.rn.f32 \t%r1070, %r42, %r1069;\n\tfma.rn.f32 \t%r1071, %r1068, 0f3F000000, %r1070;\n\tmul.f32 \t%r43, %r1071, 0f3F000000;\n\tneg.f32 \t%r1072, %r43;\n\tfma.rn.f32 \t%r1073, %r1072, %r43, %r42;\n\tabs.f32 \t%r1803, %r1073;\n\tmov.b64 \t%rd154, 0;\n\tmov.b32 \t%r1804, %r43;\n$L__BB0_146:\n\tsetp.eq.b64 \t%p440, %rd154, 2;\n\tselp.b32 \t%r1074, -2, 2, %p440;\n\tsetp.eq.b64 \t%p441, %rd154, 1;\n\tsetp.eq.b64 \t%p442, %rd154, 0;\n\tselp.b32 \t%r1075, 1, %r1074, %p441;\n\tselp.b32 \t%r1076, -1, %r1075, %p442;\n\tadd.s32 \t%r1077, %r1076, %r43;\n\tneg.f32 \t%r1078, %r1077;\n\tfma.rn.f32 \t%r1079, %r1078, %r1077, %r42;\n\tabs.f32 \t%r1080, %r1079;\n\tsetp.lt.f32 \t%p443, %r1080, %r1803;\n\tselp.f32 \t%r1804, %r1077, %r1804, %p443;\n\tselp.f32 \t%r1803, %r1080, %r1803, %p443;\n\tadd.s64 \t%rd154, %rd154, 1;\n\tsetp.ne.b64 \t%p444, %rd154, 4;\n\t@%p444 bra \t$L__BB0_146;\n\tmul.f32 \t%r1081, %r1804, 0f2F800000;\n\tselp.f32 \t%r1805, %r1081, %r1804, %p433;\n$L__BB0_148:\n\tand.b32 \t%r1082, %r1805, -2147483648;\n\tand.b32 \t%r1083, %r1805, 8388607;\n\tsetp.ne.b32 \t%p445, %r1083, 0;\n\tand.b32 \t%r1084, %r1805, 2139095040;\n\tsetp.eq.b32 \t%p446, %r1084, 0;\n\tselp.f32 \t%r1085, %r1082, %r1805, %p445;\n\tselp.f32 \t%r1806, %r1085, %r1805, %p446;\n$L__BB0_149:\n\tst.global.b32 \t[%rd26+8], %r1806;\n$L__BB0_150:\n\t@%p98 bra \t$L__BB0_158;\n\tld.global.b32 \t%r1086, [%rd11+12];\n\tand.b32 \t%r1087, %r1086, -2147483648;\n\tand.b32 \t%r1088, %r1086, 8388607;\n\tsetp.ne.b32 \t%p447, %r1088, 0;\n\tand.b32 \t%r1089, %r1086, 2139095040;\n\tsetp.eq.b32 \t%p448, %r1089, 0;\n\tselp.f32 \t%r1090, %r1087, %r1086, %p447;\n\tselp.f32 \t%r1091, %r1090, %r1086, %p448;\n\tadd.f32 \t%r1092, %r37, %r1091;\n\tand.b32 \t%r1093, %r1092, -2147483648;\n\tand.b32 \t%r1094, %r1092, 8388607;\n\tsetp.ne.b32 \t%p449, %r1094, 0;\n\tand.b32 \t%r1095, %r1092, 2139095040;\n\tsetp.eq.b32 \t%p450, %r1095, 0;\n\tselp.f32 \t%r1096, %r1093, %r1092, %p449;\n\tselp.f32 \t%r1097, %r1096, %r1092, %p450;\n\tfma.rn.f32 \t%r1098, %r1718, 0fC0000000, %r1097;\n\tand.b32 \t%r1099, %r1098, -2147483648;\n\tand.b32 \t%r1100, %r1098, 8388607;\n\tsetp.ne.b32 \t%p451, %r1100, 0;\n\tand.b32 \t%r1101, %r1098, 2139095040;\n\tsetp.eq.b32 \t%p452, %r1101, 0;\n\tselp.f32 \t%r1102, %r1099, %r1098, %p451;\n\tselp.f32 \t%r1103, %r1102, %r1098, %p452;\n\tsetp.le.f32 \t%p453, %r1103, 0f00000000;\n\tselp.f32 \t%r1810, 0f00000000, %r1103, %p453;\n\t@%p30 bra \t$L__BB0_157;\n\tabs.f32 \t%r1104, %r1810;\n\tsetp.eq.f32 \t%p455, %r1810, 0f7F800000;\n\tsetp.lt.f32 \t%p456, %r1104, 0f00800000;\n\tsetp.num.f32 \t%p457, %r1810, %r1810;\n\tsetp.ltu.f32 \t%p458, %r1810, 0f00000000;\n\tor.pred \t%p459, %p458, %p456;\n\tselp.f32 \t%r1106, 0f00000000, 0f7FC00000, %p456;\n\tor.pred \t%p460, %p455, %p459;\n\tselp.f32 \t%r1107, %r1106, %r1810, %p459;\n\tselp.f32 \t%r1809, %r1107, %r1810, %p457;\n\t@%p460 bra \t$L__BB0_156;\n\tmul.f32 \t%r1105, %r1810, 0f5F800000;\n\tsetp.lt.f32 \t%p454, %r1810, 0f0F800000;\n\tselp.f32 \t%r44, %r1105, %r1810, %p454;\n\tshr.u32 \t%r1108, %r44, 1;\n\tadd.s32 \t%r1109, %r1108, 532487669;\n\tdiv.rn.f32 \t%r1110, %r44, %r1109;\n\tadd.f32 \t%r1111, %r1110, %r1109;\n\tmul.f32 \t%r1112, %r1111, 0f3F000000;\n\tdiv.rn.f32 \t%r1113, %r44, %r1112;\n\tfma.rn.f32 \t%r1114, %r1111, 0f3F000000, %r1113;\n\tmul.f32 \t%r1115, %r1114, 0f3F000000;\n\tdiv.rn.f32 \t%r1116, %r44, %r1115;\n\tfma.rn.f32 \t%r1117, %r1114, 0f3F000000, %r1116;\n\tmul.f32 \t%r45, %r1117, 0f3F000000;\n\tneg.f32 \t%r1118, %r45;\n\tfma.rn.f32 \t%r1119, %r1118, %r45, %r44;\n\tabs.f32 \t%r1807, %r1119;\n\tmov.b64 \t%rd155, 0;\n\tmov.b32 \t%r1808, %r45;\n$L__BB0_154:\n\tsetp.eq.b64 \t%p461, %rd155, 2;\n\tselp.b32 \t%r1120, -2, 2, %p461;\n\tsetp.eq.b64 \t%p462, %rd155, 1;\n\tsetp.eq.b64 \t%p463, %rd155, 0;\n\tselp.b32 \t%r1121, 1, %r1120, %p462;\n\tselp.b32 \t%r1122, -1, %r1121, %p463;\n\tadd.s32 \t%r1123, %r1122, %r45;\n\tneg.f32 \t%r1124, %r1123;\n\tfma.rn.f32 \t%r1125, %r1124, %r1123, %r44;\n\tabs.f32 \t%r1126, %r1125;\n\tsetp.lt.f32 \t%p464, %r1126, %r1807;\n\tselp.f32 \t%r1808, %r1123, %r1808, %p464;\n\tselp.f32 \t%r1807, %r1126, %r1807, %p464;\n\tadd.s64 \t%rd155, %rd155, 1;\n\tsetp.ne.b64 \t%p465, %rd155, 4;\n\t@%p465 bra \t$L__BB0_154;\n\tmul.f32 \t%r1127, %r1808, 0f2F800000;\n\tselp.f32 \t%r1809, %r1127, %r1808, %p454;\n$L__BB0_156:\n\tand.b32 \t%r1128, %r1809, -2147483648;\n\tand.b32 \t%r1129, %r1809, 8388607;\n\tsetp.ne.b32 \t%p466, %r1129, 0;\n\tand.b32 \t%r1130, %r1809, 2139095040;\n\tsetp.eq.b32 \t%p467, %r1130, 0;\n\tselp.f32 \t%r1131, %r1128, %r1809, %p466;\n\tselp.f32 \t%r1810, %r1131, %r1809, %p467;\n$L__BB0_157:\n\tst.global.b32 \t[%rd26+12], %r1810;\n$L__BB0_158:\n\tor.b64 \t%rd21, %rd16, 6;\n\tsetp.ge.s64 \t%p468, %rd23, %rd3;\n\t@%p468 bra \t$L__BB0_189;\n\tmul.wide.s32 \t%rd66, %r76, 20;\n\tadd.s64 \t%rd24, %rd17, %rd66;\n\tld.global.b32 \t%r1132, [%rd18+20];\n\tand.b32 \t%r1133, %r1132, -2147483648;\n\tand.b32 \t%r1134, %r1132, 8388607;\n\tsetp.ne.b32 \t%p469, %r1134, 0;\n\tand.b32 \t%r1135, %r1132, 2139095040;\n\tsetp.eq.b32 \t%p470, %r1135, 0;\n\tselp.f32 \t%r1136, %r1133, %r1132, %p469;\n\tselp.f32 \t%r46, %r1136, %r1132, %p470;\n\tld.global.b32 \t%r1137, [%rd11];\n\tand.b32 \t%r1138, %r1137, -2147483648;\n\tand.b32 \t%r1139, %r1137, 8388607;\n\tsetp.ne.b32 \t%p471, %r1139, 0;\n\tand.b32 \t%r1140, %r1137, 2139095040;\n\tsetp.eq.b32 \t%p472, %r1140, 0;\n\tselp.f32 \t%r1141, %r1138, %r1137, %p471;\n\tselp.f32 \t%r1142, %r1141, %r1137, %p472;\n\tadd.f32 \t%r1143, %r46, %r1142;\n\tand.b32 \t%r1144, %r1143, -2147483648;\n\tand.b32 \t%r1145, %r1143, 8388607;\n\tsetp.ne.b32 \t%p473, %r1145, 0;\n\tand.b32 \t%r1146, %r1143, 2139095040;\n\tsetp.eq.b32 \t%p474, %r1146, 0;\n\tselp.f32 \t%r1147, %r1144, %r1143, %p473;\n\tselp.f32 \t%r1148, %r1147, %r1143, %p474;\n\tfma.rn.f32 \t%r1149, %r1719, 0fC0000000, %r1148;\n\tand.b32 \t%r1150, %r1149, -2147483648;\n\tand.b32 \t%r1151, %r1149, 8388607;\n\tsetp.ne.b32 \t%p475, %r1151, 0;\n\tand.b32 \t%r1152, %r1149, 2139095040;\n\tsetp.eq.b32 \t%p476, %r1152, 0;\n\tselp.f32 \t%r1153, %r1150, %r1149, %p475;\n\tselp.f32 \t%r1154, %r1153, %r1149, %p476;\n\tsetp.le.f32 \t%p477, %r1154, 0f00000000;\n\tselp.f32 \t%r1814, 0f00000000, %r1154, %p477;\n\t@%p30 bra \t$L__BB0_165;\n\tabs.f32 \t%r1155, %r1814;\n\tsetp.eq.f32 \t%p479, %r1814, 0f7F800000;\n\tsetp.lt.f32 \t%p480, %r1155, 0f00800000;\n\tsetp.num.f32 \t%p481, %r1814, %r1814;\n\tsetp.ltu.f32 \t%p482, %r1814, 0f00000000;\n\tor.pred \t%p483, %p482, %p480;\n\tselp.f32 \t%r1157, 0f00000000, 0f7FC00000, %p480;\n\tor.pred \t%p484, %p479, %p483;\n\tselp.f32 \t%r1158, %r1157, %r1814, %p483;\n\tselp.f32 \t%r1813, %r1158, %r1814, %p481;\n\t@%p484 bra \t$L__BB0_164;\n\tmul.f32 \t%r1156, %r1814, 0f5F800000;\n\tsetp.lt.f32 \t%p478, %r1814, 0f0F800000;\n\tselp.f32 \t%r47, %r1156, %r1814, %p478;\n\tshr.u32 \t%r1159, %r47, 1;\n\tadd.s32 \t%r1160, %r1159, 532487669;\n\tdiv.rn.f32 \t%r1161, %r47, %r1160;\n\tadd.f32 \t%r1162, %r1161, %r1160;\n\tmul.f32 \t%r1163, %r1162, 0f3F000000;\n\tdiv.rn.f32 \t%r1164, %r47, %r1163;\n\tfma.rn.f32 \t%r1165, %r1162, 0f3F000000, %r1164;\n\tmul.f32 \t%r1166, %r1165, 0f3F000000;\n\tdiv.rn.f32 \t%r1167, %r47, %r1166;\n\tfma.rn.f32 \t%r1168, %r1165, 0f3F000000, %r1167;\n\tmul.f32 \t%r48, %r1168, 0f3F000000;\n\tneg.f32 \t%r1169, %r48;\n\tfma.rn.f32 \t%r1170, %r1169, %r48, %r47;\n\tabs.f32 \t%r1811, %r1170;\n\tmov.b64 \t%rd156, 0;\n\tmov.b32 \t%r1812, %r48;\n$L__BB0_162:\n\tsetp.eq.b64 \t%p485, %rd156, 2;\n\tselp.b32 \t%r1171, -2, 2, %p485;\n\tsetp.eq.b64 \t%p486, %rd156, 1;\n\tsetp.eq.b64 \t%p487, %rd156, 0;\n\tselp.b32 \t%r1172, 1, %r1171, %p486;\n\tselp.b32 \t%r1173, -1, %r1172, %p487;\n\tadd.s32 \t%r1174, %r1173, %r48;\n\tneg.f32 \t%r1175, %r1174;\n\tfma.rn.f32 \t%r1176, %r1175, %r1174, %r47;\n\tabs.f32 \t%r1177, %r1176;\n\tsetp.lt.f32 \t%p488, %r1177, %r1811;\n\tselp.f32 \t%r1812, %r1174, %r1812, %p488;\n\tselp.f32 \t%r1811, %r1177, %r1811, %p488;\n\tadd.s64 \t%rd156, %rd156, 1;\n\tsetp.ne.b64 \t%p489, %rd156, 4;\n\t@%p489 bra \t$L__BB0_162;\n\tmul.f32 \t%r1178, %r1812, 0f2F800000;\n\tselp.f32 \t%r1813, %r1178, %r1812, %p478;\n$L__BB0_164:\n\tand.b32 \t%r1179, %r1813, -2147483648;\n\tand.b32 \t%r1180, %r1813, 8388607;\n\tsetp.ne.b32 \t%p490, %r1180, 0;\n\tand.b32 \t%r1181, %r1813, 2139095040;\n\tsetp.eq.b32 \t%p491, %r1181, 0;\n\tselp.f32 \t%r1182, %r1179, %r1813, %p490;\n\tselp.f32 \t%r1814, %r1182, %r1813, %p491;\n$L__BB0_165:\n\tst.global.b32 \t[%rd24], %r1814;\n\t@%p54 bra \t$L__BB0_173;\n\tld.global.b32 \t%r1183, [%rd11+4];\n\tand.b32 \t%r1184, %r1183, -2147483648;\n\tand.b32 \t%r1185, %r1183, 8388607;\n\tsetp.ne.b32 \t%p492, %r1185, 0;\n\tand.b32 \t%r1186, %r1183, 2139095040;\n\tsetp.eq.b32 \t%p493, %r1186, 0;\n\tselp.f32 \t%r1187, %r1184, %r1183, %p492;\n\tselp.f32 \t%r1188, %r1187, %r1183, %p493;\n\tadd.f32 \t%r1189, %r46, %r1188;\n\tand.b32 \t%r1190, %r1189, -2147483648;\n\tand.b32 \t%r1191, %r1189, 8388607;\n\tsetp.ne.b32 \t%p494, %r1191, 0;\n\tand.b32 \t%r1192, %r1189, 2139095040;\n\tsetp.eq.b32 \t%p495, %r1192, 0;\n\tselp.f32 \t%r1193, %r1190, %r1189, %p494;\n\tselp.f32 \t%r1194, %r1193, %r1189, %p495;\n\tfma.rn.f32 \t%r1195, %r1720, 0fC0000000, %r1194;\n\tand.b32 \t%r1196, %r1195, -2147483648;\n\tand.b32 \t%r1197, %r1195, 8388607;\n\tsetp.ne.b32 \t%p496, %r1197, 0;\n\tand.b32 \t%r1198, %r1195, 2139095040;\n\tsetp.eq.b32 \t%p497, %r1198, 0;\n\tselp.f32 \t%r1199, %r1196, %r1195, %p496;\n\tselp.f32 \t%r1200, %r1199, %r1195, %p497;\n\tsetp.le.f32 \t%p498, %r1200, 0f00000000;\n\tselp.f32 \t%r1818, 0f00000000, %r1200, %p498;\n\t@%p30 bra \t$L__BB0_172;\n\tabs.f32 \t%r1201, %r1818;\n\tsetp.eq.f32 \t%p500, %r1818, 0f7F800000;\n\tsetp.lt.f32 \t%p501, %r1201, 0f00800000;\n\tsetp.num.f32 \t%p502, %r1818, %r1818;\n\tsetp.ltu.f32 \t%p503, %r1818, 0f00000000;\n\tor.pred \t%p504, %p503, %p501;\n\tselp.f32 \t%r1203, 0f00000000, 0f7FC00000, %p501;\n\tor.pred \t%p505, %p500, %p504;\n\tselp.f32 \t%r1204, %r1203, %r1818, %p504;\n\tselp.f32 \t%r1817, %r1204, %r1818, %p502;\n\t@%p505 bra \t$L__BB0_171;\n\tmul.f32 \t%r1202, %r1818, 0f5F800000;\n\tsetp.lt.f32 \t%p499, %r1818, 0f0F800000;\n\tselp.f32 \t%r49, %r1202, %r1818, %p499;\n\tshr.u32 \t%r1205, %r49, 1;\n\tadd.s32 \t%r1206, %r1205, 532487669;\n\tdiv.rn.f32 \t%r1207, %r49, %r1206;\n\tadd.f32 \t%r1208, %r1207, %r1206;\n\tmul.f32 \t%r1209, %r1208, 0f3F000000;\n\tdiv.rn.f32 \t%r1210, %r49, %r1209;\n\tfma.rn.f32 \t%r1211, %r1208, 0f3F000000, %r1210;\n\tmul.f32 \t%r1212, %r1211, 0f3F000000;\n\tdiv.rn.f32 \t%r1213, %r49, %r1212;\n\tfma.rn.f32 \t%r1214, %r1211, 0f3F000000, %r1213;\n\tmul.f32 \t%r50, %r1214, 0f3F000000;\n\tneg.f32 \t%r1215, %r50;\n\tfma.rn.f32 \t%r1216, %r1215, %r50, %r49;\n\tabs.f32 \t%r1815, %r1216;\n\tmov.b64 \t%rd157, 0;\n\tmov.b32 \t%r1816, %r50;\n$L__BB0_169:\n\tsetp.eq.b64 \t%p506, %rd157, 2;\n\tselp.b32 \t%r1217, -2, 2, %p506;\n\tsetp.eq.b64 \t%p507, %rd157, 1;\n\tsetp.eq.b64 \t%p508, %rd157, 0;\n\tselp.b32 \t%r1218, 1, %r1217, %p507;\n\tselp.b32 \t%r1219, -1, %r1218, %p508;\n\tadd.s32 \t%r1220, %r1219, %r50;\n\tneg.f32 \t%r1221, %r1220;\n\tfma.rn.f32 \t%r1222, %r1221, %r1220, %r49;\n\tabs.f32 \t%r1223, %r1222;\n\tsetp.lt.f32 \t%p509, %r1223, %r1815;\n\tselp.f32 \t%r1816, %r1220, %r1816, %p509;\n\tselp.f32 \t%r1815, %r1223, %r1815, %p509;\n\tadd.s64 \t%rd157, %rd157, 1;\n\tsetp.ne.b64 \t%p510, %rd157, 4;\n\t@%p510 bra \t$L__BB0_169;\n\tmul.f32 \t%r1224, %r1816, 0f2F800000;\n\tselp.f32 \t%r1817, %r1224, %r1816, %p499;\n$L__BB0_171:\n\tand.b32 \t%r1225, %r1817, -2147483648;\n\tand.b32 \t%r1226, %r1817, 8388607;\n\tsetp.ne.b32 \t%p511, %r1226, 0;\n\tand.b32 \t%r1227, %r1817, 2139095040;\n\tsetp.eq.b32 \t%p512, %r1227, 0;\n\tselp.f32 \t%r1228, %r1225, %r1817, %p511;\n\tselp.f32 \t%r1818, %r1228, %r1817, %p512;\n$L__BB0_172:\n\tst.global.b32 \t[%rd24+4], %r1818;\n$L__BB0_173:\n\t@%p76 bra \t$L__BB0_181;\n\tld.global.b32 \t%r1229, [%rd11+8];\n\tand.b32 \t%r1230, %r1229, -2147483648;\n\tand.b32 \t%r1231, %r1229, 8388607;\n\tsetp.ne.b32 \t%p513, %r1231, 0;\n\tand.b32 \t%r1232, %r1229, 2139095040;\n\tsetp.eq.b32 \t%p514, %r1232, 0;\n\tselp.f32 \t%r1233, %r1230, %r1229, %p513;\n\tselp.f32 \t%r1234, %r1233, %r1229, %p514;\n\tadd.f32 \t%r1235, %r46, %r1234;\n\tand.b32 \t%r1236, %r1235, -2147483648;\n\tand.b32 \t%r1237, %r1235, 8388607;\n\tsetp.ne.b32 \t%p515, %r1237, 0;\n\tand.b32 \t%r1238, %r1235, 2139095040;\n\tsetp.eq.b32 \t%p516, %r1238, 0;\n\tselp.f32 \t%r1239, %r1236, %r1235, %p515;\n\tselp.f32 \t%r1240, %r1239, %r1235, %p516;\n\tfma.rn.f32 \t%r1241, %r1721, 0fC0000000, %r1240;\n\tand.b32 \t%r1242, %r1241, -2147483648;\n\tand.b32 \t%r1243, %r1241, 8388607;\n\tsetp.ne.b32 \t%p517, %r1243, 0;\n\tand.b32 \t%r1244, %r1241, 2139095040;\n\tsetp.eq.b32 \t%p518, %r1244, 0;\n\tselp.f32 \t%r1245, %r1242, %r1241, %p517;\n\tselp.f32 \t%r1246, %r1245, %r1241, %p518;\n\tsetp.le.f32 \t%p519, %r1246, 0f00000000;\n\tselp.f32 \t%r1822, 0f00000000, %r1246, %p519;\n\t@%p30 bra \t$L__BB0_180;\n\tabs.f32 \t%r1247, %r1822;\n\tsetp.eq.f32 \t%p521, %r1822, 0f7F800000;\n\tsetp.lt.f32 \t%p522, %r1247, 0f00800000;\n\tsetp.num.f32 \t%p523, %r1822, %r1822;\n\tsetp.ltu.f32 \t%p524, %r1822, 0f00000000;\n\tor.pred \t%p525, %p524, %p522;\n\tselp.f32 \t%r1249, 0f00000000, 0f7FC00000, %p522;\n\tor.pred \t%p526, %p521, %p525;\n\tselp.f32 \t%r1250, %r1249, %r1822, %p525;\n\tselp.f32 \t%r1821, %r1250, %r1822, %p523;\n\t@%p526 bra \t$L__BB0_179;\n\tmul.f32 \t%r1248, %r1822, 0f5F800000;\n\tsetp.lt.f32 \t%p520, %r1822, 0f0F800000;\n\tselp.f32 \t%r51, %r1248, %r1822, %p520;\n\tshr.u32 \t%r1251, %r51, 1;\n\tadd.s32 \t%r1252, %r1251, 532487669;\n\tdiv.rn.f32 \t%r1253, %r51, %r1252;\n\tadd.f32 \t%r1254, %r1253, %r1252;\n\tmul.f32 \t%r1255, %r1254, 0f3F000000;\n\tdiv.rn.f32 \t%r1256, %r51, %r1255;\n\tfma.rn.f32 \t%r1257, %r1254, 0f3F000000, %r1256;\n\tmul.f32 \t%r1258, %r1257, 0f3F000000;\n\tdiv.rn.f32 \t%r1259, %r51, %r1258;\n\tfma.rn.f32 \t%r1260, %r1257, 0f3F000000, %r1259;\n\tmul.f32 \t%r52, %r1260, 0f3F000000;\n\tneg.f32 \t%r1261, %r52;\n\tfma.rn.f32 \t%r1262, %r1261, %r52, %r51;\n\tabs.f32 \t%r1819, %r1262;\n\tmov.b64 \t%rd158, 0;\n\tmov.b32 \t%r1820, %r52;\n$L__BB0_177:\n\tsetp.eq.b64 \t%p527, %rd158, 2;\n\tselp.b32 \t%r1263, -2, 2, %p527;\n\tsetp.eq.b64 \t%p528, %rd158, 1;\n\tsetp.eq.b64 \t%p529, %rd158, 0;\n\tselp.b32 \t%r1264, 1, %r1263, %p528;\n\tselp.b32 \t%r1265, -1, %r1264, %p529;\n\tadd.s32 \t%r1266, %r1265, %r52;\n\tneg.f32 \t%r1267, %r1266;\n\tfma.rn.f32 \t%r1268, %r1267, %r1266, %r51;\n\tabs.f32 \t%r1269, %r1268;\n\tsetp.lt.f32 \t%p530, %r1269, %r1819;\n\tselp.f32 \t%r1820, %r1266, %r1820, %p530;\n\tselp.f32 \t%r1819, %r1269, %r1819, %p530;\n\tadd.s64 \t%rd158, %rd158, 1;\n\tsetp.ne.b64 \t%p531, %rd158, 4;\n\t@%p531 bra \t$L__BB0_177;\n\tmul.f32 \t%r1270, %r1820, 0f2F800000;\n\tselp.f32 \t%r1821, %r1270, %r1820, %p520;\n$L__BB0_179:\n\tand.b32 \t%r1271, %r1821, -2147483648;\n\tand.b32 \t%r1272, %r1821, 8388607;\n\tsetp.ne.b32 \t%p532, %r1272, 0;\n\tand.b32 \t%r1273, %r1821, 2139095040;\n\tsetp.eq.b32 \t%p533, %r1273, 0;\n\tselp.f32 \t%r1274, %r1271, %r1821, %p532;\n\tselp.f32 \t%r1822, %r1274, %r1821, %p533;\n$L__BB0_180:\n\tst.global.b32 \t[%rd24+8], %r1822;\n$L__BB0_181:\n\t@%p98 bra \t$L__BB0_189;\n\tld.global.b32 \t%r1275, [%rd11+12];\n\tand.b32 \t%r1276, %r1275, -2147483648;\n\tand.b32 \t%r1277, %r1275, 8388607;\n\tsetp.ne.b32 \t%p534, %r1277, 0;\n\tand.b32 \t%r1278, %r1275, 2139095040;\n\tsetp.eq.b32 \t%p535, %r1278, 0;\n\tselp.f32 \t%r1279, %r1276, %r1275, %p534;\n\tselp.f32 \t%r1280, %r1279, %r1275, %p535;\n\tadd.f32 \t%r1281, %r46, %r1280;\n\tand.b32 \t%r1282, %r1281, -2147483648;\n\tand.b32 \t%r1283, %r1281, 8388607;\n\tsetp.ne.b32 \t%p536, %r1283, 0;\n\tand.b32 \t%r1284, %r1281, 2139095040;\n\tsetp.eq.b32 \t%p537, %r1284, 0;\n\tselp.f32 \t%r1285, %r1282, %r1281, %p536;\n\tselp.f32 \t%r1286, %r1285, %r1281, %p537;\n\tfma.rn.f32 \t%r1287, %r1722, 0fC0000000, %r1286;\n\tand.b32 \t%r1288, %r1287, -2147483648;\n\tand.b32 \t%r1289, %r1287, 8388607;\n\tsetp.ne.b32 \t%p538, %r1289, 0;\n\tand.b32 \t%r1290, %r1287, 2139095040;\n\tsetp.eq.b32 \t%p539, %r1290, 0;\n\tselp.f32 \t%r1291, %r1288, %r1287, %p538;\n\tselp.f32 \t%r1292, %r1291, %r1287, %p539;\n\tsetp.le.f32 \t%p540, %r1292, 0f00000000;\n\tselp.f32 \t%r1826, 0f00000000, %r1292, %p540;\n\t@%p30 bra \t$L__BB0_188;\n\tabs.f32 \t%r1293, %r1826;\n\tsetp.eq.f32 \t%p542, %r1826, 0f7F800000;\n\tsetp.lt.f32 \t%p543, %r1293, 0f00800000;\n\tsetp.num.f32 \t%p544, %r1826, %r1826;\n\tsetp.ltu.f32 \t%p545, %r1826, 0f00000000;\n\tor.pred \t%p546, %p545, %p543;\n\tselp.f32 \t%r1295, 0f00000000, 0f7FC00000, %p543;\n\tor.pred \t%p547, %p542, %p546;\n\tselp.f32 \t%r1296, %r1295, %r1826, %p546;\n\tselp.f32 \t%r1825, %r1296, %r1826, %p544;\n\t@%p547 bra \t$L__BB0_187;\n\tmul.f32 \t%r1294, %r1826, 0f5F800000;\n\tsetp.lt.f32 \t%p541, %r1826, 0f0F800000;\n\tselp.f32 \t%r53, %r1294, %r1826, %p541;\n\tshr.u32 \t%r1297, %r53, 1;\n\tadd.s32 \t%r1298, %r1297, 532487669;\n\tdiv.rn.f32 \t%r1299, %r53, %r1298;\n\tadd.f32 \t%r1300, %r1299, %r1298;\n\tmul.f32 \t%r1301, %r1300, 0f3F000000;\n\tdiv.rn.f32 \t%r1302, %r53, %r1301;\n\tfma.rn.f32 \t%r1303, %r1300, 0f3F000000, %r1302;\n\tmul.f32 \t%r1304, %r1303, 0f3F000000;\n\tdiv.rn.f32 \t%r1305, %r53, %r1304;\n\tfma.rn.f32 \t%r1306, %r1303, 0f3F000000, %r1305;\n\tmul.f32 \t%r54, %r1306, 0f3F000000;\n\tneg.f32 \t%r1307, %r54;\n\tfma.rn.f32 \t%r1308, %r1307, %r54, %r53;\n\tabs.f32 \t%r1823, %r1308;\n\tmov.b64 \t%rd159, 0;\n\tmov.b32 \t%r1824, %r54;\n$L__BB0_185:\n\tsetp.eq.b64 \t%p548, %rd159, 2;\n\tselp.b32 \t%r1309, -2, 2, %p548;\n\tsetp.eq.b64 \t%p549, %rd159, 1;\n\tsetp.eq.b64 \t%p550, %rd159, 0;\n\tselp.b32 \t%r1310, 1, %r1309, %p549;\n\tselp.b32 \t%r1311, -1, %r1310, %p550;\n\tadd.s32 \t%r1312, %r1311, %r54;\n\tneg.f32 \t%r1313, %r1312;\n\tfma.rn.f32 \t%r1314, %r1313, %r1312, %r53;\n\tabs.f32 \t%r1315, %r1314;\n\tsetp.lt.f32 \t%p551, %r1315, %r1823;\n\tselp.f32 \t%r1824, %r1312, %r1824, %p551;\n\tselp.f32 \t%r1823, %r1315, %r1823, %p551;\n\tadd.s64 \t%rd159, %rd159, 1;\n\tsetp.ne.b64 \t%p552, %rd159, 4;\n\t@%p552 bra \t$L__BB0_185;\n\tmul.f32 \t%r1316, %r1824, 0f2F800000;\n\tselp.f32 \t%r1825, %r1316, %r1824, %p541;\n$L__BB0_187:\n\tand.b32 \t%r1317, %r1825, -2147483648;\n\tand.b32 \t%r1318, %r1825, 8388607;\n\tsetp.ne.b32 \t%p553, %r1318, 0;\n\tand.b32 \t%r1319, %r1825, 2139095040;\n\tsetp.eq.b32 \t%p554, %r1319, 0;\n\tselp.f32 \t%r1320, %r1317, %r1825, %p553;\n\tselp.f32 \t%r1826, %r1320, %r1825, %p554;\n$L__BB0_188:\n\tst.global.b32 \t[%rd24+12], %r1826;\n$L__BB0_189:\n\tor.b64 \t%rd19, %rd16, 7;\n\tsetp.ge.s64 \t%p555, %rd21, %rd3;\n\t@%p555 bra \t$L__BB0_220;\n\tmul.wide.s32 \t%rd65, %r76, 24;\n\tadd.s64 \t%rd22, %rd17, %rd65;\n\tld.global.b32 \t%r1321, [%rd18+24];\n\tand.b32 \t%r1322, %r1321, -2147483648;\n\tand.b32 \t%r1323, %r1321, 8388607;\n\tsetp.ne.b32 \t%p556, %r1323, 0;\n\tand.b32 \t%r1324, %r1321, 2139095040;\n\tsetp.eq.b32 \t%p557, %r1324, 0;\n\tselp.f32 \t%r1325, %r1322, %r1321, %p556;\n\tselp.f32 \t%r55, %r1325, %r1321, %p557;\n\tld.global.b32 \t%r1326, [%rd11];\n\tand.b32 \t%r1327, %r1326, -2147483648;\n\tand.b32 \t%r1328, %r1326, 8388607;\n\tsetp.ne.b32 \t%p558, %r1328, 0;\n\tand.b32 \t%r1329, %r1326, 2139095040;\n\tsetp.eq.b32 \t%p559, %r1329, 0;\n\tselp.f32 \t%r1330, %r1327, %r1326, %p558;\n\tselp.f32 \t%r1331, %r1330, %r1326, %p559;\n\tadd.f32 \t%r1332, %r55, %r1331;\n\tand.b32 \t%r1333, %r1332, -2147483648;\n\tand.b32 \t%r1334, %r1332, 8388607;\n\tsetp.ne.b32 \t%p560, %r1334, 0;\n\tand.b32 \t%r1335, %r1332, 2139095040;\n\tsetp.eq.b32 \t%p561, %r1335, 0;\n\tselp.f32 \t%r1336, %r1333, %r1332, %p560;\n\tselp.f32 \t%r1337, %r1336, %r1332, %p561;\n\tfma.rn.f32 \t%r1338, %r1723, 0fC0000000, %r1337;\n\tand.b32 \t%r1339, %r1338, -2147483648;\n\tand.b32 \t%r1340, %r1338, 8388607;\n\tsetp.ne.b32 \t%p562, %r1340, 0;\n\tand.b32 \t%r1341, %r1338, 2139095040;\n\tsetp.eq.b32 \t%p563, %r1341, 0;\n\tselp.f32 \t%r1342, %r1339, %r1338, %p562;\n\tselp.f32 \t%r1343, %r1342, %r1338, %p563;\n\tsetp.le.f32 \t%p564, %r1343, 0f00000000;\n\tselp.f32 \t%r1830, 0f00000000, %r1343, %p564;\n\t@%p30 bra \t$L__BB0_196;\n\tabs.f32 \t%r1344, %r1830;\n\tsetp.eq.f32 \t%p566, %r1830, 0f7F800000;\n\tsetp.lt.f32 \t%p567, %r1344, 0f00800000;\n\tsetp.num.f32 \t%p568, %r1830, %r1830;\n\tsetp.ltu.f32 \t%p569, %r1830, 0f00000000;\n\tor.pred \t%p570, %p569, %p567;\n\tselp.f32 \t%r1346, 0f00000000, 0f7FC00000, %p567;\n\tor.pred \t%p571, %p566, %p570;\n\tselp.f32 \t%r1347, %r1346, %r1830, %p570;\n\tselp.f32 \t%r1829, %r1347, %r1830, %p568;\n\t@%p571 bra \t$L__BB0_195;\n\tmul.f32 \t%r1345, %r1830, 0f5F800000;\n\tsetp.lt.f32 \t%p565, %r1830, 0f0F800000;\n\tselp.f32 \t%r56, %r1345, %r1830, %p565;\n\tshr.u32 \t%r1348, %r56, 1;\n\tadd.s32 \t%r1349, %r1348, 532487669;\n\tdiv.rn.f32 \t%r1350, %r56, %r1349;\n\tadd.f32 \t%r1351, %r1350, %r1349;\n\tmul.f32 \t%r1352, %r1351, 0f3F000000;\n\tdiv.rn.f32 \t%r1353, %r56, %r1352;\n\tfma.rn.f32 \t%r1354, %r1351, 0f3F000000, %r1353;\n\tmul.f32 \t%r1355, %r1354, 0f3F000000;\n\tdiv.rn.f32 \t%r1356, %r56, %r1355;\n\tfma.rn.f32 \t%r1357, %r1354, 0f3F000000, %r1356;\n\tmul.f32 \t%r57, %r1357, 0f3F000000;\n\tneg.f32 \t%r1358, %r57;\n\tfma.rn.f32 \t%r1359, %r1358, %r57, %r56;\n\tabs.f32 \t%r1827, %r1359;\n\tmov.b64 \t%rd160, 0;\n\tmov.b32 \t%r1828, %r57;\n$L__BB0_193:\n\tsetp.eq.b64 \t%p572, %rd160, 2;\n\tselp.b32 \t%r1360, -2, 2, %p572;\n\tsetp.eq.b64 \t%p573, %rd160, 1;\n\tsetp.eq.b64 \t%p574, %rd160, 0;\n\tselp.b32 \t%r1361, 1, %r1360, %p573;\n\tselp.b32 \t%r1362, -1, %r1361, %p574;\n\tadd.s32 \t%r1363, %r1362, %r57;\n\tneg.f32 \t%r1364, %r1363;\n\tfma.rn.f32 \t%r1365, %r1364, %r1363, %r56;\n\tabs.f32 \t%r1366, %r1365;\n\tsetp.lt.f32 \t%p575, %r1366, %r1827;\n\tselp.f32 \t%r1828, %r1363, %r1828, %p575;\n\tselp.f32 \t%r1827, %r1366, %r1827, %p575;\n\tadd.s64 \t%rd160, %rd160, 1;\n\tsetp.ne.b64 \t%p576, %rd160, 4;\n\t@%p576 bra \t$L__BB0_193;\n\tmul.f32 \t%r1367, %r1828, 0f2F800000;\n\tselp.f32 \t%r1829, %r1367, %r1828, %p565;\n$L__BB0_195:\n\tand.b32 \t%r1368, %r1829, -2147483648;\n\tand.b32 \t%r1369, %r1829, 8388607;\n\tsetp.ne.b32 \t%p577, %r1369, 0;\n\tand.b32 \t%r1370, %r1829, 2139095040;\n\tsetp.eq.b32 \t%p578, %r1370, 0;\n\tselp.f32 \t%r1371, %r1368, %r1829, %p577;\n\tselp.f32 \t%r1830, %r1371, %r1829, %p578;\n$L__BB0_196:\n\tst.global.b32 \t[%rd22], %r1830;\n\t@%p54 bra \t$L__BB0_204;\n\tld.global.b32 \t%r1372, [%rd11+4];\n\tand.b32 \t%r1373, %r1372, -2147483648;\n\tand.b32 \t%r1374, %r1372, 8388607;\n\tsetp.ne.b32 \t%p579, %r1374, 0;\n\tand.b32 \t%r1375, %r1372, 2139095040;\n\tsetp.eq.b32 \t%p580, %r1375, 0;\n\tselp.f32 \t%r1376, %r1373, %r1372, %p579;\n\tselp.f32 \t%r1377, %r1376, %r1372, %p580;\n\tadd.f32 \t%r1378, %r55, %r1377;\n\tand.b32 \t%r1379, %r1378, -2147483648;\n\tand.b32 \t%r1380, %r1378, 8388607;\n\tsetp.ne.b32 \t%p581, %r1380, 0;\n\tand.b32 \t%r1381, %r1378, 2139095040;\n\tsetp.eq.b32 \t%p582, %r1381, 0;\n\tselp.f32 \t%r1382, %r1379, %r1378, %p581;\n\tselp.f32 \t%r1383, %r1382, %r1378, %p582;\n\tfma.rn.f32 \t%r1384, %r1724, 0fC0000000, %r1383;\n\tand.b32 \t%r1385, %r1384, -2147483648;\n\tand.b32 \t%r1386, %r1384, 8388607;\n\tsetp.ne.b32 \t%p583, %r1386, 0;\n\tand.b32 \t%r1387, %r1384, 2139095040;\n\tsetp.eq.b32 \t%p584, %r1387, 0;\n\tselp.f32 \t%r1388, %r1385, %r1384, %p583;\n\tselp.f32 \t%r1389, %r1388, %r1384, %p584;\n\tsetp.le.f32 \t%p585, %r1389, 0f00000000;\n\tselp.f32 \t%r1834, 0f00000000, %r1389, %p585;\n\t@%p30 bra \t$L__BB0_203;\n\tabs.f32 \t%r1390, %r1834;\n\tsetp.eq.f32 \t%p587, %r1834, 0f7F800000;\n\tsetp.lt.f32 \t%p588, %r1390, 0f00800000;\n\tsetp.num.f32 \t%p589, %r1834, %r1834;\n\tsetp.ltu.f32 \t%p590, %r1834, 0f00000000;\n\tor.pred \t%p591, %p590, %p588;\n\tselp.f32 \t%r1392, 0f00000000, 0f7FC00000, %p588;\n\tor.pred \t%p592, %p587, %p591;\n\tselp.f32 \t%r1393, %r1392, %r1834, %p591;\n\tselp.f32 \t%r1833, %r1393, %r1834, %p589;\n\t@%p592 bra \t$L__BB0_202;\n\tmul.f32 \t%r1391, %r1834, 0f5F800000;\n\tsetp.lt.f32 \t%p586, %r1834, 0f0F800000;\n\tselp.f32 \t%r58, %r1391, %r1834, %p586;\n\tshr.u32 \t%r1394, %r58, 1;\n\tadd.s32 \t%r1395, %r1394, 532487669;\n\tdiv.rn.f32 \t%r1396, %r58, %r1395;\n\tadd.f32 \t%r1397, %r1396, %r1395;\n\tmul.f32 \t%r1398, %r1397, 0f3F000000;\n\tdiv.rn.f32 \t%r1399, %r58, %r1398;\n\tfma.rn.f32 \t%r1400, %r1397, 0f3F000000, %r1399;\n\tmul.f32 \t%r1401, %r1400, 0f3F000000;\n\tdiv.rn.f32 \t%r1402, %r58, %r1401;\n\tfma.rn.f32 \t%r1403, %r1400, 0f3F000000, %r1402;\n\tmul.f32 \t%r59, %r1403, 0f3F000000;\n\tneg.f32 \t%r1404, %r59;\n\tfma.rn.f32 \t%r1405, %r1404, %r59, %r58;\n\tabs.f32 \t%r1831, %r1405;\n\tmov.b64 \t%rd161, 0;\n\tmov.b32 \t%r1832, %r59;\n$L__BB0_200:\n\tsetp.eq.b64 \t%p593, %rd161, 2;\n\tselp.b32 \t%r1406, -2, 2, %p593;\n\tsetp.eq.b64 \t%p594, %rd161, 1;\n\tsetp.eq.b64 \t%p595, %rd161, 0;\n\tselp.b32 \t%r1407, 1, %r1406, %p594;\n\tselp.b32 \t%r1408, -1, %r1407, %p595;\n\tadd.s32 \t%r1409, %r1408, %r59;\n\tneg.f32 \t%r1410, %r1409;\n\tfma.rn.f32 \t%r1411, %r1410, %r1409, %r58;\n\tabs.f32 \t%r1412, %r1411;\n\tsetp.lt.f32 \t%p596, %r1412, %r1831;\n\tselp.f32 \t%r1832, %r1409, %r1832, %p596;\n\tselp.f32 \t%r1831, %r1412, %r1831, %p596;\n\tadd.s64 \t%rd161, %rd161, 1;\n\tsetp.ne.b64 \t%p597, %rd161, 4;\n\t@%p597 bra \t$L__BB0_200;\n\tmul.f32 \t%r1413, %r1832, 0f2F800000;\n\tselp.f32 \t%r1833, %r1413, %r1832, %p586;\n$L__BB0_202:\n\tand.b32 \t%r1414, %r1833, -2147483648;\n\tand.b32 \t%r1415, %r1833, 8388607;\n\tsetp.ne.b32 \t%p598, %r1415, 0;\n\tand.b32 \t%r1416, %r1833, 2139095040;\n\tsetp.eq.b32 \t%p599, %r1416, 0;\n\tselp.f32 \t%r1417, %r1414, %r1833, %p598;\n\tselp.f32 \t%r1834, %r1417, %r1833, %p599;\n$L__BB0_203:\n\tst.global.b32 \t[%rd22+4], %r1834;\n$L__BB0_204:\n\t@%p76 bra \t$L__BB0_212;\n\tld.global.b32 \t%r1418, [%rd11+8];\n\tand.b32 \t%r1419, %r1418, -2147483648;\n\tand.b32 \t%r1420, %r1418, 8388607;\n\tsetp.ne.b32 \t%p600, %r1420, 0;\n\tand.b32 \t%r1421, %r1418, 2139095040;\n\tsetp.eq.b32 \t%p601, %r1421, 0;\n\tselp.f32 \t%r1422, %r1419, %r1418, %p600;\n\tselp.f32 \t%r1423, %r1422, %r1418, %p601;\n\tadd.f32 \t%r1424, %r55, %r1423;\n\tand.b32 \t%r1425, %r1424, -2147483648;\n\tand.b32 \t%r1426, %r1424, 8388607;\n\tsetp.ne.b32 \t%p602, %r1426, 0;\n\tand.b32 \t%r1427, %r1424, 2139095040;\n\tsetp.eq.b32 \t%p603, %r1427, 0;\n\tselp.f32 \t%r1428, %r1425, %r1424, %p602;\n\tselp.f32 \t%r1429, %r1428, %r1424, %p603;\n\tfma.rn.f32 \t%r1430, %r1725, 0fC0000000, %r1429;\n\tand.b32 \t%r1431, %r1430, -2147483648;\n\tand.b32 \t%r1432, %r1430, 8388607;\n\tsetp.ne.b32 \t%p604, %r1432, 0;\n\tand.b32 \t%r1433, %r1430, 2139095040;\n\tsetp.eq.b32 \t%p605, %r1433, 0;\n\tselp.f32 \t%r1434, %r1431, %r1430, %p604;\n\tselp.f32 \t%r1435, %r1434, %r1430, %p605;\n\tsetp.le.f32 \t%p606, %r1435, 0f00000000;\n\tselp.f32 \t%r1838, 0f00000000, %r1435, %p606;\n\t@%p30 bra \t$L__BB0_211;\n\tabs.f32 \t%r1436, %r1838;\n\tsetp.eq.f32 \t%p608, %r1838, 0f7F800000;\n\tsetp.lt.f32 \t%p609, %r1436, 0f00800000;\n\tsetp.num.f32 \t%p610, %r1838, %r1838;\n\tsetp.ltu.f32 \t%p611, %r1838, 0f00000000;\n\tor.pred \t%p612, %p611, %p609;\n\tselp.f32 \t%r1438, 0f00000000, 0f7FC00000, %p609;\n\tor.pred \t%p613, %p608, %p612;\n\tselp.f32 \t%r1439, %r1438, %r1838, %p612;\n\tselp.f32 \t%r1837, %r1439, %r1838, %p610;\n\t@%p613 bra \t$L__BB0_210;\n\tmul.f32 \t%r1437, %r1838, 0f5F800000;\n\tsetp.lt.f32 \t%p607, %r1838, 0f0F800000;\n\tselp.f32 \t%r60, %r1437, %r1838, %p607;\n\tshr.u32 \t%r1440, %r60, 1;\n\tadd.s32 \t%r1441, %r1440, 532487669;\n\tdiv.rn.f32 \t%r1442, %r60, %r1441;\n\tadd.f32 \t%r1443, %r1442, %r1441;\n\tmul.f32 \t%r1444, %r1443, 0f3F000000;\n\tdiv.rn.f32 \t%r1445, %r60, %r1444;\n\tfma.rn.f32 \t%r1446, %r1443, 0f3F000000, %r1445;\n\tmul.f32 \t%r1447, %r1446, 0f3F000000;\n\tdiv.rn.f32 \t%r1448, %r60, %r1447;\n\tfma.rn.f32 \t%r1449, %r1446, 0f3F000000, %r1448;\n\tmul.f32 \t%r61, %r1449, 0f3F000000;\n\tneg.f32 \t%r1450, %r61;\n\tfma.rn.f32 \t%r1451, %r1450, %r61, %r60;\n\tabs.f32 \t%r1835, %r1451;\n\tmov.b64 \t%rd162, 0;\n\tmov.b32 \t%r1836, %r61;\n$L__BB0_208:\n\tsetp.eq.b64 \t%p614, %rd162, 2;\n\tselp.b32 \t%r1452, -2, 2, %p614;\n\tsetp.eq.b64 \t%p615, %rd162, 1;\n\tsetp.eq.b64 \t%p616, %rd162, 0;\n\tselp.b32 \t%r1453, 1, %r1452, %p615;\n\tselp.b32 \t%r1454, -1, %r1453, %p616;\n\tadd.s32 \t%r1455, %r1454, %r61;\n\tneg.f32 \t%r1456, %r1455;\n\tfma.rn.f32 \t%r1457, %r1456, %r1455, %r60;\n\tabs.f32 \t%r1458, %r1457;\n\tsetp.lt.f32 \t%p617, %r1458, %r1835;\n\tselp.f32 \t%r1836, %r1455, %r1836, %p617;\n\tselp.f32 \t%r1835, %r1458, %r1835, %p617;\n\tadd.s64 \t%rd162, %rd162, 1;\n\tsetp.ne.b64 \t%p618, %rd162, 4;\n\t@%p618 bra \t$L__BB0_208;\n\tmul.f32 \t%r1459, %r1836, 0f2F800000;\n\tselp.f32 \t%r1837, %r1459, %r1836, %p607;\n$L__BB0_210:\n\tand.b32 \t%r1460, %r1837, -2147483648;\n\tand.b32 \t%r1461, %r1837, 8388607;\n\tsetp.ne.b32 \t%p619, %r1461, 0;\n\tand.b32 \t%r1462, %r1837, 2139095040;\n\tsetp.eq.b32 \t%p620, %r1462, 0;\n\tselp.f32 \t%r1463, %r1460, %r1837, %p619;\n\tselp.f32 \t%r1838, %r1463, %r1837, %p620;\n$L__BB0_211:\n\tst.global.b32 \t[%rd22+8], %r1838;\n$L__BB0_212:\n\t@%p98 bra \t$L__BB0_220;\n\tld.global.b32 \t%r1464, [%rd11+12];\n\tand.b32 \t%r1465, %r1464, -2147483648;\n\tand.b32 \t%r1466, %r1464, 8388607;\n\tsetp.ne.b32 \t%p621, %r1466, 0;\n\tand.b32 \t%r1467, %r1464, 2139095040;\n\tsetp.eq.b32 \t%p622, %r1467, 0;\n\tselp.f32 \t%r1468, %r1465, %r1464, %p621;\n\tselp.f32 \t%r1469, %r1468, %r1464, %p622;\n\tadd.f32 \t%r1470, %r55, %r1469;\n\tand.b32 \t%r1471, %r1470, -2147483648;\n\tand.b32 \t%r1472, %r1470, 8388607;\n\tsetp.ne.b32 \t%p623, %r1472, 0;\n\tand.b32 \t%r1473, %r1470, 2139095040;\n\tsetp.eq.b32 \t%p624, %r1473, 0;\n\tselp.f32 \t%r1474, %r1471, %r1470, %p623;\n\tselp.f32 \t%r1475, %r1474, %r1470, %p624;\n\tfma.rn.f32 \t%r1476, %r1726, 0fC0000000, %r1475;\n\tand.b32 \t%r1477, %r1476, -2147483648;\n\tand.b32 \t%r1478, %r1476, 8388607;\n\tsetp.ne.b32 \t%p625, %r1478, 0;\n\tand.b32 \t%r1479, %r1476, 2139095040;\n\tsetp.eq.b32 \t%p626, %r1479, 0;\n\tselp.f32 \t%r1480, %r1477, %r1476, %p625;\n\tselp.f32 \t%r1481, %r1480, %r1476, %p626;\n\tsetp.le.f32 \t%p627, %r1481, 0f00000000;\n\tselp.f32 \t%r1842, 0f00000000, %r1481, %p627;\n\t@%p30 bra \t$L__BB0_219;\n\tabs.f32 \t%r1482, %r1842;\n\tsetp.eq.f32 \t%p629, %r1842, 0f7F800000;\n\tsetp.lt.f32 \t%p630, %r1482, 0f00800000;\n\tsetp.num.f32 \t%p631, %r1842, %r1842;\n\tsetp.ltu.f32 \t%p632, %r1842, 0f00000000;\n\tor.pred \t%p633, %p632, %p630;\n\tselp.f32 \t%r1484, 0f00000000, 0f7FC00000, %p630;\n\tor.pred \t%p634, %p629, %p633;\n\tselp.f32 \t%r1485, %r1484, %r1842, %p633;\n\tselp.f32 \t%r1841, %r1485, %r1842, %p631;\n\t@%p634 bra \t$L__BB0_218;\n\tmul.f32 \t%r1483, %r1842, 0f5F800000;\n\tsetp.lt.f32 \t%p628, %r1842, 0f0F800000;\n\tselp.f32 \t%r62, %r1483, %r1842, %p628;\n\tshr.u32 \t%r1486, %r62, 1;\n\tadd.s32 \t%r1487, %r1486, 532487669;\n\tdiv.rn.f32 \t%r1488, %r62, %r1487;\n\tadd.f32 \t%r1489, %r1488, %r1487;\n\tmul.f32 \t%r1490, %r1489, 0f3F000000;\n\tdiv.rn.f32 \t%r1491, %r62, %r1490;\n\tfma.rn.f32 \t%r1492, %r1489, 0f3F000000, %r1491;\n\tmul.f32 \t%r1493, %r1492, 0f3F000000;\n\tdiv.rn.f32 \t%r1494, %r62, %r1493;\n\tfma.rn.f32 \t%r1495, %r1492, 0f3F000000, %r1494;\n\tmul.f32 \t%r63, %r1495, 0f3F000000;\n\tneg.f32 \t%r1496, %r63;\n\tfma.rn.f32 \t%r1497, %r1496, %r63, %r62;\n\tabs.f32 \t%r1839, %r1497;\n\tmov.b64 \t%rd163, 0;\n\tmov.b32 \t%r1840, %r63;\n$L__BB0_216:\n\tsetp.eq.b64 \t%p635, %rd163, 2;\n\tselp.b32 \t%r1498, -2, 2, %p635;\n\tsetp.eq.b64 \t%p636, %rd163, 1;\n\tsetp.eq.b64 \t%p637, %rd163, 0;\n\tselp.b32 \t%r1499, 1, %r1498, %p636;\n\tselp.b32 \t%r1500, -1, %r1499, %p637;\n\tadd.s32 \t%r1501, %r1500, %r63;\n\tneg.f32 \t%r1502, %r1501;\n\tfma.rn.f32 \t%r1503, %r1502, %r1501, %r62;\n\tabs.f32 \t%r1504, %r1503;\n\tsetp.lt.f32 \t%p638, %r1504, %r1839;\n\tselp.f32 \t%r1840, %r1501, %r1840, %p638;\n\tselp.f32 \t%r1839, %r1504, %r1839, %p638;\n\tadd.s64 \t%rd163, %rd163, 1;\n\tsetp.ne.b64 \t%p639, %rd163, 4;\n\t@%p639 bra \t$L__BB0_216;\n\tmul.f32 \t%r1505, %r1840, 0f2F800000;\n\tselp.f32 \t%r1841, %r1505, %r1840, %p628;\n$L__BB0_218:\n\tand.b32 \t%r1506, %r1841, -2147483648;\n\tand.b32 \t%r1507, %r1841, 8388607;\n\tsetp.ne.b32 \t%p640, %r1507, 0;\n\tand.b32 \t%r1508, %r1841, 2139095040;\n\tsetp.eq.b32 \t%p641, %r1508, 0;\n\tselp.f32 \t%r1509, %r1506, %r1841, %p640;\n\tselp.f32 \t%r1842, %r1509, %r1841, %p641;\n$L__BB0_219:\n\tst.global.b32 \t[%rd22+12], %r1842;\n$L__BB0_220:\n\tsetp.ge.s64 \t%p642, %rd19, %rd3;\n\t@%p642 bra \t$L__BB0_251;\n\tmul.wide.s32 \t%rd64, %r76, 28;\n\tadd.s64 \t%rd20, %rd17, %rd64;\n\tld.global.b32 \t%r1510, [%rd18+28];\n\tand.b32 \t%r1511, %r1510, -2147483648;\n\tand.b32 \t%r1512, %r1510, 8388607;\n\tsetp.ne.b32 \t%p643, %r1512, 0;\n\tand.b32 \t%r1513, %r1510, 2139095040;\n\tsetp.eq.b32 \t%p644, %r1513, 0;\n\tselp.f32 \t%r1514, %r1511, %r1510, %p643;\n\tselp.f32 \t%r64, %r1514, %r1510, %p644;\n\tld.global.b32 \t%r1515, [%rd11];\n\tand.b32 \t%r1516, %r1515, -2147483648;\n\tand.b32 \t%r1517, %r1515, 8388607;\n\tsetp.ne.b32 \t%p645, %r1517, 0;\n\tand.b32 \t%r1518, %r1515, 2139095040;\n\tsetp.eq.b32 \t%p646, %r1518, 0;\n\tselp.f32 \t%r1519, %r1516, %r1515, %p645;\n\tselp.f32 \t%r1520, %r1519, %r1515, %p646;\n\tadd.f32 \t%r1521, %r64, %r1520;\n\tand.b32 \t%r1522, %r1521, -2147483648;\n\tand.b32 \t%r1523, %r1521, 8388607;\n\tsetp.ne.b32 \t%p647, %r1523, 0;\n\tand.b32 \t%r1524, %r1521, 2139095040;\n\tsetp.eq.b32 \t%p648, %r1524, 0;\n\tselp.f32 \t%r1525, %r1522, %r1521, %p647;\n\tselp.f32 \t%r1526, %r1525, %r1521, %p648;\n\tfma.rn.f32 \t%r1527, %r1727, 0fC0000000, %r1526;\n\tand.b32 \t%r1528, %r1527, -2147483648;\n\tand.b32 \t%r1529, %r1527, 8388607;\n\tsetp.ne.b32 \t%p649, %r1529, 0;\n\tand.b32 \t%r1530, %r1527, 2139095040;\n\tsetp.eq.b32 \t%p650, %r1530, 0;\n\tselp.f32 \t%r1531, %r1528, %r1527, %p649;\n\tselp.f32 \t%r1532, %r1531, %r1527, %p650;\n\tsetp.le.f32 \t%p651, %r1532, 0f00000000;\n\tselp.f32 \t%r1846, 0f00000000, %r1532, %p651;\n\t@%p30 bra \t$L__BB0_227;\n\tabs.f32 \t%r1533, %r1846;\n\tsetp.eq.f32 \t%p653, %r1846, 0f7F800000;\n\tsetp.lt.f32 \t%p654, %r1533, 0f00800000;\n\tsetp.num.f32 \t%p655, %r1846, %r1846;\n\tsetp.ltu.f32 \t%p656, %r1846, 0f00000000;\n\tor.pred \t%p657, %p656, %p654;\n\tselp.f32 \t%r1535, 0f00000000, 0f7FC00000, %p654;\n\tor.pred \t%p658, %p653, %p657;\n\tselp.f32 \t%r1536, %r1535, %r1846, %p657;\n\tselp.f32 \t%r1845, %r1536, %r1846, %p655;\n\t@%p658 bra \t$L__BB0_226;\n\tmul.f32 \t%r1534, %r1846, 0f5F800000;\n\tsetp.lt.f32 \t%p652, %r1846, 0f0F800000;\n\tselp.f32 \t%r65, %r1534, %r1846, %p652;\n\tshr.u32 \t%r1537, %r65, 1;\n\tadd.s32 \t%r1538, %r1537, 532487669;\n\tdiv.rn.f32 \t%r1539, %r65, %r1538;\n\tadd.f32 \t%r1540, %r1539, %r1538;\n\tmul.f32 \t%r1541, %r1540, 0f3F000000;\n\tdiv.rn.f32 \t%r1542, %r65, %r1541;\n\tfma.rn.f32 \t%r1543, %r1540, 0f3F000000, %r1542;\n\tmul.f32 \t%r1544, %r1543, 0f3F000000;\n\tdiv.rn.f32 \t%r1545, %r65, %r1544;\n\tfma.rn.f32 \t%r1546, %r1543, 0f3F000000, %r1545;\n\tmul.f32 \t%r66, %r1546, 0f3F000000;\n\tneg.f32 \t%r1547, %r66;\n\tfma.rn.f32 \t%r1548, %r1547, %r66, %r65;\n\tabs.f32 \t%r1843, %r1548;\n\tmov.b64 \t%rd164, 0;\n\tmov.b32 \t%r1844, %r66;\n$L__BB0_224:\n\tsetp.eq.b64 \t%p659, %rd164, 2;\n\tselp.b32 \t%r1549, -2, 2, %p659;\n\tsetp.eq.b64 \t%p660, %rd164, 1;\n\tsetp.eq.b64 \t%p661, %rd164, 0;\n\tselp.b32 \t%r1550, 1, %r1549, %p660;\n\tselp.b32 \t%r1551, -1, %r1550, %p661;\n\tadd.s32 \t%r1552, %r1551, %r66;\n\tneg.f32 \t%r1553, %r1552;\n\tfma.rn.f32 \t%r1554, %r1553, %r1552, %r65;\n\tabs.f32 \t%r1555, %r1554;\n\tsetp.lt.f32 \t%p662, %r1555, %r1843;\n\tselp.f32 \t%r1844, %r1552, %r1844, %p662;\n\tselp.f32 \t%r1843, %r1555, %r1843, %p662;\n\tadd.s64 \t%rd164, %rd164, 1;\n\tsetp.ne.b64 \t%p663, %rd164, 4;\n\t@%p663 bra \t$L__BB0_224;\n\tmul.f32 \t%r1556, %r1844, 0f2F800000;\n\tselp.f32 \t%r1845, %r1556, %r1844, %p652;\n$L__BB0_226:\n\tand.b32 \t%r1557, %r1845, -2147483648;\n\tand.b32 \t%r1558, %r1845, 8388607;\n\tsetp.ne.b32 \t%p664, %r1558, 0;\n\tand.b32 \t%r1559, %r1845, 2139095040;\n\tsetp.eq.b32 \t%p665, %r1559, 0;\n\tselp.f32 \t%r1560, %r1557, %r1845, %p664;\n\tselp.f32 \t%r1846, %r1560, %r1845, %p665;\n$L__BB0_227:\n\tst.global.b32 \t[%rd20], %r1846;\n\t@%p54 bra \t$L__BB0_235;\n\tld.global.b32 \t%r1561, [%rd11+4];\n\tand.b32 \t%r1562, %r1561, -2147483648;\n\tand.b32 \t%r1563, %r1561, 8388607;\n\tsetp.ne.b32 \t%p666, %r1563, 0;\n\tand.b32 \t%r1564, %r1561, 2139095040;\n\tsetp.eq.b32 \t%p667, %r1564, 0;\n\tselp.f32 \t%r1565, %r1562, %r1561, %p666;\n\tselp.f32 \t%r1566, %r1565, %r1561, %p667;\n\tadd.f32 \t%r1567, %r64, %r1566;\n\tand.b32 \t%r1568, %r1567, -2147483648;\n\tand.b32 \t%r1569, %r1567, 8388607;\n\tsetp.ne.b32 \t%p668, %r1569, 0;\n\tand.b32 \t%r1570, %r1567, 2139095040;\n\tsetp.eq.b32 \t%p669, %r1570, 0;\n\tselp.f32 \t%r1571, %r1568, %r1567, %p668;\n\tselp.f32 \t%r1572, %r1571, %r1567, %p669;\n\tfma.rn.f32 \t%r1573, %r1728, 0fC0000000, %r1572;\n\tand.b32 \t%r1574, %r1573, -2147483648;\n\tand.b32 \t%r1575, %r1573, 8388607;\n\tsetp.ne.b32 \t%p670, %r1575, 0;\n\tand.b32 \t%r1576, %r1573, 2139095040;\n\tsetp.eq.b32 \t%p671, %r1576, 0;\n\tselp.f32 \t%r1577, %r1574, %r1573, %p670;\n\tselp.f32 \t%r1578, %r1577, %r1573, %p671;\n\tsetp.le.f32 \t%p672, %r1578, 0f00000000;\n\tselp.f32 \t%r1850, 0f00000000, %r1578, %p672;\n\t@%p30 bra \t$L__BB0_234;\n\tabs.f32 \t%r1579, %r1850;\n\tsetp.eq.f32 \t%p674, %r1850, 0f7F800000;\n\tsetp.lt.f32 \t%p675, %r1579, 0f00800000;\n\tsetp.num.f32 \t%p676, %r1850, %r1850;\n\tsetp.ltu.f32 \t%p677, %r1850, 0f00000000;\n\tor.pred \t%p678, %p677, %p675;\n\tselp.f32 \t%r1581, 0f00000000, 0f7FC00000, %p675;\n\tor.pred \t%p679, %p674, %p678;\n\tselp.f32 \t%r1582, %r1581, %r1850, %p678;\n\tselp.f32 \t%r1849, %r1582, %r1850, %p676;\n\t@%p679 bra \t$L__BB0_233;\n\tmul.f32 \t%r1580, %r1850, 0f5F800000;\n\tsetp.lt.f32 \t%p673, %r1850, 0f0F800000;\n\tselp.f32 \t%r67, %r1580, %r1850, %p673;\n\tshr.u32 \t%r1583, %r67, 1;\n\tadd.s32 \t%r1584, %r1583, 532487669;\n\tdiv.rn.f32 \t%r1585, %r67, %r1584;\n\tadd.f32 \t%r1586, %r1585, %r1584;\n\tmul.f32 \t%r1587, %r1586, 0f3F000000;\n\tdiv.rn.f32 \t%r1588, %r67, %r1587;\n\tfma.rn.f32 \t%r1589, %r1586, 0f3F000000, %r1588;\n\tmul.f32 \t%r1590, %r1589, 0f3F000000;\n\tdiv.rn.f32 \t%r1591, %r67, %r1590;\n\tfma.rn.f32 \t%r1592, %r1589, 0f3F000000, %r1591;\n\tmul.f32 \t%r68, %r1592, 0f3F000000;\n\tneg.f32 \t%r1593, %r68;\n\tfma.rn.f32 \t%r1594, %r1593, %r68, %r67;\n\tabs.f32 \t%r1847, %r1594;\n\tmov.b64 \t%rd165, 0;\n\tmov.b32 \t%r1848, %r68;\n$L__BB0_231:\n\tsetp.eq.b64 \t%p680, %rd165, 2;\n\tselp.b32 \t%r1595, -2, 2, %p680;\n\tsetp.eq.b64 \t%p681, %rd165, 1;\n\tsetp.eq.b64 \t%p682, %rd165, 0;\n\tselp.b32 \t%r1596, 1, %r1595, %p681;\n\tselp.b32 \t%r1597, -1, %r1596, %p682;\n\tadd.s32 \t%r1598, %r1597, %r68;\n\tneg.f32 \t%r1599, %r1598;\n\tfma.rn.f32 \t%r1600, %r1599, %r1598, %r67;\n\tabs.f32 \t%r1601, %r1600;\n\tsetp.lt.f32 \t%p683, %r1601, %r1847;\n\tselp.f32 \t%r1848, %r1598, %r1848, %p683;\n\tselp.f32 \t%r1847, %r1601, %r1847, %p683;\n\tadd.s64 \t%rd165, %rd165, 1;\n\tsetp.ne.b64 \t%p684, %rd165, 4;\n\t@%p684 bra \t$L__BB0_231;\n\tmul.f32 \t%r1602, %r1848, 0f2F800000;\n\tselp.f32 \t%r1849, %r1602, %r1848, %p673;\n$L__BB0_233:\n\tand.b32 \t%r1603, %r1849, -2147483648;\n\tand.b32 \t%r1604, %r1849, 8388607;\n\tsetp.ne.b32 \t%p685, %r1604, 0;\n\tand.b32 \t%r1605, %r1849, 2139095040;\n\tsetp.eq.b32 \t%p686, %r1605, 0;\n\tselp.f32 \t%r1606, %r1603, %r1849, %p685;\n\tselp.f32 \t%r1850, %r1606, %r1849, %p686;\n$L__BB0_234:\n\tst.global.b32 \t[%rd20+4], %r1850;\n$L__BB0_235:\n\t@%p76 bra \t$L__BB0_243;\n\tld.global.b32 \t%r1607, [%rd11+8];\n\tand.b32 \t%r1608, %r1607, -2147483648;\n\tand.b32 \t%r1609, %r1607, 8388607;\n\tsetp.ne.b32 \t%p687, %r1609, 0;\n\tand.b32 \t%r1610, %r1607, 2139095040;\n\tsetp.eq.b32 \t%p688, %r1610, 0;\n\tselp.f32 \t%r1611, %r1608, %r1607, %p687;\n\tselp.f32 \t%r1612, %r1611, %r1607, %p688;\n\tadd.f32 \t%r1613, %r64, %r1612;\n\tand.b32 \t%r1614, %r1613, -2147483648;\n\tand.b32 \t%r1615, %r1613, 8388607;\n\tsetp.ne.b32 \t%p689, %r1615, 0;\n\tand.b32 \t%r1616, %r1613, 2139095040;\n\tsetp.eq.b32 \t%p690, %r1616, 0;\n\tselp.f32 \t%r1617, %r1614, %r1613, %p689;\n\tselp.f32 \t%r1618, %r1617, %r1613, %p690;\n\tfma.rn.f32 \t%r1619, %r1729, 0fC0000000, %r1618;\n\tand.b32 \t%r1620, %r1619, -2147483648;\n\tand.b32 \t%r1621, %r1619, 8388607;\n\tsetp.ne.b32 \t%p691, %r1621, 0;\n\tand.b32 \t%r1622, %r1619, 2139095040;\n\tsetp.eq.b32 \t%p692, %r1622, 0;\n\tselp.f32 \t%r1623, %r1620, %r1619, %p691;\n\tselp.f32 \t%r1624, %r1623, %r1619, %p692;\n\tsetp.le.f32 \t%p693, %r1624, 0f00000000;\n\tselp.f32 \t%r1854, 0f00000000, %r1624, %p693;\n\t@%p30 bra \t$L__BB0_242;\n\tabs.f32 \t%r1625, %r1854;\n\tsetp.eq.f32 \t%p695, %r1854, 0f7F800000;\n\tsetp.lt.f32 \t%p696, %r1625, 0f00800000;\n\tsetp.num.f32 \t%p697, %r1854, %r1854;\n\tsetp.ltu.f32 \t%p698, %r1854, 0f00000000;\n\tor.pred \t%p699, %p698, %p696;\n\tselp.f32 \t%r1627, 0f00000000, 0f7FC00000, %p696;\n\tor.pred \t%p700, %p695, %p699;\n\tselp.f32 \t%r1628, %r1627, %r1854, %p699;\n\tselp.f32 \t%r1853, %r1628, %r1854, %p697;\n\t@%p700 bra \t$L__BB0_241;\n\tmul.f32 \t%r1626, %r1854, 0f5F800000;\n\tsetp.lt.f32 \t%p694, %r1854, 0f0F800000;\n\tselp.f32 \t%r69, %r1626, %r1854, %p694;\n\tshr.u32 \t%r1629, %r69, 1;\n\tadd.s32 \t%r1630, %r1629, 532487669;\n\tdiv.rn.f32 \t%r1631, %r69, %r1630;\n\tadd.f32 \t%r1632, %r1631, %r1630;\n\tmul.f32 \t%r1633, %r1632, 0f3F000000;\n\tdiv.rn.f32 \t%r1634, %r69, %r1633;\n\tfma.rn.f32 \t%r1635, %r1632, 0f3F000000, %r1634;\n\tmul.f32 \t%r1636, %r1635, 0f3F000000;\n\tdiv.rn.f32 \t%r1637, %r69, %r1636;\n\tfma.rn.f32 \t%r1638, %r1635, 0f3F000000, %r1637;\n\tmul.f32 \t%r70, %r1638, 0f3F000000;\n\tneg.f32 \t%r1639, %r70;\n\tfma.rn.f32 \t%r1640, %r1639, %r70, %r69;\n\tabs.f32 \t%r1851, %r1640;\n\tmov.b64 \t%rd166, 0;\n\tmov.b32 \t%r1852, %r70;\n$L__BB0_239:\n\tsetp.eq.b64 \t%p701, %rd166, 2;\n\tselp.b32 \t%r1641, -2, 2, %p701;\n\tsetp.eq.b64 \t%p702, %rd166, 1;\n\tsetp.eq.b64 \t%p703, %rd166, 0;\n\tselp.b32 \t%r1642, 1, %r1641, %p702;\n\tselp.b32 \t%r1643, -1, %r1642, %p703;\n\tadd.s32 \t%r1644, %r1643, %r70;\n\tneg.f32 \t%r1645, %r1644;\n\tfma.rn.f32 \t%r1646, %r1645, %r1644, %r69;\n\tabs.f32 \t%r1647, %r1646;\n\tsetp.lt.f32 \t%p704, %r1647, %r1851;\n\tselp.f32 \t%r1852, %r1644, %r1852, %p704;\n\tselp.f32 \t%r1851, %r1647, %r1851, %p704;\n\tadd.s64 \t%rd166, %rd166, 1;\n\tsetp.ne.b64 \t%p705, %rd166, 4;\n\t@%p705 bra \t$L__BB0_239;\n\tmul.f32 \t%r1648, %r1852, 0f2F800000;\n\tselp.f32 \t%r1853, %r1648, %r1852, %p694;\n$L__BB0_241:\n\tand.b32 \t%r1649, %r1853, -2147483648;\n\tand.b32 \t%r1650, %r1853, 8388607;\n\tsetp.ne.b32 \t%p706, %r1650, 0;\n\tand.b32 \t%r1651, %r1853, 2139095040;\n\tsetp.eq.b32 \t%p707, %r1651, 0;\n\tselp.f32 \t%r1652, %r1649, %r1853, %p706;\n\tselp.f32 \t%r1854, %r1652, %r1853, %p707;\n$L__BB0_242:\n\tst.global.b32 \t[%rd20+8], %r1854;\n$L__BB0_243:\n\t@%p98 bra \t$L__BB0_251;\n\tld.global.b32 \t%r1653, [%rd11+12];\n\tand.b32 \t%r1654, %r1653, -2147483648;\n\tand.b32 \t%r1655, %r1653, 8388607;\n\tsetp.ne.b32 \t%p708, %r1655, 0;\n\tand.b32 \t%r1656, %r1653, 2139095040;\n\tsetp.eq.b32 \t%p709, %r1656, 0;\n\tselp.f32 \t%r1657, %r1654, %r1653, %p708;\n\tselp.f32 \t%r1658, %r1657, %r1653, %p709;\n\tadd.f32 \t%r1659, %r64, %r1658;\n\tand.b32 \t%r1660, %r1659, -2147483648;\n\tand.b32 \t%r1661, %r1659, 8388607;\n\tsetp.ne.b32 \t%p710, %r1661, 0;\n\tand.b32 \t%r1662, %r1659, 2139095040;\n\tsetp.eq.b32 \t%p711, %r1662, 0;\n\tselp.f32 \t%r1663, %r1660, %r1659, %p710;\n\tselp.f32 \t%r1664, %r1663, %r1659, %p711;\n\tfma.rn.f32 \t%r1665, %r1730, 0fC0000000, %r1664;\n\tand.b32 \t%r1666, %r1665, -2147483648;\n\tand.b32 \t%r1667, %r1665, 8388607;\n\tsetp.ne.b32 \t%p712, %r1667, 0;\n\tand.b32 \t%r1668, %r1665, 2139095040;\n\tsetp.eq.b32 \t%p713, %r1668, 0;\n\tselp.f32 \t%r1669, %r1666, %r1665, %p712;\n\tselp.f32 \t%r1670, %r1669, %r1665, %p713;\n\tsetp.le.f32 \t%p714, %r1670, 0f00000000;\n\tselp.f32 \t%r1858, 0f00000000, %r1670, %p714;\n\t@%p30 bra \t$L__BB0_250;\n\tabs.f32 \t%r1671, %r1858;\n\tsetp.eq.f32 \t%p716, %r1858, 0f7F800000;\n\tsetp.lt.f32 \t%p717, %r1671, 0f00800000;\n\tsetp.num.f32 \t%p718, %r1858, %r1858;\n\tsetp.ltu.f32 \t%p719, %r1858, 0f00000000;\n\tor.pred \t%p720, %p719, %p717;\n\tselp.f32 \t%r1673, 0f00000000, 0f7FC00000, %p717;\n\tor.pred \t%p721, %p716, %p720;\n\tselp.f32 \t%r1674, %r1673, %r1858, %p720;\n\tselp.f32 \t%r1857, %r1674, %r1858, %p718;\n\t@%p721 bra \t$L__BB0_249;\n\tmul.f32 \t%r1672, %r1858, 0f5F800000;\n\tsetp.lt.f32 \t%p715, %r1858, 0f0F800000;\n\tselp.f32 \t%r71, %r1672, %r1858, %p715;\n\tshr.u32 \t%r1675, %r71, 1;\n\tadd.s32 \t%r1676, %r1675, 532487669;\n\tdiv.rn.f32 \t%r1677, %r71, %r1676;\n\tadd.f32 \t%r1678, %r1677, %r1676;\n\tmul.f32 \t%r1679, %r1678, 0f3F000000;\n\tdiv.rn.f32 \t%r1680, %r71, %r1679;\n\tfma.rn.f32 \t%r1681, %r1678, 0f3F000000, %r1680;\n\tmul.f32 \t%r1682, %r1681, 0f3F000000;\n\tdiv.rn.f32 \t%r1683, %r71, %r1682;\n\tfma.rn.f32 \t%r1684, %r1681, 0f3F000000, %r1683;\n\tmul.f32 \t%r72, %r1684, 0f3F000000;\n\tneg.f32 \t%r1685, %r72;\n\tfma.rn.f32 \t%r1686, %r1685, %r72, %r71;\n\tabs.f32 \t%r1855, %r1686;\n\tmov.b64 \t%rd167, 0;\n\tmov.b32 \t%r1856, %r72;\n$L__BB0_247:\n\tsetp.eq.b64 \t%p722, %rd167, 2;\n\tselp.b32 \t%r1687, -2, 2, %p722;\n\tsetp.eq.b64 \t%p723, %rd167, 1;\n\tsetp.eq.b64 \t%p724, %rd167, 0;\n\tselp.b32 \t%r1688, 1, %r1687, %p723;\n\tselp.b32 \t%r1689, -1, %r1688, %p724;\n\tadd.s32 \t%r1690, %r1689, %r72;\n\tneg.f32 \t%r1691, %r1690;\n\tfma.rn.f32 \t%r1692, %r1691, %r1690, %r71;\n\tabs.f32 \t%r1693, %r1692;\n\tsetp.lt.f32 \t%p725, %r1693, %r1855;\n\tselp.f32 \t%r1856, %r1690, %r1856, %p725;\n\tselp.f32 \t%r1855, %r1693, %r1855, %p725;\n\tadd.s64 \t%rd167, %rd167, 1;\n\tsetp.ne.b64 \t%p726, %rd167, 4;\n\t@%p726 bra \t$L__BB0_247;\n\tmul.f32 \t%r1694, %r1856, 0f2F800000;\n\tselp.f32 \t%r1857, %r1694, %r1856, %p715;\n$L__BB0_249:\n\tand.b32 \t%r1695, %r1857, -2147483648;\n\tand.b32 \t%r1696, %r1857, 8388607;\n\tsetp.ne.b32 \t%p727, %r1696, 0;\n\tand.b32 \t%r1697, %r1857, 2139095040;\n\tsetp.eq.b32 \t%p728, %r1697, 0;\n\tselp.f32 \t%r1698, %r1695, %r1857, %p727;\n\tselp.f32 \t%r1858, %r1698, %r1857, %p728;\n$L__BB0_250:\n\tst.global.b32 \t[%rd20+12], %r1858;\n$L__BB0_251:\n\tret;\n\n}\n"
	.size	static_string_e07c7279604e36e8, 112794

	.type	static_string_73c31eed37cdc470,@object
	.p2align	4, 0x0
static_string_73c31eed37cdc470:
	.asciz	"4a3394f0ce7cabeabb041ddc19d81b51"
	.size	static_string_73c31eed37cdc470, 33

	.type	static_string_2838b8f3ca24fc26,@object
	.p2align	4, 0x0
static_string_2838b8f3ca24fc26:
	.asciz	"neighbors_checks_pinned_distan6A6A6A6A_3c55a81d6a41740d"
	.size	static_string_2838b8f3ca24fc26, 56

	.type	static_string_1ac8d80efaa5b430,@object
	.p2align	4, 0x0
static_string_1ac8d80efaa5b430:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(z: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], yt: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q_minima: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y_minima: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)], y_stride_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_features_in: ::SIMD[::DType(int32), ::SIMDLength(1)], is_sqrt_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|0b0339481906bd52"
	.size	static_string_1ac8d80efaa5b430, 1294

	.type	static_string_83a7e52fb0129882,@object
	.p2align	4, 0x0
static_string_83a7e52fb0129882:
	.asciz	"positive Int32 dimensions required"
	.size	static_string_83a7e52fb0129882, 35

	.type	static_string_5aef0422996201bd,@object
	.p2align	4, 0x0
static_string_5aef0422996201bd:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tcore_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b\n// core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_$__global_alloc_0_$__gpu_shared_mem has been demoted\n\n.visible .entry core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b(\n\t.param .u64 .ptr .align 1 core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_0,\n\t.param .u64 .ptr .align 1 core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_1,\n\t.param .u32 core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_2,\n\t.param .u32 core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_3\n)\n{\n\t.reg .pred \t%p<10>;\n\t.reg .b32 \t%r<15>;\n\t.reg .b64 \t%rd<44>;\n\t// demoted variable\n\t.shared .align 4 .b8 core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_$__global_alloc_0_$__gpu_shared_mem[4224];\n\tld.param.s32 \t%rd3, [core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_2];\n\tadd.s64 \t%rd18, %rd3, 31;\n\tshr.s64 \t%rd19, %rd18, 63;\n\tshr.u64 \t%rd20, %rd19, 59;\n\tadd.s64 \t%rd21, %rd18, %rd20;\n\tshr.s64 \t%rd22, %rd21, 5;\n\tand.b64 \t%rd23, %rd21, -32;\n\tsetp.eq.b64 \t%p1, %rd23, %rd18;\n\tselp.b64 \t%rd24, 0, %rd19, %p1;\n\tadd.s64 \t%rd10, %rd24, %rd22;\n\tmov.u32 \t%r12, %ctaid.y;\n\tcvt.u64.u32 \t%rd43, %r12;\n\tsetp.le.s64 \t%p2, %rd10, %rd43;\n\t@%p2 bra \t$L__BB0_7;\n\tld.param.b64 \t%rd15, [core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_0];\n\tld.param.b64 \t%rd16, [core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_1];\n\tcvta.to.global.u64 \t%rd1, %rd16;\n\tcvta.to.global.u64 \t%rd2, %rd15;\n\tld.param.s32 \t%rd4, [core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_param_3];\n\tmov.u32 \t%r3, %tid.x;\n\tcvt.u64.u32 \t%rd5, %r3;\n\tmov.u32 \t%r4, %tid.y;\n\tcvt.u64.u32 \t%rd6, %r4;\n\tmov.b32 \t%r5, core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b_$__global_alloc_0_$__gpu_shared_mem;\n\tmad.lo.s32 \t%r6, %r3, 132, %r5;\n\tshl.b32 \t%r7, %r4, 2;\n\tadd.s32 \t%r1, %r6, %r7;\n\tmad.lo.s32 \t%r8, %r4, 132, %r5;\n\tshl.b32 \t%r9, %r3, 2;\n\tadd.s32 \t%r2, %r8, %r9;\n\tmov.u32 \t%r10, %ctaid.x;\n\tcvt.u64.u32 \t%rd7, %r10;\n\tmul.wide.u32 \t%rd17, %r10, 32;\n\tadd.s64 \t%rd8, %rd17, %rd6;\n\tadd.s64 \t%rd9, %rd17, %rd5;\n\tmov.u32 \t%r11, %nctaid.y;\n\tcvt.u64.u32 \t%rd11, %r11;\n\tshl.b64 \t%rd41, %rd43, 5;\n\tadd.s64 \t%rd25, %rd41, %rd6;\n\tmul.lo.s64 \t%rd26, %rd25, %rd4;\n\tshl.b64 \t%rd27, %rd26, 2;\n\tshl.b64 \t%rd28, %rd7, 7;\n\tadd.s64 \t%rd29, %rd27, %rd28;\n\tshl.b64 \t%rd30, %rd5, 2;\n\tadd.s64 \t%rd31, %rd29, %rd30;\n\tadd.s64 \t%rd42, %rd1, %rd31;\n\tmul.lo.s64 \t%rd32, %rd4, %rd11;\n\tshl.b64 \t%rd12, %rd32, 7;\n\tshl.b64 \t%rd13, %rd11, 5;\n\tmul.lo.s64 \t%rd33, %rd8, %rd3;\n\tshl.b64 \t%rd34, %rd33, 2;\n\tshl.b64 \t%rd35, %rd43, 7;\n\tadd.s64 \t%rd36, %rd34, %rd35;\n\tadd.s64 \t%rd37, %rd36, %rd30;\n\tadd.s64 \t%rd40, %rd2, %rd37;\n\tshl.b64 \t%rd14, %rd11, 7;\n\tsetp.ge.s64 \t%p3, %rd9, %rd4;\n\tsetp.ge.s64 \t%p6, %rd8, %rd4;\n\tbra.uni \t$L__BB0_2;\n$L__BB0_6:\n\tbar.sync \t0;\n\tadd.s64 \t%rd43, %rd43, %rd11;\n\tadd.s64 \t%rd42, %rd42, %rd12;\n\tadd.s64 \t%rd41, %rd41, %rd13;\n\tadd.s64 \t%rd40, %rd40, %rd14;\n\tsetp.lt.s64 \t%p9, %rd43, %rd10;\n\t@!%p9 bra \t$L__BB0_7;\n$L__BB0_2:\n\tadd.s64 \t%rd38, %rd6, %rd41;\n\tsetp.ge.s64 \t%p4, %rd38, %rd3;\n\tor.pred \t%p5, %p4, %p3;\n\t@%p5 bra \t$L__BB0_4;\n\tld.global.b32 \t%r13, [%rd42];\n\tst.shared.b32 \t[%r2], %r13;\n$L__BB0_4:\n\tbar.sync \t0;\n\tadd.s64 \t%rd39, %rd5, %rd41;\n\tsetp.ge.s64 \t%p7, %rd39, %rd3;\n\tor.pred \t%p8, %p6, %p7;\n\t@%p8 bra \t$L__BB0_6;\n\tld.shared.b32 \t%r14, [%r1];\n\tst.global.b32 \t[%rd40], %r14;\n\tbra.uni \t$L__BB0_6;\n$L__BB0_7:\n\tret;\n\n}\n"
	.size	static_string_5aef0422996201bd, 3505

	.type	static_string_fa0e29d972eecbd4,@object
	.p2align	4, 0x0
static_string_fa0e29d972eecbd4:
	.asciz	"ac9e27668c15869fc9ac578d11b2470e"
	.size	static_string_fa0e29d972eecbd4, 33

	.type	static_string_047bc43de4256ef8,@object
	.p2align	4, 0x0
static_string_047bc43de4256ef8:
	.asciz	"core_column_stats_transpose_ke6A6A6A6A_452a4c7a9ca8217b"
	.size	static_string_047bc43de4256ef8, 56

	.type	static_string_a0cb3684e599879d,@object
	.p2align	4, 0x0
static_string_a0cb3684e599879d:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(dst: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], src: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|620a3eab15d03604"
	.size	static_string_a0cb3684e599879d, 470

	.type	static_string_16654fb8ec1a054b,@object
	.p2align	4, 0x0
static_string_16654fb8ec1a054b:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tneighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086\n\n.visible .entry neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086(\n\t.param .u64 .ptr .align 1 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_0,\n\t.param .u64 .ptr .align 1 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_1,\n\t.param .u64 .ptr .align 1 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_2,\n\t.param .u64 .ptr .align 1 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_3,\n\t.param .u64 .ptr .align 1 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_4,\n\t.param .u32 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_5,\n\t.param .u32 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_6,\n\t.param .u32 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_7,\n\t.param .u32 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_8,\n\t.param .u32 neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_9\n)\n{\n\t.reg .pred \t%p<39>;\n\t.reg .b32 \t%r<87>;\n\t.reg .b64 \t%rd<46>;\n\n\tld.param.b32 \t%r3, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_6];\n\tld.param.b32 \t%r6, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_5];\n\tmov.u32 \t%r7, %ctaid.x;\n\tmov.u32 \t%r8, %ntid.x;\n\tmul.wide.u32 \t%rd20, %r7, %r8;\n\tmov.u32 \t%r9, %tid.x;\n\tcvt.u64.u32 \t%rd21, %r9;\n\tadd.s64 \t%rd8, %rd20, %rd21;\n\tmul.wide.s32 \t%rd23, %r3, %r6;\n\tsetp.ge.s64 \t%p1, %rd8, %rd23;\n\t@%p1 bra \t$L__BB0_14;\n\tld.param.b32 \t%r4, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_8];\n\tld.param.b64 \t%rd14, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_0];\n\tld.param.b64 \t%rd18, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_3];\n\tld.param.b64 \t%rd19, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_4];\n\tcvt.s64.s32 \t%rd5, %r3;\n\tsetp.eq.b32 \t%p2, %r3, 0;\n\tselp.b64 \t%rd10, 1, %rd5, %p2;\n\tor.b64 \t%rd24, %rd8, %rd10;\n\tand.b64 \t%rd25, %rd24, -4294967296;\n\tsetp.ne.b64 \t%p3, %rd25, 0;\n\t@!%p3 bra \t$L__BB0_2;\n\tdiv.s64 \t%rd41, %rd8, %rd10;\n\tbra.uni \t$L__BB0_4;\n$L__BB0_2:\n\tcvt.u32.u64 \t%r10, %rd10;\n\tcvt.u32.u64 \t%r11, %rd8;\n\tdiv.u32 \t%r12, %r11, %r10;\n\tcvt.u64.u32 \t%rd41, %r12;\n$L__BB0_4:\n\tcvta.to.global.u64 \t%rd15, %rd14;\n\tshl.b64 \t%rd22, %rd8, 2;\n\tld.param.b32 \t%r5, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_9];\n\tcvta.to.global.u64 \t%rd3, %rd18;\n\tcvta.to.global.u64 \t%rd4, %rd19;\n\tsetp.lt.s32 \t%p4, %r3, 0;\n\tmul.lo.s64 \t%rd26, %rd41, %rd10;\n\tsetp.eq.b64 \t%p5, %rd26, %rd8;\n\tshr.s64 \t%rd27, %rd10, 63;\n\tselp.b64 \t%rd28, 0, %rd27, %p5;\n\tadd.s64 \t%rd29, %rd28, %rd41;\n\tselp.b64 \t%rd11, 0, %rd29, %p2;\n\tmul.lo.s64 \t%rd30, %rd41, %rd5;\n\tsub.s64 \t%rd31, %rd8, %rd30;\n\tsetp.ne.b64 \t%p6, %rd8, %rd30;\n\tselp.b64 \t%rd32, %rd5, 0, %p6;\n\tselp.b64 \t%rd33, %rd32, 0, %p4;\n\tadd.s64 \t%rd34, %rd31, %rd33;\n\tselp.b64 \t%rd12, 0, %rd34, %p2;\n\tshl.b64 \t%rd35, %rd12, 2;\n\tsetp.lt.s32 \t%p7, %r4, 1;\n\tmov.b32 \t%r82, 0f00000000;\n\t@%p7 bra \t$L__BB0_7;\n\tld.param.b64 \t%rd17, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_2];\n\tld.param.b64 \t%rd16, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_1];\n\tcvta.to.global.u64 \t%rd1, %rd17;\n\tcvt.s64.s32 \t%rd7, %r4;\n\tcvta.to.global.u64 \t%rd2, %rd16;\n\tld.param.s32 \t%rd6, [neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086_param_7];\n\tmax.s64 \t%rd44, %rd7, 0;\n\tadd.s64 \t%rd42, %rd1, %rd35;\n\tmul.lo.s64 \t%rd36, %rd11, %rd7;\n\tshl.b64 \t%rd37, %rd36, 2;\n\tadd.s64 \t%rd43, %rd2, %rd37;\n\tshl.b64 \t%rd13, %rd6, 2;\n\tmov.b32 \t%r82, 0f00000000;\n$L__BB0_6:\n\tadd.s64 \t%rd44, %rd44, -1;\n\tld.global.b32 \t%r13, [%rd43];\n\tand.b32 \t%r14, %r13, -2147483648;\n\tand.b32 \t%r15, %r13, 8388607;\n\tsetp.ne.b32 \t%p8, %r15, 0;\n\tand.b32 \t%r16, %r13, 2139095040;\n\tsetp.eq.b32 \t%p9, %r16, 0;\n\tselp.f32 \t%r17, %r14, %r13, %p8;\n\tselp.f32 \t%r18, %r17, %r13, %p9;\n\tld.global.b32 \t%r19, [%rd42];\n\tand.b32 \t%r20, %r19, -2147483648;\n\tand.b32 \t%r21, %r19, 8388607;\n\tsetp.ne.b32 \t%p10, %r21, 0;\n\tand.b32 \t%r22, %r19, 2139095040;\n\tsetp.eq.b32 \t%p11, %r22, 0;\n\tselp.f32 \t%r23, %r20, %r19, %p10;\n\tselp.f32 \t%r24, %r23, %r19, %p11;\n\tfma.rn.f32 \t%r25, %r18, %r24, %r82;\n\tand.b32 \t%r26, %r25, -2147483648;\n\tand.b32 \t%r27, %r25, 8388607;\n\tsetp.ne.b32 \t%p12, %r27, 0;\n\tand.b32 \t%r28, %r25, 2139095040;\n\tsetp.eq.b32 \t%p13, %r28, 0;\n\tselp.f32 \t%r29, %r26, %r25, %p12;\n\tselp.f32 \t%r82, %r29, %r25, %p13;\n\tadd.s64 \t%rd43, %rd43, 4;\n\tadd.s64 \t%rd42, %rd42, %rd13;\n\tsetp.ne.b64 \t%p14, %rd44, 0;\n\t@%p14 bra \t$L__BB0_6;\n$L__BB0_7:\n\tadd.s64 \t%rd9, %rd15, %rd22;\n\tsetp.eq.b32 \t%p15, %r5, 0;\n\tshl.b64 \t%rd38, %rd11, 2;\n\tadd.s64 \t%rd39, %rd3, %rd38;\n\tld.global.b32 \t%r30, [%rd39];\n\tand.b32 \t%r31, %r30, -2147483648;\n\tand.b32 \t%r32, %r30, 8388607;\n\tsetp.ne.b32 \t%p16, %r32, 0;\n\tand.b32 \t%r33, %r30, 2139095040;\n\tsetp.eq.b32 \t%p17, %r33, 0;\n\tselp.f32 \t%r34, %r31, %r30, %p16;\n\tselp.f32 \t%r35, %r34, %r30, %p17;\n\tadd.s64 \t%rd40, %rd4, %rd35;\n\tld.global.b32 \t%r36, [%rd40];\n\tand.b32 \t%r37, %r36, -2147483648;\n\tand.b32 \t%r38, %r36, 8388607;\n\tsetp.ne.b32 \t%p18, %r38, 0;\n\tand.b32 \t%r39, %r36, 2139095040;\n\tsetp.eq.b32 \t%p19, %r39, 0;\n\tselp.f32 \t%r40, %r37, %r36, %p18;\n\tselp.f32 \t%r41, %r40, %r36, %p19;\n\tadd.f32 \t%r42, %r35, %r41;\n\tand.b32 \t%r43, %r42, -2147483648;\n\tand.b32 \t%r44, %r42, 8388607;\n\tsetp.ne.b32 \t%p20, %r44, 0;\n\tand.b32 \t%r45, %r42, 2139095040;\n\tsetp.eq.b32 \t%p21, %r45, 0;\n\tselp.f32 \t%r46, %r43, %r42, %p20;\n\tselp.f32 \t%r47, %r46, %r42, %p21;\n\tfma.rn.f32 \t%r48, %r82, 0fC0000000, %r47;\n\tand.b32 \t%r49, %r48, -2147483648;\n\tand.b32 \t%r50, %r48, 8388607;\n\tsetp.ne.b32 \t%p22, %r50, 0;\n\tand.b32 \t%r51, %r48, 2139095040;\n\tsetp.eq.b32 \t%p23, %r51, 0;\n\tselp.f32 \t%r52, %r49, %r48, %p22;\n\tselp.f32 \t%r53, %r52, %r48, %p23;\n\tsetp.le.f32 \t%p24, %r53, 0f00000000;\n\tselp.f32 \t%r86, 0f00000000, %r53, %p24;\n\t@%p15 bra \t$L__BB0_13;\n\tabs.f32 \t%r54, %r86;\n\tsetp.eq.f32 \t%p26, %r86, 0f7F800000;\n\tsetp.lt.f32 \t%p27, %r54, 0f00800000;\n\tsetp.num.f32 \t%p28, %r86, %r86;\n\tsetp.ltu.f32 \t%p29, %r86, 0f00000000;\n\tor.pred \t%p30, %p29, %p27;\n\tselp.f32 \t%r56, 0f00000000, 0f7FC00000, %p27;\n\tor.pred \t%p31, %p26, %p30;\n\tselp.f32 \t%r57, %r56, %r86, %p30;\n\tselp.f32 \t%r85, %r57, %r86, %p28;\n\t@%p31 bra \t$L__BB0_12;\n\tmul.f32 \t%r55, %r86, 0f5F800000;\n\tsetp.lt.f32 \t%p25, %r86, 0f0F800000;\n\tselp.f32 \t%r1, %r55, %r86, %p25;\n\tshr.u32 \t%r58, %r1, 1;\n\tadd.s32 \t%r59, %r58, 532487669;\n\tdiv.rn.f32 \t%r60, %r1, %r59;\n\tadd.f32 \t%r61, %r60, %r59;\n\tmul.f32 \t%r62, %r61, 0f3F000000;\n\tdiv.rn.f32 \t%r63, %r1, %r62;\n\tfma.rn.f32 \t%r64, %r61, 0f3F000000, %r63;\n\tmul.f32 \t%r65, %r64, 0f3F000000;\n\tdiv.rn.f32 \t%r66, %r1, %r65;\n\tfma.rn.f32 \t%r67, %r64, 0f3F000000, %r66;\n\tmul.f32 \t%r2, %r67, 0f3F000000;\n\tneg.f32 \t%r68, %r2;\n\tfma.rn.f32 \t%r69, %r68, %r2, %r1;\n\tabs.f32 \t%r83, %r69;\n\tmov.b64 \t%rd45, 0;\n\tmov.b32 \t%r84, %r2;\n$L__BB0_10:\n\tsetp.eq.b64 \t%p32, %rd45, 2;\n\tselp.b32 \t%r70, -2, 2, %p32;\n\tsetp.eq.b64 \t%p33, %rd45, 1;\n\tsetp.eq.b64 \t%p34, %rd45, 0;\n\tselp.b32 \t%r71, 1, %r70, %p33;\n\tselp.b32 \t%r72, -1, %r71, %p34;\n\tadd.s32 \t%r73, %r72, %r2;\n\tneg.f32 \t%r74, %r73;\n\tfma.rn.f32 \t%r75, %r74, %r73, %r1;\n\tabs.f32 \t%r76, %r75;\n\tsetp.lt.f32 \t%p35, %r76, %r83;\n\tselp.f32 \t%r84, %r73, %r84, %p35;\n\tselp.f32 \t%r83, %r76, %r83, %p35;\n\tadd.s64 \t%rd45, %rd45, 1;\n\tsetp.ne.b64 \t%p36, %rd45, 4;\n\t@%p36 bra \t$L__BB0_10;\n\tmul.f32 \t%r77, %r84, 0f2F800000;\n\tselp.f32 \t%r85, %r77, %r84, %p25;\n$L__BB0_12:\n\tand.b32 \t%r78, %r85, -2147483648;\n\tand.b32 \t%r79, %r85, 8388607;\n\tsetp.ne.b32 \t%p37, %r79, 0;\n\tand.b32 \t%r80, %r85, 2139095040;\n\tsetp.eq.b32 \t%p38, %r80, 0;\n\tselp.f32 \t%r81, %r78, %r85, %p37;\n\tselp.f32 \t%r86, %r81, %r85, %p38;\n$L__BB0_13:\n\tst.global.b32 \t[%rd9], %r86;\n$L__BB0_14:\n\tret;\n\n}\n"
	.size	static_string_16654fb8ec1a054b, 7672

	.type	static_string_f055329ebaf6eb0b,@object
	.p2align	4, 0x0
static_string_f055329ebaf6eb0b:
	.asciz	"2f63928c5fa0950ff86e7d6411dc2fa0"
	.size	static_string_f055329ebaf6eb0b, 33

	.type	static_string_501a9b65d3141c0b,@object
	.p2align	4, 0x0
static_string_501a9b65d3141c0b:
	.asciz	"neighbors_checks_transposed_in6A6A6A6A_26fbbea72db13086"
	.size	static_string_501a9b65d3141c0b, 56

	.type	static_string_b10b6afccde6c412,@object
	.p2align	4, 0x0
static_string_b10b6afccde6c412:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(z: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], q_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], y_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_rows_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)], y_stride_in: ::SIMD[::DType(int32), ::SIMDLength(1)], n_features_in: ::SIMD[::DType(int32), ::SIMDLength(1)], is_sqrt_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|e6305fb844139f6a"
	.size	static_string_b10b6afccde6c412, 1023

	.type	static_string_6928b95969f03113,@object
	.p2align	4, 0x0
static_string_6928b95969f03113:
	.asciz	"/root/performance/neighbors/checks/transposed_index_distance_candidate.mojo"
	.size	static_string_6928b95969f03113, 76

	.type	static_string_c07f9321ecc43ab0,@object
	.p2align	4, 0x0
static_string_c07f9321ecc43ab0:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(in_val: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], out_val: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], out_idx: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(uint32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], buf_val: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], buf_idx: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(uint32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], len_in: ::SIMD[::DType(int32), ::SIMDLength(1)], k_in: ::SIMD[::DType(int32), ::SIMDLength(1)], buf_len_in: ::SIMD[::DType(int32), ::SIMDLength(1)], select_min_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|23dcae9f77acb221"
	.size	static_string_c07f9321ecc43ab0, 978

	.type	static_string_3648de856b228127,@object
	.p2align	4, 0x0
static_string_3648de856b228127:
	.asciz	"neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045"
	.size	static_string_3648de856b228127, 56

	.type	static_string_7ca086bb03b09a35,@object
	.p2align	4, 0x0
static_string_7ca086bb03b09a35:
	.asciz	"ad89b53b42694585e6c5cb8c25345497"
	.size	static_string_7ca086bb03b09a35, 33

	.type	static_string_d28ef84eb1c678f9,@object
	.p2align	4, 0x0
static_string_d28ef84eb1c678f9:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tneighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_0_$__gpu_shared_mem has been demoted\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem has been demoted\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem has been demoted\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_3_$__gpu_shared_mem has been demoted\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_4_$__gpu_shared_mem has been demoted\n// neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_5_$__gpu_shared_mem has been demoted\n\n.visible .entry neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045(\n\t.param .u64 .ptr .align 1 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_0,\n\t.param .u64 .ptr .align 1 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_1,\n\t.param .u64 .ptr .align 1 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_2,\n\t.param .u64 .ptr .align 1 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_3,\n\t.param .u64 .ptr .align 1 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_4,\n\t.param .u32 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_5,\n\t.param .u32 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_6,\n\t.param .u32 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_7,\n\t.param .u32 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_8\n)\n{\n\t.reg .pred \t%p<47>;\n\t.reg .b32 \t%r<104>;\n\t.reg .b64 \t%rd<114>;\n\t// demoted variable\n\t.shared .align 4 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_0_$__gpu_shared_mem[1024];\n\t// demoted variable\n\t.shared .align 4 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem[20];\n\t// demoted variable\n\t.shared .align 8 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem[8];\n\t// demoted variable\n\t.shared .align 4 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_3_$__gpu_shared_mem[1024];\n\t// demoted variable\n\t.shared .align 4 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_4_$__gpu_shared_mem[1024];\n\t// demoted variable\n\t.shared .align 4 .b8 neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_5_$__gpu_shared_mem[128];\n\tld.param.b32 \t%r17, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_8];\n\tld.param.b32 \t%r16, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_7];\n\tld.param.b32 \t%r15, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_6];\n\tld.param.b32 \t%r14, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_5];\n\tld.param.b64 \t%rd39, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_0];\n\tcvta.to.global.u64 \t%rd40, %rd39;\n\tld.param.b64 \t%rd41, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_1];\n\tcvta.to.global.u64 \t%rd1, %rd41;\n\tld.param.b64 \t%rd42, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_2];\n\tcvta.to.global.u64 \t%rd2, %rd42;\n\tld.param.b64 \t%rd43, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_3];\n\tcvta.to.global.u64 \t%rd44, %rd43;\n\tld.param.b64 \t%rd45, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_param_4];\n\tcvta.to.global.u64 \t%rd46, %rd45;\n\tmov.u32 \t%r1, %laneid;\n\tcvt.s64.s32 \t%rd3, %r14;\n\tcvt.s64.s32 \t%rd4, %r15;\n\tcvt.s64.s32 \t%rd47, %r16;\n\tmov.u32 \t%r18, %tid.x;\n\tcvt.u64.u32 \t%rd111, %r18;\n\tsetp.ne.b32 \t%p4, %r18, 0;\n\tmov.u32 \t%r19, %ctaid.x;\n\tcvt.u64.u32 \t%rd48, %r19;\n\tmul.lo.s64 \t%rd49, %rd3, %rd48;\n\tshl.b64 \t%rd50, %rd49, 2;\n\tmul.lo.s64 \t%rd7, %rd4, %rd48;\n\tshl.b64 \t%rd51, %rd7, 2;\n\tmul.lo.s64 \t%rd52, %rd48, %rd47;\n\tshl.b64 \t%rd53, %rd52, 3;\n\tadd.s64 \t%rd10, %rd44, %rd53;\n\tmul.wide.s32 \t%rd54, %r16, 4;\n\tadd.s64 \t%rd12, %rd46, %rd53;\n\tshl.b32 \t%r20, %r18, 2;\n\tmov.b32 \t%r21, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_0_$__gpu_shared_mem;\n\t@%p4 bra \t$L__BB0_2;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem], %r15;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+4], %r14;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+8], %r14;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+12], 0;\n\tst.shared.b64 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem], 0;\n$L__BB0_2:\n\tmax.s64 \t%rd5, %rd4, 0;\n\tadd.s64 \t%rd6, %rd40, %rd50;\n\tadd.s64 \t%rd8, %rd1, %rd51;\n\tadd.s64 \t%rd9, %rd2, %rd51;\n\tadd.s64 \t%rd11, %rd10, %rd54;\n\tadd.s64 \t%rd13, %rd12, %rd54;\n\tadd.s32 \t%r2, %r21, %r20;\n\tsetp.eq.b32 \t%p5, %r17, 0;\n\tbar.sync \t0;\n\tselp.b32 \t%r3, -1, 0, %p5;\n\tshr.u64 \t%rd14, %rd111, 5;\n\tcvt.u32.u64 \t%r22, %rd14;\n\tshl.b32 \t%r23, %r22, 2;\n\tmov.b32 \t%r24, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_5_$__gpu_shared_mem;\n\tadd.s32 \t%r4, %r24, %r23;\n\tshl.b32 \t%r25, %r1, 2;\n\tadd.s32 \t%r5, %r24, %r25;\n\tshl.b64 \t%rd15, %rd111, 2;\n\tmov.b64 \t%rd96, 8;\n\tcvt.u32.u64 \t%r26, %rd111;\n\tsetp.ne.b32 \t%p9, %r26, 0;\n\tbra.uni \t$L__BB0_3;\n$L__BB0_33:\n\tbar.sync \t0;\n\t@!%p9 bra \t$L__BB0_34;\n$L__BB0_35:\n\tmax.u64 \t%rd55, %rd96, 1;\n\tadd.s64 \t%rd17, %rd55, -1;\n\tbar.sync \t0;\n\tld.shared.b32 \t%r74, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+4];\n\tld.shared.b32 \t%r75, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem];\n\tsetp.ne.b32 \t%p32, %r74, %r75;\n\tsetp.ne.b64 \t%p33, %rd96, 1;\n\tand.pred \t%p34, %p33, %p32;\n\tmov.b64 \t%rd96, %rd17;\n\t@!%p34 bra \t$L__BB0_36;\n$L__BB0_3:\n\tsub.s64 \t%rd16, 8, %rd96;\n\tsetp.lt.u64 \t%p6, %rd16, 2;\n\tmov.b64 \t%rd97, %rd6;\n\tmov.b64 \t%rd98, %rd12;\n\tmov.b64 \t%rd99, %rd10;\n\tmov.b64 \t%rd100, %rd12;\n\t@%p6 bra \t$L__BB0_5;\n\tand.b64 \t%rd56, %rd16, 1;\n\tsetp.ne.b64 \t%p7, %rd56, 0;\n\tselp.b64 \t%rd100, %rd12, %rd13, %p7;\n\tselp.b64 \t%rd99, %rd10, %rd11, %p7;\n\tselp.b64 \t%rd98, %rd13, %rd12, %p7;\n\tselp.b64 \t%rd97, %rd11, %rd10, %p7;\n$L__BB0_5:\n\tld.shared.b32 \t%r6, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+4];\n\tld.shared.s32 \t%rd19, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem];\n\tld.shared.b32 \t%r27, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+8];\n\tst.shared.b32 \t[%r2], 0;\n\t@%p9 bra \t$L__BB0_7;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+16], 0;\n$L__BB0_7:\n\tcvt.s64.s32 \t%rd57, %r27;\n\tsetp.le.s32 \t%p10, %r27, %r16;\n\tselp.b64 \t%rd22, %rd57, %rd3, %p10;\n\tsetp.gt.s64 \t%p12, %rd16, 0;\n\tsetp.le.s32 \t%p11, %r6, %r16;\n\tand.pred \t%p2, %p12, %p11;\n\tbar.sync \t0;\n\tshl.b64 \t%rd58, %rd96, 3;\n\tadd.s64 \t%rd59, %rd58, -8;\n\tmax.s64 \t%rd23, %rd59, 0;\n\tcvt.u32.u64 \t%r28, %rd23;\n\tsetp.le.s64 \t%p13, %rd22, %rd111;\n\t@%p13 bra \t$L__BB0_22;\n\tsetp.gt.s64 \t%p8, %rd16, 1;\n\tand.pred \t%p1, %p8, %p10;\n\tselp.b64 \t%rd20, %rd97, %rd6, %p10;\n\tselp.b64 \t%rd21, %rd98, %rd12, %p10;\n\tshl.b64 \t%rd60, %rd16, 3;\n\tsub.s64 \t%rd61, 64, %rd60;\n\tmax.s64 \t%rd25, %rd61, 0;\n\tsub.s64 \t%rd62, %rd25, %rd23;\n\tcvt.u32.u64 \t%r29, %rd62;\n\tmov.b64 \t%rd63, -1;\n\tshl.b64 \t%rd64, %rd63, %r29;\n\tnot.b64 \t%rd26, %rd64;\n\tld.shared.b64 \t%rd27, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem];\n\tcvt.u32.u64 \t%r30, %rd25;\n\tshl.b64 \t%rd28, %rd63, %r30;\n\tadd.s64 \t%rd102, %rd20, %rd15;\n\tadd.s64 \t%rd101, %rd21, %rd15;\n\tmov.b64 \t%rd103, %rd111;\n\tbra.uni \t$L__BB0_9;\n$L__BB0_13:\n\tfence.sc.sys;\n\tatom.acquire.sys.shared.add.u32 \t%r39, [%r9], 1;\n$L__BB0_21:\n\tadd.s64 \t%rd103, %rd103, 256;\n\tadd.s64 \t%rd102, %rd102, 1024;\n\tadd.s64 \t%rd101, %rd101, 1024;\n\tsetp.lt.s64 \t%p21, %rd103, %rd22;\n\t@!%p21 bra \t$L__BB0_22;\n$L__BB0_9:\n\t@!%p1 bra \t$L__BB0_10;\n\tld.global.b32 \t%r8, [%rd101];\n\tbra.uni \t$L__BB0_12;\n$L__BB0_10:\n\tcvt.u32.u64 \t%r8, %rd103;\n$L__BB0_12:\n\tld.global.b32 \t%r7, [%rd102];\n\tsetp.ne.b64 \t%p14, %rd96, 8;\n\tsetp.lt.s32 \t%p15, %r7, 0;\n\tselp.b32 \t%r31, -1, -2147483648, %p15;\n\txor.b32 \t%r32, %r7, %r31;\n\txor.b32 \t%r33, %r32, %r3;\n\tcvt.u64.u32 \t%rd65, %r33;\n\tshl.b64 \t%rd66, %rd65, 32;\n\tcvt.u64.u32 \t%rd67, %r8;\n\tor.b64 \t%rd68, %rd66, %rd67;\n\tshr.u64 \t%rd69, %rd68, %r28;\n\tand.b64 \t%rd70, %rd69, %rd26;\n\tcvt.u32.u64 \t%r34, %rd70;\n\tshl.b32 \t%r35, %r34, 2;\n\tadd.s32 \t%r9, %r21, %r35;\n\t@!%p14 bra \t$L__BB0_13;\n\tand.b64 \t%rd29, %rd68, %rd28;\n\tsetp.ne.b64 \t%p17, %rd29, %rd27;\n\t@%p17 bra \t$L__BB0_18;\n\tnot.pred \t%p20, %p2;\n\t@%p20 bra \t$L__BB0_17;\n\tfence.sc.sys;\n\tatom.acquire.sys.shared.add.u32 \t%r37, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+16], 1;\n\tmul.wide.s32 \t%rd72, %r37, 4;\n\tadd.s64 \t%rd73, %rd99, %rd72;\n\tst.global.b32 \t[%rd73], %r7;\n\tadd.s64 \t%rd74, %rd100, %rd72;\n\tst.global.b32 \t[%rd74], %r8;\n$L__BB0_17:\n\tfence.sc.sys;\n\tatom.acquire.sys.shared.add.u32 \t%r38, [%r9], 1;\n\tbra.uni \t$L__BB0_21;\n$L__BB0_18:\n\tsetp.lt.u64 \t%p16, %rd29, %rd27;\n\tand.pred \t%p3, %p16, %p2;\n\tnot.pred \t%p18, %p3;\n\t@%p18 bra \t$L__BB0_21;\n\tfence.sc.sys;\n\tatom.acquire.sys.shared.add.u32 \t%r36, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+12], 1;\n\tsetp.ge.s32 \t%p19, %r36, %r15;\n\t@%p19 bra \t$L__BB0_21;\n\tmul.wide.s32 \t%rd71, %r36, 4;\n\tadd.s64 \t%rd30, %rd9, %rd71;\n\tadd.s64 \t%rd31, %rd8, %rd71;\n\tst.global.b32 \t[%rd31], %r7;\n\tst.global.b32 \t[%rd30], %r8;\n\tbra.uni \t$L__BB0_21;\n$L__BB0_22:\n\tsetp.gt.u32 \t%p22, %r1, 3;\n\tsetp.eq.b32 \t%p23, %r1, 0;\n\tsetp.gt.u32 \t%p24, %r1, 1;\n\tsetp.gt.u32 \t%p25, %r1, 7;\n\tsetp.gt.u32 \t%p26, %r1, 15;\n\tsetp.ne.b32 \t%p27, %r1, 31;\n\tbar.sync \t0;\n\tld.shared.b32 \t%r40, [%r2];\n\tshfl.sync.up.b32 \t%r41, %r40, 1, 0, -1;\n\tselp.b32 \t%r42, 0, %r41, %p23;\n\tadd.s32 \t%r43, %r42, %r40;\n\tshfl.sync.up.b32 \t%r44, %r43, 2, 0, -1;\n\tselp.b32 \t%r45, %r44, 0, %p24;\n\tadd.s32 \t%r46, %r43, %r45;\n\tshfl.sync.up.b32 \t%r47, %r46, 4, 0, -1;\n\tselp.b32 \t%r48, %r47, 0, %p22;\n\tadd.s32 \t%r49, %r46, %r48;\n\tshfl.sync.up.b32 \t%r50, %r49, 8, 0, -1;\n\tselp.b32 \t%r51, %r50, 0, %p25;\n\tadd.s32 \t%r52, %r49, %r51;\n\tshfl.sync.up.b32 \t%r53, %r52, 16, 0, -1;\n\tselp.b32 \t%r54, %r53, 0, %p26;\n\tadd.s32 \t%r98, %r52, %r54;\n\t@%p27 bra \t$L__BB0_24;\n\tst.shared.b32 \t[%r4], %r98;\n$L__BB0_24:\n\tsetp.ne.b64 \t%p28, %rd14, 0;\n\tbar.sync \t0;\n\t@%p28 bra \t$L__BB0_27;\n\tld.shared.b32 \t%r55, [%r5];\n\tshfl.sync.up.b32 \t%r56, %r55, 1, 0, -1;\n\tselp.b32 \t%r57, 0, %r56, %p23;\n\tadd.s32 \t%r58, %r57, %r55;\n\tshfl.sync.up.b32 \t%r59, %r58, 2, 0, -1;\n\tselp.b32 \t%r60, %r59, 0, %p24;\n\tadd.s32 \t%r61, %r58, %r60;\n\tshfl.sync.up.b32 \t%r62, %r61, 4, 0, -1;\n\tselp.b32 \t%r63, %r62, 0, %p22;\n\tadd.s32 \t%r64, %r61, %r63;\n\tshfl.sync.up.b32 \t%r65, %r64, 8, 0, -1;\n\tselp.b32 \t%r66, %r65, 0, %p25;\n\tadd.s32 \t%r10, %r64, %r66;\n\tshfl.sync.up.b32 \t%r67, %r10, 16, 0, -1;\n\t@%p25 bra \t$L__BB0_27;\n\tst.shared.b32 \t[%r5], %r10;\n$L__BB0_27:\n\tbar.sync \t0;\n\t@!%p28 bra \t$L__BB0_29;\n\tld.shared.b32 \t%r68, [%r4+-4];\n\tadd.s32 \t%r98, %r68, %r98;\n$L__BB0_29:\n\tst.shared.b32 \t[%r2], %r98;\n\tbar.sync \t0;\n\tmov.b64 \t%rd104, 0;\n\t@!%p9 bra \t$L__BB0_31;\n\tld.shared.s32 \t%rd104, [%r2+-4];\n$L__BB0_31:\n\tcvt.u32.u64 \t%r69, %rd19;\n\tld.shared.b32 \t%r70, [%r2];\n\tsetp.lt.s32 \t%p29, %r70, %r69;\n\tsetp.ge.s64 \t%p30, %rd104, %rd19;\n\tor.pred \t%p31, %p30, %p29;\n\t@%p31 bra \t$L__BB0_33;\n\tshl.b64 \t%rd24, %rd111, %r28;\n\tcvt.u32.u64 \t%r71, %rd104;\n\tsub.s32 \t%r72, %r69, %r71;\n\tsub.s32 \t%r73, %r70, %r71;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem], %r72;\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+4], %r73;\n\tld.shared.b64 \t%rd75, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem];\n\tor.b64 \t%rd76, %rd75, %rd24;\n\tst.shared.b64 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem], %rd76;\n\tbra.uni \t$L__BB0_33;\n$L__BB0_34:\n\tst.shared.b32 \t[neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+8], %r6;\n\tbra.uni \t$L__BB0_35;\n$L__BB0_36:\n\tcvt.s64.s32 \t%rd18, %r6;\n\tselp.b64 \t%rd33, %rd18, %rd3, %p2;\n\tld.shared.b64 \t%rd34, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_2_$__gpu_shared_mem];\n\tbar.sync \t0;\n\tsetp.le.s64 \t%p35, %rd33, %rd111;\n\t@%p35 bra \t$L__BB0_45;\n\tselp.b64 \t%rd32, %rd99, %rd6, %p2;\n\tmov.b64 \t%rd77, -1;\n\tshl.b64 \t%rd35, %rd77, %r28;\n\tadd.s64 \t%rd106, %rd32, %rd15;\n\tadd.s64 \t%rd105, %rd100, %rd15;\n\tmov.b64 \t%rd107, %rd111;\n\tbra.uni \t$L__BB0_38;\n$L__BB0_44:\n\tadd.s64 \t%rd107, %rd107, 256;\n\tadd.s64 \t%rd106, %rd106, 1024;\n\tadd.s64 \t%rd105, %rd105, 1024;\n\tsetp.lt.s64 \t%p39, %rd107, %rd33;\n\t@!%p39 bra \t$L__BB0_45;\n$L__BB0_38:\n\t@!%p2 bra \t$L__BB0_39;\n\tld.global.b32 \t%r99, [%rd105];\n\tbra.uni \t$L__BB0_41;\n$L__BB0_39:\n\tcvt.u32.u64 \t%r99, %rd107;\n$L__BB0_41:\n\tld.global.b32 \t%r11, [%rd106];\n\tsetp.lt.s32 \t%p36, %r11, 0;\n\tselp.b32 \t%r76, -1, -2147483648, %p36;\n\txor.b32 \t%r77, %r11, %r76;\n\txor.b32 \t%r78, %r77, %r3;\n\tcvt.u64.u32 \t%rd78, %r78;\n\tshl.b64 \t%rd79, %rd78, 32;\n\tcvt.u64.u32 \t%rd80, %r99;\n\tor.b64 \t%rd81, %rd79, %rd80;\n\tand.b64 \t%rd82, %rd81, %rd35;\n\tsetp.gt.u64 \t%p37, %rd82, %rd34;\n\t@%p37 bra \t$L__BB0_44;\n\tfence.sc.sys;\n\tatom.acquire.sys.shared.add.u32 \t%r79, [neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_1_$__gpu_shared_mem+12], 1;\n\tsetp.ge.s32 \t%p38, %r79, %r15;\n\t@%p38 bra \t$L__BB0_44;\n\tmul.wide.s32 \t%rd83, %r79, 4;\n\tadd.s64 \t%rd36, %rd9, %rd83;\n\tadd.s64 \t%rd37, %rd8, %rd83;\n\tst.global.b32 \t[%rd37], %r11;\n\tst.global.b32 \t[%rd36], %r99;\n\tbra.uni \t$L__BB0_44;\n$L__BB0_45:\n\tbar.sync \t0;\n\tsetp.ge.s32 \t%p40, %r26, %r15;\n\t@%p40 bra \t$L__BB0_48;\n\tadd.s64 \t%rd84, %rd51, %rd15;\n\tadd.s64 \t%rd109, %rd1, %rd84;\n\tadd.s64 \t%rd108, %rd2, %rd84;\n\tshl.b32 \t%r80, %r26, 2;\n\tmov.b32 \t%r81, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_4_$__gpu_shared_mem;\n\tadd.s32 \t%r101, %r81, %r80;\n\tmov.b32 \t%r82, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_3_$__gpu_shared_mem;\n\tadd.s32 \t%r100, %r82, %r80;\n\tmov.b64 \t%rd110, %rd111;\n$L__BB0_47:\n\tld.global.b32 \t%r83, [%rd109];\n\tst.shared.b32 \t[%r100], %r83;\n\tld.global.b32 \t%r84, [%rd108];\n\tst.shared.b32 \t[%r101], %r84;\n\tadd.s64 \t%rd110, %rd110, 256;\n\tadd.s64 \t%rd109, %rd109, 1024;\n\tadd.s64 \t%rd108, %rd108, 1024;\n\tadd.s32 \t%r101, %r101, 1024;\n\tadd.s32 \t%r100, %r100, 1024;\n\tsetp.lt.s64 \t%p41, %rd110, %rd4;\n\t@%p41 bra \t$L__BB0_47;\n$L__BB0_48:\n\tbar.sync \t0;\n\t@%p40 bra \t$L__BB0_53;\n\tmov.b32 \t%r96, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_4_$__gpu_shared_mem;\n\tmov.b32 \t%r97, neighbors_checks_select_radix_6A6A6A6A_d3b3608d3d3e0045_$__global_alloc_3_$__gpu_shared_mem;\n$L__BB0_50:\n\tcvt.u32.u64 \t%r85, %rd111;\n\tshl.b32 \t%r86, %r85, 2;\n\tadd.s32 \t%r87, %r97, %r86;\n\tadd.s32 \t%r88, %r96, %r86;\n\tld.shared.b32 \t%r12, [%r87];\n\tld.shared.b32 \t%r13, [%r88];\n\tsetp.gt.s32 \t%p42, %r12, -1;\n\tselp.b32 \t%r89, -2147483648, -1, %p42;\n\txor.b32 \t%r90, %r89, %r3;\n\txor.b32 \t%r91, %r90, %r12;\n\tcvt.u64.u32 \t%rd85, %r91;\n\tshl.b64 \t%rd86, %rd85, 32;\n\tcvt.u64.u32 \t%rd87, %r13;\n\tor.b64 \t%rd38, %rd86, %rd87;\n\tmov.b64 \t%rd112, 0;\n\tmov.b32 \t%r102, %r97;\n\tmov.b32 \t%r103, %r96;\n\tmov.b64 \t%rd113, %rd5;\n$L__BB0_51:\n\tadd.s64 \t%rd113, %rd113, -1;\n\tld.shared.b32 \t%r92, [%r102];\n\tld.shared.b32 \t%rd88, [%r103];\n\tsetp.gt.s32 \t%p43, %r92, -1;\n\tselp.b32 \t%r93, -2147483648, -1, %p43;\n\txor.b32 \t%r94, %r93, %r3;\n\txor.b32 \t%r95, %r94, %r92;\n\tcvt.u64.u32 \t%rd89, %r95;\n\tshl.b64 \t%rd90, %rd89, 32;\n\tor.b64 \t%rd91, %rd90, %rd88;\n\tsetp.lt.u64 \t%p44, %rd91, %rd38;\n\tselp.b64 \t%rd92, 1, 0, %p44;\n\tadd.s64 \t%rd112, %rd112, %rd92;\n\tadd.s32 \t%r103, %r103, 4;\n\tadd.s32 \t%r102, %r102, 4;\n\tsetp.ne.b64 \t%p45, %rd113, 0;\n\t@%p45 bra \t$L__BB0_51;\n\tshl.b64 \t%rd93, %rd112, 2;\n\tadd.s64 \t%rd94, %rd8, %rd93;\n\tst.global.b32 \t[%rd94], %r12;\n\tadd.s64 \t%rd95, %rd9, %rd93;\n\tst.global.b32 \t[%rd95], %r13;\n\tadd.s64 \t%rd111, %rd111, 256;\n\tsetp.lt.s64 \t%p46, %rd111, %rd4;\n\t@%p46 bra \t$L__BB0_50;\n$L__BB0_53:\n\tbar.sync \t0;\n\tret;\n\n}\n"
	.size	static_string_d28ef84eb1c678f9, 16369

	.type	static_string_f6c401c515dc2a68,@object
	.p2align	4, 0x0
static_string_f6c401c515dc2a68:
	.asciz	"max/mojo/max/gpu/host/_device_context_extras.mojo"
	.size	static_string_f6c401c515dc2a68, 50

	.type	static_string_561d9efdd15f277f,@object
	.p2align	4, 0x0
static_string_561d9efdd15f277f:
	.asciz	"metal"
	.size	static_string_561d9efdd15f277f, 6

	.type	static_string_fe95cf738c304de4,@object
	.p2align	4, 0x0
static_string_fe95cf738c304de4:
	.asciz	" with error '"
	.size	static_string_fe95cf738c304de4, 14

	.type	static_string_d8f96e4c39e045bb,@object
	.p2align	4, 0x0
static_string_d8f96e4c39e045bb:
	.asciz	"' on device "
	.size	static_string_d8f96e4c39e045bb, 13

	.type	static_string_aaccaef1399538c1,@object
	.p2align	4, 0x0
static_string_aaccaef1399538c1:
	.asciz	" failed calling '"
	.size	static_string_aaccaef1399538c1, 18

	.type	static_string_7b5f0d71131768e3,@object
	.p2align	4, 0x0
static_string_7b5f0d71131768e3:
	.asciz	"/root/performance/bench/knn_index_layout_main.mojo"
	.size	static_string_7b5f0d71131768e3, 51

	.type	static_string_5f81310f9d7e8c41,@object
	.p2align	4, 0x0
static_string_5f81310f9d7e8c41:
	.asciz	"def[LITImmOrigin, ::Origin[::Bool(False), $0]](*args: **?) thin -> None|def(out_norm: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], a: ::Pointer[::Bool(True), MutUnsafeAnyOrigin, ::SIMD[::DType(float32), ::SIMDLength(1)], *?, ::AddressSpace(::SIMDLength(0))], n_cols_in: ::SIMD[::DType(int32), ::SIMDLength(1)], take_sqrt_in: ::SIMD[::DType(int32), ::SIMDLength(1)]) thin -> None|901d937c3442e354"
	.size	static_string_5f81310f9d7e8c41, 476

	.type	static_string_510d7aabfd7afaf5,@object
	.p2align	4, 0x0
static_string_510d7aabfd7afaf5:
	.asciz	"core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302"
	.size	static_string_510d7aabfd7afaf5, 56

	.type	static_string_91afa7b607590f5d,@object
	.p2align	4, 0x0
static_string_91afa7b607590f5d:
	.asciz	"d1cf309341aa6f69ccd09a4abc4638bf"
	.size	static_string_91afa7b607590f5d, 33

	.type	static_string_ba51a876e4c062cc,@object
	.p2align	4, 0x0
static_string_ba51a876e4c062cc:
	.asciz	"//\n// Generated by LLVM NVPTX Back-End\n//\n\n.version 8.5\n.target sm_90a\n.address_size 64\n\n\t// .globl\tcore_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302\n// core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem has been demoted\n\n.visible .entry core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302(\n\t.param .u64 .ptr .align 1 core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_0,\n\t.param .u64 .ptr .align 1 core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_1,\n\t.param .u32 core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_2,\n\t.param .u32 core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_3\n)\n{\n\t.reg .pred \t%p<27>;\n\t.reg .b32 \t%r<105>;\n\t.reg .b64 \t%rd<16>;\n\t// demoted variable\n\t.shared .align 4 .b8 core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem[512];\n\tld.param.b32 \t%r7, [core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_2];\n\tmov.u32 \t%r8, %ctaid.x;\n\tmov.u32 \t%r1, %tid.x;\n\tsetp.ge.s32 \t%p1, %r1, %r7;\n\tmov.b32 \t%r100, 0f00000000;\n\t@%p1 bra \t$L__BB0_3;\n\tld.param.b64 \t%rd7, [core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_1];\n\tcvta.to.global.u64 \t%rd1, %rd7;\n\tcvt.s64.s32 \t%rd2, %r7;\n\tcvt.u64.u32 \t%rd3, %r8;\n\tcvt.u64.u32 \t%rd14, %r1;\n\tmul.lo.s64 \t%rd9, %rd2, %rd3;\n\tshl.b64 \t%rd10, %rd9, 2;\n\tmul.wide.u32 \t%rd11, %r1, 4;\n\tadd.s64 \t%rd12, %rd10, %rd11;\n\tadd.s64 \t%rd13, %rd1, %rd12;\n\tmov.b32 \t%r100, 0f00000000;\n$L__BB0_2:\n\tld.global.b32 \t%r9, [%rd13];\n\tand.b32 \t%r10, %r9, -2147483648;\n\tand.b32 \t%r11, %r9, 8388607;\n\tsetp.ne.b32 \t%p2, %r11, 0;\n\tand.b32 \t%r12, %r9, 2139095040;\n\tsetp.eq.b32 \t%p3, %r12, 0;\n\tselp.f32 \t%r13, %r10, %r9, %p2;\n\tselp.f32 \t%r14, %r13, %r9, %p3;\n\tfma.rn.f32 \t%r15, %r14, %r14, %r100;\n\tand.b32 \t%r16, %r15, -2147483648;\n\tand.b32 \t%r17, %r15, 8388607;\n\tsetp.ne.b32 \t%p4, %r17, 0;\n\tand.b32 \t%r18, %r15, 2139095040;\n\tsetp.eq.b32 \t%p5, %r18, 0;\n\tselp.f32 \t%r19, %r16, %r15, %p4;\n\tselp.f32 \t%r100, %r19, %r15, %p5;\n\tadd.s64 \t%rd14, %rd14, 128;\n\tadd.s64 \t%rd13, %rd13, 512;\n\tsetp.lt.s64 \t%p6, %rd14, %rd2;\n\t@%p6 bra \t$L__BB0_2;\n$L__BB0_3:\n\tshl.b32 \t%r20, %r1, 2;\n\tmov.b32 \t%r21, core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem;\n\tadd.s32 \t%r2, %r21, %r20;\n\tst.shared.b32 \t[%r2], %r100;\n\tbar.sync \t0;\n\tsetp.gt.u32 \t%p7, %r1, 15;\n\t@%p7 bra \t$L__BB0_5;\n\tld.shared.b32 \t%r22, [%r2];\n\tld.shared.b32 \t%r23, [%r2+64];\n\tld.shared.b32 \t%r24, [%r2+128];\n\tld.shared.b32 \t%r25, [%r2+192];\n\tld.shared.b32 \t%r26, [%r2+256];\n\tld.shared.b32 \t%r27, [%r2+320];\n\tld.shared.b32 \t%r28, [%r2+384];\n\tld.shared.b32 \t%r29, [%r2+448];\n\tadd.f32 \t%r30, %r22, %r26;\n\tadd.f32 \t%r31, %r23, %r27;\n\tadd.f32 \t%r32, %r24, %r28;\n\tadd.f32 \t%r33, %r25, %r29;\n\tadd.f32 \t%r34, %r30, %r32;\n\tadd.f32 \t%r35, %r31, %r33;\n\tadd.f32 \t%r36, %r34, %r35;\n\tst.shared.b32 \t[%r2], %r36;\n$L__BB0_5:\n\tbar.sync \t0;\n\tld.shared.b32 \t%r37, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem];\n\tld.shared.b32 \t%r38, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+4];\n\tld.shared.b32 \t%r39, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+8];\n\tld.shared.b32 \t%r40, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+12];\n\tld.shared.b32 \t%r41, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+16];\n\tld.shared.b32 \t%r42, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+20];\n\tld.shared.b32 \t%r43, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+24];\n\tld.shared.b32 \t%r44, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+28];\n\tld.shared.b32 \t%r45, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+32];\n\tld.shared.b32 \t%r46, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+36];\n\tld.shared.b32 \t%r47, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+40];\n\tld.shared.b32 \t%r48, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+44];\n\tld.shared.b32 \t%r49, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+48];\n\tld.shared.b32 \t%r50, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+52];\n\tld.shared.b32 \t%r51, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+56];\n\tld.shared.b32 \t%r52, [core_pinned_reduce_halving_blo6A6A6A6A_ed576d668f3d5dc0_$__global_alloc_0_$__gpu_shared_mem+60];\n\tbar.sync \t0;\n\tsetp.ne.b32 \t%p11, %r1, 0;\n\t@%p11 bra \t$L__BB0_13;\n\tld.param.b64 \t%rd5, [core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_0];\n\tcvta.to.global.u64 \t%rd6, %rd5;\n\tmul.wide.u32 \t%rd8, %r8, 4;\n\tld.param.b32 \t%r6, [core_row_norms_row_norm_kernel6A6A6A6A_1b52a3dc0e3ed302_param_3];\n\tadd.s64 \t%rd4, %rd6, %rd8;\n\tadd.f32 \t%r53, %r37, %r45;\n\tadd.f32 \t%r54, %r38, %r46;\n\tadd.f32 \t%r55, %r39, %r47;\n\tadd.f32 \t%r56, %r40, %r48;\n\tadd.f32 \t%r57, %r41, %r49;\n\tadd.f32 \t%r58, %r42, %r50;\n\tadd.f32 \t%r59, %r43, %r51;\n\tadd.f32 \t%r60, %r44, %r52;\n\tadd.f32 \t%r61, %r53, %r57;\n\tadd.f32 \t%r62, %r54, %r58;\n\tadd.f32 \t%r63, %r55, %r59;\n\tadd.f32 \t%r64, %r56, %r60;\n\tadd.f32 \t%r65, %r61, %r63;\n\tadd.f32 \t%r66, %r62, %r64;\n\tadd.f32 \t%r67, %r65, %r66;\n\tand.b32 \t%r68, %r67, 2139095040;\n\tsetp.eq.b32 \t%p8, %r68, 0;\n\tand.b32 \t%r69, %r67, 8388607;\n\tsetp.ne.b32 \t%p9, %r69, 0;\n\tand.b32 \t%r70, %r67, -2147483648;\n\tselp.f32 \t%r71, %r70, %r67, %p9;\n\tselp.f32 \t%r104, %r71, %r67, %p8;\n\tsetp.eq.b32 \t%p12, %r6, 0;\n\t@%p12 bra \t$L__BB0_12;\n\tsetp.le.f32 \t%p10, %r104, 0f00000000;\n\tselp.f32 \t%r3, 0f00000000, %r104, %p10;\n\tabs.f32 \t%r72, %r3;\n\tsetp.eq.f32 \t%p14, %r3, 0f7F800000;\n\tsetp.lt.f32 \t%p15, %r72, 0f00800000;\n\tsetp.num.f32 \t%p16, %r3, %r3;\n\tsetp.ltu.f32 \t%p17, %r3, 0f00000000;\n\tor.pred \t%p18, %p17, %p15;\n\tselp.f32 \t%r74, 0f00000000, 0f7FC00000, %p15;\n\tor.pred \t%p19, %p14, %p18;\n\tselp.f32 \t%r75, %r74, %r3, %p18;\n\tselp.f32 \t%r103, %r75, %r3, %p16;\n\t@%p19 bra \t$L__BB0_11;\n\tmul.f32 \t%r73, %r3, 0f5F800000;\n\tsetp.lt.f32 \t%p13, %r3, 0f0F800000;\n\tselp.f32 \t%r4, %r73, %r3, %p13;\n\tshr.u32 \t%r76, %r4, 1;\n\tadd.s32 \t%r77, %r76, 532487669;\n\tdiv.rn.f32 \t%r78, %r4, %r77;\n\tadd.f32 \t%r79, %r78, %r77;\n\tmul.f32 \t%r80, %r79, 0f3F000000;\n\tdiv.rn.f32 \t%r81, %r4, %r80;\n\tfma.rn.f32 \t%r82, %r79, 0f3F000000, %r81;\n\tmul.f32 \t%r83, %r82, 0f3F000000;\n\tdiv.rn.f32 \t%r84, %r4, %r83;\n\tfma.rn.f32 \t%r85, %r82, 0f3F000000, %r84;\n\tmul.f32 \t%r5, %r85, 0f3F000000;\n\tneg.f32 \t%r86, %r5;\n\tfma.rn.f32 \t%r87, %r86, %r5, %r4;\n\tabs.f32 \t%r101, %r87;\n\tmov.b64 \t%rd15, 0;\n\tmov.b32 \t%r102, %r5;\n$L__BB0_9:\n\tsetp.eq.b64 \t%p20, %rd15, 2;\n\tselp.b32 \t%r88, -2, 2, %p20;\n\tsetp.eq.b64 \t%p21, %rd15, 1;\n\tsetp.eq.b64 \t%p22, %rd15, 0;\n\tselp.b32 \t%r89, 1, %r88, %p21;\n\tselp.b32 \t%r90, -1, %r89, %p22;\n\tadd.s32 \t%r91, %r90, %r5;\n\tneg.f32 \t%r92, %r91;\n\tfma.rn.f32 \t%r93, %r92, %r91, %r4;\n\tabs.f32 \t%r94, %r93;\n\tsetp.lt.f32 \t%p23, %r94, %r101;\n\tselp.f32 \t%r102, %r91, %r102, %p23;\n\tselp.f32 \t%r101, %r94, %r101, %p23;\n\tadd.s64 \t%rd15, %rd15, 1;\n\tsetp.ne.b64 \t%p24, %rd15, 4;\n\t@%p24 bra \t$L__BB0_9;\n\tmul.f32 \t%r95, %r102, 0f2F800000;\n\tselp.f32 \t%r103, %r95, %r102, %p13;\n$L__BB0_11:\n\tand.b32 \t%r96, %r103, -2147483648;\n\tand.b32 \t%r97, %r103, 8388607;\n\tsetp.ne.b32 \t%p25, %r97, 0;\n\tand.b32 \t%r98, %r103, 2139095040;\n\tsetp.eq.b32 \t%p26, %r98, 0;\n\tselp.f32 \t%r99, %r96, %r103, %p25;\n\tselp.f32 \t%r104, %r99, %r103, %p26;\n$L__BB0_12:\n\tst.global.b32 \t[%rd4], %r104;\n$L__BB0_13:\n\tret;\n\n}\n"
	.size	static_string_ba51a876e4c062cc, 7730

	.type	static_string_1c530a05b12890aa,@object
	.p2align	4, 0x0
static_string_1c530a05b12890aa:
	.asciz	"post-timing distance"
	.size	static_string_1c530a05b12890aa, 21

	.type	static_string_1a02af91e8b4e009,@object
	.p2align	4, 0x0
static_string_1a02af91e8b4e009:
	.asciz	"SAMPLE"
	.size	static_string_1a02af91e8b4e009, 7

	.type	static_string_0bb90f8e145278cc,@object
	.p2align	4, 0x0
static_string_0bb90f8e145278cc:
	.asciz	"legacy_distance"
	.size	static_string_0bb90f8e145278cc, 16

	.type	static_string_d7230136ba2f387c,@object
	.p2align	4, 0x0
static_string_d7230136ba2f387c:
	.asciz	"TIMING components_only norms_and_allocations_excluded scratch_bytes"
	.size	static_string_d7230136ba2f387c, 68

	.type	static_string_499a369ebb9323d7,@object
	.p2align	4, 0x0
static_string_499a369ebb9323d7:
	.asciz	"selected_pairs"
	.size	static_string_499a369ebb9323d7, 15

	.type	static_string_9188e23ae65af2ff,@object
	.p2align	4, 0x0
static_string_9188e23ae65af2ff:
	.asciz	"distance_cells"
	.size	static_string_9188e23ae65af2ff, 15

	.type	static_string_caf946eb805bcec1,@object
	.p2align	4, 0x0
static_string_caf946eb805bcec1:
	.asciz	"BITGATE PASS"
	.size	static_string_caf946eb805bcec1, 13

	.type	static_string_56c10b529cd986fa,@object
	.p2align	4, 0x0
static_string_56c10b529cd986fa:
	.asciz	"CELL"
	.size	static_string_56c10b529cd986fa, 5

	.type	static_string_fdc4d37c65200cd0,@object
	.p2align	4, 0x0
static_string_fdc4d37c65200cd0:
	.asciz	"1"
	.size	static_string_fdc4d37c65200cd0, 2

	.type	static_string_66d118ae2d66e30c,@object
	.p2align	4, 0x0
static_string_66d118ae2d66e30c:
	.asciz	"MOJOLEARN_KNN_LAYOUT_DUMP"
	.size	static_string_66d118ae2d66e30c, 26

	.type	static_string_5a65be5ae798a7df,@object
	.p2align	4, 0x0
static_string_5a65be5ae798a7df:
	.asciz	"index mutated"
	.size	static_string_5a65be5ae798a7df, 14

	.type	static_string_3893ea46334eb8c6,@object
	.p2align	4, 0x0
static_string_3893ea46334eb8c6:
	.asciz	"query mutated"
	.size	static_string_3893ea46334eb8c6, 14

	.type	static_string_96fcc284d4fc120e,@object
	.p2align	4, 0x0
static_string_96fcc284d4fc120e:
	.asciz	"selected distance"
	.size	static_string_96fcc284d4fc120e, 18

	.type	static_string_77c62120cb28fcc2,@object
	.p2align	4, 0x0
static_string_77c62120cb28fcc2:
	.asciz	"distance"
	.size	static_string_77c62120cb28fcc2, 9

	.type	static_string_8d2be8d385cdccef,@object
	.p2align	4, 0x0
static_string_8d2be8d385cdccef:
	.asciz	"index transpose changed bits"
	.size	static_string_8d2be8d385cdccef, 29

	.type	static_string_ba2ac5804aa058eb,@object
	.p2align	4, 0x0
static_string_ba2ac5804aa058eb:
	.asciz	"zero-distance ties must select lowest indices"
	.size	static_string_ba2ac5804aa058eb, 46

	.type	static_string_d302bded2ba36da2,@object
	.p2align	4, 0x0
static_string_d302bded2ba36da2:
	.asciz	"selected index mismatch or poison"
	.size	static_string_d302bded2ba36da2, 34

	.type	static_string_894406302c64c97c,@object
	.p2align	4, 0x0
static_string_894406302c64c97c:
	.asciz	"distance poison survived"
	.size	static_string_894406302c64c97c, 25

	.type	static_string_263b3a2b28ad4c61,@object
	.p2align	4, 0x0
static_string_263b3a2b28ad4c61:
	.asciz	"cuda"
	.size	static_string_263b3a2b28ad4c61, 5

	.type	static_string_df3c90ecf5db28f9,@object
	.p2align	4, 0x0
static_string_df3c90ecf5db28f9:
	.asciz	"KNN INDEX LAYOUT QUALIFICATION PASS"
	.size	static_string_df3c90ecf5db28f9, 36

	.type	static_string_9901187edc54c332,@object
	.p2align	4, 0x0
static_string_9901187edc54c332:
	.asciz	"MOJOLEARN_KNN_LAYOUT_PROFILE"
	.size	static_string_9901187edc54c332, 29

	.type	static_string_7c8c647ff852be50,@object
	.p2align	4, 0x0
static_string_7c8c647ff852be50:
	.asciz	"MOJOLEARN_KNN_LAYOUT_D"
	.size	static_string_7c8c647ff852be50, 23

	.type	static_string_65b768cdacbddd0e,@object
	.p2align	4, 0x0
static_string_65b768cdacbddd0e:
	.asciz	"MOJOLEARN_KNN_LAYOUT_COLS"
	.size	static_string_65b768cdacbddd0e, 26

	.type	static_string_e3b932ac05451006,@object
	.p2align	4, 0x0
static_string_e3b932ac05451006:
	.asciz	"MOJOLEARN_KNN_LAYOUT_ROWS"
	.size	static_string_e3b932ac05451006, 26

	.type	static_string_db528282ff266e15,@object
	.p2align	4, 0x0
static_string_db528282ff266e15:
	.asciz	"MOJOLEARN_KNN_LAYOUT_LARGE"
	.size	static_string_db528282ff266e15, 27

	.type	static_string_f94463e33bca9e65,@object
	.p2align	4, 0x0
static_string_f94463e33bca9e65:
	.asciz	"MOJOLEARN_KNN_LAYOUT_SAMPLES"
	.size	static_string_f94463e33bca9e65, 29

	.type	static_string_89492c12f76adff2,@object
	.p2align	4, 0x0
static_string_89492c12f76adff2:
	.asciz	"at least seven samples required"
	.size	static_string_89492c12f76adff2, 32

	.type	static_string_fbc1a80614d0cd78,@object
	.p2align	4, 0x0
static_string_fbc1a80614d0cd78:
	.asciz	"fixture exceeds bounded positive dimensions/storage"
	.size	static_string_fbc1a80614d0cd78, 52

	.type	static_string_a74d59023276de02,@object
	.p2align	4, 0x0
static_string_a74d59023276de02:
	.asciz	"large fixture PROFILE must be 0 (duplicates) or 3 (random)"
	.size	static_string_a74d59023276de02, 59

	.type	static_string_26a85fbdc19bc0a1,@object
	.p2align	4, 0x0
static_string_26a85fbdc19bc0a1:
	.asciz	"Unhandled exception caught during execution:"
	.size	static_string_26a85fbdc19bc0a1, 45

	.type	static_string_fbe1ca471a988c5b,@object
	.p2align	4, 0x0
static_string_fbe1ca471a988c5b:
	.asciz	"stack trace was not collected. Enable stack trace collection with environment variable `MODULAR_DEBUG=stack-trace-on-error`"
	.size	static_string_fbe1ca471a988c5b, 124

	.type	static_string_a61c3395ab9379d9,@object
	.p2align	4, 0x0
static_string_a61c3395ab9379d9:
	.asciz	"Runtime"
	.size	static_string_a61c3395ab9379d9, 8

	.type	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])",@object
	.p2align	3, 0x0
".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])":
	.ascii	"\027\021\023"
	.size	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)])", 3

	.type	static_string_e5411518d45eb182,@object
	.p2align	4, 0x0
static_string_e5411518d45eb182:
	.asciz	"nan"
	.size	static_string_e5411518d45eb182, 4

	.type	static_string_a8e3dd8c929b6eb8,@object
	.p2align	4, 0x0
static_string_a8e3dd8c929b6eb8:
	.asciz	"-"
	.size	static_string_a8e3dd8c929b6eb8, 2

	.type	static_string_d9df22dbe27ec153,@object
	.p2align	4, 0x0
static_string_d9df22dbe27ec153:
	.asciz	"oss/modular/mojo/stdlib/std/builtin/format_int.mojo"
	.size	static_string_d9df22dbe27ec153, 52

	.type	static_string_978d8d34847e5196,@object
	.p2align	4, 0x0
static_string_978d8d34847e5196:
	.asciz	"0123456789abcdefghijklmnopqrstuvwxyz"
	.size	static_string_978d8d34847e5196, 37

	.type	static_string_fd5c39b3eb3d3242,@object
	.p2align	4, 0x0
static_string_fd5c39b3eb3d3242:
	.asciz	":"
	.size	static_string_fd5c39b3eb3d3242, 2

	.type	static_string_ba261bf194cae289,@object
	.p2align	4, 0x0
static_string_ba261bf194cae289:
	.asciz	"none"
	.size	static_string_ba261bf194cae289, 5

	.type	static_string_cfa776fe0f373673,@object
	.p2align	4, 0x0
static_string_cfa776fe0f373673:
	.asciz	"oss/modular/mojo/stdlib/std/builtin/_format_float.mojo"
	.size	static_string_cfa776fe0f373673, 55

	.type	global_constant_0,@object
	.p2align	4, 0x0
global_constant_0:
	.quad	2731688931043774331
	.quad	-38366372719436721
	.quad	8624834609543440813
	.quad	-6941508010590729807
	.quad	-3054014793352862696
	.quad	-4065198994811024355
	.quad	5405853545163697438
	.quad	-469812725086392539
	.quad	5684501474941004851
	.quad	-7211161980820077193
	.quad	2493940825248868160
	.quad	-4402266457597708587
	.quad	7729112049988473104
	.quad	-891147053569747830
	.quad	-9004363024039368022
	.quad	-7474495936122174250
	.quad	2579604275232953684
	.quad	-4731433901725329908
	.quad	3224505344041192105
	.quad	-1302606358729274481
	.quad	8932844867666826922
	.quad	-7731658001846878407
	.quad	-2669001970698630060
	.quad	-5052886483881210105
	.quad	-3336252463373287575
	.quad	-1704422086424124727
	.quad	2526528228819083170
	.quad	-7982792831656159810
	.quad	-6065211750830921845
	.quad	-5366805021142811859
	.quad	1641857348316123501
	.quad	-2096820258001126919
	.quad	-5891368184943504668
	.quad	-8228041688891786181
	.quad	-7364210231179380835
	.quad	-5673366092687344822
	.quad	4629795266307937668
	.quad	-2480021597431793123
	.quad	5199465050656154995
	.quad	-8467542526035952558
	.quad	-2724040723534582064
	.quad	-5972742139117552794
	.quad	-8016736922845615485
	.quad	-2854241655469553088
	.quad	6518754469289960082
	.quad	-8701430062309552536
	.quad	8148443086612450103
	.quad	-6265101559459552766
	.quad	962181821410786820
	.quad	-3219690930897053053
	.quad	-1704479370831952189
	.quad	-8929835859451740015
	.quad	7092772823314835571
	.quad	-6550608805887287114
	.quad	-357406007711231344
	.quad	-3576574988931720989
	.quad	8999993282035256218
	.quad	-9152888395723407474
	.quad	2026619565689294465
	.quad	-6829424476226871438
	.quad	-6690097579743157727
	.quad	-3925094576856201394
	.quad	5472436080603216553
	.quad	-294682202642863838
	.quad	8031958568804398250
	.quad	-7101705404292871755
	.quad	-3795109844276665900
	.quad	-4265445736938701790
	.quad	9091170749936331337
	.quad	-720121152745989333
	.quad	3376138709496513134
	.quad	-7367604748107325189
	.quad	-391512631556746487
	.quad	-4597819916706768583
	.quad	8733981247408842699
	.quad	-1135588877456072824
	.quad	5458738279630526687
	.quad	-7627272076051127371
	.quad	-7011635205744005353
	.quad	-4922404076636521310
	.quad	5070514048102157021
	.quad	-1541319077368263733
	.quad	863228270850154186
	.quad	-7880853450996246689
	.quad	-3532650679864695172
	.quad	-5239380795317920458
	.quad	-9027499368258256869
	.quad	-1937539975720012668
	.quad	-3336344095947716591
	.quad	-8128491512466089774
	.quad	-8782116138362033642
	.quad	-5548928372155224313
	.quad	7469098900757009563
	.quad	-2324474446766642487
	.quad	-2249342214667950879
	.quad	-8370325556870233411
	.quad	6411694268519837209
	.quad	-5851220927660403859
	.quad	-5820440219632367201
	.quad	-2702340141148116920
	.quad	7891439908798240260
	.quad	-8606491615858654931
	.quad	-3970758169284363388
	.quad	-6146428501395930760
	.quad	-351761693178066331
	.quad	-3071349608317525546
	.quad	6697677969404790400
	.quad	-8837122532839535322
	.quad	-851274575098787809
	.quad	-6434717147622031249
	.quad	-1064093218873484761
	.quad	-3431710416100151157
	.quad	8558313775058847833
	.quad	-9062348037703676329
	.quad	6086206200396171887
	.quad	-6716249028702207507
	.quad	-6227300304786948854
	.quad	-3783625267450371480
	.quad	-3172439362556298163
	.quad	-117845565885576446
	.quad	-4288617610811380304
	.quad	-6991182506319567135
	.quad	3862600023340550428
	.quad	-4127292114472071014
	.quad	-4395122007679087773
	.quad	-547429124662700864
	.quad	8782263791269039902
	.quad	-7259672230555269896
	.quad	-7468914334623251739
	.quad	-4462904269766699466
	.quad	4498915137003099038
	.quad	-966944318780986428
	.quad	-6411550076227838909
	.quad	-7521869226879198374
	.quad	5820620459997365076
	.quad	-4790650515171610063
	.quad	-6559282480285457367
	.quad	-1376627125537124675
	.quad	-8711237568605798758
	.quad	-7777920981101784778
	.quad	2946011094524915264
	.quad	-5110715207949843068
	.quad	3682513868156144080
	.quad	-1776707991509915931
	.quad	4607414176811284002
	.quad	-8027971522334779313
	.quad	1147581702586717098
	.quad	-5423278384491086237
	.quad	-3177208890193991531
	.quad	-2167411962186469893
	.quad	7237616480483531101
	.quad	-8272161504007625539
	.quad	-4788037454677749836
	.quad	-5728515861582144020
	.quad	-1373360799919799391
	.quad	-2548958808550292121
	.quad	-858350499949874619
	.quad	-8510628282985014432
	.quad	3538747893490044630
	.quad	-6026599335303880135
	.quad	9035120885289943692
	.quad	-2921563150702462265
	.quad	-5882264492762254952
	.quad	-8743505996830120772
	.quad	-2741144597525430787
	.quad	-6317696477610263061
	.quad	-3426430746906788484
	.quad	-3285434578585440922
	.quad	4776009810824339054
	.quad	-8970925639256982432
	.quad	5970012263530423817
	.quad	-6601971030643840136
	.quad	7462515329413029772
	.quad	-3640777769877412266
	.quad	52386062455755703
	.quad	-9193015133814464522
	.quad	-9157889458785081179
	.quad	-6879582898840692749
	.quad	6999382250228200142
	.quad	-3987792605123478032
	.quad	8749227812785250178
	.quad	-373054737976959636
	.quad	-3755104653863994447
	.quad	-7150688238876681629
	.quad	-4693880817329993059
	.quad	-4326674280168464132
	.quad	-1255665003235103419
	.quad	-796656831783192261
	.quad	8438581409832836171
	.quad	-7415439547505577019
	.quad	-3286831292991118498
	.quad	-4657613415954583370
	.quad	-8720225134666286027
	.quad	-1210330751515841308
	.quad	-3144297699952734815
	.quad	-7673985747338482674
	.quad	-8542058143368306422
	.quad	-4980796165745715438
	.quad	3157485376071780684
	.quad	-1614309188754756393
	.quad	8890957387685944784
	.quad	-7926472270612804602
	.quad	1890324697752655171
	.quad	-5296404319838617848
	.quad	2362905872190818964
	.quad	-2008819381370884406
	.quad	6088502188546649757
	.quad	-8173041140997884610
	.quad	-1612744301171463612
	.quad	-5604615407819967859
	.quad	7207441660390446293
	.quad	-2394083241347571919
	.quad	-2412877989897052923
	.quad	-8413831053483314306
	.quad	-7627783505798704058
	.quad	-5905602798426754978
	.quad	4300328673033783640
	.quad	-2770317479606055818
	.quad	-1923980597781273129
	.quad	-8648977452394866743
	.quad	6818396289628184397
	.quad	-6199535797066195524
	.quad	8522995362035230496
	.quad	-3137733727905356501
	.quad	3021029092058325108
	.quad	-8878612607581929669
	.quad	-835399653354481519
	.quad	-6486579741050024183
	.quad	8179122470161673909
	.quad	-3496538657885142324
	.quad	-4111420493003729615
	.quad	-9102865688819295809
	.quad	-5139275616254662019
	.quad	-6766896092596731857
	.quad	-6424094520318327523
	.quad	-3846934097318526917
	.quad	-8030118150397909404
	.quad	-196981603220770742
	.quad	-7324666853212387329
	.quad	-7040642529654063570
	.quad	4679224488766679550
	.quad	-4189117143640191558
	.quad	-3374341425896426371
	.quad	-624710411122851544
	.quad	-9026492418826348337
	.quad	-7307973034592864071
	.quad	-2059743486678159614
	.quad	-4523280274813692185
	.quad	-2574679358347699518
	.quad	-1042414325089727327
	.quad	3002511419460075706
	.quad	-7569037980822161435
	.quad	8364825292752482536
	.quad	-4849611457600313890
	.quad	1232659579085827362
	.quad	-1450328303573004458
	.quad	-3841273781498745803
	.quad	-7823984217374209643
	.quad	4421779809981343555
	.quad	-5168294253290374149
	.quad	915538744049291539
	.quad	-1848681798185579782
	.quad	5183897733458195116
	.quad	-8072955151507069220
	.quad	6479872166822743895
	.quad	-5479507920956448621
	.quad	3488154190101041965
	.quad	-2237698882768172872
	.quad	2180096368813151228
	.quad	-8316090829371189901
	.quad	-1886565557410948869
	.quad	-5783427518286599473
	.quad	-2358206946763686086
	.quad	-2617598379430861437
	.quad	7749492695127472004
	.quad	-8553528014785370254
	.quad	463493832054564197
	.quad	-6080224000054324913
	.quad	-4032318728359182658
	.quad	-2988593981640518238
	.quad	-4826042214438183113
	.quad	-8785400266166405755
	.quad	3190819268807046917
	.quad	-6370064314280619289
	.quad	-623161932418579258
	.quad	-3350894374423386208
	.quad	-7307005235402693892
	.quad	-9011838011655698236
	.quad	-4522070525825979461
	.quad	-6653111496142234891
	.quad	3570783879572301481
	.quad	-3704703351750405709
	.quad	-148206168962011053
	.quad	-19193171260619233
	.quad	-92628855601256908
	.quad	-6929524759678968877
	.quad	-115786069501571135
	.quad	-4050219931171323192
	.quad	4466953431550423985
	.quad	-451088895536766085
	.quad	486002885505321039
	.quad	-7199459587351560659
	.quad	5219189625309039203
	.quad	-4387638465762062920
	.quad	6523987031636299003
	.quad	-872862063775190746
	.quad	-534194123654701027
	.quad	-7463067817500576073
	.quad	-667742654568376284
	.quad	-4717148753448332187
	.quad	8388693718644305453
	.quad	-1284749923383027329
	.quad	-6286281471915778851
	.quad	-7720497729755473937
	.quad	-7857851839894723564
	.quad	-5038936143766954517
	.quad	8624429273841147160
	.quad	-1686984161281305242
	.quad	778582277723329071
	.quad	-7971894128441897632
	.quad	973227847154161339
	.quad	-5353181642124984136
	.quad	1216534808942701674
	.quad	-2079791034228842266
	.quad	-3851351762838199358
	.quad	-8217398424034108273
	.quad	-4814189703547749197
	.quad	-5660062011615247437
	.quad	-6017737129434686497
	.quad	-2463391496091671392
	.quad	7768129340171790700
	.quad	-8457148712698376476
	.quad	-8736582398494813241
	.quad	-5959749872445582691
	.quad	-1697355961263740744
	.quad	-2838001322129590460
	.quad	1244995533423855987
	.quad	-8691279853972075893
	.quad	-3055441601647567920
	.quad	-6252413799037706963
	.quad	5404070034795315908
	.quad	-3203831230369745799
	.quad	-3539985255894009413
	.quad	-8919923546622172981
	.quad	-4424981569867511767
	.quad	-6538218414850328322
	.quad	8303831092947774003
	.quad	-3561087000135522498
	.quad	578208414664970848
	.quad	-9143208402725783417
	.quad	-3888925500096174344
	.quad	-6817324484979841368
	.quad	-249470856692830026
	.quad	-3909969587797413806
	.quad	-4923524589293425437
	.quad	-275775966319379353
	.quad	-3077202868308390898
	.quad	-7089889006590693952
	.quad	765182433041899282
	.quad	-4250675239810979535
	.quad	5568164059729762006
	.quad	-701658031336336515
	.quad	5785945546544795206
	.quad	-7356065297226292178
	.quad	-1990940103673781801
	.quad	-4583395603105477319
	.quad	6734696907262548557
	.quad	-1117558485454458744
	.quad	4209185567039092848
	.quad	-7616003081050118571
	.quad	-8573576096483297652
	.quad	-4908317832885260310
	.quad	3118087934678041647
	.quad	-1523711272679187483
	.quad	4254647968387469982
	.quad	-7869848573065574033
	.quad	706623942056949573
	.quad	-5225624697904579637
	.quad	-3728406090856200938
	.quad	-1920344853953336643
	.quad	-6941939825212513490
	.quad	-8117744561361917258
	.quad	5157633273766521850
	.quad	-5535494683275008668
	.quad	6447041592208152312
	.quad	-2307682335666372931
	.quad	6335244004343789147
	.quad	-8359830487432564938
	.quad	-1304317031425039374
	.quad	-5838102090863318269
	.quad	-1630396289281299218
	.quad	-2685941595151759932
	.quad	1286845328412881941
	.quad	-8596242524610931813
	.quad	-3003129357911285478
	.quad	-6133617137336276863
	.quad	5469460339465668960
	.quad	-3055335403242958174
	.quad	8030098730593431004
	.quad	-8827113654667930715
	.quad	-3797434642040374957
	.quad	-6422206049907525490
	.quad	9088264752731695016
	.quad	-3416071543957018958
	.quad	-8154892584824854327
	.quad	-9052573742614218705
	.quad	8253128342678483707
	.quad	-6704031159840385477
	.quad	5704724409920716730
	.quad	-3768352931373093942
	.quad	-2092466524453879895
	.quad	-98755145788979524
	.quad	998051431430019018
	.quad	-6979250993759194058
	.quad	-7975807747567252036
	.quad	-4112377723771604669
	.quad	8476984389250486571
	.quad	-528786136287117932
	.quad	-3925256793573221701
	.quad	-7248020362820530564
	.quad	-294884973539139223
	.quad	-4448339435098275301
	.quad	-368606216923924028
	.quad	-948738275445456222
	.quad	-2536221894791146469
	.quad	-7510490449794491995
	.quad	6053094668365842721
	.quad	-4776427043815727089
	.quad	2954682317029915497
	.quad	-1358847786342270957
	.quad	-459166561069996766
	.quad	-7766808894105001205
	.quad	-573958201337495958
	.quad	-5096825099203863602
	.quad	-5329133770099257851
	.quad	-1759345355577441598
	.quad	-5636551615525730109
	.quad	-8017119874876982855
	.quad	2177682517447613172
	.quad	-5409713825168840664
	.quad	2722103146809516465
	.quad	-2150456263033662926
	.quad	6313000485183335695
	.quad	-8261564192037121185
	.quad	3279564588051781714
	.quad	-5715269221619013577
	.quad	-512230283362660762
	.quad	-2532400508596379068
	.quad	1985699082112030976
	.quad	-8500279345513818773
	.quad	-2129562165787349184
	.quad	-6013663163464885563
	.quad	6561419329620589328
	.quad	-2905392935903719049
	.quad	-7428327965055601430
	.quad	-8733399612580906262
	.quad	4549648098962661925
	.quad	-6305063497298744923
	.quad	-8147997931578836306
	.quad	-3269643353196043250
	.quad	1825030320404309165
	.quad	-8961056123388608887
	.quad	6892973918932774360
	.quad	-6589634135808373205
	.quad	4004531380238580046
	.quad	-3625356651333078602
	.quad	-2108853905778275375
	.quad	-9183376934724255983
	.quad	6587304654631931589
	.quad	-6867535149977932074
	.quad	-989241218564861322
	.quad	-3972732919045027189
	.quad	-1236551523206076653
	.quad	-354230130378896082
	.quad	6144684325637283948
	.quad	-7138922859127891907
	.quad	-6154202648235558777
	.quad	-4311967555482476980
	.quad	-3081067291867060567
	.quad	-778273425925708321
	.quad	-1925667057416912854
	.quad	-7403949918844649557
	.quad	-2407083821771141068
	.quad	-4643251380128424042
	.quad	-7620540795641314239
	.quad	-1192378206733142148
	.quad	-2456994988062127447
	.quad	-7662765406849295699
	.quad	6152128301777116499
	.quad	-4966770740134231719
	.quad	-6144897678060768089
	.quad	-1596777406740401745
	.quad	-3840561048787980055
	.quad	-7915514906853832947
	.quad	4422670725869800739
	.quad	-5282707615139903279
	.quad	-8306719647944912789
	.quad	-1991698500497491195
	.quad	8643358275316593219
	.quad	-8162340590452013853
	.quad	6192511825718353620
	.quad	-5591239719637629412
	.quad	7740639782147942025
	.quad	-2377363631119648861
	.quad	2532056854628769814
	.quad	-8403381297090862394
	.quad	-6058300968568813541
	.quad	-5892540602936190089
	.quad	-7572876210711016926
	.quad	-2753989735242849707
	.quad	9102010423587778133
	.quad	-8638772612167862923
	.quad	-2457545025797441046
	.quad	-6186779746782440750
	.quad	-7683617300674189211
	.quad	-3121788665050663033
	.quad	-4802260812921368257
	.quad	-8868646943297746252
	.quad	-1391139997724322417
	.quad	-6474122660694794911
	.quad	7484447039699372787
	.quad	-3480967307441105734
	.quad	-9157278655470055720
	.quad	-9093133594791772940
	.quad	-6834912300910181746
	.quad	-6754730975062328271
	.quad	679731660717048625
	.quad	-3831727700400522434
	.quad	-8373707460958465027
	.quad	-177973607073265139
	.quad	8601490892183123070
	.quad	-7028762532061872568
	.quad	-7694880458480647778
	.quad	-4174267146649952806
	.quad	4216457482181353989
	.quad	-606147914885053103
	.quad	-4282243101277735613
	.quad	-7296371474444240046
	.quad	8482254178684994196
	.quad	-4508778324627912153
	.quad	5991131704928854841
	.quad	-1024286887357502287
	.quad	-3173071712060547580
	.quad	-7557708332239520786
	.quad	-8578025658503072379
	.quad	-4835449396872013078
	.quad	3112525982153323238
	.quad	-1432625727662628443
	.quad	4251171748059520976
	.quad	-7812920107430224633
	.quad	702278666647013315
	.quad	-5154464115860392887
	.quad	5489534351736154548
	.quad	-1831394126398103205
	.quad	1125115960621402641
	.quad	-8062150356639896359
	.quad	6018080969204141205
	.quad	-5466001927372482545
	.quad	2910915193077788602
	.quad	-2220816390788215277
	.quad	-486521013540076076
	.quad	-8305539271883716405
	.quad	-608151266925095095
	.quad	-5770238071427257602
	.quad	-5371875102083756772
	.quad	-2601111570856684098
	.quad	3560107088838733873
	.quad	-8543223759426509417
	.quad	-161552157378970562
	.quad	-6067343680855748868
	.quad	4409745821703674701
	.quad	-2972493582642298180
	.quad	-6467280898289979120
	.quad	-8775337516792518219
	.quad	1139270913992301908
	.quad	-6357485877563259869
	.quad	-3187597375937010519
	.quad	-3335171328526686933
	.quad	7231123676894144234
	.quad	-9002011107970261189
	.quad	4427218577690292388
	.quad	-6640827866535438582
	.quad	-3689348814741910323
	.quad	-3689348814741910324
	.quad	0
	.quad	-9223372036854775808
	.quad	0
	.quad	-6917529027641081856
	.quad	0
	.quad	-4035225266123964416
	.quad	0
	.quad	-432345564227567616
	.quad	0
	.quad	-7187745005283311616
	.quad	0
	.quad	-4372995238176751616
	.quad	0
	.quad	-854558029293551616
	.quad	0
	.quad	-7451627795949551616
	.quad	0
	.quad	-4702848726509551616
	.quad	0
	.quad	-1266874889709551616
	.quad	0
	.quad	-7709325833709551616
	.quad	0
	.quad	-5024971273709551616
	.quad	0
	.quad	-1669528073709551616
	.quad	0
	.quad	-7960984073709551616
	.quad	0
	.quad	-5339544073709551616
	.quad	0
	.quad	-2062744073709551616
	.quad	0
	.quad	-8206744073709551616
	.quad	0
	.quad	-5646744073709551616
	.quad	0
	.quad	-2446744073709551616
	.quad	0
	.quad	-8446744073709551616
	.quad	0
	.quad	-5946744073709551616
	.quad	0
	.quad	-2821744073709551616
	.quad	0
	.quad	-8681119073709551616
	.quad	0
	.quad	-6239712823709551616
	.quad	0
	.quad	-3187955011209551616
	.quad	0
	.quad	-8910000909647051616
	.quad	0
	.quad	-6525815118631426616
	.quad	0
	.quad	-3545582879861895366
	.quad	4611686018427387904
	.quad	-9133518327554766460
	.quad	5764607523034234880
	.quad	-6805211891016070171
	.quad	-6629298651489370112
	.quad	-3894828845342699810
	.quad	5548434740920451072
	.quad	-256850038250986858
	.quad	-1143914305352105984
	.quad	-7078060301547948643
	.quad	7793479155164643328
	.quad	-4235889358507547899
	.quad	-4093209111326359552
	.quad	-683175679707046970
	.quad	4359273333062107136
	.quad	-7344513827457986212
	.quad	5449091666327633920
	.quad	-4568956265895094861
	.quad	2199678564482154496
	.quad	-1099509313941480672
	.quad	1374799102801346560
	.quad	-7604722348854507276
	.quad	1718498878501683200
	.quad	-4894216917640746191
	.quad	6759809616554491904
	.quad	-1506085128623544835
	.quad	6530724019560251392
	.quad	-7858832233030797378
	.quad	-1059967012404461568
	.quad	-5211854272861108819
	.quad	7898413271349198848
	.quad	-1903131822648998119
	.quad	-1981020733047832576
	.quad	-8106986416796705681
	.quad	-2476275916309790720
	.quad	-5522047002568494197
	.quad	-3095344895387238400
	.quad	-2290872734783229842
	.quad	4982938468024057856
	.quad	-8349324486880600507
	.quad	-7606384970252091392
	.quad	-5824969590173362730
	.quad	4327076842467049472
	.quad	-2669525969289315508
	.quad	-6518949010312869888
	.quad	-8585982758446904049
	.quad	-8148686262891087360
	.quad	-6120792429631242157
	.quad	8260886245095692416
	.quad	-3039304518611664792
	.quad	5163053903184807760
	.quad	-8817094351773372351
	.quad	-7381240676301154012
	.quad	-6409681921289327535
	.quad	-3178808521666707
	.quad	-3400416383184271515
	.quad	-4613672773753429595
	.quad	-9042789267131251553
	.quad	-5767090967191786994
	.quad	-6691800565486676537
	.quad	-7208863708989733743
	.quad	-3753064688430957767
	.quad	212292400617608629
	.quad	-79644842111309304
	.quad	132682750386005393
	.quad	-6967307053960650171
	.quad	4777539456409894646
	.quad	-4097447799023424810
	.quad	-3251447716342407501
	.quad	-510123730351893109
	.quad	7191217214140771120
	.quad	-7236356359111015049
	.quad	4377335499248575996
	.quad	-4433759430461380907
	.quad	-8363388681221443717
	.quad	-930513269649338230
	.quad	-7532960934977096275
	.quad	-7499099821171918250
	.quad	4418856886560793368
	.quad	-4762188758037509908
	.quad	5523571108200991710
	.quad	-1341049929119499481
	.quad	-8076983103442849941
	.quad	-7755685233340769032
	.quad	-5484542860876174523
	.quad	-5082920523248573386
	.quad	6979379479186945559
	.quad	-1741964635633328828
	.quad	-4861259862362934834
	.quad	-8006256924911912374
	.quad	7758483227328495170
	.quad	-5396135137712502563
	.quad	-4136954021121544750
	.quad	-2133482903713240300
	.quad	-279753253987271517
	.quad	-8250955842461857044
	.quad	4261994450943298508
	.quad	-5702008784649933400
	.quad	5327493063679123135
	.quad	-2515824962385028846
	.quad	7941369183226839864
	.quad	-8489919629131724885
	.quad	5315025460606161925
	.quad	-6000713517987268202
	.quad	-2579590211097073401
	.quad	-2889205879056697349
	.quad	7611128154919104932
	.quad	-8723282702051517699
	.quad	-4321147861633282547
	.quad	-6292417359137009220
	.quad	-789748808614215279
	.quad	-3253835680493873621
	.quad	8729779031470891259
	.quad	-8951176327949752869
	.quad	6300537770911226169
	.quad	-6577284391509803182
	.quad	-1347699823215743097
	.quad	-3609919470959866074
	.quad	6075216638131242421
	.quad	-9173728696990998152
	.quad	7594020797664053026
	.quad	-6855474852811359786
	.quad	269153960225290474
	.quad	-3957657547586811828
	.quad	336442450281613092
	.quad	-335385916056126881
	.quad	7127805559067090039
	.quad	-7127145225176161157
	.quad	4298070930406474645
	.quad	-4297245513042813542
	.quad	-3850783373846682502
	.quad	-759870872876129024
	.quad	9122475437414293196
	.quad	-7392448323188662496
	.quad	-7043649776941685121
	.quad	-4628874385558440216
	.quad	-4192876202749718497
	.quad	-1174406963520662366
	.quad	-4926390635932268013
	.quad	-7651533379841495835
	.quad	3065383741939440792
	.quad	-4952730706374481889
	.quad	-779956341003086914
	.quad	-1579227364540714458
	.quad	6430056314514152535
	.quad	-7904546130479028392
	.quad	8037570393142690669
	.quad	-5268996644671397586
	.quad	823590954573587528
	.quad	-1974559787411859078
	.quad	5126430365035880109
	.quad	-8151628894773493780
	.quad	6408037956294850136
	.quad	-5577850100039479321
	.quad	3398361426941174766
	.quad	-2360626606621961247
	.quad	-4793553135802847627
	.quad	-8392920656779807636
	.quad	-1380255401326171630
	.quad	-5879464802547371641
	.quad	-1725319251657714538
	.quad	-2737644984756826647
	.quad	3533361486141316318
	.quad	-8628557143114098510
	.quad	-4806670179178130410
	.quad	-6174010410465235234
	.quad	7826720331309500699
	.quad	-3105826994654156138
	.quad	280014188641050033
	.quad	-8858670899299929442
	.quad	-8873354301053463267
	.quad	-6461652605697523899
	.quad	-1868320839462053276
	.quad	-3465379738694516970
	.quad	5749828502977298559
	.quad	-9083391364325154962
	.quad	-2036086408133152610
	.quad	-6742553186979055799
	.quad	6678264026688335046
	.quad	-3816505465296431844
	.quad	8347830033360418807
	.quad	-158945813193151901
	.quad	2911550761636567803
	.quad	-7016870160886801794
	.quad	-5583933584809066055
	.quad	-4159401682681114339
	.quad	2243455055843443239
	.quad	-587566084924005019
	.quad	3708002419115845977
	.quad	-7284757830718584993
	.quad	23317005467419567
	.quad	-4494261269970843337
	.quad	-4582539761593113445
	.quad	-1006140569036166268
	.quad	-558244341782001951
	.quad	-7546366883288685774
	.quad	-5309491445654890343
	.quad	-4821272585683469313
	.quad	-6636864307068612929
	.quad	-1414904713676948737
	.quad	-4148040191917883080
	.quad	-7801844473689174817
	.quad	-5185050239897353851
	.quad	-5140619573684080617
	.quad	-6481312799871692314
	.quad	-1814088448677712867
	.quad	-8662506518347195600
	.quad	-8051334308064652398
	.quad	3006924907348169212
	.quad	-5452481866653427593
	.quad	-853029884242176389
	.quad	-2203916314889396588
	.quad	1772699331562333709
	.quad	-8294976724446954723
	.quad	6827560182880305040
	.quad	-5757034887131305500
	.quad	8534450228600381300
	.quad	-2584607590486743971
	.quad	7639874402088932265
	.quad	-8532908771695296838
	.quad	326470965756389523
	.quad	-6054449946191733143
	.quad	5019774725622874807
	.quad	-2956376414312278525
	.quad	831516194300602803
	.quad	-8765264286586255934
	.quad	-8183976793979022305
	.quad	-6344894339805432014
	.quad	3605087062808385831
	.quad	-3319431906329402113
	.quad	9170708441896323001
	.quad	-8992173969096958177
	.quad	6851699533943015847
	.quad	-6628531442943809817
	.quad	3952938399001381904
	.quad	-3673978285252374367
	.quad	-4446942528265218166
	.quad	-9213765455923815836
	.quad	-946992141904134803
	.quad	-6905520801477381891
	.quad	8039631859474607304
	.quad	-4020214983419339459
	.quad	-3785518230938904582
	.quad	-413582710846786420
	.quad	-60105885123121412
	.quad	-7176018221920323369
	.quad	-75132356403901765
	.quad	-4358336758973016307
	.quad	9129456591349898602
	.quad	-836234930288882479
	.quad	-1211618658047395230
	.quad	-7440175859071633406
	.quad	-6126209340986631941
	.quad	-4688533805412153853
	.quad	-7657761676233289927
	.quad	-1248981238337804412
	.quad	-2480258038432112252
	.quad	-7698142301602209614
	.quad	-7712008566467528219
	.quad	-5010991858575374113
	.quad	8806733365625141342
	.quad	-1652053804791829737
	.quad	-6025006692552756421
	.quad	-7950062655635975442
	.quad	6303799689591218186
	.quad	-5325892301117581398
	.quad	-1343622424865753076
	.quad	-2045679357969588844
	.quad	1466078993672598280
	.quad	-8196078626372074883
	.quad	6444284760518135753
	.quad	-5633412264537705700
	.quad	8055355950647669692
	.quad	-2430079312244744221
	.quad	2728754459941099605
	.quad	-8436328597794046994
	.quad	-5812428961928401301
	.quad	-5933724728815170839
	.quad	1957835834444274181
	.quad	-2805469892591575644
	.quad	-7999724640327104445
	.quad	-8670947710510816634
	.quad	3835402254873283156
	.quad	-6226998619711132888
	.quad	4794252818591603945
	.quad	-3172062256211528206
	.quad	7608094030047140370
	.quad	-8900067937773286985
	.quad	4898431519131537558
	.quad	-6513398903789220827
	.quad	-7712018656367741764
	.quad	-3530062611309138130
	.quad	2097517367411243254
	.quad	-9123818159709293187
	.quad	7233582727691441971
	.quad	-6793086681209228580
	.quad	9041978409614302463
	.quad	-3879672333084147821
	.quad	6690786993590490175
	.quad	-237904397927796872
	.quad	4181741870994056360
	.quad	-7066219276345954901
	.quad	615491320315182545
	.quad	-4221088077005055722
	.quad	-8454007886460797626
	.quad	-664674077828931749
	.quad	3939617107816777292
	.quad	-7332950326284164199
	.quad	-8910536670511192098
	.quad	-4554501889427817345
	.quad	7308573235570561494
	.quad	-1081441343357383777
	.quad	-6961356773836868826
	.quad	-7593429867239446717
	.quad	-8701695967296086033
	.quad	-4880101315621920492
	.quad	-6265433940692719637
	.quad	-1488440626100012711
	.quad	695789805494438131
	.quad	-7847804418953589800
	.quad	869737256868047664
	.quad	-5198069505264599346
	.quad	-8136200465769716229
	.quad	-1885900863153361279
	.quad	-473439272678684739
	.quad	-8096217067111932656
	.quad	4019886927579031981
	.quad	-5508585315462527915
	.quad	-8810199395808373736
	.quad	-2274045625900771990
	.quad	-7812217631593927537
	.quad	-8338807543829064350
	.quad	4069786015789754291
	.quad	-5811823411358942533
	.quad	475546501309804959
	.quad	-2653093245771290262
	.quad	4908902581746016004
	.quad	-8575712306248138270
	.quad	-3087243809672255804
	.quad	-6107954364382784934
	.quad	-8470740780517707659
	.quad	-3023256937051093263
	.quad	-682526969396179382
	.quad	-8807064613298015146
	.quad	-5464844730172612132
	.quad	-6397144748195131028
	.quad	-2219369894288377261
	.quad	-3384744916816525881
	.quad	-1387106183930235788
	.quad	-9032994600651410532
	.quad	2877803288514593169
	.quad	-6679557232386875260
	.quad	3597254110643241461
	.quad	-3737760522056206171
	.quad	9108253656731439730
	.quad	-60514634142869810
	.quad	1080972517029761927
	.quad	-6955350673980375487
	.quad	5962901664714590313
	.quad	-4082502324048081455
	.quad	-6381430974388925821
	.quad	-491441886632713915
	.quad	-8600080377420466542
	.quad	-7224680206786528053
	.quad	7696643601933968438
	.quad	-4419164240055772162
	.quad	397432465562684740
	.quad	-912269281642327298
	.quad	-4363290727450709941
	.quad	-7487697328667536418
	.quad	8380944645968776285
	.quad	-4747935642407032618
	.quad	1252808770606194548
	.quad	-1323233534581402868
	.quad	-8440366555225904215
	.quad	-7744549986754458649
	.quad	7896285879677171347
	.quad	-5069001465015685407
	.quad	-3964700705685699528
	.quad	-1724565812842218855
	.quad	2133748077373825699
	.quad	-7995382660667468640
	.quad	2667185096717282124
	.quad	-5382542307406947896
	.quad	3333981370896602654
	.quad	-2116491865831296966
	.quad	6695424375237764563
	.quad	-8240336443785642460
	.quad	8369280469047205704
	.quad	-5688734536304665171
	.quad	-3373457468973156582
	.quad	-2499232151953443560
	.quad	-9025939945749304720
	.quad	-8479549122611984081
	.quad	7164319141522920716
	.quad	-5987750384837592197
	.quad	4343712908476262991
	.quad	-2873001962619602342
	.quad	7326506586225052274
	.quad	-8713155254278333320
	.quad	9158133232781315342
	.quad	-6279758049420528746
	.quad	2224294504121868369
	.quad	-3238011543348273028
	.quad	-7833187971778608077
	.quad	-8941286242233752499
	.quad	-568112927868484288
	.quad	-6564921784364802720
	.quad	3901544858591782543
	.quad	-3594466212028615495
	.quad	-4479063491021217766
	.quad	-9164070410158966541
	.quad	-5598829363776522208
	.quad	-6843401994271320272
	.quad	-2386850686293264856
	.quad	-3942566474411762436
	.quad	1628122660560806834
	.quad	-316522074587315140
	.quad	-8205795374004271537
	.quad	-7115355324258153819
	.quad	-1033872180650563613
	.quad	-4282508136895304370
	.quad	-5904026244240592420
	.quad	-741449152691742558
	.quad	-5995859411864064214
	.quad	-7380934748073420955
	.quad	1728547772024695540
	.quad	-4614482416664388289
	.quad	-2451001303396518479
	.quad	-1156417002403097458
	.quad	5385653213018257807
	.quad	-7640289654143017767
	.quad	-7102991539009341454
	.quad	-4938676049251384305
	.quad	-8878739423761676818
	.quad	-1561659043136842477
	.quad	3674159897003727797
	.quad	-7893565929601608404
	.quad	4592699871254659746
	.quad	-5255271393574622601
	.quad	1129188820640936779
	.quad	-1957403223540890347
	.quad	3011586022114279439
	.quad	-8140906042354138323
	.quad	8376168546070237203
	.quad	-5564446534515285000
	.quad	-7976533391121755113
	.quad	-2343872149716718346
	.quad	1932195658189984911
	.quad	-8382449121214030822
	.quad	-6808127464117294670
	.quad	-5866375383090150624
	.quad	-3898473311719230433
	.quad	-2721283210435300376
	.quad	9092669226243950739
	.quad	-8618331034163144591
	.quad	-2469221522477225288
	.quad	-6161227774276542835
	.quad	6136845133758244198
	.quad	-3089848699418290639
	.quad	-3082000819042179232
	.quad	-8848684464777513506
	.quad	-8464187042230111944
	.quad	-6449169562544503978
	.quad	3254824252494523782
	.quad	-3449775934753242068
	.quad	-7189106879045698444
	.quad	-9073638986861858149
	.quad	-8986383598807123056
	.quad	-6730362715149934782
	.quad	2602078556773259892
	.quad	-3801267375510030573
	.quad	-1359087822460813039
	.quad	-139898200960150313
	.quad	-849429889038008149
	.quad	-7004965403241175802
	.quad	-5673473379724898090
	.quad	-4144520735624081848
	.quad	-2480155706228734709
	.quad	-568964901102714406
	.quad	-3855940325606653145
	.quad	-7273132090830278360
	.quad	-208239388580928527
	.quad	-4479729095110460046
	.quad	-4871985254153548563
	.quad	-987975350460687153
	.quad	-3044990783845967852
	.quad	-7535013621679011327
	.quad	5417133557047315993
	.quad	-4807081008671376254
	.quad	-2451955090545630817
	.quad	-1397165242411832414
	.quad	-3838314940804713212
	.quad	-7790757304148477115
	.quad	4425478360848884292
	.quad	-5126760611758208489
	.quad	920161932633717461
	.quad	-1796764746270372707
	.quad	2880944217109767366
	.quad	-8040506994060064798
	.quad	-5622191765467566601
	.quad	-5438947724147693094
	.quad	6807318348447705460
	.quad	-2186998636757228463
	.quad	-2662955059861265943
	.quad	-8284403175614349646
	.quad	-7940379843253970333
	.quad	-5743817951090549153
	.quad	8521269269642088700
	.quad	-2568086420435798537
	.quad	-6203421752542164322
	.quad	-8522583040413455942
	.quad	6080780864604458309
	.quad	-6041542782089432023
	.quad	-6234081974526590826
	.quad	-2940242459184402125
	.quad	5327070802775656542
	.quad	-8755180564631333184
	.quad	6658838503469570677
	.quad	-6332289687361778576
	.quad	8323548129336963346
	.quad	-3303676090774835316
	.quad	-4021154456019173716
	.quad	-8982326584375353929
	.quad	-5026443070023967146
	.quad	-6616222212041804507
	.quad	2940318199324816876
	.quad	-3658591746624867729
	.quad	8755227902219092404
	.quad	-9204148869281624187
	.quad	-2891023177508298208
	.quad	-6893500068174642330
	.quad	-8225464990312760664
	.quad	-4005189066790915008
	.quad	-5670145219463562926
	.quad	-394800315061255856
	.quad	7985374283903742932
	.quad	-7164279224554366766
	.quad	758345818024902857
	.quad	-4343663012265570553
	.quad	-3663753745896259333
	.quad	-817892746904575288
	.quad	-9207375118826243939
	.quad	-7428711994456441411
	.quad	-2285846861678029116
	.quad	-4674203974643163860
	.quad	1754377441329851509
	.quad	-1231068949876566920
	.quad	1096485900831157193
	.quad	-7686947121313936181
	.quad	-3241078642388441413
	.quad	-4996997883215032323
	.quad	5172023733869224042
	.quad	-1634561335591402499
	.quad	5538357842881958978
	.quad	-7939129862385708418
	.quad	-2300424733252327085
	.quad	-5312226309554747619
	.quad	6347841120289366951
	.quad	-2028596868516046619
	.quad	6273243709394548297
	.quad	-8185402070463610993
	.quad	3229868618315797467
	.quad	-5620066569652125837
	.quad	-574350245532641070
	.quad	-2413397193637769393
	.quad	-358968903457900669
	.quad	-8425902273664687727
	.quad	8774660907532399972
	.quad	-5920691823653471754
	.quad	1744954097560724157
	.quad	-2789178761139451788
	.quad	-8132775725879323210
	.quad	-8660765753353239224
	.quad	-5554283638921766109
	.quad	-6214271173264161126
	.quad	6892203506629956076
	.quad	-3156152948152813503
	.quad	-2609901835997359308
	.quad	-8890124620236590296
	.quad	1349308723430688769
	.quad	-6500969756868349965
	.quad	-2925050114139026943
	.quad	-3514526177658049553
	.quad	-1828156321336891839
	.quad	-9114107888677362827
	.quad	6938176635183661009
	.quad	-6780948842419315629
	.quad	4061034775552188357
	.quad	-3864500034596756632
	.quad	5076293469440235446
	.quad	-218939024818557886
	.quad	7784369436827535058
	.quad	-7054365918152680535
	.quad	-4104596259247744890
	.quad	-4206271379263462765
	.quad	-5130745324059681112
	.quad	-646153205651940552
	.size	global_constant_0, 9904

	.type	static_string_e1c7ba1ec05cb570,@object
	.p2align	4, 0x0
static_string_e1c7ba1ec05cb570:
	.asciz	"oss/modular/mojo/stdlib/std/collections/check_bounds.mojo"
	.size	static_string_e1c7ba1ec05cb570, 58

	.type	static_string_ac6214ef63a1e455,@object
	.p2align	4, 0x0
static_string_ac6214ef63a1e455:
	.asciz	"slice start index "
	.size	static_string_ac6214ef63a1e455, 19

	.type	static_string_3892d7ebe761439e,@object
	.p2align	4, 0x0
static_string_3892d7ebe761439e:
	.asciz	"slice end index "
	.size	static_string_3892d7ebe761439e, 17

	.type	static_string_fb3c88b69992ef11,@object
	.p2align	4, 0x0
static_string_fb3c88b69992ef11:
	.asciz	" is greater than slice end index "
	.size	static_string_fb3c88b69992ef11, 34

	.type	static_string_e7661a0566dadf97,@object
	.p2align	4, 0x0
static_string_e7661a0566dadf97:
	.asciz	"'"
	.size	static_string_e7661a0566dadf97, 2

	.type	static_string_ffbf4d7e5dffbc40,@object
	.p2align	4, 0x0
static_string_ffbf4d7e5dffbc40:
	.asciz	"String is not convertible to integer with base "
	.size	static_string_ffbf4d7e5dffbc40, 48

	.type	static_string_0eb5fc97304e63c7,@object
	.p2align	4, 0x0
static_string_0eb5fc97304e63c7:
	.asciz	": '"
	.size	static_string_0eb5fc97304e63c7, 4

	.type	static_string_98e090712d66312f,@object
	.p2align	4, 0x0
static_string_98e090712d66312f:
	.asciz	"HEAP_BUFFER_BYTES exceeded, increase with: `mojo -D HEAP_BUFFER_BYTES=4096`\n"
	.size	static_string_98e090712d66312f, 77

	.type	static_string_0d78baac08237ddb,@object
	.p2align	4, 0x0
static_string_0d78baac08237ddb:
	.asciz	"a"
	.size	static_string_0d78baac08237ddb, 2

	.type	static_string_0dcb71a55f79a509,@object
	.p2align	4, 0x0
static_string_0dcb71a55f79a509:
	.asciz	"At: %s:%llu:%llu: Assert Error: %s\n"
	.size	static_string_0dcb71a55f79a509, 36

	.type	static_string_e167731b2f840751,@object
	.p2align	4, 0x0
static_string_e167731b2f840751:
	.asciz	"oss/modular/mojo/stdlib/std/memory/alloc.mojo"
	.size	static_string_e167731b2f840751, 46

	.type	static_string_09e773a88105e290,@object
	.p2align	4, 0x0
static_string_09e773a88105e290:
	.asciz	"alloc failed: returned a null pointer"
	.size	static_string_09e773a88105e290, 38

	.type	static_string_f9c5d72f244f07d1,@object
	.p2align	4, 0x0
static_string_f9c5d72f244f07d1:
	.asciz	"`Optional.value()` called on empty `Optional`. Consider using `if optional:` to check whether the `Optional` is empty before calling `.value()`, or use `.or_else()` to provide a default value."
	.size	static_string_f9c5d72f244f07d1, 193

	.type	static_string_31203c1a2bdb78cc,@object
	.p2align	4, 0x0
static_string_31203c1a2bdb78cc:
	.asciz	"ABORT:"
	.size	static_string_31203c1a2bdb78cc, 7

	.type	static_string_bbe01a6a523daf15,@object
	.p2align	4, 0x0
static_string_bbe01a6a523daf15:
	.asciz	"\n"
	.size	static_string_bbe01a6a523daf15, 2

	.type	static_string_7f1562353e292282,@object
	.p2align	4, 0x0
static_string_7f1562353e292282:
	.asciz	": "
	.size	static_string_7f1562353e292282, 3

	.type	static_string_1e19992a0a485e4d,@object
	.p2align	4, 0x0
static_string_1e19992a0a485e4d:
	.asciz	"oss/modular/mojo/stdlib/std/collections/string/codepoint.mojo"
	.size	static_string_1e19992a0a485e4d, 62

	.type	static_string_d02c1546a6049ede,@object
	.p2align	4, 0x0
static_string_d02c1546a6049ede:
	.asciz	"Codepoint.ord: input string must not be empty"
	.size	static_string_d02c1546a6049ede, 46

	.type	static_string_e19fed3f50227db6,@object
	.p2align	4, 0x0
static_string_e19fed3f50227db6:
	.asciz	" String expresses an integer too large to store in Int."
	.size	static_string_e19fed3f50227db6, 56

	.type	static_string_69b8ed51c73424d7,@object
	.p2align	4, 0x0
static_string_69b8ed51c73424d7:
	.asciz	"max/mojo/max/gpu/host/device_context.mojo"
	.size	static_string_69b8ed51c73424d7, 42

	.type	static_string_ffe5c571af8dd3fc,@object
	.p2align	4, 0x0
static_string_ffe5c571af8dd3fc:
	.asciz	"index "
	.size	static_string_ffe5c571af8dd3fc, 7

	.type	static_string_a0fcf35b7349c924,@object
	.p2align	4, 0x0
static_string_a0fcf35b7349c924:
	.asciz	" is out of bounds, valid range is 0 to "
	.size	static_string_a0fcf35b7349c924, 40

	.type	static_string_0c4c4fc91aeab35e,@object
	.p2align	4, 0x0
static_string_0c4c4fc91aeab35e:
	.asciz	"/root/performance/bench/gemv_serial_layout_main.mojo"
	.size	static_string_0c4c4fc91aeab35e, 53

	.type	static_string_9f98073b08f39257,@object
	.p2align	4, 0x0
static_string_9f98073b08f39257:
	.asciz	" size mismatch"
	.size	static_string_9f98073b08f39257, 15

	.type	static_string_18a20bf0a49020c4,@object
	.p2align	4, 0x0
static_string_18a20bf0a49020c4:
	.asciz	" bit mismatch at "
	.size	static_string_18a20bf0a49020c4, 18

	.type	static_string_2d06800538d394c2,@object
	.p2align	4, 0x0
static_string_2d06800538d394c2:
	.size	static_string_2d06800538d394c2, 0

	.type	static_string_c44bdff4074eecdb,@object
	.p2align	4, 0x0
static_string_c44bdff4074eecdb:
	.zero	1
	.size	static_string_c44bdff4074eecdb, 1

	.type	static_string_a8d4ace0dc8d360e,@object
	.p2align	4, 0x0
static_string_a8d4ace0dc8d360e:
	.asciz	" "
	.size	static_string_a8d4ace0dc8d360e, 2

	.type	static_string_5b36d0b72ea8da9a,@object
	.p2align	4, 0x0
static_string_5b36d0b72ea8da9a:
	.asciz	"unchanged_selection"
	.size	static_string_5b36d0b72ea8da9a, 20

	.type	static_string_ab27f80eac047a9c,@object
	.p2align	4, 0x0
static_string_ab27f80eac047a9c:
	.asciz	"prepared_distance"
	.size	static_string_ab27f80eac047a9c, 18

	.type	static_string_b19b1e892664eeb4,@object
	.p2align	4, 0x0
static_string_b19b1e892664eeb4:
	.asciz	"transpose_plus_distance"
	.size	static_string_b19b1e892664eeb4, 24

	.type	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel",@object
	.p2align	2, 0x0
".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel":
	.long	static_string_b19b1e892664eeb4-".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel"
	.long	static_string_ab27f80eac047a9c-".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel"
	.long	static_string_5b36d0b72ea8da9a-".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel"
	.size	".Lswitch.table.knn_index_layout_main::_case(::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::SIMD[::DType(int), ::SIMDLength(1)],::Bool,::SIMD[::DType(int), ::SIMDLength(1)]).1.rel", 12

	.section	".note.GNU-stack","",@progbits
