# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Andrew Hendel. Part of mojolearn, https://doi.org/10.5281/zenodo.22068632
"""CPython boundary for the verified metrics kernels and for spectral clustering.

Kept in a SEPARATE extension, like `_mojolearn_estimators.mojo`, so an
independently changing binding does not become a merge point. Arrays cross
as borrowed NumPy addresses; every device buffer and context lives for one
call and no pointer is retained past the call that was handed it.

`metrics/` and `spectral/` both got
their Python surface in the same round and neither is large enough to earn a
build script of its own. They share nothing but this file and
`bindings/build_metrics.sh`.
UMAP shares this extension because its pipeline uses the same neighbor and
spectral primitives. Its source fixture evidence is recorded in umap/README.md;
its Python surface is gated separately by tests/test_umap_surface.py.

WHY THE SCALARS ARRIVE AS ONE LIST. `PythonModuleBuilder.def_function`
infers its signature from arity and stops working above roughly nine
arguments. Buffer addresses go positionally, every scalar goes in one
`params` list, and **THE ORDER OF THAT LIST IS WRITTEN OUT IN A COMMENT ON
BOTH SIDES IN THE SAME WORDS** -- here and in
`python/mojolearn/_metrics_impl.py` / `_spectral_impl.py`. A silent
reordering here is a WRONG ANSWER rather than a failure, so every entry
below also checks `len(params)` and names the count it wanted.

THE CERTIFICATION STATUS OF THE TWO LANES IS NOT THE SAME, and a reader of
this file should know which is which before believing a number that comes
out of it:

  * `metrics/` is CERTIFIED bit-identical Apple M4 <-> NVIDIA H100 <-> AMD
    MI325X at leg 11 (`archive/evidence/E3_RESULTS.md` round 11, commit 144aa5b, section 7,
    34 stages), on the 34-stage card of that commit. The card has since
    grown to 61 stages on Apple only; the three-vendor leg on the GROWN card
    is OWED (`metrics/README.md` Status).
  * `spectral/` has run on ONE Apple M4 and NOWHERE ELSE. Its contract says
    so in section 10: "no cross-vendor result of any kind". It is not in
    `tools/e1_bootstrap.sh` phase 8, it has no card in either leg-11 lane
    directory, and `tools/e3_round_judge.sh` section 7 does not name it.

Neither of those sentences may be softened in this file or in the Python
wrappers without a leg to point at.
"""

# DEVIATION 2486: shared byte-preserving host copies.
from bindings.hostptr import f32_ptr, i32_ptr, read_f32, read_i32
from std.os import abort
from std.python import Python, PythonObject
from std.python._cpython import GILReleased
from std.python.bindings import PythonModuleBuilder

from checks.vendor import COMPILED_VENDOR
from checks.numerics import GLOBAL_NUMERIC_MODE
from max.gpu.host import DeviceContext
from std.math import isfinite
from umap.estimator import fit_transform as umap_fit_transform
from umap.transform import transform as umap_transform
from umap.params import UMAPParams

from metrics.estimator import (
    accuracy_score_host,
    adjusted_rand_score_host,
    completeness_score_host,
    entropy_host,
    homogeneity_score_host,
    kl_divergence_host,
    mutual_info_score_host,
    r2_score_host,
    regression_error_host,
    log_loss_host,
    binary_ranking_host,
    confusion_matrix_host,
    precision_recall_fscore_host,
    rand_score_host,
    silhouette_host,
    trustworthiness_host,
    v_measure_score_host,
)
from spectral.estimator import (
    spectral_fit_predict_dataset_host,
    spectral_fit_predict_graph_host,
)


def _f32_ptr(addr: Int) raises -> MutPointer[Float32, MutUntrackedOrigin]:
    return f32_ptr(addr)


def _i32_ptr(addr: Int) raises -> MutPointer[Int32, MutUntrackedOrigin]:
    return i32_ptr(addr)


def _load_i32(addr: Int, n: Int) raises -> List[Int32]:
    return read_i32(addr, max(0, n))


def _load_f32(addr: Int, n: Int) raises -> List[Float32]:
    return read_f32(addr, max(0, n))


def _want(name: String, params: PythonObject, k: Int) raises:
    if len(params) != k:
        raise Error(
            name + ": params must contain " + String(k) + " values, got "
            + String(len(params))
        )


# ===========================================================================
# Group A: the label metrics. int32 labels, one shape each.
# ===========================================================================


def accuracy_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::accuracy_score_py`: the fraction of agreeing positions.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
    """
    _want(String("accuracy_score"), params, 1)
    var n = Int(py=params[0])
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float32(0.0)
    with GILReleased(Python()):
        out = accuracy_score_host(yt, yp, n)
    return PythonObject(Float64(out))


def rand_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::rand_index` (DEVIATION 652).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
    """
    _want(String("rand_score"), params, 1)
    var n = Int(py=params[0])
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = rand_score_host(yt, yp, n)
    return PythonObject(out)


def adjusted_rand_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::adjusted_rand_index`, the int32 instantiation. Takes
    RAW labels: this entry has no label range, because theirs has none.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
    """
    _want(String("adjusted_rand_score"), params, 1)
    var n = Int(py=params[0])
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = adjusted_rand_score_host(yt, yp, n)
    return PythonObject(out)


def entropy_binding(
    labels_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::entropy`, in NATS (DEVIATIONS 650, 651).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
        1  lower_class_range
        2  upper_class_range
    """
    _want(String("entropy"), params, 3)
    var n = Int(py=params[0])
    var lower = Int32(Int(py=params[1]))
    var upper = Int32(Int(py=params[2]))
    var lab = _load_i32(Int(py=labels_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = entropy_host(lab, n, lower, upper)
    return PythonObject(out)


def mutual_info_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::mutual_info_score`, in NATS (DEVIATIONS 650, 651).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
        1  lower_class_range
        2  upper_class_range
    """
    _want(String("mutual_info_score"), params, 3)
    var n = Int(py=params[0])
    var lower = Int32(Int(py=params[1]))
    var upper = Int32(Int(py=params[2]))
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = mutual_info_score_host(yt, yp, n, lower, upper)
    return PythonObject(out)


def homogeneity_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::homogeneity_score`.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
        1  lower_class_range
        2  upper_class_range
    """
    _want(String("homogeneity_score"), params, 3)
    var n = Int(py=params[0])
    var lower = Int32(Int(py=params[1]))
    var upper = Int32(Int(py=params[2]))
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = homogeneity_score_host(yt, yp, n, lower, upper)
    return PythonObject(out)


def completeness_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::completeness_score` (RAFT's homogeneity with the two
    arrays swapped, so the TRANSPOSED fold).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
        1  lower_class_range
        2  upper_class_range
    """
    _want(String("completeness_score"), params, 3)
    var n = Int(py=params[0])
    var lower = Int32(Int(py=params[1]))
    var upper = Int32(Int(py=params[2]))
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = completeness_score_host(yt, yp, n, lower, upper)
    return PythonObject(out)


def v_measure_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::v_measure` with `beta` honored.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
        1  lower_class_range
        2  upper_class_range
        3  beta               (float)
    """
    _want(String("v_measure_score"), params, 4)
    var n = Int(py=params[0])
    var lower = Int32(Int(py=params[1]))
    var upper = Int32(Int(py=params[2]))
    var beta = Float64(py=params[3])
    var yt = _load_i32(Int(py=y_true_addr), n)
    var yp = _load_i32(Int(py=y_pred_addr), n)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = v_measure_score_host(yt, yp, n, lower, upper, beta)
    return PythonObject(out)


# ===========================================================================
# Group B: r2 and KL divergence. float32 in, float32 out.
# ===========================================================================


def r2_score_binding(
    y_true_addr: PythonObject,
    y_pred_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::r2_score_py`, the float overload (DEVIATIONS 653, 657).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
    """
    _want(String("r2_score"), params, 1)
    var n = Int(py=params[0])
    var y = _load_f32(Int(py=y_true_addr), n)
    var yh = _load_f32(Int(py=y_pred_addr), n)
    var out = Float32(0.0)
    with GILReleased(Python()):
        out = r2_score_host(y, yh, n)
    return PythonObject(Float64(out))



def regression_error_binding[absolute: Bool = False, root: Bool = False](
    y_true_addr: PythonObject, y_pred_addr: PythonObject, params: PythonObject,
) raises -> PythonObject:
    # params[0] = n; finite 1-D Float32, unweighted. Entire reduction is GPU.
    _want(String("regression_error"), params, 1)
    var n = Int(py=params[0])
    var y = _load_f32(Int(py=y_true_addr), n)
    var prediction = _load_f32(Int(py=y_pred_addr), n)
    var result = Float32(0.0)
    with GILReleased(Python()):
        result = regression_error_host[absolute, root](y, prediction, n)
    return PythonObject(Float64(result))




def roc_auc_score_binding(true_addr: PythonObject, score_addr: PythonObject, out_addr: PythonObject, params: PythonObject) raises -> PythonObject:
    _want(String("roc_auc_score"),params,1)
    var n = Int(py=params[0])
    if n <= 0 or n > 2147483647:
        raise Error("roc_auc_score: invalid n")
    var y = _load_i32(Int(py=true_addr),n)
    var scores = _load_f32(Int(py=score_addr),n)
    var output = _f32_ptr(Int(py=out_addr))
    with GILReleased(Python()):
        var result = binary_ranking_host[False](y,scores,n)
        output.unsafe_store(0,result[0][0])
    return PythonObject(1)


def precision_recall_curve_binding(true_addr: PythonObject, score_addr: PythonObject, precision_addr: PythonObject, recall_addr: PythonObject, threshold_addr: PythonObject, params: PythonObject) raises -> PythonObject:
    _want(String("precision_recall_curve"),params,1)
    var n = Int(py=params[0])
    if n <= 0 or n > 2147483647:
        raise Error("precision_recall_curve: invalid n")
    var y = _load_i32(Int(py=true_addr),n)
    var scores = _load_f32(Int(py=score_addr),n)
    var precision = _f32_ptr(Int(py=precision_addr))
    var recall = _f32_ptr(Int(py=recall_addr))
    var thresholds = _f32_ptr(Int(py=threshold_addr))
    var m = 0
    with GILReleased(Python()):
        var result = binary_ranking_host[True](y,scores,n)
        m = result[1]
        for i in range(m+1):
            precision.unsafe_store(i,result[0][i])
            recall.unsafe_store(i,result[0][n+1+i])
        for i in range(m):
            thresholds.unsafe_store(i,result[0][2*(n+1)+i])
    return PythonObject(m)


def log_loss_binding(
    true_addr: PythonObject, probabilities_addr: PythonObject, out_addr: PythonObject, params: PythonObject,
) raises -> PythonObject:
    _want(String("log_loss"), params, 3)
    var n = Int(py=params[0])
    var k = Int(py=params[1])
    var normalize = Int(py=params[2])
    if n <= 0 or n > 2147483647 or k < 2 or k > 2147483647 // n:
        raise Error("log_loss: invalid input dimensions")
    var y = _load_i32(Int(py=true_addr), n)
    var probability = _load_f32(Int(py=probabilities_addr), n*k)
    var out = _f32_ptr(Int(py=out_addr))
    with GILReleased(Python()):
        out.unsafe_store(0, log_loss_host(y,probability,n,k,normalize))
    return PythonObject(1)


def confusion_matrix_binding(
    true_addr: PythonObject, pred_addr: PythonObject, out_addr: PythonObject, params: PythonObject,
) raises -> PythonObject:
    # params=[n,n_classes,normalization]; norm0:Int64,1true/2pred/3all:Float32.
    _want(String("confusion_matrix"),params,3)
    var n = Int(py=params[0])
    var k = Int(py=params[1])
    var normalization = Int(py=params[2])
    var address = Int(py=out_addr)
    if address == 0:
        raise Error("confusion_matrix: null output")
    var y = _load_i32(Int(py=true_addr),n)
    var p = _load_i32(Int(py=pred_addr),n)
    if normalization == 0:
        var output = MutPointer[Int64, MutUntrackedOrigin](unsafe_from_address=address)
        with GILReleased(Python()):
            var values = confusion_matrix_host[DType.int64](y,p,n,k,normalization)
            for i in range(len(values)):
                output.unsafe_store(i,values[i])
    else:
        var output = _f32_ptr(address)
        with GILReleased(Python()):
            var values = confusion_matrix_host[DType.float32](y,p,n,k,normalization)
            for i in range(len(values)):
                output.unsafe_store(i,values[i])
    return PythonObject(k*k)


def precision_recall_fscore_binding(
    true_addr: PythonObject, pred_addr: PythonObject, out_addr: PythonObject, params: PythonObject,
) raises -> PythonObject:
    # params=[n,k,average,pos_idx,zero_division,n_selected]. The selected
    # classes are first in the encoding; all remaining labels STILL count.
    # avg0None/1binary/2micro/3macro/4weighted. Output3*w+3 Float32:
    # precision,recall,F1 rows; three trailing undefined flags.
    _want(String("precision_recall_fscore"),params,6)
    var n = Int(py=params[0])
    var k = Int(py=params[1])
    var average = Int(py=params[2])
    var positive = Int(py=params[3])
    var zero = Int(py=params[4])
    var selected = Int(py=params[5])
    var y = _load_i32(Int(py=true_addr),n)
    var p = _load_i32(Int(py=pred_addr),n)
    var output = _f32_ptr(Int(py=out_addr))
    var written = 0
    with GILReleased(Python()):
        var values = precision_recall_fscore_host(y,p,n,k,average,positive,zero,selected)
        for i in range(len(values)):
            output.unsafe_store(i,values[i])
        written = len(values)
    return PythonObject(written)


def kl_divergence_binding(
    p_addr: PythonObject,
    q_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::kl_divergence`, the float overload (DEVIATIONS 653,
    658). NOT normalized, exactly as theirs.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n
    """
    _want(String("kl_divergence"), params, 1)
    var n = Int(py=params[0])
    var p = _load_f32(Int(py=p_addr), n)
    var q = _load_f32(Int(py=q_addr), n)
    var out = Float32(0.0)
    with GILReleased(Python()):
        out = kl_divergence_host(p, q, n)
    return PythonObject(Float64(out))


# ===========================================================================
# Group C: silhouette. Writes n_rows per-sample scores, returns their mean.
# ===========================================================================


def silhouette_binding(
    x_addr: PythonObject,
    labels_addr: PythonObject,
    scores_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::Batched::silhouette_score`, the float batched entry
    cuML's Python dispatches (DEVIATIONS 654, 656). Writes `n_rows` float32
    per-sample coefficients to `scores_addr` (cuML's `silhouette_samples`)
    and returns their mean (cuML's `silhouette_score`).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n_rows
        1  n_cols
        2  n_labels    (labels must already be mapped onto [0, n_labels-1])
        3  chunksize   (cuML's chunk, default 40000; validated >= 1,
                        SCHEDULING only -- no distance tile is materialized)

    There is no `metric` slot: only `DistanceType::L2SqrtUnexpanded` (cuML
    'euclidean'/'l2') is implemented and the Python wrapper refuses every other
    name before reaching here.
    """
    _want(String("silhouette"), params, 4)
    var n_rows = Int(py=params[0])
    var n_cols = Int(py=params[1])
    var n_labels = Int(py=params[2])
    var chunk = Int(py=params[3])
    var x = _load_f32(Int(py=x_addr), n_rows * n_cols)
    var lab = _load_i32(Int(py=labels_addr), n_rows)
    var sp = _f32_ptr(Int(py=scores_addr))
    var scores = List[Float32]()
    var mean = Float32(0.0)
    with GILReleased(Python()):
        mean = silhouette_host(x, lab, n_rows, n_cols, n_labels, chunk, scores)
    for i in range(n_rows):
        sp.unsafe_store(i, scores[i])
    return PythonObject(Float64(mean))


# ===========================================================================
# Group D: trustworthiness.
# ===========================================================================


def trustworthiness_binding(
    x_addr: PythonObject,
    x_embedded_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`ML::Metrics::trustworthiness_score<float, L2SqrtUnexpanded>`
    (DEVIATION 655).

    `params`, in this exact order (mirrored in
    `python/mojolearn/_metrics_impl.py`):

        0  n            (rows of X and of X_embedded)
        1  m            (columns of X)
        2  d            (columns of X_embedded)
        3  n_neighbors
        4  batch_size   (cuML's batchSize; validated >= 1, sizes nothing
                         because DEVIATION 655 counts ranks instead of
                         sorting the n x n distance matrix)
    """
    _want(String("trustworthiness"), params, 5)
    var n = Int(py=params[0])
    var m = Int(py=params[1])
    var d = Int(py=params[2])
    var n_neighbors = Int(py=params[3])
    var batch_size = Int(py=params[4])
    var x = _load_f32(Int(py=x_addr), n * m)
    var emb = _load_f32(Int(py=x_embedded_addr), n * d)
    var out = Float64(0.0)
    with GILReleased(Python()):
        out = trustworthiness_host(x, emb, n, m, d, n_neighbors, batch_size)
    return PythonObject(out)


# ===========================================================================
# spectral: cuML's `ML::SpectralClustering::fit_predict`, two overloads.
# ===========================================================================


def _guard_spectral_outputs(
    labels: List[Int32],
    embedding: List[Float32],
    n_samples: Int,
    n_components: Int,
) raises:
    """The two output buffers were sized by the Python caller from
    `n_samples` and `n_components`. Check what came back BEFORE writing a
    single element into them.

    `n_out == n_components` holds on the clustering path because cuVS's
    clustering overload sets `drop_first = false`, so this cannot fire
    today. It is here because the day it CAN fire -- somebody threading
    `drop_first` through, say -- the alternative is a silent heap overrun
    in a NumPy array, which is the worst failure this boundary can have."""
    if len(labels) != n_samples:
        raise Error(
            "spectral clustering: the kernel returned " + String(len(labels))
            + " labels for " + String(n_samples)
            + " samples; the output buffer was sized for n_samples"
        )
    if len(embedding) != n_samples * n_components:
        raise Error(
            "spectral clustering: the kernel returned "
            + String(len(embedding)) + " embedding floats, but the output"
            " buffer was sized for n_samples * n_components = "
            + String(n_samples * n_components)
        )


def spectral_fit_predict_dataset_binding(
    x_addr: PythonObject,
    labels_addr: PythonObject,
    embedding_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`fit_predict` on a DATASET (cuML `affinity='nearest_neighbors'`):
    kNN connectivity graph, Laplacian, thick-restart Lanczos, k-means.

    Writes `n_samples` int32 labels to `labels_addr` and the `n_samples x
    n_out` row-major embedding to `embedding_addr`; returns `n_out`, which
    equals `n_components` on this path because cuVS's clustering overload
    sets `drop_first = false`. The caller must have sized `embedding_addr`
    for `n_samples * n_components` floats.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_spectral_impl.py`):

        0  n_samples
        1  n_features
        2  n_clusters
        3  n_components
        4  n_init
        5  n_neighbors
        6  eigen_tol      (float; cuVS's plumbed `tolerance`, default 1e-5)
        7  seed           (cuVS's `rng_state` seed; the no-seed arm is
                           REFUSED by DEVIATION 772, so there is always one)
    """
    _want(String("spectral_fit_predict_dataset"), params, 8)
    var n_samples = Int(py=params[0])
    var n_features = Int(py=params[1])
    var n_clusters = Int(py=params[2])
    var n_components = Int(py=params[3])
    var n_init = Int(py=params[4])
    var n_neighbors = Int(py=params[5])
    var eigen_tol = Float32(Float64(py=params[6]))
    var seed = UInt64(Int(py=params[7]))
    var x = _load_f32(Int(py=x_addr), n_samples * n_features)
    var lp = _i32_ptr(Int(py=labels_addr))
    var ep = _f32_ptr(Int(py=embedding_addr))
    var labels = List[Int32]()
    var embedding = List[Float32]()
    var n_out = 0
    with GILReleased(Python()):
        n_out = spectral_fit_predict_dataset_host(
            x, n_samples, n_features, n_clusters, n_components, n_init,
            n_neighbors, eigen_tol, seed, labels, embedding,
        )
    _guard_spectral_outputs(labels, embedding, n_samples, n_components)
    for i in range(n_samples):
        lp.unsafe_store(i, labels[i])
    for i in range(len(embedding)):
        ep.unsafe_store(i, embedding[i])
    return PythonObject(n_out)


def spectral_fit_predict_graph_binding(
    rows_addr: PythonObject,
    cols_addr: PythonObject,
    vals_addr: PythonObject,
    labels_addr: PythonObject,
    embedding_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """`fit_predict` on a PRECOMPUTED connectivity graph given as COO
    triples (cuML `affinity='precomputed'`). No kNN runs, so `n_neighbors`
    is carried in the config and read by nobody on this path.

    Writes `n_samples` int32 labels and the `n_samples x n_out` row-major
    embedding; returns `n_out`.

    `params`, in this exact order (mirrored in
    `python/mojolearn/_spectral_impl.py`):

        0  n_samples
        1  nnz            (length of rows, cols and vals)
        2  n_clusters
        3  n_components
        4  n_init
        5  n_neighbors    (carried, unused on this path)
        6  eigen_tol      (float)
        7  seed
    """
    _want(String("spectral_fit_predict_graph"), params, 8)
    var n_samples = Int(py=params[0])
    var nnz = Int(py=params[1])
    var n_clusters = Int(py=params[2])
    var n_components = Int(py=params[3])
    var n_init = Int(py=params[4])
    var n_neighbors = Int(py=params[5])
    var eigen_tol = Float32(Float64(py=params[6]))
    var seed = UInt64(Int(py=params[7]))
    var rows = _load_i32(Int(py=rows_addr), nnz)
    var cols = _load_i32(Int(py=cols_addr), nnz)
    var vals = _load_f32(Int(py=vals_addr), nnz)
    var lp = _i32_ptr(Int(py=labels_addr))
    var ep = _f32_ptr(Int(py=embedding_addr))
    var labels = List[Int32]()
    var embedding = List[Float32]()
    var n_out = 0
    with GILReleased(Python()):
        n_out = spectral_fit_predict_graph_host(
            rows, cols, vals, n_samples, n_clusters, n_components, n_init,
            n_neighbors, eigen_tol, seed, labels, embedding,
        )
    _guard_spectral_outputs(labels, embedding, n_samples, n_components)
    for i in range(n_samples):
        lp.unsafe_store(i, labels[i])
    for i in range(len(embedding)):
        ep.unsafe_store(i, embedding[i])
    return PythonObject(n_out)


def umap_fit_transform_binding(
    x_addr: PythonObject,
    embedding_addr: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """Borrow input/output buffers for the supported UMAP slice.

    params order (mirrored in _umap_impl.py): n_samples, n_features,
    n_neighbors, n_components, n_epochs, min_dist, spread,
    set_op_mix_ratio, local_connectivity, random_state, then optional
    learning_rate, repulsion_strength, negative_sample_rate.
    """
    if len(params) != 10:
        _want(String("umap_fit_transform"), params, 13)
    var n = Int(py=params[0])
    var d = Int(py=params[1])
    var seed = Int(py=params[9])
    if d < 1 or seed < 0:
        raise Error("UMAP requires positive features and a nonnegative seed")
    var config = UMAPParams(
        n_neighbors=Int(py=params[2]), n_components=Int(py=params[3]),
        n_epochs=Int(py=params[4]), min_dist=Float32(Float64(py=params[5])),
        spread=Float32(Float64(py=params[6])),
        set_op_mix_ratio=Float32(Float64(py=params[7])),
        local_connectivity=Float32(Float64(py=params[8])),
        random_seed=UInt64(seed),
    )
    if len(params) == 13:
        config.learning_rate = Float32(Float64(py=params[10]))
        config.repulsion_strength = Float32(Float64(py=params[11]))
        config.negative_sample_rate = Int(py=params[12])
    config.validate(n)
    if (config.n_components != 2 and config.n_components != 3) or (
        n < 2 * config.n_components + 4
    ):
        raise Error("UMAP requires 2D/3D output and enough samples for spectral init")
    var x = _load_f32(Int(py=x_addr), n * d)
    var output = _f32_ptr(Int(py=embedding_addr))
    var embedding = List[Float32]()
    with GILReleased(Python()):
        var ctx = DeviceContext()
        embedding = umap_fit_transform(ctx, x, n, d, config)
    if len(embedding) != n * config.n_components:
        raise Error("UMAP returned an unexpected embedding shape")
    for value in embedding:
        if not isfinite(value):
            raise Error("UMAP returned a non-finite embedding")
    for i in range(len(embedding)):
        output.unsafe_store(i, embedding[i])
    return PythonObject(config.n_components)


def umap_transform_binding(addrs: PythonObject, params: PythonObject) raises -> PythonObject:
    """Addresses: training X, frozen embedding, query X, output.

    Scalars: n_train, n_queries, n_features, then the eight legacy fit parameters
    and optional learning_rate, repulsion_strength, negative_sample_rate.
    The training arrays are read-only; only output is written.
    """
    _want(String("umap_transform addresses"), addrs, 4)
    if len(params) != 11:
        _want(String("umap_transform parameters"), params, 14)
    var n = Int(py=params[0])
    var rows = Int(py=params[1])
    var d = Int(py=params[2])
    var seed = Int(py=params[10])
    if n < 2 or rows < 1 or d < 1 or seed < 0:
        raise Error("UMAP transform requires positive dimensions and a nonnegative seed")
    var config = UMAPParams(
        n_neighbors=Int(py=params[3]), n_components=Int(py=params[4]),
        n_epochs=Int(py=params[5]), min_dist=Float32(Float64(py=params[6])),
        spread=Float32(Float64(py=params[7])),
        set_op_mix_ratio=Float32(Float64(py=params[8])),
        local_connectivity=Float32(Float64(py=params[9])), random_seed=UInt64(seed),
    )
    if len(params) == 14:
        config.learning_rate = Float32(Float64(py=params[11]))
        config.repulsion_strength = Float32(Float64(py=params[12]))
        config.negative_sample_rate = Int(py=params[13])
    config.validate(n)
    if config.n_components != 2 and config.n_components != 3:
        raise Error("UMAP transform supports only 2D or 3D")
    var training = _load_f32(Int(py=addrs[0]), n * d)
    var fitted = _load_f32(Int(py=addrs[1]), n * config.n_components)
    var queries = _load_f32(Int(py=addrs[2]), rows * d)
    var output = _f32_ptr(Int(py=addrs[3]))
    var embedding = List[Float32]()
    with GILReleased(Python()):
        with DeviceContext() as ctx:
            embedding = umap_transform(ctx, training, fitted, queries, n, rows, d, config)
    if len(embedding) != rows * config.n_components:
        raise Error("UMAP transform returned an unexpected shape")
    for value in embedding:
        if not isfinite(value):
            raise Error("UMAP transform returned a non-finite embedding")
    for i in range(len(embedding)):
        output.unsafe_store(i, embedding[i])
    return PythonObject(config.n_components)


def umap_numeric_mode_binding() raises -> PythonObject:
    return PythonObject(Int(GLOBAL_NUMERIC_MODE))


def metrics_vendor_binding() raises -> PythonObject:
    """THE ACCELERATOR API THIS BINARY WAS COMPILED FOR: 'metal', 'cuda',
    'hip' or 'none'. A compile-time constant folded in from
    `checks/vendor.mojo`, the same shape as the tier read-back
    (`gbdt_numeric_mode`): the answer comes from the binary that actually
    loaded, never from the directory it sat in or from the environment.
    `python/mojolearn/_backend.py` refuses at import when this disagrees
    with the vendor directory the set was loaded from."""
    return PythonObject(String(COMPILED_VENDOR))


@export
def PyInit__mojolearn_metrics() abi("C") -> PythonObject:
    try:
        var m = PythonModuleBuilder("_mojolearn_metrics")
        m.def_function[metrics_vendor_binding]("metrics_vendor")
        m.def_function[umap_fit_transform_binding]("umap_fit_transform")
        m.def_function[umap_transform_binding]("umap_transform")
        m.def_function[umap_numeric_mode_binding]("umap_numeric_mode")
        m.def_function[accuracy_score_binding]("accuracy_score")
        m.def_function[rand_score_binding]("rand_score")
        m.def_function[adjusted_rand_score_binding]("adjusted_rand_score")
        m.def_function[entropy_binding]("entropy")
        m.def_function[mutual_info_score_binding]("mutual_info_score")
        m.def_function[homogeneity_score_binding]("homogeneity_score")
        m.def_function[completeness_score_binding]("completeness_score")
        m.def_function[v_measure_score_binding]("v_measure_score")
        m.def_function[r2_score_binding]("r2_score")
        m.def_function[roc_auc_score_binding]("roc_auc_score")
        m.def_function[precision_recall_curve_binding]("precision_recall_curve")
        m.def_function[log_loss_binding]("log_loss")
        m.def_function[confusion_matrix_binding]("confusion_matrix")
        m.def_function[precision_recall_fscore_binding]("precision_recall_fscore")
        m.def_function[regression_error_binding[False, False]]("mean_squared_error")
        m.def_function[regression_error_binding[True, False]]("mean_absolute_error")
        m.def_function[regression_error_binding[False, True]]("root_mean_squared_error")
        m.def_function[umap_numeric_mode_binding]("metrics_numeric_mode")
        m.def_function[kl_divergence_binding]("kl_divergence")
        m.def_function[silhouette_binding]("silhouette")
        m.def_function[trustworthiness_binding]("trustworthiness")
        m.def_function[spectral_fit_predict_dataset_binding](
            "spectral_fit_predict_dataset"
        )
        m.def_function[spectral_fit_predict_graph_binding](
            "spectral_fit_predict_graph"
        )
        return m.finalize()
    except e:
        abort(String("failed to create _mojolearn_metrics: ", e))
