# SPDX-License-Identifier: Apache-2.0
"""Cooperative classical estimators with explicit per-algorithm partitions."""
from ._parallel_pool import DevicePool
from ._buffer import as_f32_c


def fit_gram_estimator(estimator, X, y=None, *, devices=(0,), sample_weight=None):
    """Distribute the existing pinned Gram chunks for OLS, Ridge, PCA and SVD.

    This entry admits the Gram/eigendecomposition paths at 1..128 features.
    The root still owns preprocessing and solver state; this is computation
    partitioning, not a fit beyond one GPU's memory capacity.
    """
    from .linear_model import LinearRegression, Ridge
    from .decomposition import PCA, TruncatedSVD
    if type(estimator) not in (LinearRegression, Ridge, PCA, TruncatedSVD):
        raise TypeError('fit_gram_estimator requires LinearRegression, Ridge, PCA or TruncatedSVD')
    if estimator.numeric_mode not in (None, 'identical'):
        raise ValueError('parallel Gram estimators require IDENTICAL numeric mode')
    data, _ = as_f32_c(X, ndim=2, name='X')
    rows, columns = data.shape
    if not 1 <= columns <= 128:
        raise ValueError('parallel Gram currently requires 1..128 features')
    if type(estimator) is LinearRegression and rows < columns:
        raise ValueError('the wide minimum-norm OLS path is not yet distributed')
    if type(estimator) is PCA and estimator.svd_solver not in estimator._COV_SOLVERS:
        raise ValueError('parallel PCA currently requires a covariance solver')
    kwargs = {} if sample_weight is None else dict(sample_weight=sample_weight)
    pool = DevicePool(devices, cooperative=True)
    try:
        result = pool.map([('gram_fit', estimator, (data, y, kwargs))])[0]
    finally:
        pool.close()
    estimator.__dict__ = result.__dict__.copy()
    return estimator


def fit_arima(estimator, y, *, devices=(0,), series_per_shard=1, exog=None):
    """Fit independent series on GPU workers, retaining each solver's order.

    A worker receives only its series, so fitting does not require the entire
    batch on one GPU. A single series must still fit on one GPU. The returned
    estimator's existing prediction methods are unchanged and use one GPU.
    """
    from ._arima_impl import ARIMA, _series_major
    from ._buffer import empty, addr, addr_ro
    from ._bufcheck import memcopy
    if type(estimator) is not ARIMA:
        raise TypeError('fit_arima requires mojolearn.ARIMA')
    if exog is not None:
        raise NotImplementedError('ARIMA exogenous regressors are not implemented')
    if estimator.numeric_mode not in (None, 'identical'):
        raise ValueError('parallel ARIMA requires IDENTICAL numeric mode')
    if type(series_per_shard) is not int or series_per_shard < 1:
        raise ValueError('series_per_shard must be a positive integer')
    data, batch, observations, copied = _series_major(y, 'y')
    params = dict(order=estimator.order, seasonal_order=estimator.seasonal_order,
                  trend='c' if estimator.k_ else 'n', method=estimator.method,
                  maxiter=estimator.maxiter, numeric_mode='identical')
    requests = [('arima_fit', params, (data[start:start + series_per_shard],))
                for start in range(0, batch, series_per_shard)]
    pool = DevicePool(devices)
    try:
        parts = pool.map(requests)
    finally:
        pool.close()
    result = ARIMA(**params)
    result.__dict__.update(parts[0].__dict__)
    for name in ('params_', 'x_', 'x0_', 'n_iter_', 'retcode_', 'llf_', 'fx_', 'aic_', 'bic_'):
        arrays = [getattr(part, name) for part in parts]
        merged = empty((batch,) + arrays[0].shape[1:], arrays[0].dtype)
        cursor = 0
        for array in arrays:
            memcopy(addr(merged, name=name) + cursor, addr_ro(array, name=name), array.nbytes)
            cursor += array.nbytes
        setattr(result, name, merged)
    result.batch_size_, result.n_obs_ = batch, observations
    result._y, result.input_copied_ = data, copied
    estimator.__dict__ = result.__dict__.copy()
    return estimator


def fit_kmeans(estimator, X, *, devices=(0,), sample_weight=None):
    """Distribute KMeans row assignments; retain full-data update/reduction order.

    Initialization, fixed-point centroid sums, restart choice and convergence
    use the existing implementation. Whole aligned row tiles compute distances
    concurrently. This first path stages buffers per assignment call.
    """
    from .cluster import KMeans
    if type(estimator) is not KMeans:
        raise TypeError('fit_kmeans requires mojolearn.KMeans')
    params = {name: getattr(estimator, name) for name in (
        'n_clusters', 'init', 'n_init', 'max_iter', 'tol', 'random_state', 'init_centroids')}
    mode = getattr(estimator, 'numeric_mode', None)
    if mode not in (None, 'identical'):
        raise ValueError('parallel KMeans requires IDENTICAL numeric mode')
    params['numeric_mode'] = 'identical'
    X, _ = as_f32_c(X, ndim=2, name='X')
    if sample_weight is not None:
        sample_weight, _ = as_f32_c(sample_weight, ndim=1, name='sample_weight')
    pool = DevicePool(devices, cooperative=True)
    try:
        result = pool.map([('kmeans_fit', params, (X, sample_weight))])[0]
    finally:
        pool.close()
    estimator.__dict__ = result.__dict__.copy()
    return estimator
