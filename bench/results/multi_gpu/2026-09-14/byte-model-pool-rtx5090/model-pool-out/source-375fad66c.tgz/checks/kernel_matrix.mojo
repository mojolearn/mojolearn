# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Andrew Hendel. Part of mojolearn, https://doi.org/10.5281/zenodo.22068632
"""One table: every kernel, every tunable it takes, per GPU vendor."""

from std.sys.compile import is_defined
from std.sys.info import (
    has_amd_gpu_accelerator,
    has_amd_rdna_gpu_accelerator,
    has_apple_gpu_accelerator,
    has_nvidia_gpu_accelerator,
)

from checks.numerics import (
    NumericMode,
    NUMERIC_FAST,
    NUMERIC_IDENTICAL,
    GLOBAL_NUMERIC_MODE,
)


comptime COLUMN_BIT_IDENTICAL = 0
comptime COLUMN_APPLE = 1
comptime COLUMN_NVIDIA = 2
comptime COLUMN_AMD = 3

comptime COLUMN_AMD_RDNA = 4
comptime COLUMN_QUALCOMM = 5
comptime COLUMN_INTEL = 6

comptime COLUMN_SPEC_BASELINE = 7

#: THE CPU COLUMN (the CPU training lane, 2026-09-13; brief
#: docs/lanes/BRIEF_cpu_training_2026-09-13.md section 2). A build with NO
#: accelerator target compiles this column, never `COLUMN_APPLE`, which the
#: fallthrough of `TARGET_COLUMN` handed every host build until this column
#: existed. It is not a vendor: no kernel is launched on it, and every
#: NUMERIC row it answers is the pinned `COLUMN_BIT_IDENTICAL` reading, so a
#: host routine that MIRRORS a device fold reads the same widths and budgets
#: the identical contract pins (32 lanes, the 32 KB identity floor, 1024
#: threads). Every SCHEDULING and ROUTING row answers the non-vendor default,
#: never NVIDIA's or AMD's measured schedule and never Apple's repairs (the
#: kNN zero-FMA repair and preflight, the two-level quantize search, the
#: subnormal-flushing compare), because a CPU FMA rounds once and flushes
#: nothing. FAST rows never reach it: every `build_*_host.sh` is IDENTICAL
#: only. `bindings/build_byte_lm_host.sh` and `bindings/build_forest_host.sh`
#: pass `-D MOJOLEARN_COLUMN_CPU`, and each host binding carries
#: `comptime assert TARGET_COLUMN == COLUMN_CPU`.
comptime COLUMN_CPU = 8

comptime COLUMN_COUNT = 9

comptime COLUMN_METAL = COLUMN_APPLE
comptime COLUMN_CUDA = COLUMN_NVIDIA
comptime COLUMN_HIP = COLUMN_AMD
comptime COLUMN_CDNA = COLUMN_AMD
comptime COLUMN_RDNA = COLUMN_AMD_RDNA
comptime COLUMN_ADRENO = COLUMN_QUALCOMM
comptime COLUMN_XE = COLUMN_INTEL
comptime COLUMN_HOST = COLUMN_CPU


def column_name(column: Int) -> String:
    if column == COLUMN_BIT_IDENTICAL:
        return String("bit-identical")
    if column == COLUMN_APPLE:
        return String("apple")
    if column == COLUMN_NVIDIA:
        return String("nvidia")
    if column == COLUMN_AMD:
        return String("amd")
    if column == COLUMN_QUALCOMM:
        return String("qualcomm")
    if column == COLUMN_INTEL:
        return String("intel")
    if column == COLUMN_AMD_RDNA:
        return String("amd-rdna")
    if column == COLUMN_SPEC_BASELINE:
        return String("spec-baseline")
    if column == COLUMN_CPU:
        return String("cpu")
    return String("unknown")


def column_is_buildable(column: Int) -> Bool:
    """Whether Mojo can emit a kernel for this column TODAY. The CPU column
    emits no kernel and is buildable in the only sense that matters here: a
    host build with no accelerator target compiles it, on seven CI runners
    (the byte LM CPU gate)."""
    return (
        column == COLUMN_BIT_IDENTICAL
        or column == COLUMN_APPLE
        or column == COLUMN_NVIDIA
        or column == COLUMN_AMD
        or column == COLUMN_AMD_RDNA
        or column == COLUMN_CPU
    )

comptime K_HIST_BINARY = 0
comptime K_HIST_HALF_BYTE = 1
comptime K_HIST_ONE_BYTE = 2
comptime K_SCAN = 3
comptime K_SUBTRACT = 4
comptime K_SCORES = 5
comptime K_SPLIT_POINTS = 6
comptime K_HIST_2_ONE_BYTE = 7

comptime K_POINTWISE_HIST_2 = 8

comptime K_POINTWISE_HIST_2_HALF_BYTE = 9

comptime PINNED_REPLICATION_LANES = 32

comptime PINNED_REDUCE_WIDTH = 512


@fieldwise_init
struct KernelSpec(Copyable, Movable):
    """Every knob one kernel takes. Resolved once, never re-derived."""

    var block_size: Int
    """SCHEDULING. Threads per threadgroup."""

    var hist_floats_per_thread: Int
    """NUMERIC, and it reads as a memory-budget row."""

    var features_per_int: Int
    """NUMERIC in effect: it is the packing, so it decides which features share a load and therefore which sums are formed."""

    var replication_lanes: Int
    """NUMERIC. See PINNED_REPLICATION_LANES."""

    var reduce_width: Int
    """NUMERIC. See PINNED_REDUCE_WIDTH."""

    var deterministic_flush: Bool
    """NUMERIC."""

    var flush_forced_by_vendor: Bool
    """Whether `deterministic_flush` is the mode's choice or the vendor's constraint."""

    def shared_bytes(self) -> Int:
        """What this spec asks of threadgroup memory."""
        return self.block_size * self.hist_floats_per_thread * 4



comptime IDENTITY_PROFILE = 1

comptime IDENTITY_FLOOR_SHARED_BYTES = 32 * 1024

comptime IDENTITY_FLOOR_LANES = 32

comptime IDENTITY_FLOOR_BLOCK = 512


def column_meets_identity_floor(column: Int) -> Bool:
    """Whether this vendor can join `IDENTICAL` without the floor moving."""
    return (
        column_shared_limit(column) >= IDENTITY_FLOOR_SHARED_BYTES
        and column_has_threadgroup_int_atomics(column)
        and column_max_block_size(column) >= IDENTITY_FLOOR_BLOCK
    )


def identity_refusal_reason(column: Int) -> String:
    """Why `IDENTICAL` refuses this column, or empty if it does not."""
    if column_shared_limit(column) < IDENTITY_FLOOR_SHARED_BYTES:
        return (
            column_name(column)
            + " allows "
            + String(column_shared_limit(column) // 1024)
            + " KB of threadgroup memory per block; the identity floor"
            " (profile "
            + String(IDENTITY_PROFILE)
            + ") needs "
            + String(IDENTITY_FLOOR_SHARED_BYTES // 1024)
            + " KB, because the block size it buys decides the replication"
            " factor and the replication factor decides which partial sums"
            " combine"
        )
    if not column_has_threadgroup_int_atomics(column):
        return (
            column_name(column)
            + " has no threadgroup integer atomic add; the identity column"
            " accumulates the histogram in shared Int32 and there is no"
            " substitute that keeps addition associative"
        )
    if column_max_block_size(column) < IDENTITY_FLOOR_BLOCK:
        return (
            column_name(column)
            + " dispatches at most "
            + String(column_max_block_size(column))
            + " threads per block; the identity column's hist_2 arm runs "
            + String(IDENTITY_FLOOR_BLOCK)
        )
    return String("")


def column_shared_limit(column: Int) -> Int:
    """Threadgroup / shared / LDS / SLM bytes a single block may claim."""
    if column == COLUMN_APPLE:
        return 32 * 1024
    if column == COLUMN_NVIDIA:
        return 48 * 1024
    if column == COLUMN_AMD:
        return 64 * 1024
    if column == COLUMN_QUALCOMM:
        return 32 * 1024
    if column == COLUMN_INTEL:
        return 64 * 1024
    if column == COLUMN_AMD_RDNA:
        return 64 * 1024
    if column == COLUMN_SPEC_BASELINE:
        return 16 * 1024
    if column == COLUMN_CPU:
        # No threadgroup memory exists on the host. The row sizes device
        # pages only, and the identical reading is the one every host twin
        # of a device fold must see, so this is the frozen floor and not a
        # vendor's budget: the byte LM host binding compiles
        # `lib_smem_pages_for` / `lib_smem_page_fits_for` through
        # gemm/checks/gemm_identical.mojo, and 32 KB is the value it compiled
        # under the Apple fallthrough on seven runners.
        return IDENTITY_FLOOR_SHARED_BYTES
    return IDENTITY_FLOOR_SHARED_BYTES  # BIT_IDENTICAL: frozen, not derived


def column_has_float_atomics(column: Int) -> Bool:
    """Whether this vendor can do `atomicAdd` on a `float` at all."""
    return (
        column == COLUMN_BIT_IDENTICAL
        or column == COLUMN_APPLE
        or column == COLUMN_NVIDIA
        or column == COLUMN_AMD
        or column == COLUMN_AMD_RDNA
        or column == COLUMN_INTEL
        # the identical reading; a host build is IDENTICAL only, where
        # `deterministic_flush_for` is true whatever this row says
        or column == COLUMN_CPU
    )


def column_compares_flush_subnormals(column: Int) -> Bool:
    """CAPABILITY. The CPU column answers False: `ftz` is explicit under
    IDENTICAL (checks/numerics.mojo flushes by bits, not by MXCSR), and a
    host compare sees the subnormal it is handed."""
    if column == COLUMN_CPU:
        return False
    return column == COLUMN_APPLE


comptime VENDOR_TF32_PRODUCT_REL_BOUND = Float64(1.0e-3)


def column_vendor_fp32_matmul_is_tf32(column: Int) -> Bool:
    """CAPABILITY. The CPU column answers False: a host fp32 product is fp32."""
    if column == COLUMN_CPU:
        return False
    return column == COLUMN_NVIDIA


def vendor_fp32_matmul_is_lossy(column: Int, compute_capability: Int) -> Bool:
    """The runtime form of `column_vendor_fp32_matmul_is_tf32`: the column predicate OR'd with the one generation fact the column cannot carry -- an Apple part reporting `compute_capability == 5` (M5) runs MAX 26.5.0's fp19 simdgroup path by default."""
    if column_vendor_fp32_matmul_is_tf32(column):
        return True
    return column == COLUMN_APPLE and compute_capability == 5


def vendor_fp32_matmul_precision_name(
    column: Int, compute_capability: Int
) -> String:
    """What a check prints beside its tolerance: the precision class of the vendor fp32 product on this build and device."""
    if column_vendor_fp32_matmul_is_tf32(column):
        return String("TF32 (10-bit mantissa tensor-core product)")
    if column == COLUMN_APPLE and compute_capability == 5:
        return String("fp19 (Apple M5 simdgroup MMA, 10-bit mantissa)")
    return String("fp32")


def column_has_threadgroup_int_atomics(column: Int) -> Bool:
    """Whether a block can `atomicAdd` an `Int32` in THREADGROUP memory."""
    return True


def column_has_dedicated_shared_memory(column: Int) -> Bool:
    """Whether "shared memory" is an on-chip scratchpad or just cached RAM."""
    return True


def column_spec_guarantees_onchip_shared(column: Int) -> Bool:
    """Whether anything PROMISES the shared memory is on chip."""
    return column != COLUMN_SPEC_BASELINE


def column_max_block_size(column: Int) -> Int:
    """Largest threadgroup the vendor will dispatch, before our budget bites."""
    if column == COLUMN_SPEC_BASELINE:
        return 128
    if column == COLUMN_CPU:
        return 1024  # the identical reading; no block is ever dispatched
    return 1024


def column_lane_width(column: Int) -> Int:
    """Hardware lanes that move in lockstep: warp on NVIDIA, SIMD group on Apple, WAVEFRONT on AMD, wave on Adreno, sub-group on Intel."""
    if column == COLUMN_AMD:
        return 64
    if column == COLUMN_QUALCOMM:
        return 8
    if column == COLUMN_INTEL:
        return 8
    if column == COLUMN_AMD_RDNA:
        return 32
    if column == COLUMN_SPEC_BASELINE:
        return 1
    if column == COLUMN_CPU:
        # PINNED_REPLICATION_LANES, the identical reading (`lane_width_for`
        # answers it under IDENTICAL on every column). Not 1: a host has no
        # lanes, but a host twin of a device fold restates a 32-lane group,
        # and `GEMM_HEAD_LANES = lib_lane_width_for[TARGET_COLUMN]()` in
        # gemm/checks/gemm_identical.mojo:2882 is compiled into the byte LM
        # host binding, which matched the GPU bits on seven runners at 32.
        return PINNED_REPLICATION_LANES
    return 32


def column_lane_width_is_fixed(column: Int) -> Bool:
    """Whether `column_lane_width` is a property of the DEVICE or a decision the vendor's compiler makes per kernel. The CPU column answers True: its width is the pinned constant, not a compiler's choice."""
    if column == COLUMN_CPU:
        return True
    return (
        column != COLUMN_QUALCOMM
        and column != COLUMN_INTEL
        and column != COLUMN_SPEC_BASELINE
    )


def spec_for(kernel: Int, device: Int, mode: NumericMode) raises -> KernelSpec:
    """The resolved knobs for one kernel, substituting column by column."""
    var identical = mode.mode == NUMERIC_IDENTICAL
    var numeric_column = COLUMN_BIT_IDENTICAL if identical else device

    var floats_per_thread = 16
    var per_int = 8
    if kernel == K_HIST_BINARY:
        per_int = 32
    elif kernel == K_HIST_ONE_BYTE or kernel == K_HIST_2_ONE_BYTE:
        floats_per_thread = 32
        per_int = 4
    elif kernel == K_HIST_HALF_BYTE:
        per_int = 8
    else:
        floats_per_thread = 0
        per_int = 0

    var catboost_block = 384 if (
        kernel == K_HIST_ONE_BYTE or kernel == K_HIST_2_ONE_BYTE
    ) else 768
    var block = catboost_block
    if floats_per_thread > 0:
        var limit = column_shared_limit(numeric_column) // (
            floats_per_thread * 4
        )
        if limit < block:
            block = limit
    var hard_cap = column_max_block_size(device)
    if hard_cap < block:
        block = hard_cap
    elif kernel == K_SCORES:
        block = 128  # compute_scores.cu:167
    elif kernel == K_SPLIT_POINTS:
        block = 256  # compute_scores.cu:493
    else:
        block = 512

    if block < 32:
        raise Error(
            "kernel "
            + String(kernel)
            + " cannot fit a block in column "
            + column_name(numeric_column)
            + ": "
            + String(floats_per_thread)
            + " floats per thread leaves room for "
            + String(block)
            + " threads, and the replication geometry needs at least one"
            " full lane group"
        )

    var vendor_forces_flush = not column_has_float_atomics(device)
    var flush = mode.deterministic_flush() or vendor_forces_flush

    return KernelSpec(
        block,
        floats_per_thread,
        per_int,
        PINNED_REPLICATION_LANES,
        PINNED_REDUCE_WIDTH if identical else block,
        flush,
        vendor_forces_flush,
    )



#: The build's column. The `-D MOJOLEARN_COLUMN_*` define wins, the CPU
#: define first (a host build script passes it and nothing else may); then
#: the accelerator target the compiler was handed; and a build with no
#: accelerator target at all is the CPU column. Until 2026-09-13 the last
#: line read `COLUMN_APPLE` unconditionally, so every host build compiled as
#: the Apple column (bit-inert for the rows the byte LM reaches, wrong for the
#: kNN rows a host fit would reach). Apple is now behind its own predicate,
#: the one `checks/vendor.mojo` already folds into `COMPILED_VENDOR`, so a
#: Metal build still compiles Apple and a build with no accelerator does not.
comptime TARGET_COLUMN = (
    COLUMN_CPU if is_defined["MOJOLEARN_COLUMN_CPU"]() else
    COLUMN_APPLE if is_defined["MOJOLEARN_COLUMN_APPLE"]() else
    COLUMN_NVIDIA if is_defined["MOJOLEARN_COLUMN_NVIDIA"]() else
    COLUMN_AMD if is_defined["MOJOLEARN_COLUMN_AMD"]() else
    COLUMN_AMD_RDNA if is_defined["MOJOLEARN_COLUMN_AMD_RDNA"]() else
    # Explicit declaration simulation only; these do not enable a backend.
    COLUMN_QUALCOMM if is_defined["MOJOLEARN_COLUMN_QUALCOMM"]() else
    COLUMN_INTEL if is_defined["MOJOLEARN_COLUMN_INTEL"]() else
    COLUMN_SPEC_BASELINE if is_defined["MOJOLEARN_COLUMN_SPEC_BASELINE"]() else
    COLUMN_AMD_RDNA if has_amd_rdna_gpu_accelerator() else
    COLUMN_AMD if has_amd_gpu_accelerator() else
    COLUMN_NVIDIA if has_nvidia_gpu_accelerator() else
    COLUMN_APPLE if has_apple_gpu_accelerator() else
    COLUMN_CPU
)


comptime DETECTED_COLUMN = (
    COLUMN_AMD_RDNA if has_amd_rdna_gpu_accelerator() else
    COLUMN_AMD if has_amd_gpu_accelerator() else
    COLUMN_NVIDIA if has_nvidia_gpu_accelerator() else
    COLUMN_APPLE if has_apple_gpu_accelerator() else
    COLUMN_CPU
)


def column_is_simulated() -> Bool:
    """True when `-D MOJOLEARN_COLUMN_*` names a vendor this device is not."""
    return TARGET_COLUMN != DETECTED_COLUMN


def column_is_host(column: Int) -> Bool:
    """Whether `column` is the CPU column, the one a build with no accelerator target compiles."""
    return column == COLUMN_CPU


def hist_floats_per_thread_for[kernel: Int]() -> Int:
    """Shared floats per thread. `GetHistSize()` is this times the block."""
    if (
        kernel == K_HIST_ONE_BYTE
        or kernel == K_HIST_2_ONE_BYTE
        or kernel == K_POINTWISE_HIST_2
    ):
        return 32
    return 16


def catboost_block_for[kernel: Int]() -> Int:
    """What CatBoost uses, before our shared-memory budget bites."""
    if (
        kernel == K_HIST_ONE_BYTE
        or kernel == K_HIST_2_ONE_BYTE
        or kernel == K_POINTWISE_HIST_2
    ):
        return 384
    return 768


def block_size_for[kernel: Int, column: Int]() -> Int:
    """SCHEDULING row, bounded by a NUMERIC one."""
    comptime floats = hist_floats_per_thread_for[kernel]()
    comptime identical = GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL
    comptime cb_cap = catboost_block_for[kernel]()
    comptime cap = (
        IDENTITY_FLOOR_BLOCK if identical
        and IDENTITY_FLOOR_BLOCK < cb_cap else cb_cap
    )
    comptime budget = (
        IDENTITY_FLOOR_SHARED_BYTES if identical
        else column_shared_limit(column)
    )
    comptime limit = budget // (floats * 4)
    comptime by_smem = limit if limit < cap else cap
    comptime hard = column_max_block_size(column)
    return by_smem if by_smem < hard else hard


def lane_width_for[column: Int, identical: Bool]() -> Int:
    """NUMERIC."""
    if identical:
        return PINNED_REPLICATION_LANES
    return column_lane_width(column)


def replication_lanes_for[column: Int, identical: Bool]() -> Int:
    """NUMERIC, and it is the row the whole CatBoost histogram family's layout actually rests on: the LOGICAL width of one private-replica group."""
    comptime assert PINNED_REPLICATION_LANES == IDENTITY_FLOOR_LANES, (
        "the logical replication width and the identity floor's lane count"
        " are one guarantee with two names; keep them equal"
    )
    return PINNED_REPLICATION_LANES


def reduce_width_for[kernel: Int, column: Int, identical: Bool]() -> Int:
    """NUMERIC."""
    comptime block = block_size_for[kernel, column]()
    comptime pinned = PINNED_REDUCE_WIDTH if identical else block
    return block if block < pinned else pinned



comptime SYNC_BLOCK = 0

comptime SYNC_LANE = 1


def sync_granularity_for[column: Int]() -> Int:
    """The finest sync a kernel may rely on."""
    return SYNC_BLOCK


def requires_uniform_iteration_for[column: Int]() -> Bool:
    """Whether every thread of a block must run the SAME iteration count."""
    return sync_granularity_for[column]() == SYNC_BLOCK


def sub_byte_lane_sync_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 1947): which barrier the CatBoost histogram accumulators use for their TURN-TAKING sync, the one that stands where theirs writes `tiled_partition<8>::sync()` or `tiled_partition<32>::sync()` between two writes to the same private slice."""
    if not column_lane_width_is_fixed(column):
        return SYNC_BLOCK
    if column_lane_width(column) != PINNED_REPLICATION_LANES:
        return SYNC_BLOCK
    return SYNC_LANE


def deterministic_flush_for[column: Int, identical: Bool]() -> Bool:
    """NUMERIC row, comptime, so a kernel can branch on it."""
    return identical or not column_has_float_atomics(column)



comptime HIST_SMEM_WARP_PRIVATE_F32 = 0

comptime HIST_SMEM_SHARED2_I32 = 1


def pointwise_one_byte_fixed_for[column: Int, identical: Bool]() -> Bool:
    """NUMERIC row: whether the POINTWISE one-byte family routes EVERY width through the 8-bit fixed-point accumulator."""
    comptime if identical:
        return True
    return column == COLUMN_APPLE


def pointwise_doc_split_for[column: Int, ordered: Bool]() -> Bool:
    """NUMERIC row (DEVIATION 2624): whether the POINTWISE histogram launchers split the DOCUMENT axis `EstimateBlockPerFeatureMultiplier` ways. Above one, every document block of a feature float-`atomicAdd`s its partial into the same `binSums` cell in whatever order the device finishes them, and the multiplier itself follows `sm_count`, so the ordered tiers (deterministic and identical) keep one block per feature group per part; see `pw_block_multiplier` in `gbdt/methods/pointwise_kernels.mojo`."""
    comptime if ordered:
        return False
    return True


#: DEVIATION 2670 (OPT-IN, NOT FLIPPED): the multiprocessor count the ordered
#: tiers' pointwise multiplier estimate reads on EVERY vendor, in place of
#: the device's own. A power of two near an H100's 132; NUMERIC, never tuned
#: per vendor, because the multiplier decides which document lands in which
#: block and therefore the float fold.
comptime PW_2670_PINNED_SM = 128


def pointwise_private_doc_slots_sm_for[column: Int, ordered: Bool]() -> Int:
    """NUMERIC row (DEVIATION 2670, opt-in behind `-D MOJOLEARN_2670_PW_PRIVATE_DOC_SLOTS=1`): 0 keeps DEVIATION 2624 (one document block per feature group per part). Non-zero splits the document axis in the ordered tiers at the multiplier `EstimateBlockPerFeatureMultiplier` gives for THIS pinned SM count, every document block writes its partial into its OWN scratch slot with a plain store, and one launch folds the slots into `binSums` in block order 0..M-1. New bits against 2624 (float addition is not associative, DEVIATION 2669), the same bits at every launch geometry and on every vendor; see `pw_block_multiplier` in `gbdt/methods/pointwise_kernels.mojo`."""
    comptime if ordered and is_defined["MOJOLEARN_2670_PW_PRIVATE_DOC_SLOTS"]():
        return PW_2670_PINNED_SM
    return 0


def greedy_one_byte_fixed_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 1906, NARROWED by DEVIATION 1947): whether the GREEDY one-byte family routes EVERY width through the fused 8-bit fixed-point kernel (`hist_2_one_byte_8bit.mojo`) instead of CatBoost's maxBins ladder."""
    comptime if identical:
        return False
    comptime if is_defined["MOJOLEARN_2043_FAST_FUSED_ONE_BYTE"]():
        return True
    return True


def greedy_sub_byte_excluded_for[column: Int, identical: Bool]() -> Bool:
    """ROUTING row, RETRACTED 2026-09-01 (DEVIATION 1947 supersedes DEVIATION 1910): whether the GREEDY sub-byte histogram families -- BINARY (32 features per word) and HALF-BYTE (8 per word) -- are comptime-EXCLUDED from the build, their launch sites refusing at runtime BY NAME."""
    return False


def greedy_quantized_hist_for[column: Int, identical: Bool]() -> Bool:
    """NUMERIC row (DEVIATIONS 1911/1912): whether the NON-SYMMETRIC drivers' one-byte histogram build routes through the QUANTIZED SHARED-HISTOGRAM family (`kernel/hist_quantized_shared.mojo`) -- per-round fixed-point gradient pairs packed one 64-bit word per row, ONE shared-memory Int32 histogram per thread block accumulated with threadgroup integer..."""
    comptime if identical:
        return False
    comptime if is_defined["MOJOLEARN_2045_FAST_NO_QUANT_HIST"]():
        return False
    return (
        column == COLUMN_APPLE
        or column == COLUMN_NVIDIA
        or column == COLUMN_AMD
        or column == COLUMN_AMD_RDNA
    )


def quantized_hist_group_features_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 1913): how many one-byte features one thread block's shared histogram covers in the quantized family."""
    comptime limit = column_shared_limit(column)
    var g = limit // (256 * 2 * 4)
    g = (g // 4) * 4
    if g < 4:
        g = 4
    if g > 32:
        g = 32
    return g


def reorder_single_pass_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 1907): stable partition above 500,000 rows.

    IDENTICAL's NVIDIA candidate requires an explicit build define until
    a large-input identity and timing run exercises the routed kernel.
    Small identity fixtures cannot reach this branch. The kill switch wins
    over the opt-in, and other vendors retain the established partition.
    """
    comptime if is_defined["MOJOLEARN_2042_FAST_NO_LOOKBACK"]():
        return False
    comptime if identical:
        return (
            column == COLUMN_NVIDIA
            and is_defined["MOJOLEARN_IDENTICAL_SINGLE_PASS_PARTITION"]()
        )
    return column == COLUMN_NVIDIA


def ridx_only_splits_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 1902): whether the NON-SYMMETRIC driver's split moves only the row index, leaving the stat planes stationary for the life of the fit, with every stat reader gathering `stats[row_index[pos]]` instead of reading a permuted plane."""
    comptime if identical:
        return False
    comptime if is_defined["MOJOLEARN_2044_FAST_NO_RIDX_ONLY"]():
        return False
    return (
        column == COLUMN_APPLE
        or column == COLUMN_NVIDIA
        or column == COLUMN_AMD
        or column == COLUMN_AMD_RDNA
    )


def hist_smem_mode_for[column: Int, identical: Bool]() -> Int:
    """NUMERIC row: HOW the hist_2 family accumulates in shared memory."""

    comptime CATBOOST_PRIVATE_BYTES = 384 * 32 * 4
    comptime limit = column_shared_limit(column)

    comptime if is_defined["MOJOLEARN_2046_FAST_SHARED_I32"]():
        return HIST_SMEM_SHARED2_I32
    comptime if identical:
        return HIST_SMEM_SHARED2_I32  # the BIT_IDENTICAL column's value
    elif limit < CATBOOST_PRIVATE_BYTES:
        return HIST_SMEM_SHARED2_I32
    else:
        return HIST_SMEM_WARP_PRIVATE_F32



comptime PINNED_PARTITION_CHUNKS_SM = 32


def partition_chunks_sm_for[identical: Bool](device_sm: Int) -> Int:
    """The `sm_count` the partition-stats chunk formula is fed."""
    comptime if identical:
        return PINNED_PARTITION_CHUNKS_SM
    else:
        return device_sm


def hist2_block_size_for[column: Int, smem_mode: Int]() -> Int:
    """SCHEDULING row bounded by the NUMERIC budget, per accumulation mode."""

    comptime hard = column_max_block_size(column)
    comptime if smem_mode == HIST_SMEM_SHARED2_I32:
        comptime limit = column_shared_limit(column) // 64
        comptime by_smem = 512 if limit >= 512 else limit
        return by_smem if by_smem < hard else hard
    else:
        return block_size_for[K_HIST_2_ONE_BYTE, column]()


def pw_hist2_block_size_for[column: Int, fixed: Bool]() -> Int:
    """SCHEDULING row for the POINTWISE one-byte family's block, per route."""
    return block_size_for[K_POINTWISE_HIST_2, column]()


def pw_hist2_smem_floats_for[column: Int, fixed: Bool]() -> Int:
    """Companion to `pw_hist2_block_size_for`: the shared scratch, in 4-byte slots."""
    return 32 * pw_hist2_block_size_for[column, fixed]()


def replicas_for(hist_cells: Int) -> Int:
    """DELETED IN SPIRIT."""
    return -16
    return 1



comptime K_LIB_ROW_NORM = 100
comptime K_LIB_COLUMN_STATS = 101
comptime K_LIB_TRANSPOSE = 102
comptime K_LIB_GEMM_CONTRACTION = 103
comptime K_LIB_FUSED_DISTANCE_NN = 104
comptime K_LIB_REDUCE_BY_KEY = 105
comptime K_LIB_PLUS_PLUS = 106
comptime K_LIB_EPS_NEIGHBORHOOD = 107
comptime K_LIB_ADJ_SCAN = 108
comptime K_LIB_WEAK_CC = 109
comptime K_LIB_SELECT_RADIX = 110
comptime K_LIB_SELECT_WARPSORT = 111
comptime K_LIB_BALL_COVER_EPS = 112
comptime K_LIB_JACOBI_EIGH = 113
comptime K_LIB_GRAM_SPLITK = 114
comptime K_LIB_WEIGHTED_VERTEX_DEG = 115


comptime PINNED_LIB_REDUCE_LANES = 32

comptime PINNED_ACC_ROWS_PER_TH = 4
comptime PINNED_ACC_COLS_PER_TH = 4
comptime PINNED_KBLK = 32
comptime PINNED_VECLEN = 4


@fieldwise_init
struct LibKernelSpec(Copyable, Movable):
    """The knobs one library kernel takes, resolved per column."""

    var block_size: Int
    """SCHEDULING. Threads per threadgroup."""

    var lane_width: Int
    """SCHEDULING **only for indexing**, NUMERIC when it bounds a reduction."""

    var reduce_lanes: Int
    """NUMERIC. See `PINNED_LIB_REDUCE_LANES`."""

    var acc_rows_per_th: Int
    """NUMERIC. Policy4x4 accumulation geometry."""

    var acc_cols_per_th: Int
    """NUMERIC. Policy4x4 accumulation geometry."""

    var kblk: Int
    """NUMERIC. Policy4x4 K-block."""

    var veclen: Int
    """NUMERIC. Policy4x4 vector length."""

    var shared_limit: Int
    """SCHEDULING. Threadgroup bytes this column allows a block to claim."""


def lib_block_size(kernel: Int, column: Int) -> Int:
    """SCHEDULING."""
    if kernel == K_LIB_SELECT_RADIX:
        return 256
    if kernel == K_LIB_SELECT_WARPSORT:
        return 8 * lib_lane_width(column)
    if kernel == K_LIB_TRANSPOSE:
        return 32 * 32 // 4
    if kernel == K_LIB_JACOBI_EIGH:
        return 32
    if kernel == K_LIB_GEMM_CONTRACTION or kernel == K_LIB_FUSED_DISTANCE_NN:
        return 16 * 16
    if kernel == K_LIB_GRAM_SPLITK:
        return 256
    return 128


def lib_lane_width(column: Int) -> Int:
    """SCHEDULING."""
    return column_lane_width(column)


def lib_spec_for(
    kernel: Int, device: Int, mode: NumericMode
) raises -> LibKernelSpec:
    """The resolved knobs for one library kernel."""
    var identical = mode.mode == NUMERIC_IDENTICAL
    var numeric_column = COLUMN_BIT_IDENTICAL if identical else device

    var reduce_lanes = PINNED_LIB_REDUCE_LANES
    if not identical:
        reduce_lanes = PINNED_LIB_REDUCE_LANES

    var spec = LibKernelSpec(
        lib_block_size(kernel, device),
        lib_lane_width(device),
        reduce_lanes,
        PINNED_ACC_ROWS_PER_TH,
        PINNED_ACC_COLS_PER_TH,
        PINNED_KBLK,
        PINNED_VECLEN,
        column_shared_limit(numeric_column),
    )

    if spec.block_size < spec.reduce_lanes:
        raise Error(
            "library kernel "
            + String(kernel)
            + " resolves to a block of "
            + String(spec.block_size)
            + " threads in column "
            + column_name(device)
            + ", which is narrower than the "
            + String(spec.reduce_lanes)
            + "-lane fold it has to perform"
        )
    return spec^



def lib_smem_pages(kernel: Int, column: Int, page_bytes: Int) -> Int:
    """SCHEDULING."""
    if 2 * page_bytes <= column_shared_limit(column):
        return 2
    return 1



def lib_block_bounds_a_float_fold[kernel: Int]() -> Bool:
    """NUMERIC CLASSIFIER, and the correction of a label this file got wrong."""
    return (
        kernel == K_LIB_ROW_NORM
        or kernel == K_LIB_REDUCE_BY_KEY
        or kernel == K_LIB_PLUS_PLUS
        or kernel == K_LIB_COLUMN_STATS
        or kernel == K_LIB_JACOBI_EIGH
        or kernel == K_LIB_WEIGHTED_VERTEX_DEG
    )


def lib_block_size_for[kernel: Int, column: Int]() -> Int:
    """SCHEDULING for most rows, NUMERIC for three of them."""
    comptime identical = GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL
    comptime numeric_row = lib_block_bounds_a_float_fold[kernel]()
    comptime resolved = (
        COLUMN_BIT_IDENTICAL if identical and numeric_row else column
    )
    comptime lanes = column_lane_width(resolved)
    if kernel == K_LIB_SELECT_RADIX:
        return 256
    if kernel == K_LIB_SELECT_WARPSORT:
        return 8 * lanes
    if kernel == K_LIB_TRANSPOSE:
        return 256
    if kernel == K_LIB_JACOBI_EIGH:
        return 32 if lanes <= 32 else lanes
    if kernel == K_LIB_GEMM_CONTRACTION or kernel == K_LIB_FUSED_DISTANCE_NN:
        return 256
    if kernel == K_LIB_GRAM_SPLITK:
        return 256
    return 128


def lib_lane_width_for[column: Int]() -> Int:
    """SCHEDULING."""
    return column_lane_width(column)


def lib_reduce_lanes_for[column: Int, identical: Bool]() -> Int:
    """NUMERIC."""
    return PINNED_LIB_REDUCE_LANES


def lib_smem_pages_for[column: Int, page_bytes: Int]() -> Int:
    """SCHEDULING."""
    comptime limit = column_shared_limit(column)
    return 2 if 2 * page_bytes <= limit else 1


def lib_smem_page_fits_for[column: Int, page_bytes: Int]() -> Bool:
    """SCHEDULING row (2026-09-09, orchestrator, Apple RUN OWED of the split-K lane): whether ONE shared page of `page_bytes` fits under the column's shared limit at all. `lib_smem_pages_for` answers "one page or two"; it cannot say "not even one". The 128x128 tuned pair at K step 32 is 36,864 bytes a page, which no NVIDIA leg noticed (48 KB) and which Metal refuses at pipeline creation (32 KB: "Threadgroup memory size (36864) exceeds the maximum threadgroup memory allowed (32768)", gemm_device_check and gemm_backward_check on the M4). A plan whose page does not fit resolves its K step down through this row instead of naming a vendor. The fused attention kernels ask the same question per head dim: the head-dim-128 backward path claims 35,600 bytes and takes the eager path on a 32 KB column; register-blocked forward needs 18,624 bytes and fits."""
    return page_bytes <= column_shared_limit(column)


def lib_hardware_ftz_fma_for[column: Int]() -> Bool:
    """Capability row for NVIDIA's explicit round-to-nearest FMA intrinsics.

    This is not permission to replace round-then-flush with a bare .ftz
    instruction. At a smallest-normal rounding boundary, fma.rn.ftz can
    return zero where round-then-flush returns 0x00800000. Callers must
    preserve explicit round-then-flush semantics or correct that case;
    see the adversarial seam evidence from 2026-09-09.
    Other columns retain their existing software spelling. The CPU column
    answers False, the software spelling: the host has no `.ftz` instruction
    and the fold flush is `ftz` in checks/numerics.mojo.
    """
    if column == COLUMN_CPU:
        return False
    return column == COLUMN_NVIDIA


def attn_zdot_rows_per_block_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 2528, 2026-09-11, trial arm only; brief docs/lanes/BRIEF_attention_step_2026-09-11.md section 12): query rows per 256-thread block of the fused attention's register-blocked y/dy kernel (`fused_bwd_ydy_tiled_kernel`), 64 or 32. The kernel's shared page is `(2 * rows + 128) * 20` floats (20,480 B at 64, 15,360 B at 32), and on a column whose shared memory is partitioned per compute unit the page bounds the resident blocks. The rows are a schedule, never a numeric term: every chain keeps its terms and order at either value. UNMEASURED on every column. AMD reads 32 as the variant section 11.3 named to price; the page-only count (3 blocks x 64 rows vs 4 x 32 rows per CU) does not favor it, so the AMD leg prices both through the `_r32` / `_r64` arm names and this row follows that measurement. The shipped build reads it nowhere."""
    if column == COLUMN_AMD:
        return 32
    if column == COLUMN_CPU:
        return 64  # the non-vendor default; no attention kernel runs here
    return 64


def lib_gemm_block_parallelism_for[column: Int]() -> Int:
    """SCHEDULING row, SHIPPED since DEVIATION 2595 (2026-09-11; brief docs/lanes/BRIEF_gemm_long_k_2026-09-11.md sections 3, 4 and 10; first added by DEVIATION 2591 as a trial-arm row): how many 256-thread GEMM blocks the column runs side by side. A value above 0 TURNS ON the `ksplit` default in `gemm/checks/gemm_identical.mojo::identical_gemm_shipped_into`: every call the long-k group rule takes (section 4, rules 1, 2 and 4, at `S` = this value) runs the 128x128 group kernel over power-of-two leaf groups plus one fold launch, and every other call runs the plan `choose_gemm_plan` picks, as before. 0 turns it off: the dispatch compiles to the old line and the TUNED 128x128 plan runs exactly as it did. NVIDIA 132, MEASURED: the H100's SM count (docs/lanes/BRIEF_attention_step_2026-09-11.md section 3.1), and the value the `ksplit` arm ran at on the H100 leg that flipped it (bench/results/e1g/2026-09-11_152822-nvidia-h100-80gb-hbm3-gemm-longk, lean step geomean 0.895 on enwik8 and Pile GitHub, every step witness equal). AMD 110, MEASURED 2026-09-11 on the Hot Aisle MI300X (bench/results/e1g/2026-09-11_164818-amd-mi300x-hotaisle-gemm-longk): lean step 1.953 -> 1.198 s on both corpora, `ksplit` verdict FLIP at geomean 0.6136 and `ksplit_leaf` 0.6090, every step witness equal to shipped. The classical callers were then checked to HOLD under this row (68be1c79: SVC, kmeans, PCA and KDE on the same MI300X). This sentence previously said "AMD 0, OFF UNTIL THE MI300X LEG DECIDES" and contradicted the body below it for two days. The trial arm still runs on AMD at the column's reading through `lib_gemm_block_parallelism_trial_for`. Every other column 0 (Apple included, so the Apple identity card compiles the old line). A wrong value costs time and can never move a bit, because the group size reaches no leaf boundary and no tree level (brief section 5.5)."""
    if column == COLUMN_NVIDIA:
        return 132
    if column == COLUMN_AMD:
        # Measured 2026-09-11 on the Hot Aisle MI300X with the trial arm at S=110
        # (e1g/2026-09-11_164818-amd-mi300x-hotaisle-gemm-longk): lean step
        # 1.953 -> 1.198 s on both corpora, geomean 0.614, witnesses equal.
        return 110
    if column == COLUMN_CPU:
        # 0: the host oracle (`gemm_oracle`) folds the contract tree without
        # groups, and the dispatch compiles to the old line as it did under
        # the Apple fallthrough.
        return 0
    return 0


def lib_gemm_kernel_body_for[column: Int]() -> Int:
    """SCHEDULING row, SHIPPED since DEVIATION 2707 (2026-09-13; brief docs/lanes/BRIEF_gemm_kernel_2026-09-11.md sections 16 to 18): which KERNEL BODY the IDENTICAL GEMM dispatch runs on every call the TUNED 128x128 plan serves. 0 is the 2595 dispatch as it stood (`identical_gemm_tuned_kernel` where the ksplit rule declines the call, `identical_gemm_ksplit_kernel` groups where it takes it). 1 is the `kpack_hg` body (DEVIATION 2706): `identical_gemm_kpack_kernel` at the shipped 128x128 geometry with the padded, 16-byte-aligned packed page (2700, 2703), ONE 8-wide conflict-free shared store per thread per window instead of sixteen scalar stores at a four-way bank conflict (gather staging), and the fold's flush spelled as the hardware `mul.rn.ftz` by one that the step seam already uses (one instruction for six); the same group rule at the same row, the same fold tree, the same words at the same addresses in the same order, so no bit moves and the M4 arms check and the H100 step check say so. NVIDIA 1, MEASURED 2026-09-13 on a RunPod H100 (bench/results/e1g/2026-09-13_175602-nvidia-h100-gemm-hfgs): lean step 0.232 -> 0.211 s on enwik8 and Pile GitHub (geomean 0.9085), GEMM sum 143 -> 122 ms (0.852), every step witness equal to shipped; the decomposition that named the two costs is bench/results/e1g/2026-09-13_174125-nvidia-h100-gemm-diag2 (staging phase a third of the window, fold a fifth). AMD 1 as well, MEASURED 2026-09-13 on a Hot Aisle MI300X (the body's comment names the leg): the gather staging is placement and applies, the fold flush is NVIDIA's instruction and compiles out there. Apple and every other column 0: they compile exactly the line they compiled before. A wrong value costs time and can never move a bit. This row is the switch: 0 here is the revert."""
    if column == COLUMN_NVIDIA:
        return 1
    if column == COLUMN_AMD:
        # AMD 1, MEASURED 2026-09-13 on a Hot Aisle MI300X (gfx942), 8core VM,
        # one heat window, commit bfde0442
        # (bench/results/e1g/2026-09-13_193949-amd-mi300x-hotaisle-gemm-amd-row):
        #   verdict kpack_gs FLIP geomean=0.9570 enwik8=0.9559 pilegithub=0.9580
        #   verdict kpack_hg FLIP geomean=0.9585 enwik8=0.9573 pilegithub=0.9597
        #   every step witness equal to shipped on both corpora; step check PASS
        # GEMM sum 592 -> 561 ms (kpack_gs 0.947) and 559 ms (kpack_hg 0.944).
        # On this column the body's hardware fold flush compiles out
        # (`comptime if HW and TUNED_HW_FTZ_FMA`, NVIDIA only), so 1 here IS
        # the gather staging alone and the two arms price the same to 0.15
        # percent; one row value keeps one code path. Shipped-build gate on
        # the MI300X: brief section 18.4.
        return 1
    if column == COLUMN_CPU:
        return 0  # the revert line; no GEMM kernel body runs on the host
    return 0


def lib_gemm_block_parallelism_trial_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 2595, 2026-09-11, trial arm only; brief docs/lanes/BRIEF_gemm_long_k_2026-09-11.md section 10): the `S` the `ksplit` TRIAL arm reads, so a leg can still force the arm on a column whose shipped row is 0. The shipped row wherever it is above 0 (NVIDIA 132, so the arm and the default split identically there). AMD 110, from a READING, not a measurement (DEVIATION 2591): the attention brief section 11.1 transcribes 110 CUs (pinned to the MI250X; the MI325X and MI300X counts are not in the repository) and resident blocks per CU as `min(2048 // 256, 65536 // page bytes)`; the shipped 128x128 GEMM block holds two 20,480 B pages (40,960 B), so one block per CU and 110 side by side. The MI300X leg's CONTROL pair `ctl_nt_1536x1408x768` / `ctl_nt_1664x1408x768` (`bench/gemm_step_price_main.mojo`) reads the real value. Every other column 0, meaning no reading: the arm then takes the finest split the workspace cap allows. The shipped build reads it nowhere."""
    comptime shipped = lib_gemm_block_parallelism_for[column]()
    if shipped > 0:
        return shipped
    if column == COLUMN_AMD:
        return 110
    if column == COLUMN_CPU:
        return 0  # no reading: the host has no blocks to run side by side
    return 0


def attn_fwd_rows_per_block_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 2531, 2026-09-11; brief docs/lanes/BRIEF_attention_step_2026-09-11.md sections 14 and 15): query rows per 256-thread block of the fused attention's second-round forward kernel (`fused_attn_forward_r2_kernel`), 64 (the shipped hd-64 sstash geometry) or 32, read by the bare `_fgrid` arm token (`_fgrid_r32` / `_fgrid_r64` force it). The kernel's shared page is `(32 * 64 + rows * 35) * 4` bytes (17,152 B at 64 rows, 12,672 B at 32), and on a column whose shared memory is partitioned per compute unit the page bounds the resident blocks. The rows are a schedule, never a numeric term: the score, denominator and context chains keep their terms and order at either value, and the row maximum is an `identical_fmax` fold whose grouping is free. NVIDIA 32, MEASURED (DEVIATION 2534, H100 leg bench/results/e1g/2026-09-11_154257-nvidia-h100-80gb-hbm3-attention-round3, commit 5bcfa71d): the lean LM step under `stash_tiled_fgrid_r32` was 0.3718 / 0.3716 s against `stash_tiled` 0.3845 / 0.3819 s (enwik8 / Pile GitHub), every step witness equal, and `fgrid_r64` priced at 1.00x of stash_tiled on real activations while `fgrid_r32` priced 1.07x. AMD 32 is still the variant brief section 11.4 named to price (the page-only count, 3 blocks x 64 rows against 5 x 32 per CU, does not settle it); THE MI300X LEG DECIDES IT through the `_fgrid_r32` / `_fgrid_r64` arm names. Every other column 64, unmeasured. The shipped default arm (`attn_default_arm_for`) forces its rows with `_fgrid_r32`, so this row never moves a shipped path."""
    if column == COLUMN_NVIDIA:
        return 32
    if column == COLUMN_AMD:
        return 32
    if column == COLUMN_CPU:
        return 64  # the non-vendor default; no attention kernel runs here
    return 64


def attn_dkdv_keys_per_block_for[column: Int]() -> Int:
    """SCHEDULING row (DEVIATION 2597, 2026-09-11; brief docs/lanes/BRIEF_attention_step_2026-09-11.md sections 16 and 18): keys per 256-thread block of the fused attention's trial dk/dv folds over the stash (`fused_bwd_dkdv_r2_kernel`, and `fused_bwd_kvfold_r2_kernel` under the `_kvsplit` token), 64 (the shipped `fused_bwd_dkdv_tiled_pf_kernel` geometry) or 32, read by the bare `_kvgrid` arm token (`_kvgrid_r32` / `_kvgrid_r64` force it). At 32 keys a thread holds 8 dk and 8 dv accumulators instead of 16 and 16, and the joint page is `(2 * 16 * 64 + 2 * 16 * keys) * 4` bytes (16,384 B at 64, 12,288 B at 32; a `_kvsplit` fold page is half that). The keys per block are a schedule, never a numeric term: every dk and dv chain keeps its terms and its order (heads of the kv group ascending, queries ascending over the key's visible range) at either value. AMD 32, MEASURED: DigitalOcean MI325X leg bench/results/e1g/2026-09-11_180903-amd-mi325x-do-attention-dkdv (commit 5cc3b8df), `stash_tiled_fgrid_r32_qres_pf_kvgrid_r32` against `baseline` lean step 1.623 / 1.633 -> 1.376 / 1.370 s (enwik8 / Pile GitHub, FLIP geomean 0.8436, every step witness equal), in-step dk/dv 169.8 ms (baseline) -> 21.2 ms; section 16 had read 32 from the tiled dk/dv thread state (32 accumulators and 10 operand registers per thread, twice the tiled dq fold's). The AMD shipped default (`attn_default_arm_for`) forces the same 32 with `_kvgrid_r32` (brief section 18), so this row and the default agree on AMD and a bare `_kvgrid` resolves to the default's instantiation there. Every other column 64, unmeasured. A shipped build reads this row only for a default carrying bare `_kvgrid`, which no column's default does."""
    if column == COLUMN_AMD:
        return 32
    if column == COLUMN_CPU:
        return 64  # the non-vendor default; no attention kernel runs here
    return 64


comptime ATTN_DEFAULT_WORD_BASELINE = 0
comptime ATTN_DEFAULT_WORD_STASH_TILED = 7
"""The attention arm word `stash_tiled`: bits 1 (fwd_sstash), 2 (bwd_stash) and 4 (bwd_tiled) of transformer/impl/llama/fused_attention.mojo (DEVIATIONS 2525 to 2527). The matrix cannot import that file (it imports this one), so the word is a literal here and fused_attention.mojo asserts at build time that it equals its own composition."""

comptime ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF = 3175
"""The attention arm word `stash_tiled_fgrid_r32_qres_pf`: stash_tiled (7) | 64 (fwd_grid, DEVIATION 2531) | 2048 (forward rows 32) | 32 (fwd_qres, DEVIATION 2530) | 1024 (preflush, DEVIATION 2533) = 3175. fused_attention.mojo asserts at build time that it equals its own composition."""

comptime ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_KVGRID_R32 = 52327
"""The attention arm word `stash_tiled_fgrid_r32_qres_pf_kvgrid_r32`: stash_tiled_fgrid_r32_qres_pf (3175) | 16384 (bwd_kvgrid, DEVIATION 2597) | 32768 (dk/dv keys per block 32) = 52327. fused_attention.mojo asserts at build time that it equals its own composition (`ATTN_ARM_R3_KVGRID_R32_DEFAULT`)."""

comptime ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_ESTASH_DRES_KVGRID_R32 = 6343783
"""The attention arm word `stash_tiled_fgrid_r32_qres_pf_estash_dres_kvgrid_r32`: stash_tiled_fgrid_r32_qres_pf_kvgrid_r32 (52327) | 2097152 (bwd_estash, DEVIATION 2650) | 4194304 (estash_dres, DEVIATION 2651) = 6343783. fused_attention.mojo asserts at build time that it equals its own composition (`ATTN_ARM_R3_KVGRID_R32_ESTASH_DRES_DEFAULT`)."""


def attn_default_arm_for[column: Int]() -> Int:
    """ROUTING row (DEVIATION 2534, 2026-09-11; brief docs/lanes/BRIEF_attention_step_2026-09-11.md sections 15 and 18): the attention arm word the SHIPPED build runs on this column (`ATTN_ARM_DEFAULT` in transformer/impl/llama/fused_attention.mojo; a `-D MOJOLEARN_ATTN_ARM_TRIAL=1` build runs it when MOJOLEARN_ATTN_ARM is unset and keeps every other arm selectable by name). Every arm is bit-equal to the eager oracle by the identity arguments of brief sections 4, 12, 14 and 16, so this row picks a schedule and never a result. NVIDIA `stash_tiled_fgrid_r32_qres_pf`, MEASURED: H100 leg bench/results/e1g/2026-09-11_154257-nvidia-h100-80gb-hbm3-attention-round3 (commit 5bcfa71d), lean LM step 0.3845 / 0.3819 s under stash_tiled against 0.3346 / 0.3340 s (enwik8 / Pile GitHub), every step witness equal, fwd+bwd on real activations 1.41x of stash_tiled; ENGINEERING_RULES 9 flips it. AMD `stash_tiled_fgrid_r32_qres_pf_kvgrid_r32` (ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_KVGRID_R32), MEASURED on the DigitalOcean MI325X against the previous AMD default `baseline`, every step witness equal (the comment in the body names the evidence and the verdict); a shipped build compiles its DEVIATION 2597 dk/dv kernel because the default carries it (brief section 18). Apple and every other column `stash_tiled` (unmeasured for the round 3 and 2597 arms as a price). `-D MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN=1` returns the NVIDIA word on every column, so a no-trial build on a Mac reaches the shipped round 3 branch; `-D MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN=1` returns the previous NVIDIA word (now AMD's) on every column, so the same build reaches the shipped DEVIATION 2597 dk/dv branch; `-D MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN=1` returns the current NVIDIA word on every column, so a no-trial build on a Mac reaches the shipped DEVIATION 2650 / 2651 estash branch (DEVIATION 2657, `ATTN_SHIPPED_BWD_ESTASH`; this is how the M4 gates that branch, since Apple's own default carries no estash bit). Check knobs, the `MOJOLEARN_EXPERIMENTAL_SMALLK_IDENTICAL` pattern; never a shipped build; at most one of the three."""
    comptime assert not (is_defined["MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN"]() and is_defined["MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN"]()), (
        "MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN and"
        " MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN each name a different"
        " default for every column; define at most one"
    )
    comptime assert not (is_defined["MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN"]() and is_defined["MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN"]()), (
        "MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN and"
        " MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN each name a different"
        " default for every column; define at most one"
    )
    comptime assert not (is_defined["MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN"]() and is_defined["MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN"]()), (
        "MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN and"
        " MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN each name a different"
        " default for every column; define at most one"
    )
    comptime if is_defined["MOJOLEARN_ATTN_DEFAULT_ESTASH_EVERY_COLUMN"]():
        return ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_ESTASH_DRES_KVGRID_R32
    comptime if is_defined["MOJOLEARN_ATTN_DEFAULT_KVGRID_EVERY_COLUMN"]():
        return ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_KVGRID_R32
    comptime if is_defined["MOJOLEARN_ATTN_DEFAULT_R3_EVERY_COLUMN"]():
        return ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF
    if column == COLUMN_NVIDIA:
        # DEVIATION 2657. Measured 2026-09-11 on a RunPod H100 80GB HBM3
        # against the previous NVIDIA default
        # stash_tiled_fgrid_r32_qres_pf_kvgrid_r32, commit 8dc33f00, every step
        # witness equal on both corpora, Apple vs NVIDIA identity trace
        # IDENTICAL over 60 stages
        # (bench/results/e1g/2026-09-11_215636-nvidia-h100-80gb-hbm3-attention-estash):
        #   verdict stash_tiled_fgrid_r32_qres_pf_estash_dres_kvgrid_r32 FLIP
        #   geomean=0.8207 enwik8=0.8226 pilegithub=0.8190 (same pod)
        # Lean step 0.2922 / 0.2916 -> 0.2403 / 0.2388 s (enwik8 / Pile GitHub).
        # In-step zdot 66.4 -> 14.9 ms; on real activations the backward is
        # 7.52 -> 3.23 ms (fwd+bwd 1.85x, the forward untouched at 1.00x).
        # The runner-up on the same leg, _estash without _dres, FLIP 0.8348:
        # ENGINEERING_RULES 9 takes the winner. The register lens (brief
        # section 20.2) reads the same: the shipped zdot kernel is 134 regs and
        # 1 block per SM, _estash 125 and 2, _estash_dres 64 and 4.
        # Before it: stash_tiled_fgrid_r32_qres_pf_kvgrid_r32 (e1g/...185833,
        # FLIP geomean 0.9908); before that stash_tiled_fgrid_r32_qres_pf
        # (round 3, e1g/...154257).
        return ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_ESTASH_DRES_KVGRID_R32
    if column == COLUMN_AMD:
        # DEVIATION 2657 ON AMD TOO. Measured 2026-09-12 on a Hot Aisle MI300X
        # (gfx942) against the previous AMD default
        # stash_tiled_fgrid_r32_qres_pf_kvgrid_r32, commit bb679f19, one VM and
        # one heat window, every step witness equal on both corpora
        # (bench/results/e1g/2026-09-12_133010-amd-mi300x-hotaisle-attn-estash):
        #   verdict stash_tiled_fgrid_r32_qres_pf_estash_dres_kvgrid_r32 FLIP
        #   geomean=0.9716 enwik8=0.9724 pilegithub=0.9709
        #   witnesses_equal_baseline=True on both corpora
        # Lean step 0.7573 / 0.7593 -> 0.7363 / 0.7372 s (enwik8 / Pile GitHub).
        # The gain is a third of NVIDIA's (0.8207 there) and the register lens
        # on this same VM says why. The shipped zdot kernel `zdot_stash_pf` is
        # 118 regs at a 17,696 byte page and ALREADY fits 3 blocks per CU here,
        # where on the H100 the same kernel was 134 regs at 1 block per SM. The
        # flipped kernel `zdot_estash_dres_pf` is 60 regs at 12,480 bytes and 5
        # blocks per CU (the plain `_estash` variant is 116 regs, 10,432 bytes,
        # 4 blocks). So AMD goes 3 -> 5 blocks where NVIDIA went 1 -> 4, and it
        # was never as starved to begin with, which is the whole difference in
        # the two gains. ENGINEERING_RULES 9 takes the win anyway: below 1 on
        # both corpora with the bits unmoved, and the rule sets no magnitude bar.
        # Before it: stash_tiled_fgrid_r32_qres_pf_kvgrid_r32, measured
        # 2026-09-11 on the DigitalOcean MI325X against baseline, commit
        # 5cc3b8df (e1g/2026-09-11_180903-amd-mi325x-do-attention-dkdv, FLIP
        # geomean=0.8436, in-step dk/dv 169.8 -> 21.2 ms); before that baseline
        # (e1g/2026-09-11_171959-amd-mi300x-runpod-attention-three).
        return ATTN_DEFAULT_WORD_STASH_TILED_FGRID_R32_QRES_PF_ESTASH_DRES_KVGRID_R32
    if column == COLUMN_CPU:
        # The non-vendor default, the word the Apple fallthrough compiled into
        # the byte LM host binding. No fused attention kernel runs on the
        # host; the host step goes to the transformer oracles.
        return ATTN_DEFAULT_WORD_STASH_TILED
    return ATTN_DEFAULT_WORD_STASH_TILED


comptime STEP_GLUE_DEFAULT_WORD_SHIPPED = 0
comptime STEP_GLUE_DEFAULT_WORD_OPTSKIP_NOSHADOW_ROWS16 = 7
"""The step glue arm word `optskip_noshadow_rows16`: bits 1 (optskip, DEVIATION 2646), 2 (noshadow, DEVIATION 2647) and 4 (rows16, DEVIATION 2645) of core/step_glue.mojo = 7. The matrix cannot import that file (it imports this one), so the word is a literal here and core/step_glue.mojo asserts at build time that it equals its own composition (`STEP_GLUE_ARM_OPTSKIP_NOSHADOW_ROWS16`)."""


def step_glue_default_arm_for[column: Int]() -> Int:
    """ROUTING row (DEVIATION 2649, 2026-09-12; brief docs/lanes/BRIEF_step_glue_2026-09-11.md sections 2, 4 and 5): the step glue arm word the SHIPPED build runs on this column (`STEP_GLUE_ARM_DEFAULT` in core/step_glue.mojo; a `-D MOJOLEARN_STEP_GLUE_TRIAL=1` build runs it when MOJOLEARN_STEP_GLUE_ARM is unset and keeps every other arm selectable by name). Every arm is bit-equal to the shipped step by the identity arguments of brief sections 4.1, 4.2 and 4.3 and refuses the same inputs by section 5, so this row picks a schedule and never a result. NVIDIA `optskip_noshadow_rows16`, MEASURED (the body names the evidence and the verdict). Apple and every other column `shipped`, unmeasured as a price. `-D MOJOLEARN_STEP_GLUE_DEFAULT_EVERY_COLUMN=1` returns the NVIDIA word on every column, so a no-trial build on a Mac reaches the shipped glue branch; this is how the M4 gates that branch, since Apple's own default carries no glue bit. A check knob, the `MOJOLEARN_EXPERIMENTAL_SMALLK_IDENTICAL` pattern; never a shipped build."""
    comptime if is_defined["MOJOLEARN_STEP_GLUE_DEFAULT_EVERY_COLUMN"]():
        return STEP_GLUE_DEFAULT_WORD_OPTSKIP_NOSHADOW_ROWS16
    if column == COLUMN_NVIDIA:
        # DEVIATION 2649. Measured 2026-09-11 on a RunPod H100 80GB HBM3,
        # commit 030079af, one pod and one heat window, against the same
        # build's `shipped` arm
        # (bench/results/e1g/2026-09-11_215139-nvidia-h100-80gb-hbm3-step-glue):
        #   verdict optskip_noshadow_rows16 FLIP geomean=0.9723
        #   enwik8=0.9744 pilegithub=0.9703 witnesses_equal_shipped=True
        # Lean step 0.2911 / 0.2921 -> 0.2837 / 0.2834 s (enwik8 / Pile
        # GitHub). Attribution on the same box (timers build,
        # timing_witnesses_equal=True), enwik8, ms: fwd.norm1 3.068 -> 1.554,
        # fwd.norm2 3.077 -> 1.562, grad.norm1_kernels 2.026 -> 1.399,
        # grad.norm2_kernels 2.038 -> 1.393, and step.shadow_copy (2.309) and
        # step.opt_refuse_scan (2.175) gone; the optimizer, the scans and the
        # packing are unchanged to within 0.013 ms. The runners-up on the same
        # leg all FLIP too: optskip_noshadow_rows8 0.9734, optskip_noshadow
        # 0.9849, rows16 0.9852, rows8 0.9873. ENGINEERING_RULES 9 takes the
        # winner.
        return STEP_GLUE_DEFAULT_WORD_OPTSKIP_NOSHADOW_ROWS16
    if column == COLUMN_AMD:
        # DEVIATION 2649 ON AMD TOO. Measured 2026-09-12 on a Hot Aisle MI300X
        # (gfx942) against the SAME BUILD's `shipped` arm, commit bb679f19, one
        # VM and one heat window
        # (bench/results/e1g/2026-09-12_133013-amd-mi300x-hotaisle-step-glue):
        #   verdict optskip_noshadow_rows16 FLIP geomean=0.9854
        #   enwik8=0.9854 pilegithub=0.9853 witnesses_equal_shipped=True
        # Lean step 0.7634 / 0.7620 -> 0.7523 / 0.7509 s (enwik8 / Pile
        # GitHub), and against the separate SHIPPED build 0.9848 / 0.9839. The
        # drift control re-ran `shipped` last at 0.9971 of the first `shipped`
        # run, which is smaller than the 1.5 percent gain, so the win is not
        # the VM warming up. `step_glue_check: PASS` on the same box with the
        # reach lines for every arm (threads_per_block=16 first_moved_row=32
        # forward and backward, update first_moved_element=768).
        # The gain is half of NVIDIA's (0.9723 there) and the reason is the
        # same occupancy story read the other way: 2,048 token rows at
        # LLAMA_TPB 128 are 16 blocks, which starve an H100's 132 SMs harder
        # than they starve this board. ENGINEERING_RULES 9 sets no magnitude
        # bar, and both corpora are below 1 with the bits unmoved.
        return STEP_GLUE_DEFAULT_WORD_OPTSKIP_NOSHADOW_ROWS16
    if column == COLUMN_CPU:
        return STEP_GLUE_DEFAULT_WORD_SHIPPED  # the non-vendor default
    return STEP_GLUE_DEFAULT_WORD_SHIPPED


def knn_warpsort_select_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 1922): whether the k-NN TILED path's selector is the implemented RAFT WARPSORT (`select_warpsort.mojo`, `warpsort_topk_block_kernel`) instead of the implemented RAFT radix (`select_radix.mojo`) for `2 < k <= 256`."""
    comptime if identical:
        return False
    if column == COLUMN_CPU:
        return False  # FAST row; a host build is IDENTICAL only
    return column == COLUMN_NVIDIA


def knn_auto_follows_their_dispatch_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 1923): whether the k-NN AUTO arm follows cuVS's dispatch UNCONDITIONALLY -- `k <= 64` + row-major + L2 goes to `fusedL2Knn`, x-split included (`knn_brute_force.cuh:443`) -- instead of DEVIATION 36's shape test (fused only when `launchConfigGenerator` picks `grid_x == 1`, tiled when it would engage the x-split)."""
    comptime if identical:
        return False
    if column == COLUMN_CPU:
        return False  # FAST row; a host build is IDENTICAL only
    return column == COLUMN_NVIDIA



comptime QUANTIZE_SEARCH_LINEAR = 0

comptime QUANTIZE_SEARCH_BINARY = 1

comptime QUANTIZE_SEARCH_TWO_LEVEL = 2


def quantize_search_for[column: Int]() -> Int:
    """SCHEDULING row: HOW the evaluator's quantize finds a value's bin."""
    if column == COLUMN_APPLE:
        return QUANTIZE_SEARCH_TWO_LEVEL
    if column == COLUMN_CPU:
        return QUANTIZE_SEARCH_LINEAR  # scheduling; never Apple's two-level
    return QUANTIZE_SEARCH_LINEAR


def _knn_identical_round_column(column: Int) -> Bool:
    """The columns whose IDENTICAL k-NN defaults were flipped 2026-09-09: small-k selector, transposed index layout with the register tile, and index-axis tiling. NVIDIA and AMD flipped on the H100 evidence; Apple flipped the same afternoon on the M4 four-arm price (100k x 32, k 10, 9 rounds, PRICE_MS medians baseline -> both: 20.5 -> 15.1 ms at 32 queries, 26.9 -> 14.9 at 128, 182.2 -> 66.6 at 1000; all four arms byte-equal to the NVIDIA baseline across 143,628 cells). On Apple the transpose-only arm was slightly faster still at 128 and 1000 queries (12.1, 60.2 ms) and slower at 32 (16.3 ms); the both column is the shipped one."""
    return (
        column == COLUMN_NVIDIA
        or column == COLUMN_AMD
        or column == COLUMN_AMD_RDNA
        or column == COLUMN_APPLE
        # the CPU column takes the 2026-09-09 IDENTICAL defaults too, so a
        # host k-NN twin restates what all four GPU columns run
        or column == COLUMN_CPU
    )


def knn_smallk_select_for[column: Int, identical: Bool]() -> Bool:
    """ROUTING row: whether the IDENTICAL tiled k-NN arm selects k <= KNN_SMALLK_MAX_K with the per-thread composite-key selector (`neighbors/checks/select_smallk_identical_candidate.mojo`) instead of the 64-bit radix. Both return the k smallest (distance, index) keys ascending, so the bits are equal by construction and the gate is the four-arm dispatch check. `-D MOJOLEARN_KNN_IDENTICAL_LEGACY_SELECT=1` forces the radix on every column; `-D MOJOLEARN_EXPERIMENTAL_SMALLK_IDENTICAL=1` forces the selector on every column."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_LEGACY_SELECT"]():
        return False
    comptime if is_defined["MOJOLEARN_EXPERIMENTAL_SMALLK_IDENTICAL"]():
        return True
    return _knn_identical_round_column(column)


def knn_transposed_index_for[column: Int, identical: Bool]() -> Bool:
    """ROUTING row: whether the IDENTICAL tiled k-NN arm transposes the index once per request so the pinned distance tile reads it coalesced. Same per-cell fma chain, so the bits are equal. `-D MOJOLEARN_KNN_IDENTICAL_LEGACY_LAYOUT=1` forces the row-major layout; `-D MOJOLEARN_EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL=1` forces the transpose on every column."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_LEGACY_LAYOUT"]():
        return False
    comptime if is_defined["MOJOLEARN_EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL"]():
        return True
    return _knn_identical_round_column(column)


def knn_distance_register_tile_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row: whether the transposed IDENTICAL distance tile computes a column-selected register tile per thread (`pinned_distance_tile.mojo::pinned_distance_register_tile_kernel`) instead of one cell per thread. Every cell's chain is still one ascending serial fma chain over the feature axis (IDENTITY_PATHS row 24), so the bits are equal. Only reachable when `knn_transposed_index_for` is true. `-D MOJOLEARN_KNN_IDENTICAL_SCALAR_TILE=1` keeps one cell per thread."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_SCALAR_TILE"]():
        return False
    return knn_transposed_index_for[column, identical]()


def knn_selector_specialize_common_for[column: Int, identical: Bool]() -> Bool:
    """Compile-time k=10/15 removes dynamic insertion guards and threshold
    selection. NVIDIA 400k/4000q/k10: selector 20.3 -> 9.1 ms on the L40S
    (2026-09-09 selector resume). The same integer composite-key scan and
    block minimum are retained. Other columns can force the specialization
    for qualification; the generic capacity buckets remain the A/B arm.
    """
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_GENERIC_K"]():
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_SPECIALIZE_COMMON"]():
        return True
    if column == COLUMN_CPU:
        return False  # NVIDIA's schedule, never the host's
    return column == COLUMN_NVIDIA


def knn_selector_shuffle_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (2026-09-09, lane/knn-selector): whether the IDENTICAL small-k selector (`select_smallk_identical_candidate.mojo::smallk_bucket_kernel`) takes each rank's block minimum through a lane-group butterfly (`shuffle_xor` over `column_lane_width` lanes, one shared slot per lane group, ONE barrier per rank, double-buffered slots) instead of the eight-level shared-memory tree (eleven barriers per rank). The reduced value is a UInt64 composite key and the fold is an integer minimum, which is associative, commutative and idempotent, so the winner is the same key under any tree and the bits are equal by construction; the gate is the four-arm dispatch check. Every column with a fixed lane width (`column_lane_width_is_fixed`) takes the butterfly; the Qualcomm and Intel columns, whose lane width the vendor's compiler chooses per kernel, keep the tree. `-D MOJOLEARN_KNN_IDENTICAL_TREE_SELECT=1` forces the tree on every column."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_TREE_SELECT"]():
        return False
    if column == COLUMN_CPU:
        return True  # the fixed-width reading, what every GPU column answers
    return column_lane_width_is_fixed(column)


def knn_selector_warpbound_guard_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (2026-09-11, DEVIATION 2523): whether the IDENTICAL small-k selector (`select_smallk_identical_candidate.mojo::smallk_bucket_kernel`) runs its per-lane insertion chain behind a warp-uniform ballot with a warp-scope admission bound (every second batch, each lane publishes its list head, aligned lane groups take their minimum through five xor shuffles, the bound is the maximum over groups, and a lane admits against min(own k-th smallest, bound)) instead of the always-issued predicated chain. The bound is at or above the k-th smallest of a subset of the union of the warp's lists, so at least k union keys are at or below it and no key above it can be in the row's top-k; keys carry their column so no equality; the union still holds the true top-k, the rank phase pops the same UInt64 minima with the same index tie rule, and the bits are equal by construction (the nine-arm dispatch check, 18 planted cases, M4 and H100). Measured on the H100 2026-09-11: the chain issued on 90 to 96 percent of warp-steps under the per-lane threshold and on 46 percent under the bound; full requests at 400k x 4k x d32 went 30.8 to 27.8 ms (k10) and 36.0 to 31.0 ms (k15), every pair in both orders (bench/results/e1g/2026-09-11_023138-nvidia). NVIDIA only until the Apple and AMD columns are timed (RUN OWED; both are fixed-lane-width columns and pass the identity check, so timing is the only gate). Requires the block-uniform trip count (DEVIATION 2497) and a fixed-lane-width column. `-D MOJOLEARN_KNN_IDENTICAL_INSERT_CHAIN=1` restores the predicated chain on every column."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_INSERT_CHAIN"]():
        return False
    comptime if not column_lane_width_is_fixed(column):
        return False
    if column == COLUMN_CPU:
        return False  # NVIDIA's schedule, never the host's
    return column == COLUMN_NVIDIA


def svm_block_solve_warp_folds_for[column: Int, width: Int]() -> Bool:
    """SCHEDULING row (2026-09-11, DEVIATION 2623): whether `svm/impl/smoblocksolve.mojo::smo_block_solve_kernel[width]` folds its three arg-reductions with `block_argext` warp butterflies (DEVIATION 2491) instead of the halving trees with a one-slot thread ballot that preceded it. Both select the same (value, key) element under a total order with unique keys, so no column's bits depend on this row. NVIDIA refuses the warp kernel at width 1024 (H100 80GB HBM3, driver 580.126.09, CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES, so every SVC fit above 512 training rows failed from 2491 through 0.8.2) and launches it at 512; the tree kernel launches at 1024 there. Fusing two of the warp folds or dropping the WSIZE threadgroup diagonal did not make the warp kernel launch. The Apple M4 and the AMD MI300X launch the warp kernel at 1024. `-D MOJOLEARN_SVM_TREE_FOLDS` takes the tree schedule on every column for an A/B."""
    comptime if is_defined["MOJOLEARN_SVM_TREE_FOLDS"]():
        return False
    if column == COLUMN_CPU:
        return True  # the every-width reading; the oracle spells the fold serially
    return not (column == COLUMN_NVIDIA and width > 512)


comptime SVM_SCHED_TREE = 0
comptime SVM_SCHED_WARP = 1
comptime SVM_SCHED_WARP_LANE0 = 2
comptime SVM_SCHED_FUSED_TREE = 3
comptime SVM_SCHED_RARY_TREE = 4


def svm_block_solve_tree_arity_for[column: Int, width: Int]() -> Int:
    """SCHEDULING row (2026-09-11, DEVIATION 2628): the arity R of SVM_SCHED_RARY_TREE's threadgroup tree (a power of two; levels = ceil(log_R(width))). Selection under a total order, so no bits depend on it. `-D MOJOLEARN_SVM_ARITY_16` / `_64` for an A/B; default 32."""
    comptime if is_defined["MOJOLEARN_SVM_ARITY_16"]():
        return 16
    comptime if is_defined["MOJOLEARN_SVM_ARITY_64"]():
        return 64
    return 32


def svm_block_solve_schedule_for[column: Int, width: Int]() -> Int:
    """SCHEDULING row (2026-09-11, DEVIATIONS 2627 and 2628): which schedule folds the three arg-reductions of `svm/impl/smoblocksolve.mojo::smo_block_solve_kernel[width]`. SVM_SCHED_TREE (0) is the pre-2491 halving trees with a thread ballot for `u` and `l` (42 barriers per inner iteration at width 1024); SVM_SCHED_WARP (1) is DEVIATION 2491's `block_argext` warp butterflies (8); SVM_SCHED_WARP_LANE0 (2) is `block_argext_lane0`, the same butterflies with the cross-warp fold on lane 0 in a runtime loop and a warp broadcast (DEVIATION 2627, 5); SVM_SCHED_FUSED_TREE (3) is one halving tree carrying the argmin, its thread and the argmax together plus a thread-carrying tree for `l`, no ballot (DEVIATION 2628, 26); SVM_SCHED_RARY_TREE (4) carries the same selections on a threadgroup tree of arity `svm_block_solve_tree_arity_for` (DEVIATION 2628's second shape, about 10). All five select the same (value, key) element under a total order with unique keys, so no column's bits depend on this row. Default: `svm_block_solve_warp_folds_for` (DEVIATION 2623) picks WARP or TREE. `-D MOJOLEARN_SVM_SCHED_TREE`, `_WARP`, `_WARP_LANE0`, `_FUSED_TREE` or `_RARY_TREE` forces one schedule on every column for an A/B (the `_RARY_TREE` define was missing from this row at 48f92b19, so that commit's R-ary kernel was unreachable)."""
    comptime if is_defined["MOJOLEARN_SVM_SCHED_TREE"]():
        return SVM_SCHED_TREE
    comptime if is_defined["MOJOLEARN_SVM_SCHED_WARP"]():
        return SVM_SCHED_WARP
    comptime if is_defined["MOJOLEARN_SVM_SCHED_WARP_LANE0"]():
        return SVM_SCHED_WARP_LANE0
    comptime if is_defined["MOJOLEARN_SVM_SCHED_FUSED_TREE"]():
        return SVM_SCHED_FUSED_TREE
    comptime if is_defined["MOJOLEARN_SVM_SCHED_RARY_TREE"]():
        return SVM_SCHED_RARY_TREE
    if svm_block_solve_warp_folds_for[column, width]():
        return SVM_SCHED_WARP
    # DEVIATION 2666 (2026-09-11): the column DEVIATION 2623 sends to the
    # halving trees -- NVIDIA above width 512, where CUDA refuses the warp
    # kernel -- takes the FUSED_TREE schedule instead. Measured on an NVIDIA
    # H200 (RunPod 4oih8bhjepzlmm, driver 570.211.01, ptxas 12.9.86), taxi
    # 10,000 x 11, five fits each: FUSED_TREE 771.1 ms, TREE 866.9 ms,
    # RARY_TREE at arity 16 1,324.4 ms and at 32 1,945.6 ms (1,937.3 ms
    # without its trailing and second update barriers), every arm giving the
    # same fits (n=400/600/2000 457e29b82bca9df9, 733a383c5699f427,
    # 2b66bc991a9c9ed0; taxi b0f91a7958162936) from five different binaries.
    # NVIDIA ONLY: Metal refuses the fused kernel's width-1024 pipeline
    # (threadgroup memory 36872 > 32768, Apple M4 gate 2026-09-11), so this
    # stays a row and never a global default. `-D MOJOLEARN_SVM_TREE_FOLDS`
    # still takes the pre-2491 trees on every column for an A/B.
    comptime if not is_defined["MOJOLEARN_SVM_TREE_FOLDS"]():
        comptime if column == COLUMN_NVIDIA:
            return SVM_SCHED_FUSED_TREE
    return SVM_SCHED_TREE


def umap_device_optimizer_for[column: Int, identical: Bool]() -> Bool:
    """ROUTING row (2026-09-09, lane/umap-optimizer): whether the IDENTICAL UMAP layout optimizer runs on the device (`umap/optimizer_identical_device.mojo`: one thread per vertex, one epoch snapshot, each vertex's update a fixed-order fold over its CSR row, negatives from Philox keyed by (seed, epoch, edge, slot), no atomics, no launch-geometry dependence) instead of the serial host loop (`umap/optimizer.mojo::optimize_layout_identical`, `umap/sparse_optimizer.mojo::optimize_sparse_layout_identical`). The two produce DIFFERENT bits (Jacobi versus Gauss-Seidel order); the device path is the IDENTICAL contract on every column and is gated against itself across launch widths and GPUs, not against the host loop. `-D MOJOLEARN_UMAP_IDENTICAL_HOST_OPTIMIZER=1` restores the host loop on every column (the pre-2026-09-09 cards). FAST and DETERMINISTIC never enter this row."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_UMAP_IDENTICAL_HOST_OPTIMIZER"]():
        return False
    return True


comptime KNN_IDENTICAL_INDEX_TILE = 65536


def knn_index_tile_columns_for[column: Int, identical: Bool]() -> Int:
    """SCHEDULING row: the widest index-axis column tile the IDENTICAL tiled k-NN arm computes per query tile before merging partial top-k lists under the composite total order (`select_smallk_identical_candidate.mojo::partial_topk_merge_kernel`). 0 means the index axis is never split. Merging sorted (distance, index) lists is order-independent, so the bits are equal to the untiled path. `-D MOJOLEARN_KNN_IDENTICAL_NO_INDEX_TILE=1` restores the untiled path."""
    comptime if not identical:
        return 0
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_NO_INDEX_TILE"]():
        return 0
    if _knn_identical_round_column(column):
        return KNN_IDENTICAL_INDEX_TILE
    return 0


def gemm_wide_split_for[column: Int]() -> Bool:
    """Execution-only wide split-K tiles on the measured NVIDIA column. The CPU column answers False.

    The 128x128/KS16 tile reduces operand reloads for complete output tiles.
    Other columns keep their previous dispatcher pending local timings;
    every column's all-plan correctness gate still exercises the new tile.
    """
    if column == COLUMN_CPU:
        return False
    return column == COLUMN_NVIDIA


def knn_distance_zero_fma_repair_for[column: Int, identical: Bool]() -> Bool:
    """Repair Apple's pre-round FMA underflow only at the kNN register seam.

    The integer slow path runs only for a zero result and restores a rounded
    smallest-normal result when required. NVIDIA already uses round-then-FTZ.
    The exact integer oracle checks 396584 actual/simulated-underflow triples.
    The disable flag retains an explicit Apple before/after performance arm.
    """
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_NO_ZERO_FMA_REPAIR"]():
        return False
    if column == COLUMN_CPU:
        return False  # a CPU FMA rounds once and does not pre-round underflow
    return identical and column == COLUMN_APPLE


@always_inline
def knn_distance_preflight_for[column: Int, identical: Bool]() -> Bool:
    """Exact whole-chain exponent admission avoids unnecessary Apple repairs."""
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_NO_PREFLIGHT"]():
        return False
    if column == COLUMN_CPU:
        return False  # Apple's repair admission; nothing to repair on a CPU
    return identical and column == COLUMN_APPLE


@always_inline
def knn_distance_metadata_for[column: Int, identical: Bool]() -> Bool:
    """Force request-local exponent minima outside the measured default scope."""
    comptime if is_defined["MOJOLEARN_EXPERIMENTAL_KNN_PREFLIGHT_METADATA"]():
        return knn_distance_preflight_for[column, identical]()
    return False


@always_inline
def knn_distance_metadata_default_for[column: Int, identical: Bool]() -> Bool:
    """Apple capability; runtime dispatch additionally requires measured shapes."""
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_NO_METADATA"]():
        return False
    return knn_distance_preflight_for[column, identical]()


@always_inline
def knn_distance_hardware_flush_for[column: Int, identical: Bool]() -> Bool:
    """Fully rounded NVIDIA FMA followed by exact hardware FTZ multiplication."""
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_SOFTWARE_FLUSH"]():
        return False
    if column == COLUMN_CPU:
        return False  # the software flush, NVIDIA's instruction is not here
    return identical and column == COLUMN_NVIDIA


@always_inline
def knn_distance_rows_for[column: Int, identical: Bool]() -> Int:
    """Measured NVIDIA eight-query register tile; each cell keeps its FMA chain.

    The 32/128-feature cases improve; the 8-feature coverage is flat to 0.9%
    slower. Other columns retain four query rows per thread.
    """
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_ROWS4"]():
        return 4
    if column == COLUMN_CPU:
        return 4  # scheduling; NVIDIA's eight-row tile is NVIDIA's
    return 8 if identical and column == COLUMN_NVIDIA else 4


@always_inline
def knn_distance_exact_chain_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 2629, 2026-09-11, lane/knn-speed): whether the transposed IDENTICAL register-tile distance admits a tile to the UNFLUSHED chain (`pinned_distance_tile.mojo::_rt_step_exact`) when request-local exponent metadata proves every product and every partial sum of every cell in the tile is zero or at least the smallest normal (minimum biased exponent sum >= 174, maximum sum plus ceil(log2 d) <= 376, no nonfinite input). Under that proof the per-step flush never sees a subnormal, so dropping it moves no bit; a tile that fails admission keeps the flushed chain. Kernel code is the same on every column; this row only decides where the admission runs. MEASURED NEUTRAL on the H100 2026-09-11 (pod 62dlwtf4amlt2s, 400k x 4k x d32, three interleaved before/after pairs of 7 rounds): request k10 23.65 -> 23.85 ms, k15 26.24 -> 26.19 ms, distance class 15.31 -> 15.41 ms; full distance and index dumps equal to origin/main, sabotage flips them. The flush is not what the distance class pays for, so the row is OFF on every column and stays opt-in: `-D MOJOLEARN_EXPERIMENTAL_KNN_EXACT_CHAIN=1` admits on every column; `-D MOJOLEARN_KNN_IDENTICAL_FLUSHED_CHAIN=1` forces the flushed chain."""
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_FLUSHED_CHAIN"]():
        return False
    comptime if is_defined["MOJOLEARN_EXPERIMENTAL_KNN_EXACT_CHAIN"]():
        return identical
    return False


#: DEVIATION 2631's measured tile, FLIPPED 2026-09-11 on the H200 (pod
#: `zwmta1li2twxx2`): synthetic 400k x 4k x d32 request 23.53 -> 21.38 ms at
#: k10 (0.909) and 25.98 -> 23.52 at k15 (0.905) against the 512 default,
#: taxi 22.14 -> 19.92 ms (0.900) and Istella-S 100.29 -> 95.51 (0.952) in
#: interleaved races, geomean 0.926, recall@10 unchanged on both datasets and
#: every output bit equal. At 4,000 queries `plan_query_tile`'s query clamp
#: lowers it to 4,000, so the benchmark shape runs as ONE query tile.
comptime KNN_IDENTICAL_WIDE_QUERY_TILE = 4096


@always_inline
def knn_query_tile_for[column: Int, identical: Bool]() -> Int:
    """SCHEDULING row (DEVIATION 2631, 2026-09-11, lane/knn-finish): the default query tile of the IDENTICAL tiled k-NN arm (`neighbors/estimator.mojo::DEFAULT_QUERY_TILE`), and on the same column the radix scratch the small-k selector never reads is not allocated (`knn_brute_force.mojo::tiled_radix_scratch_len`). 0 means the estimator's historical rule (512 on NVIDIA IDENTICAL, 256 elsewhere). Tiling cannot move a bit: every cell's chain is a function of its query row and index column alone, every row's selection and partial merges run in the same column-tile order whatever the query tile, and the scratch is never read on a k <= 64 request. Arms for the A/B: `-D MOJOLEARN_KNN_QUERY_TILE_ARM_512`, `_1024`, `_2048`, `_4096` force that tile on every column; `-D MOJOLEARN_KNN_IDENTICAL_FULL_RADIX_SCRATCH=1` keeps the historical scratch."""
    comptime if not identical:
        return 0
    comptime if is_defined["MOJOLEARN_KNN_QUERY_TILE_ARM_512"]():
        return 512
    comptime if is_defined["MOJOLEARN_KNN_QUERY_TILE_ARM_1024"]():
        return 1024
    comptime if is_defined["MOJOLEARN_KNN_QUERY_TILE_ARM_2048"]():
        return 2048
    comptime if is_defined["MOJOLEARN_KNN_QUERY_TILE_ARM_4096"]():
        return 4096
    if column == COLUMN_CPU:
        return 0  # scheduling; the measured tile is NVIDIA's
    return KNN_IDENTICAL_WIDE_QUERY_TILE if column == COLUMN_NVIDIA else 0


@always_inline
def knn_radix_scratch_shrink_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 2631): whether a k <= 64 IDENTICAL tiled request allocates `k` radix scratch pairs per query row instead of `n_index // 8`. The small-k selector (`knn_smallk_select_for`) serves every column tile of such a request, so the radix kernel that reads the scratch is never launched and no output can depend on its size. Same column scope as `knn_query_tile_for`'s measured tile. `-D MOJOLEARN_KNN_IDENTICAL_FULL_RADIX_SCRATCH=1` keeps the historical size everywhere."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_FULL_RADIX_SCRATCH"]():
        return False
    if column == COLUMN_CPU:
        return False  # scheduling; NVIDIA's
    return column == COLUMN_NVIDIA


@always_inline
def knn_fused_distance_select_for[column: Int, identical: Bool]() -> Bool:
    """SCHEDULING row (DEVIATION 2667, 2026-09-11, lane/knn-finish): whether the transposed IDENTICAL tiled k-NN arm computes each column tile's distances INSIDE the small-k selector (`neighbors/checks/fused_distance_select_identical.mojo`), one launch per tile, instead of a register-tile distance launch that writes a `query_tile x index_tile` matrix and a selector launch that reads it back. The shape of cuVS's `fusedL2Knn` (`knn_brute_force.cuh:447-451`): no distance matrix is written. Each candidate's distance is the register tile's cell chain (`pinned_distance_tile.mojo::_rt_step` over the feature axis ascending, then the same epilogue, clamp and root), its key is the same composite (distance, index) key, and the selector's rank phase returns the k smallest keys of the whole tile, which do not depend on which thread saw which column, so neighbors and distances are the same bits. `-D MOJOLEARN_EXPERIMENTAL_KNN_FUSED_SELECT=1` forces it on every column; `-D MOJOLEARN_KNN_IDENTICAL_UNFUSED_SELECT=1` forces the two-launch form."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_KNN_IDENTICAL_UNFUSED_SELECT"]():
        return False
    comptime if is_defined["MOJOLEARN_EXPERIMENTAL_KNN_FUSED_SELECT"]():
        return True
    return False


@always_inline
def umap_device_optimizer_live_row_for[column: Int, identical: Bool]() -> Bool:
    """ROUTING row (DEVIATION 2668, 2026-09-11, lane/knn-finish): whether the IDENTICAL UMAP device optimizer (`umap/optimizer_identical_device.mojo::umap_identical_epoch_kernel`) applies a vertex's own attractive and repulsive moves to its running position during its fold (cuML's per-vertex serial kernel, `optimize_batch_kernel.cuh:569-577, 608-616`) instead of summing every move from the epoch snapshot. The mirror edge's tail move stays deferred. MOVES UMAP BITS on every column (the IDENTICAL contract is one default for all columns); both forms are pure functions of the epoch snapshot with one writer per vertex, so each is independent of launch width and vendor, and the 2668 fold's 20,000-row fingerprint is one value (4040033352384472344) across launch widths 64, 128 and 256 with both UMAP identity checks passing. OFF BY DEFAULT: measured on the H200 2026-09-11 it SPLITS on the two datasets, which ENGINEERING_RULES section 9 gates per dataset. Sampled trustworthiness and 10-neighbor retention at 100,000 rows, 200 epochs: taxi 0.9062 / 0.3736 to 0.9323 / 0.3627 (trust up, retention down) and Istella-S 0.9737 / 0.4832 to 0.9636 / 0.4264 (both down), with the time flat on both (1.003 and 1.000). Quality worse on a dataset is a regression a user on that data sees, so the row stays opt-in through `-D MOJOLEARN_UMAP_IDENTICAL_LIVE_ROW=1`; `-D MOJOLEARN_UMAP_IDENTICAL_SNAPSHOT_FOLD=1` forces the snapshot fold even then. What the measurement DID establish is the cause of the cuML gap on taxi (the update order: our own serial host loop scores 0.9796 on the same graph and init against cuML's 0.9657), and that on Istella-S the shipped fold already beats cuML by a wide margin."""
    comptime if not identical:
        return False
    comptime if is_defined["MOJOLEARN_UMAP_IDENTICAL_SNAPSHOT_FOLD"]():
        return False
    comptime if is_defined["MOJOLEARN_UMAP_IDENTICAL_LIVE_ROW"]():
        return True
    return False
