# Support and certification

mojolearn **0.8.3 is published on PyPI** as a Linux x86-64 wheel (CUDA sm_89,
CUDA sm_90a, HIP gfx942) and a macOS arm64 wheel, both from commit f8b65ee2
(tags alpha-api-0.8.3-20260911 and v0.8.3), published 2026-09-11. The installed
Linux wheel passed its identical qualification jobs on HIP gfx942 and CUDA
sm_90a (29 smoke lanes, equal hashes on both); sm_89 was not qualified
installed. Only the three tree bindings (GBDT, Random Forest, Extra Trees) ship
the `fast` and `deterministic` tiers; every other binding builds and ships
`identical` only, and asking one of them for a lower tier raises a named error
(DEVIATION 2490, 0.8.0). The per-release detail, including what each patch
release changed and what was not qualified, is in [CHANGELOG.md](CHANGELOG.md).
Publication does not certify all features, architectures or current source
edits.

The [September 6 Apple 0.6.0 candidate](bench/results/resume/2026-09-06-feature-finish/README.md)
rebuilds all 45 extensions and passes all fifteen installed Python 3.10–3.14 /
numeric-mode jobs. This includes UMAP transform, OrderedRMSE and saved numeric
modes, plus all 102 Mamba and 44 Transformer surface checks per job. Those retained native-build checks do not qualify Linux or every later Python overlay. Corrected Apple native backward
passes all five baseline cases and Mamba1 L64; Mamba3 L65 remains RED on one
independent float32-reference intermediate despite matching the older AMD
capture's 93 shared native arrays. Python zero-state IDENTICAL backward is now exposed; exact installed-artifact and broader backward qualification remain open.

For the enforced identity surface, see the
[identity-path ledger](IDENTITY_PATHS.md). Fresh certification artifacts name
their commit, device, mode, and limitations; stale narrative reports are not a
support source.

## Numeric modes

| Mode | Contract |
|---|---|
| `fast` | Performance-oriented. No repeatability or cross-vendor bitwise promise. |
| `deterministic` | Repeated execution on the same device and build is intended to return the same bits. It makes no cross-vendor promise. |
| `identical` | For a specifically certified fixture and configuration, raw result bits match across the recorded Metal, CUDA, and HIP legs. |

Select a process default with `mojolearn.set_numeric_mode(...)` or
`MOJOLEARN_NUMERIC_MODE`. Estimators that accept `numeric_mode=` can override
the process default. All three modes are runtime-selectable binary sets, not
separate packages.

`identical` is not a blanket claim for arbitrary shapes, parameters, hardware,
drivers, or future builds. The claim is limited to completed evidence cards.
An unrun column is **pending**, never inferred from source inspection or another
device.

## Installation support

| Platform | Status | Qualification |
|---|---|---|
| macOS arm64 / Apple silicon | Published 0.8.3 wheel | Built at the Apple M1 ISA floor from commit f8b65ee2. The tree bindings ship three tiers; every other binding ships `identical` only (DEVIATION 2490). The 0.8.3 SVC fix was verified on the Apple M4 and the 0.8.2 GBDT fix gave 36/36 identity cells equal to the H100 on the Apple M4 ([CHANGELOG.md](CHANGELOG.md)). |
| Linux x86-64 / NVIDIA CUDA | Published 0.8.3 wheel, `sm_89` and `sm_90a` | Installed 0.8.3 wheel passed its identical qualification jobs on CUDA sm_90a (29 smoke lanes) and fit SVC at 400, 600 and 2,000 rows on an H100 with the source builds' bits; sm_89 was not qualified installed. Device code is architecture-specific. Certification on one NVIDIA architecture does not certify another. Release 0.3.0 had an AVX-512 host-code defect; it is historical and must not be used as current evidence. |
| Linux x86-64 / AMD HIP | Published 0.8.3 wheel, `gfx942` | Installed 0.8.3 wheel passed its identical qualification jobs on HIP gfx942 (29 smoke lanes, hashes equal to sm_90a). The 0.8.2 GBDT sync fix (DEVIATION 2600) was verified 36/36 identity cells equal to the H100 on an MI300X. Measured chiefly on `gfx942`. That is not evidence for every AMD architecture. |
| CPU-only and other accelerators | Source-built CPU bindings for named lanes, held to the GPU identity gate; no silent CPU fallback | No estimator falls back to a CPU on its own; the library refuses. Named CPU paths exist and each is gated bit for bit against the Apple, NVIDIA and AMD columns with a sabotage build required to fail; the whole surface is declared once in `python/mojolearn/host_surface.py` and tabulated under [The CPU surface](#the-cpu-surface) below. Inference from a saved model: <!--fact:host_inference_surfaces-->random forests, Extra Trees and the four gradient boosting variants; nearest neighbors, k-NN classification and k-NN regression; linear regression, ridge, truncated SVD, logistic regression, PCA with and without whitening and kernel density; SVC<!--/fact--> (the forests: 24 three-GPU recordings reproduced on seven CPUs, run 34782452584, [fixtures](bench/results/forest_host/README.md); the first five classical estimators: three-vendor recordings, 45 fixtures each; kernel density, SVC, whitened PCA and the k-NN classes: three-vendor recordings, 54 fixtures each, [fixtures](bench/results/classical_host/)). Training: <!--fact:host_training_lanes-->pinned GEMM, kernel density, Holt-Winters, lasso, elasticnet, SVC, agglomerative clustering, the Extra Trees classifier, the Extra Trees regressor and the isolation forest<!--/fact-->, the first six identical to the three GPU columns of the 46-lane harness on seven CPUs ([gate](.github/workflows/cpu-identity-gate.yml)), agglomerative clustering, Extra Trees (classifier and regressor, saved model bytes included) and the isolation forest since 2026-09-14, identical to the three GPU columns on the Apple M4 host path, the seven-runner run pending ([columns](bench/results/identity_break/2026-09-14_cpu-phase1b/README.md)). Only the byte LM host binding ships in a wheel; the rest build with `bindings/build_*_host.sh`, each a shim over `bindings/build_host_family.sh`. Every other lane has no CPU path (<!--fact:no_cpu_path-->k-means, DBSCAN, spectral clustering, UMAP, the Gaussian process, ARIMA, the neural blocks and training for the random forests, gradient boosting and k-NN<!--/fact-->). The byte LM has two CPU surfaces needing no GPU: `LanguageModelInference` for the forward pass ([docs/BYTE_LM_CPU_INFERENCE.md](docs/BYTE_LM_CPU_INFERENCE.md)), and `LanguageModelHostTrainer` for one training step, forward, backward and the AdamW update, which reproduces the recorded GPU bytes of the retained three-vendor capture for all 128 of its steps, gradient and loss and post-step parameters and both Adam moments alike, on seven CPUs, with a wrong-gradient build required to fail the same gate ([docs/BYTE_LM_CPU_TRAINING.md](docs/BYTE_LM_CPU_TRAINING.md)). Both are one model profile at one batch shape; identity is claimed per shape, because the weight gradients contract over the token count. Reference path, one thread: a whole step measured 37 to 39 ms on the Linux CI runners and 69 ms on Apple M1. |

## The CPU surface

Generated from `python/mojolearn/host_surface.py` by `tools/docs_facts.py
--write`; `pixi run check-docs-facts` fails when this table and the manifest
disagree. Every binding below is IDENTICAL only, compiles as the kernel
matrix's CPU column (asserted at build time, read back before use), and
refuses by name every function it does not list.

<!--fact:host_surface_table-->| family | binding under `mojolearn/host/` | routes (CPU-only install) | trains on a CPU (identity_break lanes) | predicts on a CPU from a saved model | gate | in a wheel |
|---|---|---|---|---|---|---|
| byte_lm | `_mojolearn_byte_lm_host.so` | loaded by path | no | LanguageModelInference, LanguageModelHostTrainer | .github/workflows/byte-lm-cpu-gate.yml | yes |
| forest | `_mojolearn_forest_host.so` | loaded by path | no | RandomForestClassifier, RandomForestRegressor, ExtraTreesClassifier, ExtraTreesRegressor, GradientBoosting (rf_classifier, rf_regressor, et_classifier, et_regressor, gbdt_symmetric, gbdt_depthwise, gbdt_lossguide, gbdt_rmse) | tools/forest_host_gate.py (.github/workflows/forest-host-gate.yml) | no, `bindings/build_forest_host.sh` |
| tokenizer | `_mojolearn_tokenizer_host.so` | loaded by path | no | GPT2Tokenizer | pixi run check-tokenizer and python/mojolearn/tests/test_tokenizer_surface.py | no, `bindings/build_tokenizer_host.sh` |
| core | `_mojolearn_core_host.so` | `_mojolearn` | no | NearestNeighbors, KNeighborsClassifier, KNeighborsRegressor (knn, knn-clf, knn-reg) | tools/classical_host_gate.py (cpu-identity-gate.yml) | no, `bindings/build_core_host.sh` |
| linalg | `_mojolearn_linalg_host.so` | `_mojolearn_linalg` | gemm-pinned | no | tools/identity_break.py (cpu-identity-gate.yml) | no, `bindings/build_linalg_host.sh` |
| estimators | `_mojolearn_estimators_host.so` | `_mojolearn_estimators` | kde | LinearRegression, Ridge, TruncatedSVD, LogisticRegression, PCA, KernelDensity (ols, ridge, tsvd, logistic, logistic-multiclass, pca, pca-whiten, kde) | tools/identity_break.py and tools/classical_host_gate.py (cpu-identity-gate.yml) | no, `bindings/build_estimators_host.sh` |
| tsa | `_mojolearn_tsa_host.so` | `_mojolearn_tsa` | holtwinters | no | tools/identity_break.py (cpu-identity-gate.yml) | no, `bindings/build_tsa_host.sh` |
| solver | `_mojolearn_solver_host.so` | `_mojolearn_solver` | lasso, elasticnet, agglomerative | no | tools/identity_break.py (cpu-identity-gate.yml) | no, `bindings/build_solver_host.sh` |
| svm | `_mojolearn_svm_host.so` | `_mojolearn_svm` | svc, iforest | SVC, IsolationForest (svc) | tools/identity_break.py and tools/classical_host_gate.py (cpu-identity-gate.yml) | no, `bindings/build_svm_host.sh` |
| trees | `_mojolearn_trees_host.so` | `_mojolearn_trees` | et-clf, et-reg | no | tools/identity_break.py (cpu-identity-gate.yml) | no, `bindings/build_trees_host.sh` |<!--/fact-->

Before publishing a release, validate the installed wheel rather than only the
source tree. Import it in a clean environment, load every shipped extension in
each tier it ships (three tiers for the tree bindings, `identical` only for the
rest), and run the public smoke suite. See [release instructions](docs/PYPI_RELEASE.md)
and the [release checklist](docs/RELEASE_CHECKLIST.md).

## Capability snapshot

The table groups public surfaces by the strongest evidence currently retained.
“Three-vendor card” means at least one named fixture has matching IDENTICAL
cards on Apple, NVIDIA, and AMD; it does not extend beyond that fixture. Each
row's evidence was recorded at the commit its cited card or brief names, and a
row that names no commit is certified only at the commit of its linked record,
not at the current source.

**Known IDENTICAL violation.** The Gram product `A^T A` that PCA, truncated
SVD and OLS run their first step through ([IDENTITY_PATHS.md](IDENTITY_PATHS.md)
row 27) falls back to the vendor matmul under IDENTICAL when the design has
more columns than the split-K kernel's capacity, instead of refusing. The
129-column fallback arm of `decomposition/checks/pca_check.mojo` completes
under IDENTICAL and returns a model that mode promises is vendor-independent
and is not. Recorded as pre-existing on NVIDIA and AMD in the
[AMD confirmations brief](docs/lanes/BRIEF_amd_confirmations_2026-09-12.md)
(finding 3); the refusal past capacity is still owed.

**A cross-vendor divergence found and fixed (DEVIATION 2710).** On 2026-09-13 the
46-lane run of `tools/identity_break.py` found `ExperimentalTwoLevelFeatureFreq`
different between every pair of an Apple M4, an NVIDIA H100 and an AMD MI325X
on 8 of 9 hostile fixtures while the other 43 lanes were identical. The cause
was memory, not arithmetic: the synchronized tensor drivers sized and zeroed
the fixed-point histogram accumulator by a literal dead flag, so under
IDENTICAL the histogram kernels wrote 264 cells into a 4-byte, never-zeroed
buffer and read back whatever each vendor's allocator had left there. Sized by
the live flag, all three vendors give the Apple column's bits on every fixture
and column (fixed arm base 7d9c56b51213cb42, hashed 9d97a55431b6f8e0; the old
code, selectable with `-D MOJOLEARN_2710_TENSOR_ACC_DEAD=1`, reproduces each
vendor's wrong hashes), see
`docs/lanes/BRIEF_feature_freq_divergence_2026-09-13.md`. The fix shipped in 0.8.5;
0.8.4 carries the defect on this estimator. Verified after the fix on 2026-09-14: the 46-lane
three-column rerun reads IDENTICAL x3 on every cell of every lane, this one included
(`bench/results/identity_break/2026-09-14_46-lanes/README.md`, 414 train and 459 infer and
model cells on an Apple M4, an NVIDIA H100 and an AMD MI300X, no one-column cell).

**Mamba-2 read past the end of X_d, 2026-09-14, DEVIATIONS 2712 and 2713, CLOSED together, one cause.**
`m2_ydiag_kernel` (`mamba/impl/modules/ssd_minimal.mojo`, S13 and S14, Y_diag = M . X_d) looped over
the chunk width Q = 256 and loaded the X_d row c * Q + jj for every jj, including rows at or past
T (X_d is [B, T, H, P]; T is 16 in the identity lanes and 1 in the step), a read past the end of the
allocation. The multiplier there is the structural +0.0, so 0 x finite garbage is 0 and every CUDA
and HIP run and every cold Metal run carried the same bits; 0 x NaN is NaN, which is what Metal
handed back in a warm process (DEVIATION 2712: the Apple M4 column of the 120-lane record at
65ae7612f, `step` and `backward` NaN on all nine mamba2 fixtures, first misattributed to AMD and
corrected the same day; the step reads farthest past since its T is 1); and the row past the last
allocation is an unmapped page on the DigitalOcean MI325X 24.04 image (DEVIATION 2713: "Memory
access fault by GPU node-1" at the first forward launch, where the Hot Aisle MI300X allocator
happened to back the page). Named by a poison-and-band build: every Mamba device allocation filled
with the canonical quiet NaN where nothing writes and given a 4096-element NaN band past its logical
length (`-D MOJOLEARN_MAMBA_POISON=1`), under which the block check reported `ydiag.out` MOVED 256
of 256 with every input stage OK. Fixed by reading X_d only below T (+0.0 past it, the bits every
record carries); the sixty Mamba-2 backward buffers that were allocated with no fill are filled
(`mamba_scratch`, zero in production). The gate that catches the next read of this class is
`pixi run check-mamba-poison` (`tools/mamba_poison_gate.sh`): the poison binding built into a copy of
the package, mamba1, mamba2, mamba2-dtlimit and mamba3 cold, all 36 training rows required IDENTICAL
against the three vendor columns of `2026-09-14_120-lanes-2711flip`, with three sabotages (the fix
removed, a planted over-read with the band, the same without it as the control). On the Apple M4:
36 of 36 with the fix, the fix-removed and planted-over-read sabotages fail, the control passes.
Owed: the gate on the H100 and the MI300X, the poison build on the MI325X image, and the 120-lane
three-column rerun that becomes the CPU gate's GPU columns (brief section 3.3).

**RTX 5090 (sm_120a), 2026-09-14, DEVIATION 2711, found and FIXED the same day.** The first leg on
a Blackwell consumer part refused four cells (pca, tsvd, ols, ridge on the 17-column `odd`
fixture): an sm_120a ahead-of-time pass miscompiled the strided-singles arm of the 17-wide split-K
Gram, so the Jacobi was handed an asymmetric matrix (a JIT build of the same source on the same GPU
was already right, and the wrong cells repeated bit for bit). `core/gram_splitk.mojo` ships the
scalar strided arm from 83380ca6d, the same products in the same order with per-cell scalar
accumulators; `-D MOJOLEARN_2711_GRAM_STRIDED_DEAD=1` restores the old arm for an A/B. Proof: the
120-lane record `bench/results/identity_break/2026-09-14_120-lanes-2711flip/README.md`, where the
Apple M4, the H100, the MI300X and the RTX 5090 read IDENTICAL on 1071 training and 1476 inference
and model cells, the four cells included, and the H100 and MI300X columns are identical to their
columns before the flip on every shared cell.

| Surface | Public availability | Strongest retained identity evidence | Important open work |
|---|---|---|---|
| Gradient boosting | Beta | Three-vendor cards for recorded configurations | Numeric single-permutation ordered RMSE passes AMD/NVIDIA at `6dd44ac5`, with 130 bitwise-matching records. Broader categorical/CTR coverage and external parity remain. |
| Random Forest / Extra Trees | Beta | Three-vendor cards for recorded configurations | Keep sklearn `max_leaf_nodes` semantics distinct from cuML-style level-order `max_leaves`; extend NVIDIA performance coverage. |
| k-means, DBSCAN | Beta | Three-vendor cards for recorded fixtures | Broaden shapes and public-surface wheel smoke. |
| k-NN | Beta | Three-vendor cards; the completed AMD four-arm layout outputs also match retained NVIDIA outputs and Apple hashes | Selector and transposed-distance flags remain opt-in. Broaden distributions and installed/external comparisons before changing normal dispatch. |
| PCA, truncated SVD, OLS, Ridge, logistic regression | Beta | Three-vendor matrix for recorded fixtures | Broaden shapes and public-surface wheel smoke. |
| FP32 matrix multiplication | Beta | Three-vendor frozen-profile sweep | Shapes and plans outside the recorded profile remain uncertified. |
| Isolation Forest | Beta | Three-vendor card for the recorded fixture | Re-run current bindings on NVIDIA architectures affected by earlier context-lifetime failures. |
| ARIMA filtering | Beta | Three-vendor card for the recorded filter fixture | The fitted estimator passes the frozen AMD/NVIDIA installed candidates in all three modes; final release qualification remains. |
| Holt-Winters and spectral/time-series helpers | Beta | Apple–AMD cards for recorded fixtures | NVIDIA column remains pending. `kpss_test` and `select_d` are public with no three-vendor card and no CPU path (`IDENTITY_PATHS.md` has no tsa row; the claim-surface census, 2026-09-14). |
| Gaussian process | Experimental | Apple–AMD IDENTICAL card for recorded fixture | Complete current-wheel and NVIDIA qualification; no performance claim. |
| GPT-2 tokenizer (`GPT2Tokenizer`) | Alpha, from source: `bindings/build_tokenizer_host.sh` builds the CPU binding and the two tables are read from the checkout or `MOJOLEARN_TOKENIZER_DATA`; no wheel carries either yet | Apple M4 only (2026-09-14, lane `lane/expose-tokenizer`): through the Python door, 43 of 43 recorded tiktoken 0.14.0 id sequences exact and 43 of 43 decode round trips byte-exact (`python/mojolearn/tests/test_tokenizer_surface.py`, 13 checks), the Mojo gate the same 43 (`pixi run check-tokenizer`); a reversed-ids sabotage build failed 6 of the 13 checks (37 of 43 id sequences) and was refused by name without the gate's allow flag. Host integers and tables only, no float arithmetic, so cross-vendor identity is by construction and is not a claim; agreement with the reference is what was measured | NVIDIA and AMD runs of the same test (`docs/lanes/BRIEF_expose_tokenizer_2026-09-14.md` section 5), the `tokenizer` identity_break lane (section 3, for the harness's owner), packaging the binding and tables in the wheels. |
| Mamba 1 | Experimental | Three-vendor operator/backward evidence at `718495cd`; baseline and L64 pass and match AMD/NVIDIA at `395d9421` | Frozen AMD installed checks pass all modes; NVIDIA IDENTICAL passes, with non-IDENTICAL sequence accuracy work remaining. Python zero-state IDENTICAL backward is now exposed; exact installed-artifact and broader backward qualification remain open. |
| Mamba 2 | Experimental | Three-vendor backward certificate at `718495cd`; baseline, L257 and incoming state pass and match AMD/NVIDIA at `395d9421` | Newer NVIDIA/AMD source forward/state checks passed, including the AMD binding fix. Frozen AMD installed checks pass all modes and NVIDIA IDENTICAL passes. Python zero-state IDENTICAL backward is now exposed; broader fixtures and exact installed-artifact qualification remain open. |
| Mamba 3 | Experimental | Baseline and L65 pass AMD/NVIDIA at `395d9421`; public gradients and complete retained diagnostics match by bits | L65 uses the explicit [compositional arithmetic contract](mamba/BACKWARD_CERTIFICATION.md), with independent whole-forward public gradients. Current Apple installed checks pass all modes/interpreters and corrected native baseline passes; Apple L65 remains RED as described above. Later NVIDIA source passes FAST/IDENTICAL surface checks; the frozen failing wheel is not relabeled. Zero-state IDENTICAL Python backward is exposed; final Linux wheel and broader backward qualification remain open. |
| Transformer block | Experimental | Three-vendor operator card for an earlier fixture | Frozen AMD installed API checks pass. NVIDIA lifetime fix passes IDENTICAL; the subsequent full-FP32 patch passes FAST/DETERMINISTIC. The current Apple wheel passes the full surface in all fifteen interpreter/mode jobs. Final Linux qualification and an independent corpus API oracle remain pending. |
| UMAP | Published 0.6.0 alpha API: `fit`, `fit_transform`, `transform` and CSR graph storage | Original three-vendor fixtures; expanded six-case IDENTICAL inputs/embeddings and 876 native stage cells match AMD/NVIDIA at `d88c7883` | All six expanded quality cases pass in all modes on AMD/NVIDIA after the self-neighbor fix. The frozen Linux candidates pass all installed UMAP modes and match six IDENTICAL input/embedding fixtures. The published alpha wheel has inherited native provenance; combined CUDA/HIP wheel qualification and larger-scale coverage remain open. |
| Training primitives and checkpointing | Experimental | Local correctness gates | Cross-vendor public-surface qualification remains open. |

The [AMD k-NN layout record](bench/results/e1/2026-09-05_215006-mojolearn-e2-amd/README.md)
retains all four arms, correctness bytes, rotating timing rounds and the
comparison with earlier NVIDIA and Apple evidence. Its speedups are scoped
to those fixtures and devices, not a general dispatch or scalability claim.

The [weighted CTR slice](bench/results/e1/2026-09-05_235251-amd-catboost-fixed-partition/README.md)
passes on AMD, including the production leaf estimator on fixed occupied
zero-mass partitions at L2=0 and L2=3. This is focused native correctness;
the numeric single-permutation [ordered RMSE path](gbdt/ORDERED_RMSE.md) now
passes both GPUs at `6dd44ac5`, including fresh weighted-CTR checks. The
[comparison](bench/results/resume/2026-09-06-ordered-mamba-knn/cross-device-continued.json)
also matches all 5,440 new adversarial kNN records in all four flag arms.

The [installed comparison](bench/results/resume/2026-09-06-installed-gap-closure/installed-lane-comparison.json)
adds six UMAP fixtures (24 arrays) and the full OrderedRMSE model plus 72
prediction cells matching across AMD/NVIDIA at `eb835021`. Both complete
candidate dispositions remain visible; lane agreement does not approve the
failed NVIDIA candidate for release. GBDT/OrderedRMSE saves now persist the
effective numeric mode at `29a8c848`, tested with changed process defaults in
lightweight checks and a separate NVIDIA native wrapper overlay. That newer
wrapper is exposed in the 0.6.0 alpha Python overlay; that does not recertify inherited native binaries.

## What counts as certification

A cross-vendor result is accepted only when all of the following are recorded:

1. The same source state, fixture bytes, numeric profile, and card schema were
   used on each claimed vendor.
2. Each hardware leg actually ran and records device and toolchain provenance.
3. Stage tags, dtypes, element counts, and raw-bit hashes agree.
4. A sabotage or alternate-spelling arm demonstrates that the check detects the
   numerical mechanism it is intended to protect.
5. Refused configurations are reported as refusals, not passes.

`python -m mojolearn verify` is a useful local check against a shipped
reference card, but one local run cannot independently establish a
cross-vendor claim. See [verification](docs/VERIFY.md) and
[conformance bundles](docs/CONFORMANCE.md).

## Current priorities (2026-09-13)

- 0.8.5 is published (2026-09-14) with the `ExperimentalTwoLevelFeatureFreq` fix (DEVIATION 2710)
  and the AMD GEMM row; the next release carries whatever the lanes below merge.
- CPU training phase 1 (`docs/lanes/BRIEF_cpu_training_2026-09-13.md`): gemm-pinned first, then
  kde, holtwinters, lasso and elasticnet, svc (merged 2026-09-13, seven runners green), then
  agglomerative, et-clf, et-reg, iforest (phase 1b, 2026-09-14, IDENTICAL x4 on the Apple M4 host
  path, the seven-runner run owed); a lane passes only when the fourth column reads IDENTICAL on
  every cell. Still owed there: the isolation forest's GPU-side model export.
- DONE 2026-09-14: the 46-lane three columns rerun with every byte level language model cell
  filled (`bench/results/identity_break/2026-09-14_46-lanes/`).
- CPU inference for the classical lanes, per the costing in
  `docs/lanes/BRIEF_forest_host_inference_2026-09-13.md`: ols, ridge, tsvd, logistic and pca
  merged 2026-09-13 with three-vendor recordings 2026-09-14; kde, svc, the whitened pca and
  knn, knn-clf, knn-reg merged 2026-09-14 (Apple M4 measured, NVIDIA and AMD recordings owed);
  iforest not started.

The project-level sequencing lives in [ROADMAP.md](ROADMAP.md). Update this
page only from recorded evidence; do not turn planned or in-progress runs into
support claims.

## UMAP and Mamba closure (2026-09-05)

`UMAP.fit` and `fit_transform` expose the supported dense Euclidean 2D/3D
slice in the published macOS 0.5.0 wheel. Its installed API passed in all
three modes on Python 3.10–3.14. The downloaded PyPI artifact matched the
publication digest and passed additional API checks; see the
[post-publication record](bench/results/wheels/2026-09-05-umap-api/postpublish/results.json).
A refreshed Linux wheel and NVIDIA/AMD installed-artifact qualification remain pending.

At `718495cd`, Apple M4, NVIDIA RTX 4090, and AMD MI300X matched all 54
native Mamba backward gradient tensors across five cases and all 186 cells
in the named UMAP fixture. See the [three-vendor record](bench/results/e1g/2026-09-05_042552-amd-mamba/cross-device.json).
These source certificates do not certify other shapes or installed artifacts.
The Mamba3 correctness claim from that historical certificate is superseded:
its staged reference shared a missing scale/gamma chain-rule contribution.
The [corrected AMD/NVIDIA record](bench/results/resume/2026-09-05-next-certification/corrected-backward-cross-device.json)
passes all five baseline cases and matches 54 gradient tensors, while requiring
independent whole-forward gradients for every Mamba3 public leaf. Its long
profile was RED on intermediate checks despite matching public tensors. The
[September 6 certificate](bench/results/resume/2026-09-06-ordered-mamba-knn/README.md)
now passes both profiles on AMD/NVIDIA under the documented compositional
arithmetic policy, retaining all intermediate outputs and direct differences.
The later AMD allocation fix has its own successful source Python API rerun;
see the [AMD source qualification record](bench/results/e1/2026-09-05_134041-mojolearn-e2-amd/README.md).
That later binding evidence is separate from the original native certificate.

## UMAP 0.6.0 release candidate (historical, 2026-09-05)

0.6.0 was published on 2026-09-06 and the wheels since (0.7.0 through 0.8.4) supersede this
candidate; the section stays as the record of what that candidate's evidence covered.

The source candidate implements `fit`, `fit_transform` and `transform` with
dense Euclidean input and two- or three-dimensional output. Public fitting
now stores the fuzzy graph in CSR form using O(n_samples × n_neighbors)
space. This does not add sparse input support or approximate neighbors:
exact neighbor search still performs quadratic pair comparisons.

`transform` embeds new samples against the frozen fitted embedding. Private
training and embedding copies add O(n_samples × (n_features + n_components))
storage. Changes to parameters or numeric mode require refitting; changing
query batching can change results. Supervised targets and alternate metrics
or initialization remain unsupported.

| Evidence layer | Completed evidence | Still pending |
|---|---|---|
| Published 0.5.0 macOS artifact | Dense fit/fit_transform installed-wheel checks | Transform and CSR are not in this published artifact |
| Source transform and sparse native paths before public CSR integration | Named held-out transform embeddings match Apple, NVIDIA and AMD; separate sparse native gates passed | This earlier source does not certify the later public integration |
| Integrated public CSR fit/transform source | All three numeric modes passed API and held-out quality checks on Apple, NVIDIA and AMD; named IDENTICAL held-out layouts match | Broader shapes and metrics remain outside this evidence |
| 0.6.0 release candidate artifact | macOS candidate passed Python 3.10–3.14/mode smoke and clean Python 3.12 UMAP fit/transform/quality checks in all modes | Publication and Linux installed-artifact checks |

Evidence: [Apple public integration](bench/results/umap/2026-09-05-public-sparse/README.md),
[AMD integrated API results](bench/results/e1/2026-09-05_142553-mojolearn-e2-amd/diag/followup/results.tsv),
and [earlier NVIDIA transform and sparse qualification](bench/results/e1g/2026-09-05_095508-nvidia-mamba/README.md).
The latter records frozen source `72da212b`, whose public fit remained dense;
public CSR integration landed separately at `274ba7c0`. The later AMD
integration ran source `e2cfe1ac`. Keep these revisions and source hashes with
their results rather than relabeling them as one release certificate.

The original 186-cell UMAP certificate and 54-tensor Mamba backward
certificate above retain their original counts and scope. New transform
quality/identity checks are separate evidence, not additions to those totals.
The k-NN optimization remains experimental and is not enabled in normal
wheel builds.

Latest evidence: [integrated NVIDIA qualification and native public k-NN pricing](bench/results/e1g/2026-09-05_103918-nvidia-mamba/README.md),
and [exact macOS 0.6.0 candidate qualification](bench/results/wheels/2026-09-05-umap-060/README.md).
The flag-gated k-NN selector improved paired median native request times by
2.99x/5.99x/18.86x on the named NVIDIA 32/128/1000-query fixtures; these are
not cuML comparisons or a claim that every algorithm improved.

## September 6 bounded follow-ups and alpha exposure

The [public alpha guide](python/mojolearn/ALPHA_API.md) lists ordinary module
imports, existing optimizers/losses, fixed trainers and required native bindings.
Alpha exposure does not certify missing binaries or unfinished algorithms.
Ordered RMSE is not a ranking objective; see the
[tree feature inventory](docs/TREE_ALPHA_FEATURE_STATUS.md).

The [NVIDIA MLP campaign](bench/results/resume/2026-09-06-root-training-nvidia/README.md)
passed all 18 jobs at `8f6ed41`, including independent reference/edge checks,
16-step learning and complete same-device checkpoint continuation. The
[September 7 AMD MLP run](bench/results/resume/2026-09-07-root-mlp-amd/README.md)
also passed all 18 jobs; all 16 complete raw training steps match NVIDIA.
MLP Metal and foreign-vendor MLP resume remain open. The two-block,
34,944-parameter byte LM passed
all 12 single-vendor jobs on NVIDIA and AMD at `d921eade`; all 128 retained
steps, heldout bytes and final checkpoints match between these two runs.
Heldout loss fell 5.5413 → 2.8436. The final
[raw comparator](bench/results/resume/2026-09-06-root-byte-lm-cross-vendor/README.md)
now admits checkpoint continuation in both NVIDIA/AMD directions with effective
optimizer-state controls. Metal and step costs remain open.

The [NVIDIA digits experiment](bench/results/resume/2026-09-06-root-umap-nvidia/README.md)
measured real-data neighborhood trustworthiness and retention against
umap-learn, plus a separate matched cuML timing workload. All 15 jobs passed.
This closes that bounded real-data experiment, not arbitrary dataset or
cross-vendor coverage. The
[missing-vendor inventory](docs/MISSING_VENDOR_EVIDENCE_QUEUE.md) distinguishes
existing ARIMA fitted API passes and other smoke/timing results from the full
identity cells still owed.
