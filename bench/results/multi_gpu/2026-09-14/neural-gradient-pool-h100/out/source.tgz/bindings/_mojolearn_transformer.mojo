# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Andrew Hendel. Part of mojolearn, https://doi.org/10.5281/zenodo.22068632
"""CPython boundary for the transformer (Llama-shaped decoder) block lane.

A FIFTEENTH extension module, and a separate one on purpose, for the
reason `bindings/_mojolearn_estimators.mojo`'s header gives: an
independently changing binding must not become a merge point. This file
gives the certified transformer block (profile
`mojolearn.identical.transformer.fp32.v1`, forward clause (a) and clause
(d) recorded on THREE columns 2026-08-28, the same card bytes on Apple,
NVIDIA and AMD -- `transformer/README.md`'s status block) its first
Python symbol: before it the lane exported nothing an outside consumer
could import.

THE BINDING CALLS THE CERTIFIED ENTRY POINT AND NOTHING ELSE. Every call
below goes through `llama_decoder_layer_forward`
(`transformer/impl/llama/modeling_llama.mojo`) --
the SAME function `transformer/checks/transformer_check.mojo` gates
(through its planted twin, with the plant OFF). NO arithmetic is
respelled in this file: a binding-side copy of any seam would be a
second spelling of a pinned rounding, which is the drift the whole lane
exists to forbid. The decode entry point is the contract's own
construction -- the block forward at `l = 1` with the KV cache carried
and `pos0 = cached_tokens` (contract section 7.2, ONE SPELLING FOR BOTH
PATHS) -- with no arithmetic of its own.

THE TWO-LIST ABI IS DEVIATION 791'S, ADOPTED, NOT RE-DECIDED. Each entry
point takes exactly TWO Python lists, `addrs` (every NumPy buffer
address, in an exact order written in each docstring and mirrored at the
`_transformer_impl.py` call site) and `params` (the scalars), because
`PythonModuleBuilder.def_function` stops elaborating above roughly nine
arguments (MEASURED 2026-09-01, `bindings/_mojolearn_gp.mojo`'s header)
and `transformer_forward` carries thirteen addresses. Every array whose
address goes into `addrs` MUST be bound to a Python local for the
duration of the call: an address inside a list keeps nothing alive
(`python/mojolearn/_arrays.py`).

DEVIATION 795 -- THE TRANSFORMER SURFACE'S OWN DEPARTURES, IN ONE BLOCK.

  (i) A POINTER-ABI SURFACE WHERE UPSTREAM HAS ONLY TORCH MODULES.
  Upstream's only Python face for this block is `LlamaDecoderLayer`, an
  `nn.Module` over torch tensors, autograd and a `DynamicCache` object.
  This surface is bare float32 buffer addresses plus packed scalars into
  the certified Mojo entry point, torch-free by design (the package's
  standing shape, mamba DEVIATIONS 791/792 applied to this lane): the
  consumer's job is cross-checking bits, and a torch dependency on the
  checking side would put the reference's own arithmetic inside the
  instrument.

  (ii) THE STATE IS THE KV CACHE, CROSSING AS TWO CALLER-OWNED
  FULL-CAPACITY BUFFERS PACKED AT THE USED STRIDE, PLUS ONE INTEGER.
  DEVIATION 792's caller-owned-buffers rule extends here with a twist
  none of the mamba states has: `LlamaKVCache` is PACKED at stride `s`
  (the USED length), not at stride `s_max` (DEVIATION 1022 -- the stage
  card records `[B, n_kv, S, head_dim]` and the packed used region IS
  that array), so the caller's `k_cache`/`v_cache` buffers are FLAT
  capacity buffers of `B * n_kv * max_tokens * head_dim` floats whose
  first `B * n_kv * cached_tokens * head_dim` elements are the cache at
  stride `cached_tokens`. Both are READ at entry and WRITTEN BACK whole
  before return, so the caller's bytes round-trip exactly; zeros in,
  with `cached_tokens = 0`, is a fresh sequence. `cached_tokens` is the
  one integer piece of state and crosses as a params scalar IN and as
  the return value OUT (mamba2 `buf_len`'s shape). `max_tokens` (the
  capacity, `s_max`) is a params scalar too, because the packing stride
  and every refusal about growth are functions of it.

  (iii) THE ROTARY TABLE AND THE ATTENTION SCALE ARE REBUILT PER CALL
  FROM FROZEN CONSTANTS, NEVER PARAMETERS. rms eps (1e-6, bits
  0x358637BD) and rope theta (10000.0, bits 0x461C4000) are contract
  section 3 FROZEN constants, imported from
  `transformer/checks/transformer_fixture.mojo` (the fixture is their
  bit authority); changing either is a v2 profile, not a knob. The
  rotary table is `LlamaRopeTable(ctx, dims, ROPE_THETA, max_tokens)`,
  computed on-device per call exactly as the lane's own check driver
  builds it -- a caching layer would be state this surface deliberately
  does not hold (upstream computes it once per config; recomputing is
  bit-inert because S6-S8 are pure functions of (theta, head_dim,
  position)).

  (iv) WHAT IS REFUSED HERE, AND WHAT GOES DOWN UNJUDGED (DEVIATION
  793's split, applied). Refused HERE: a null address, an
  `addrs`/`params` list of the wrong length, and a `cached_tokens`
  outside `[0, max_tokens]` -- each means the two sides of THIS boundary
  disagree and no lane refusal exists for it. Everything else goes down
  UNJUDGED so the lane's own refusals stay reachable from Python: the
  five divisibility rules are `LlamaDims.validate`'s (refused by name in
  Mojo), capacity growth past `max_tokens` and the 8192 absolute-
  position ceiling (DEVIATION 812) are `llama_decoder_layer_forward`'s
  and `LlamaKVCache`'s, and non-finite inputs are refused BY NAME on the
  device path (`llama_refuse_bad_call` for x/rope/cache per call;
  weights once at upload, DEVIATION 1875). The dtype refusals (float32
  ONLY) live in `_transformer_impl.py`, because dtype is a NumPy
  property this side cannot see.

  (v) BLAST RADIUS. This file, `python/mojolearn/_transformer_impl.py`,
  `python/mojolearn/transformer.py` and
  `python/mojolearn/tests/test_transformer_surface.py`. The lane's
  kernels, oracle, gates and contract are untouched. Since 2026-09-09
  the BACKWARD (`transformer/checks/transformer_backward.mojo`) is on
  this surface too, as `transformer_backward`, IDENTICAL tier only, and
  `window` (sliding-window causal attention with a ring KV cache) is
  the tenth forward scalar.

THE THREE-TIER SEMANTICS ARE THE BUILD'S, NOT THIS FILE'S. The numeric
mode (fast / deterministic / identical) is a compile-time define
(`checks/numerics.mojo`), one binary per tier under
`python/mojolearn/[<tier>/]_mojolearn_transformer.so`;
`transformer_numeric_mode` below is the read-back
`_transformer_impl.py` cross-checks so a wrong-arm measurement cannot be
correctly labelled by accident.

THE GIL is released around every device call, and nothing inside a
`GILReleased` block touches a `PythonObject`.

RUN LEDGER. First compiled 2026-09-02 on the Apple M4 (all three
tiers); the window and backward entry points first compiled and ran
on an NVIDIA L40S 2026-09-09 (identical tier), Apple RUN OWED. Build:
`bash bindings/build_transformer.sh` (per tier via
MOJOLEARN_NUMERIC_MODE); gate:
`cd python && python3 -m mojolearn.tests.test_transformer_surface`.
"""

# DEVIATION 2486: shared byte-preserving host copies.
from bindings.hostptr import f32_ptr, read_f32, copy_f32
from std.os import abort
from std.python import Python, PythonObject
from std.python._cpython import GILReleased
from std.python.bindings import PythonModuleBuilder

from max.gpu.host import DeviceBuffer, DeviceContext
from std.memory import memcpy
from std.os import getenv
from std.time import perf_counter_ns
from std.sys.compile import is_defined
from checks.kernel_matrix import COLUMN_NVIDIA, TARGET_COLUMN

from core.identity_trace import IdentityTrace
from checks.numerics import GLOBAL_NUMERIC_MODE, NUMERIC_IDENTICAL
from checks.vendor import COMPILED_VENDOR
from gemm.checks.gemm_backward import ANY_BWD_SABOTAGE as GEMM_ANY_BWD_SABOTAGE
from gemm.checks.gemm_identical import ANY_SABOTAGE as GEMM_ANY_SABOTAGE

# The two FROZEN arithmetic constants, from their bit authority
# (`transformer_fixture.mojo` cross-checks both against their hex bits in
# `profile_constants_are_intact`). The binding importing from
# `transformer/checks/` is the mamba binding's own precedent (it imports
# `mamba_fixture`'s constants); it is the IMPL file that may not
# (`modeling_llama.mojo`'s "no fixture type crosses this boundary").
from transformer.checks.transformer_fixture import RMS_EPS, ROPE_THETA

# `_upload`/`_download` by their underscore names is DEVIATION 1112's
# settled pattern (`transformer_check.mojo` imports the same pair).
from transformer.impl.llama.fused_attention import (
    fused_forward_supported_head_dim,
)
from transformer.impl.llama.modeling_llama import (
    ATTN_PATH_EAGER,
    BLOCK_ANY_SABOTAGE,
    PLANT_AT_NONE,
    attention_path_choice,
    LlamaDeviceStages,
    LlamaDeviceWeights,
    LlamaDims,
    LlamaKVCache,
    LlamaRopeTable,
    _download,
    _upload,
    llama_decoder_layer_forward,
)
from transformer.checks.transformer_backward import (
    BWD_ANY_SABOTAGE,
    LlamaBackwardStages,
    llama_decoder_layer_backward,
)


def _f32_ptr(addr: Int) raises -> MutPointer[Float32, MutUntrackedOrigin]:
    return f32_ptr(addr)


def _read_f32(addr: Int, n: Int) raises -> List[Float32]:
    return read_f32(addr, n)


def _write_f32(addr: Int, values: List[Float32]) raises:
    copy_f32(values.unsafe_ptr(), _f32_ptr(addr), len(values))


def _upload_addr(
    ctx: DeviceContext, addr: Int, n: Int
) raises -> DeviceBuffer[DType.float32]:
    """Copy a live caller buffer, synchronizing before its borrow ends.

    IDENTICAL uses DeviceContext's ordinary host-pointer transfer directly.
    Other modes and the diagnostic legacy flag retain pinned staging.
    """
    var p = _f32_ptr(addr)
    var n_buf = n
    if n_buf < 1:
        n_buf = 1
    var dev = ctx.enqueue_create_buffer[DType.float32](n_buf)
    comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL and not is_defined["MOJOLEARN_TRANSFORMER_LEGACY_CALLER_TRANSFER"]():
        if n > 0:
            ctx.enqueue_copy(dst_buf=dev, src_ptr=p)
            ctx.synchronize()
            return dev^
    var host = ctx.enqueue_create_host_buffer[DType.float32](n_buf)
    ctx.synchronize()
    if n > 0:
        memcpy(dest=host.unsafe_ptr(), src=p, count=n)
    ctx.enqueue_copy(dst_buf=dev, src_ptr=host.unsafe_ptr())
    ctx.synchronize()
    _ = host^
    return dev^


def _download_addr(
    ctx: DeviceContext, mut buf: DeviceBuffer[DType.float32], n: Int, addr: Int
) raises:
    """Copy the first `n` elements into a live caller buffer.

    The synchronized IDENTICAL path avoids a pinned staging allocation and
    its memcpy. Caller arrays remain owned by the Python frame throughout.
    """
    var p = _f32_ptr(addr)
    comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL and not is_defined["MOJOLEARN_TRANSFORMER_LEGACY_CALLER_TRANSFER"]():
        if n == len(buf):
            ctx.enqueue_copy(dst_ptr=p, src_buf=buf)
        else:
            var direct_view = buf.create_sub_buffer[DType.float32](0, n)
            ctx.enqueue_copy(dst_ptr=p, src_buf=direct_view)
        ctx.synchronize()
        return
    var host = ctx.enqueue_create_host_buffer[DType.float32](n)
    ctx.synchronize()
    if n == len(buf):
        ctx.enqueue_copy(dst_ptr=host.unsafe_ptr(), src_buf=buf)
    else:
        var view = buf.create_sub_buffer[DType.float32](0, n)
        ctx.enqueue_copy(dst_ptr=host.unsafe_ptr(), src_buf=view)
    ctx.synchronize()
    memcpy(dest=p, src=host.unsafe_ptr(), count=n)
    _ = host^


def _btick(on: Bool, mut t: Int, name: String):
    if not on:
        return
    var now = Int(perf_counter_ns())
    print(
        "timing " + name + " " + String(Float64(now - t) / 1000000.0) + " ms"
    )
    t = now


def transformer_numeric_mode_binding() raises -> PythonObject:
    """THE BUILD'S TIER, as the `NUMERIC_*` code itself: 0 FAST, 1
    IDENTICAL, 2 DETERMINISTIC. The same shape as `mamba_numeric_mode`
    and for the same reason: `_transformer_impl.py` reads it once and
    refuses to run if the binary it loaded disagrees with the mode the
    package asked for."""
    return PythonObject(GLOBAL_NUMERIC_MODE)


def transformer_vendor_binding() raises -> PythonObject:
    """'metal', 'cuda', 'hip' or 'none' -- the accelerator API this
    binary was compiled for, folded in from `checks/vendor.mojo`. The
    answer comes from the binary that actually loaded, never from the
    directory it sat in."""
    return PythonObject(String(COMPILED_VENDOR))


# ===========================================================================
# The block: profile mojolearn.identical.transformer.fp32.v1
# ===========================================================================


def transformer_lean_stages(hd: Int) -> Bool:
    """Whether this call may skip the `[B, n_heads, L, S]` attention stage
    allocations: the fused attention path will be attempted (IDENTICAL
    build, supported head_dim, not forced eager) and the trace is off here
    always. The eager fallback grows the buffers on demand."""
    comptime if GLOBAL_NUMERIC_MODE != NUMERIC_IDENTICAL:
        return False
    if not fused_forward_supported_head_dim(hd):
        return False
    return attention_path_choice(PLANT_AT_NONE) != ATTN_PATH_EAGER


def _load_transformer_weights(
    ctx: DeviceContext, dims: LlamaDims, a: List[Int],
) raises -> LlamaDeviceWeights:
    """One-call uploads; IDENTICAL skips intermediate host weight Lists.
    Mutable caller arrays are reread and refused on every call as before.
    """
    var dm = dims.d_model
    var qw = dims.q_width()
    var kw = dims.kv_width()
    var it = dims.intermediate
    comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL and not is_defined["MOJOLEARN_TRANSFORMER_LEGACY_WEIGHT_COPY"]():
        return LlamaDeviceWeights(
            ctx, dims, RMS_EPS,
            _upload_addr(ctx, a[1], dm),
            _upload_addr(ctx, a[2], dm),
            _upload_addr(ctx, a[3], qw * dm),
            _upload_addr(ctx, a[4], kw * dm),
            _upload_addr(ctx, a[5], kw * dm),
            _upload_addr(ctx, a[6], dm * qw),
            _upload_addr(ctx, a[7], it * dm),
            _upload_addr(ctx, a[8], it * dm),
            _upload_addr(ctx, a[9], dm * it),
        )
    else:
        return LlamaDeviceWeights(
            ctx, dims, RMS_EPS,
            _read_f32(a[1], dm),
            _read_f32(a[2], dm),
            _read_f32(a[3], qw * dm),
            _read_f32(a[4], kw * dm),
            _read_f32(a[5], kw * dm),
            _read_f32(a[6], dm * qw),
            _read_f32(a[7], it * dm),
            _read_f32(a[8], it * dm),
            _read_f32(a[9], dm * it),
        )


def _transformer_run[discard_cache: Bool = False](
    a: List[Int],
    b: Int,
    l: Int,
    dm: Int,
    nh: Int,
    nkv: Int,
    hd: Int,
    it: Int,
    smax: Int,
    s0: Int,
    window: Int,
) raises -> Int:
    """The GIL-free half of the two entry points: everything after the
    `PythonObject`s have been read. Builds the device weights, uploads
    the caller's cache state, runs THE certified entry point once, and
    writes the output and the post-call state back into the caller's
    buffers. Returns the post-call `cached_tokens` (DEVIATION 795(ii):
    the one integer piece of the state).

    `[[mojo-buffer-freed-at-last-use]]`: every device buffer below is
    still alive when `llama_decoder_layer_forward` returns because that
    function synchronizes before it does, and the explicit transfers at
    the end hold them past the last download anyway."""
    # LlamaDims.validate REFUSES the five divisibility rules by name
    # (d_model == n_heads*head_dim, n_heads % n_kv == 0, head_dim even,
    # positivity) -- reached BEFORE any buffer size below is computed
    # from them, which is why nothing here pre-judges the shape.
    var dims = LlamaDims(dm, nh, nkv, hd, it)
    dims.validate()
    if s0 < 0 or s0 > smax:
        raise Error(
            String("transformer: cached_tokens must be in [0, ")
            + String(smax)
            + "] (the cache capacity, max_tokens), got "
            + String(s0)
            + "; the two sides of this boundary disagree about the state"
        )

    if window < 0:
        raise Error("transformer: window must be >= 0 (0 = full causal)")
    # The caller's cache buffers: `smax` slots for the linear cache, a ring
    # of `window` slots per (batch, kv head) under a sliding window.
    var cap = smax
    if window > 0:
        cap = window
    var cache_n = b * nkv * cap * hd

    var ctx = DeviceContext()
    var ton = String(getenv("MOJOLEARN_TRANSFORMER_TIMING")) != ""
    var tk = Int(perf_counter_ns())
    # Host weights THROUGH the lane's own struct (its length table is the
    # upstream shape authority, and its constructor is where the weights
    # are refused non-finite ONCE, DEVIATION 1875); values arrive as
    # given bits, unjudged.
    var w = _load_transformer_weights(ctx, dims, a)
    # The caller's cache over the fresh zeros. LlamaKVCache's own
    # constructor refuses b <= 0, smax <= 0 and smax > 8192 (the
    # absolute-position ceiling, DEVIATION 812) BY NAME before the
    # uploads below. Zeros in with s0 == 0 IS a fresh sequence; anything
    # else is a carried one, packed at stride s0 (DEVIATION 795(ii)).
    _btick(ton, tk, "surface.weights_up")
    var kv = LlamaKVCache(ctx, b, dims, smax, window)
    comptime if not discard_cache:
        kv.k = _upload_addr(ctx, a[10], cache_n)
        kv.v = _upload_addr(ctx, a[11], cache_n)
    kv.s = s0
    # Per call, from the FROZEN theta (DEVIATION 795(iii)). p_max is the
    # cache capacity: pos0 + l <= kv.s_max <= p_max holds for every legal
    # call, so the table always covers the absolute positions used.
    var rope = LlamaRopeTable(ctx, dims, ROPE_THETA, smax)
    var stages = LlamaDeviceStages(
        ctx, b, l, smax, dims, window, lean=transformer_lean_stages(hd)
    )
    var dx = _upload_addr(ctx, a[0], b * l * dm)
    _btick(ton, tk, "surface.cache_stages_x_up")

    var trace = IdentityTrace.disabled()
    # pos0 = s0: DEVIATION 1028 (cache slot j IS absolute position j)
    # refuses any other value, and this surface has no other value to
    # offer. Prefill, chunked continuation and decode are all this one
    # call; capacity growth past smax is refused by name downstream.
    llama_decoder_layer_forward(
        ctx, stages, kv, rope, w, dx, b, l, s0, trace, String("py")
    )

    # The block output is residual2 (contract section 2's
    # `residual2 + mlp(...)`, stage `residual2.out`), and the cache goes
    # back to its owner whole -- the full capacity buffer, so the bytes
    # round-trip exactly whatever the used stride is.
    _btick(ton, tk, "surface.forward")
    _download_addr(ctx, stages.residual2, b * l * dm, a[12])
    comptime if not discard_cache:
        _download_addr(ctx, kv.k, cache_n, a[10])
        _download_addr(ctx, kv.v, cache_n, a[11])
    _btick(ton, tk, "surface.outputs_down")
    var out_len = kv.s
    _ = w^
    _ = kv^
    _ = rope^
    _ = stages^
    _ = dx^
    # Keep the context alive until every device allocation is destroyed.
    _ = ctx^
    return out_len


def _transformer_addrs(addrs: PythonObject, what: String) raises -> List[Int]:
    if len(addrs) != 13:
        raise Error(
            what
            + ": addrs must contain 13 addresses (x,"
            " input_layernorm.weight, post_attention_layernorm.weight,"
            " q_proj.weight, k_proj.weight, v_proj.weight, o_proj.weight,"
            " gate_proj.weight, up_proj.weight, down_proj.weight, k_cache,"
            " v_cache, y_out), got "
            + String(len(addrs))
        )
    var a = List[Int]()
    for i in range(13):
        a.append(Int(py=addrs[i]))
    return a^


def transformer_forward_fresh_binding(
    addrs: PythonObject, params: PythonObject,
) raises -> PythonObject:
    """Stateless prefill: original zero device cache, only y is returned.

    Eleven pointers: x, nine weights, y. Eight scalars: B, L, d_model,
    n_heads, n_kv_heads, head_dim, intermediate, window. Capacity remains
    L (or a window-sized ring), exactly as Python allocate_state(B, L).
    The zero sentinel cache pointers never reach a transfer in this arm.
    """
    if len(addrs) != 11 or len(params) != 8:
        raise Error("transformer_forward_fresh: expected 11 addresses and 8 scalars")
    var a = List[Int]()
    for i in range(10):
        var address = Int(py=addrs[i])
        if address == 0:
            raise Error("transformer_forward_fresh: null buffer address at slot " + String(i))
        a.append(address)
    a.append(0)
    a.append(0)
    var y = Int(py=addrs[10])
    if y == 0:
        raise Error("transformer_forward_fresh: null output address")
    a.append(y)
    var b = Int(py=params[0])
    var l = Int(py=params[1])
    var dm = Int(py=params[2])
    var nh = Int(py=params[3])
    var nkv = Int(py=params[4])
    var hd = Int(py=params[5])
    var it = Int(py=params[6])
    var window = Int(py=params[7])
    if b <= 0 or l <= 0:
        raise Error("transformer_forward_fresh: B and L must be positive")
    var out_len = 0
    with GILReleased(Python()):
        out_len = _transformer_run[True](a, b, l, dm, nh, nkv, hd, it, l, 0, window)
    return PythonObject(out_len)


def transformer_forward_binding(
    addrs: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """One transformer block call: prefill from the state the caller
    hands in -- fresh (zero caches, cached_tokens 0) or resumed (a
    carried cache: chunked-prefill continuation) -- any B and L that fit
    the capacity. Returns the post-call `cached_tokens`.

    `addrs` is the THIRTEEN buffer addresses, in this exact order
    (mirrored in `python/mojolearn/_transformer_impl.py`; QW =
    n_heads*head_dim = d_model, KW = n_kv_heads*head_dim, IT =
    intermediate_size, SMAX = max_tokens):

        0  x                                B * L * d_model float32, read
        1  input_layernorm.weight           d_model, read
        2  post_attention_layernorm.weight  d_model, read
        3  q_proj.weight                    QW * d_model, read (torch
                                             [out, in]; OP_NT reads it)
        4  k_proj.weight                    KW * d_model, read
        5  v_proj.weight                    KW * d_model, read
        6  o_proj.weight                    d_model * QW, read
        7  gate_proj.weight                 IT * d_model, read
        8  up_proj.weight                   IT * d_model, read
        9  down_proj.weight                 d_model * IT, read
       10  k_cache                          B * n_kv * SMAX * head_dim,
                                             READ AND WRITTEN (state;
                                             PACKED at stride
                                             cached_tokens, DEVIATION
                                             795(ii))
       11  v_cache                          B * n_kv * SMAX * head_dim,
                                             READ AND WRITTEN (state)
       12  y_out                            B * L * d_model, WRITTEN (the
                                             block output, both residual
                                             adds included -- contract
                                             section 2)

    `params` is, in this exact order:

        0  B
        1  L
        2  d_model        must equal n_heads*head_dim; refused otherwise
                           BY NAME in Mojo (LlamaDims.validate)
        3  n_heads
        4  n_kv_heads     n_heads % n_kv_heads must be 0 (GQA admitted,
                           contract DEVIATION 813)
        5  head_dim       must be even (RoPE pairs halves)
        6  intermediate   intermediate_size, > 0
        7  max_tokens     the cache capacity s_max; cached_tokens + L
                           past it, and any value over 8192 (DEVIATION
                           812's ceiling), are refused by name in Mojo
        8  cached_tokens  the carried cache's used length; 0 for a
                           fresh sequence
        9  window         0 for full causal attention; W > 0 for sliding-
                           window causal attention (query p sees keys
                           [max(0, p-W+1), p]) with k_cache/v_cache a
                           RING of B * n_kv * W * head_dim floats, slot
                           = position % W

    Profile constants (rms eps 1e-6, rope theta 10000.0, eager attention,
    the causal mask value, no biases, silu -- contract section 3) are NOT
    parameters: changing one is a v2 profile, not a knob. There is no
    bias address and no dropout: the profile REFUSES both by absence."""
    var a = _transformer_addrs(addrs, String("transformer_forward"))
    if len(params) != 10:
        raise Error(
            "transformer_forward: params must contain 10 values (B, L,"
            " d_model, n_heads, n_kv_heads, head_dim, intermediate,"
            " max_tokens, cached_tokens, window), got "
            + String(len(params))
        )
    var b = Int(py=params[0])
    var l = Int(py=params[1])
    var dm = Int(py=params[2])
    var nh = Int(py=params[3])
    var nkv = Int(py=params[4])
    var hd = Int(py=params[5])
    var it = Int(py=params[6])
    var smax = Int(py=params[7])
    var s0 = Int(py=params[8])
    var window = Int(py=params[9])
    var out_len = 0
    with GILReleased(Python()):
        out_len = _transformer_run(
            a, b, l, dm, nh, nkv, hd, it, smax, s0, window
        )
    return PythonObject(out_len)


def transformer_decode_step_binding(
    addrs: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """One decode token: the profile's spelling -- the block forward at
    L = 1 with the KV cache carried and `pos0 = cached_tokens` (contract
    section 7.2: ONE SPELLING FOR BOTH PATHS is what makes clause (d),
    decode == prefill bitwise, a theorem the gate verifies rather than a
    coincidence it hopes for), with NO arithmetic of its own. There is
    deliberately no second entry path to drift.

    `addrs`: the same THIRTEEN as `transformer_forward` with L = 1
    shapes (x and y_out are B * d_model). `params`: 0 B, 1 d_model,
    2 n_heads, 3 n_kv_heads, 4 head_dim, 5 intermediate, 6 max_tokens,
    7 cached_tokens, 8 window. Returns the post-call cached_tokens."""
    var a = _transformer_addrs(addrs, String("transformer_decode_step"))
    if len(params) != 9:
        raise Error(
            "transformer_decode_step: params must contain 9 values (B,"
            " d_model, n_heads, n_kv_heads, head_dim, intermediate,"
            " max_tokens, cached_tokens, window), got "
            + String(len(params))
        )
    var b = Int(py=params[0])
    var dm = Int(py=params[1])
    var nh = Int(py=params[2])
    var nkv = Int(py=params[3])
    var hd = Int(py=params[4])
    var it = Int(py=params[5])
    var smax = Int(py=params[6])
    var s0 = Int(py=params[7])
    var window = Int(py=params[8])
    var out_len = 0
    with GILReleased(Python()):
        out_len = _transformer_run(
            a, b, 1, dm, nh, nkv, hd, it, smax, s0, window
        )
    return PythonObject(out_len)


# ===========================================================================
# The block backward: a zero-state prefill's VJP, IDENTICAL tier only.
# ===========================================================================


def _transformer_backward_run(
    a: List[Int],
    b: Int,
    l: Int,
    dm: Int,
    nh: Int,
    nkv: Int,
    hd: Int,
    it: Int,
    window: Int,
) raises:
    """Forward from a zero cache at positions [0, L), then
    `llama_decoder_layer_backward` on the saved stages; the ten gradients
    are written into the caller's buffers. The forward is recomputed here
    rather than taken from a previous call because the lane's backward
    reads the forward's DEVICE stages (`LlamaDeviceStages`) and those are
    not part of the Python-visible state."""
    var dims = LlamaDims(dm, nh, nkv, hd, it)
    dims.validate()
    if window < 0:
        raise Error("transformer backward: window must be >= 0")
    var qw = dims.q_width()
    var kw = dims.kv_width()
    var m = b * l
    var ctx = DeviceContext()
    var ton = String(getenv("MOJOLEARN_TRANSFORMER_TIMING")) != ""
    var tk = Int(perf_counter_ns())
    var w = _load_transformer_weights(ctx, dims, a)
    var kv = LlamaKVCache(ctx, b, dims, l, window)
    var rope = LlamaRopeTable(ctx, dims, ROPE_THETA, l)
    var lean = transformer_lean_stages(hd)
    var stages = LlamaDeviceStages(ctx, b, l, l, dims, window, lean=lean)
    var dx = _upload_addr(ctx, a[0], m * dm)
    _btick(ton, tk, "surface.inputs_up")
    var off = IdentityTrace.disabled()
    llama_decoder_layer_forward(
        ctx, stages, kv, rope, w, dx, b, l, 0, off, String("pyf")
    )
    _btick(ton, tk, "surface.forward")
    var bst = LlamaBackwardStages(ctx, b, l, l, dims, lean=lean)
    var d_out = _read_f32(a[10], m * dm)
    var offb = IdentityTrace.disabled()
    llama_decoder_layer_backward(
        ctx, bst, stages, w, rope.cos, rope.sin, dx, d_out, b, l, 0,
        offb, String("pyb"),
    )
    _btick(ton, tk, "surface.backward")
    _download_addr(ctx, bst.d_x, m * dm, a[11])
    _download_addr(ctx, bst.dw_norm1, dm, a[12])
    _download_addr(ctx, bst.dw_norm2, dm, a[13])
    _download_addr(ctx, bst.dw_q, qw * dm, a[14])
    _download_addr(ctx, bst.dw_k, kw * dm, a[15])
    _download_addr(ctx, bst.dw_v, kw * dm, a[16])
    _download_addr(ctx, bst.dw_o, dm * qw, a[17])
    _download_addr(ctx, bst.dw_gate, it * dm, a[18])
    _download_addr(ctx, bst.dw_up, it * dm, a[19])
    _download_addr(ctx, bst.dw_down, dm * it, a[20])
    _btick(ton, tk, "surface.outputs_down")
    _ = bst^
    _ = stages^
    _ = w^
    _ = kv^
    _ = rope^
    _ = dx^
    _ = ctx^


def transformer_backward_binding(
    addrs: PythonObject,
    params: PythonObject,
) raises -> PythonObject:
    """The zero-state prefill VJP of one block call, IDENTICAL tier only.

    `addrs` is TWENTY-ONE addresses: 0 x (B*L*d_model), 1-9 the nine
    weights in `transformer_forward`'s order, 10 grad_output (B*L*d_model),
    11 grad_x (B*L*d_model, WRITTEN), 12-20 the nine weight gradients in
    the same order and shapes as the weights (WRITTEN). `params`: 0 B,
    1 L, 2 d_model, 3 n_heads, 4 n_kv_heads, 5 head_dim, 6 intermediate,
    7 window. The activation gradients are the lane's pinned chains; every
    weight gradient is a sum over this call's B*L tokens."""
    comptime if GLOBAL_NUMERIC_MODE != NUMERIC_IDENTICAL:
        raise Error(
            "transformer backward: only the IDENTICAL zero-state prefill"
            " backward is implemented"
        )
    if len(addrs) != 21 or len(params) != 8:
        raise Error(
            "transformer backward: expected 21 addresses and 8 scalars (B,"
            " L, d_model, n_heads, n_kv_heads, head_dim, intermediate,"
            " window)"
        )
    var a = List[Int]()
    for i in range(21):
        var address = Int(py=addrs[i])
        if address == 0:
            raise Error(
                "transformer backward: null buffer address at slot "
                + String(i)
            )
        a.append(address)
    var b = Int(py=params[0])
    var l = Int(py=params[1])
    var dm = Int(py=params[2])
    var nh = Int(py=params[3])
    var nkv = Int(py=params[4])
    var hd = Int(py=params[5])
    var it = Int(py=params[6])
    var window = Int(py=params[7])
    if b <= 0 or l <= 0 or dm <= 0:
        raise Error("transformer backward: B, L and d_model must be positive")
    with GILReleased(Python()):
        _transformer_backward_run(a, b, l, dm, nh, nkv, hd, it, window)
    return PythonObject(0)


@export
def PyInit__mojolearn_transformer() abi("C") -> PythonObject:
    # IDENTICAL-ONLY (2026-09-10). The FAST and DETERMINISTIC builds of this
    # lane were never a faster path: every fused kernel here is gated on
    # `GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL`, so the lower tiers fell back
    # to the unfused arms and ran SLOWER than the default. They are no longer
    # built (bindings/build_transformer.sh refuses) and the lane no longer carries
    # the fallbacks. Refuse to exist rather than answer under a tier label
    # whose arithmetic is gone.
    comptime if GLOBAL_NUMERIC_MODE != NUMERIC_IDENTICAL:
        abort(
            String(
                "_mojolearn_transformer: refusing to initialize -- this lane supports only"
                " the IDENTICAL tier. Rebuild with"
                " MOJOLEARN_NUMERIC_MODE=identical bash bindings/build_transformer.sh"
            )
        )
    # DEVIATION 793's last clause, applied here: a sabotage arm exists to
    # be run by a gate and to FAIL; a Python surface that quietly served
    # one would be a wrong answer wearing a green label. Refuse to exist
    # instead.
    comptime if (
        BLOCK_ANY_SABOTAGE
        or BWD_ANY_SABOTAGE
        or GEMM_ANY_BWD_SABOTAGE
        or GEMM_ANY_SABOTAGE
    ):
        abort(
            String(
                "_mojolearn_transformer: refusing to initialize -- a"
                " sabotage arm is compiled into this binary. Sabotage"
                " defines are for the lane gates (transformer/checks/),"
                " never for a shipped binding; rebuild with"
                " bash bindings/build_transformer.sh and no"
                " MOJOLEARN_TRANSFORMER_SABOTAGE_*,"
                " MOJOLEARN_BATCHINV_SABOTAGE_* or GEMM sabotage define."
            )
        )
    try:
        var m = PythonModuleBuilder("_mojolearn_transformer")
        m.def_function[transformer_vendor_binding]("transformer_vendor")
        m.def_function[transformer_numeric_mode_binding](
            "transformer_numeric_mode"
        )
        m.def_function[transformer_forward_binding]("transformer_forward")
        # NVIDIA's full public A/B gate admits discarded-cache prefill.
        # Apple retains its prior default until separately priced; the explicit
        # force flag remains available for its completed arithmetic gate.
        comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL and (is_defined["MOJOLEARN_TRANSFORMER_FRESH_PREFILL"]() or (TARGET_COLUMN == COLUMN_NVIDIA and not is_defined["MOJOLEARN_TRANSFORMER_LEGACY_FRESH_PREFILL"]())):
            m.def_function[transformer_forward_fresh_binding]("transformer_forward_fresh")
        m.def_function[transformer_decode_step_binding](
            "transformer_decode_step"
        )
        m.def_function[transformer_backward_binding]("transformer_backward")
        return m.finalize()
    except e:
        abort(String("failed to create _mojolearn_transformer: ", e))
