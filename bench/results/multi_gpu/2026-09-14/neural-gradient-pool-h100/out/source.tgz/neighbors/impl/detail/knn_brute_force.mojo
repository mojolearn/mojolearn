# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Andrew Hendel. Part of mojolearn, https://doi.org/10.5281/zenodo.22068632
"""Brute-force k-nearest-neighbors: their DISPATCH, and their FALLBACK.

FOLLOWS `cuvs/src/neighbors/detail/knn_brute_force.cuh` at cuVS `94c2819`:
`brute_force_knn_impl`'s dispatch (`:443-447`) and `tiled_brute_force_knn`
(`:69-340`). Partial.

WHAT THEIR DISPATCH DOES, WHICH IS NOT WHAT THIS FILE USED TO SAY
------------------------------------------------------------------
`brute_force_knn_impl` chooses between two entirely different algorithms at
`:443`:

    if (k <= 64 && rowMajorQuery == rowMajorIndex && rowMajorQuery == true &&
        (metric == L2Unexpanded || L2SqrtUnexpanded ||
         L2Expanded  || L2SqrtExpanded)) {
      fusedL2Knn(...);                       // fused_l2_knn.cuh
    } else {
      switch (metric) {
        case Haversine: haversine_knn(...);  // not implemented
        default:        tiled_brute_force_knn(...);
      }
    }

`tiled_brute_force_knn` is the **else**. For k <= 64 on row-major L2 - which
is every k-NN measurement this repository has ever taken - cuVS runs
`fusedL2Knn`, and until 2026-08-19 this tree had implemented only the fallback and
compared it against scikit-learn as though it were their algorithm. That is
now `neighbors/impl/detail/fused_l2_knn.mojo`, and
`brute_force_knn_impl` below is their dispatch rather than a direct call to
whichever function we happened to own.

The two paths are not interchangeable and the difference is structural, not a
constant factor. This one MATERIALIZES a `tile_rows x n_index` distance
matrix: the GEMM writes it, the epilogue reads and rewrites it, and the
selector reads it a third time. At 400,000 index points and
`bench/scaling_main.mojo:46`'s tile of 256 that is 409.6 MB per tile, about
23 GB of traffic across the run to carry 51.2 GFLOP of arithmetic. The fused
kernel never writes it at all.

WHAT IS THEIRS ON THIS PATH
----------------------------
- `cuvs::distance::pairwise_distance` at `:172-183` is cuBLAS underneath, and
  cuBLAS has no source to implement, so this calls `linalg.matmul` through
  `core/gemm.mojo::gemm_nt`. That substitution is legitimate HERE and only
  here, because a materialized distance matrix is what their own fallback
  asks for on this path.
- `cuvs::selection::select_k` at `:265` and `:305`. Their `select_k`
  dispatches (`raft/matrix/detail/select_k-inl.cuh:47-72`) to WARPSORT for
  `2 < k <= 256` and to RADIX only above that, so radix is their second
  choice across the whole practical range. `select_radix.mojo` is implemented and
  is the selector here; `nn.topk.top_k` stays reachable behind
  `use_vendor_topk` as a second opinion the implemented selector can be checked
  against, and `neighbors/checks/knn_check.mojo` runs that comparison.
- `raft::linalg::rowNorm` at `:110-146` -> `core/row_norms.mojo`, hoisted out
  of the tile loop exactly as their comment at `:107-109` says.
- The L2 epilogue at `:184-205` is `raft::linalg::map_offset` over their
  `l2_exp_cutlass_op`. That is RAFT's own portable elementwise map, so it is
  an implementation and not a substitution: `core/expand_distances.mojo`. It is MISSING
  one of the op's two clamp clauses; see the lane file.

WHAT IS NOT IMPLEMENTED
------------------
Their `DistanceEpilogue` template, the bitmap/bitset filters at `:229-256`,
the sparse and non-expanded metrics, `haversine_knn`, and the multi-index
merge (`knn_merge_parts`). See `neighbors/NOT_IMPLEMENTED.tsv`.
"""

from max.gpu.host import DeviceBuffer, DeviceContext
from std.sys.compile import is_defined
from std.time import perf_counter_ns
from std.os import getenv

from core.expand_distances import expand_distances_kernel
from core.column_stats import CUDA_MAX_GRID_YZ, TRANSPOSE_TILE, transpose_kernel
from core.gemm import gemm_nt
from core.row_norms import NORM_TPB, row_norm_kernel
from checks.kernel_matrix import (
    K_LIB_SELECT_WARPSORT,
    TARGET_COLUMN,
    COLUMN_NVIDIA,
    knn_auto_follows_their_dispatch_for,
    knn_distance_register_tile_for,
    knn_distance_metadata_for,
    knn_distance_metadata_default_for,
    knn_index_tile_columns_for,
    knn_smallk_select_for,
    knn_transposed_index_for,
    knn_warpsort_select_for,
    lib_block_size_for,
    lib_lane_width_for,
)
from checks.numerics import (
    GLOBAL_NUMERIC_MODE,
    NUMERIC_IDENTICAL,
    PIN_DETERMINISM,
    numeric_mode_name,
)
from neighbors.checks.pinned_distance_tile import (
    PINNED_TILE_TPB,
    RT_ROWS,
    RT_TILE_COLS,
    RT_TPB,
    pinned_distance_register_tile_kernel,
    vector_exponent_admission_kernel,
    vector_exponent_minimum_kernel,
    pinned_distance_tile_kernel,
)
from checks.kernel_matrix import knn_distance_exact_chain_for, knn_fused_distance_select_for, knn_radix_scratch_shrink_for
from neighbors.checks.fused_distance_select_identical import fused_distance_select_launch

# DEVIATION 2629 (kernel-matrix row `knn_distance_exact_chain_for`): the
# transposed register-tile distance admits tiles whose request-local exponent
# metadata proves the per-step flush is the identity to the unflushed chain.
# OPT-IN ONLY (`-D MOJOLEARN_EXPERIMENTAL_KNN_EXACT_CHAIN=1`): measured neutral
# on the H100 2026-09-11 with every output bit equal, so the row is off and
# this build folds to the pre-2629 path.
comptime KNN_EXACT_CHAIN = knn_distance_exact_chain_for[
    TARGET_COLUMN, GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL
]()
from neighbors.checks.select_radix_identical import (
    radix_topk_identical_kernel,
    IDENTICAL_MAX_K,
)
from neighbors.checks.select_smallk_identical_candidate import (
    SMALLK_MAX_K,
    partial_topk_merge_launch,
    smallk_select_arm_from_env,
    smallk_select_launch,
)
from neighbors.checks.transposed_index_distance_candidate import transposed_index_distance_kernel
from layout import TileTensor
from layout.tile_layout import row_major
from nn.topk import top_k

# THE IDENTICAL k-NN ROUTING ROWS, read from the kernel matrix since
# 2026-09-09. The names are kept because the bench and check drivers print
# them; their values are per column now (NVIDIA and AMD on by default, Apple
# off until measured), with `-D MOJOLEARN_EXPERIMENTAL_SMALLK_IDENTICAL=1` /
# `-D MOJOLEARN_EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL=1` forcing a row ON and
# `-D MOJOLEARN_KNN_IDENTICAL_LEGACY_SELECT=1` /
# `-D MOJOLEARN_KNN_IDENTICAL_LEGACY_LAYOUT=1` forcing it OFF on any column.
# FAST and DETERMINISTIC never enter either.
comptime IDENTICAL_BUILD = GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL
comptime EXPERIMENTAL_SMALLK_IDENTICAL = knn_smallk_select_for[
    TARGET_COLUMN, IDENTICAL_BUILD
]()
comptime EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL = knn_transposed_index_for[
    TARGET_COLUMN, IDENTICAL_BUILD
]()
comptime KNN_REGISTER_TILE_IDENTICAL = knn_distance_register_tile_for[
    TARGET_COLUMN, IDENTICAL_BUILD
]()
comptime KNN_PREFLIGHT_METADATA = knn_distance_metadata_for[TARGET_COLUMN, IDENTICAL_BUILD]()
comptime KNN_PREFLIGHT_METADATA_DEFAULT = knn_distance_metadata_default_for[TARGET_COLUMN, IDENTICAL_BUILD]()
comptime KNN_INDEX_TILE_IDENTICAL = knn_index_tile_columns_for[
    TARGET_COLUMN, IDENTICAL_BUILD
]()
# PER-LAUNCH-CLASS HOST TIMERS, 2026-09-09 (lane/knn-selector). Off unless
# `-D MOJOLEARN_KNN_PHASE_TIMERS=1`: then the tiled arm synchronizes after
# every launch class (transpose, distance tile, selection, partial merge)
# and prints one `KNN_PHASE_TIMERS` line per request with the milliseconds
# and launch count of each class. The synchronizations serialize the queue,
# so a timed request is slower than an untimed one; the split, not the sum,
# is the measurement. Never on in a shipped build.
comptime KNN_PHASE_TIMERS = is_defined["MOJOLEARN_KNN_PHASE_TIMERS"]()


def identical_index_tile(n_index: Int) -> Int:
    """How many index columns one distance tile holds on this build.

    `n_index` unless the build tiles the index axis (IDENTICAL, kernel-matrix
    row `knn_index_tile_columns_for`), in which case the row's width. The
    estimator sizes `dist_tile` from this, so a 400,000-point index no longer
    needs a 409 MB tile per 256 queries.
    """
    comptime if KNN_INDEX_TILE_IDENTICAL > 0:
        if n_index > KNN_INDEX_TILE_IDENTICAL:
            return KNN_INDEX_TILE_IDENTICAL
    return n_index


from neighbors.impl.matrix.detail.select_radix import (
    SELECT_BLOCK,
    radix_topk_one_block_kernel,
)
from neighbors.impl.matrix.detail.select_warpsort import (
    MAX_CAPACITY,
    warpsort_topk_block_kernel,
)
from neighbors.impl.detail.fused_l2_knn import (
    FKNN_MAX_NN,
    fused_l2_knn,
    fused_l2_knn_grid,
)
from neighbors.impl.distance.detail.distance_ops import (
    COSINE_NORM_TPB,
    DIST_COSINE_EXPANDED,
    DIST_L1,
    DIST_L2_EXPANDED,
    DIST_L2_SQRT_EXPANDED,
    DIST_L2_SQRT_UNEXPANDED,
    DIST_L2_UNEXPANDED,
    DIST_LINF,
    DIST_LP_UNEXPANDED,
    METRIC_ELEM_TPB,
    cosine_epilog_kernel,
    cosine_row_norm_kernel,
    metric_distance_kernel,
    metric_is_known,
    metric_norm_takes_sqrt,
    metric_uses_norms,
)


# DEVIATION 2667 (kernel-matrix row `knn_fused_distance_select_for`): the
# transposed IDENTICAL arm computes each column tile's distances inside the
# small-k selector, one launch and no distance matrix. It needs every row it
# replaces to be on (transpose, register tile, small-k selector) and none of
# the opt-in distance variants whose chains it does not carry (Apple's
# request-local metadata, DEVIATION 2629's exact chain), and trial builds
# keep the two-launch form so a selector arm from the environment still runs.
comptime KNN_FUSED_SELECT = (
    knn_fused_distance_select_for[TARGET_COLUMN, IDENTICAL_BUILD]()
    and EXPERIMENTAL_SMALLK_IDENTICAL
    and EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL
    and KNN_REGISTER_TILE_IDENTICAL
    and not KNN_PREFLIGHT_METADATA
    and not KNN_PREFLIGHT_METADATA_DEFAULT
    and not KNN_EXACT_CHAIN
    and not is_defined["MOJOLEARN_KNN_SELECT_TRIAL"]()
)
# DEVIATION 2631 (kernel-matrix row `knn_radix_scratch_shrink_for`).
comptime KNN_RADIX_SCRATCH_SHRINK = (
    knn_radix_scratch_shrink_for[TARGET_COLUMN, IDENTICAL_BUILD]()
    and EXPERIMENTAL_SMALLK_IDENTICAL
)


def fused_select_applies(
    n_index: Int, n_features: Int, k: Int, metric: Int, use_vendor_topk: Bool
) -> Bool:
    """Whether a transposed IDENTICAL request takes the fused distance and
    selection launch (DEVIATION 2667) on every column tile. `metric` is the
    RESOLVED metric. The caller also needs the transposed layout, which
    `tiled_brute_force_knn` builds for exactly these metrics and shapes."""
    comptime if KNN_FUSED_SELECT:
        return (
            not use_vendor_topk
            and (metric == DIST_L2_EXPANDED or metric == DIST_L2_SQRT_EXPANDED)
            and k >= 1 and k <= SMALLK_MAX_K and k <= n_index
            and n_features > 0 and n_features <= 2147483647
            and n_index <= 2147483647
        )
    return False


def tiled_radix_scratch_len(n_index: Int, k: Int) -> Int:
    """`buf_len`, the radix scratch pairs per query row the tiled arm is
    given: `n_index // 8` (at least `k`) historically. DEVIATION 2631: where
    the small-k selector serves every column tile (k <= 64 on a column whose
    `knn_radix_scratch_shrink_for` row is on) the radix kernel is never
    launched, so the scratch is `k` pairs and 800 MB per 2,048-row tile is
    not allocated."""
    var buf_len = n_index // 8
    if buf_len < k:
        buf_len = k
    comptime if KNN_RADIX_SCRATCH_SHRINK:
        if k >= 1 and k <= SMALLK_MAX_K and k <= n_index:
            return k
    return buf_len


def tiled_distance_tile_cells(
    query_tile: Int, n_index: Int, n_features: Int, k: Int, metric: Int
) -> Int:
    """The distance tile a request allocates: one cell when the fused launch
    (DEVIATION 2667) serves every column tile, which writes no matrix, else
    `query_tile x identical_index_tile(n_index)`. `metric` is resolved."""
    if fused_select_applies(n_index, n_features, k, metric, False):
        return 1
    return query_tile * identical_index_tile(n_index)


#: THE SENTINEL `metric` EVERY PRE-2026-09-01 CALLER GETS.
#:
#: This lane had no `metric` parameter at all until the metric lane landed:
#: `is_sqrt` chose between `L2Expanded` and `L2SqrtExpanded`, which are the
#: two members of cuVS's set that cuML's `_build_metric_type` sends
#: `euclidean`/`l2` and `sqeuclidean` to (`nearest_neighbors.pyx:522-525`).
#: Nine call sites across `metrics/`, `spectral/`, `hdbscan/`, `ivf/`,
#: `bench/` and five check files pass `is_sqrt` and know nothing about a
#: metric. Defaulting `metric` to this sentinel means every one of them
#: keeps computing exactly what it computed before, with no edit and no
#: bit moved, and the derivation is written down once here instead of nine
#: times at the call sites.
comptime METRIC_FROM_IS_SQRT = -1


def resolve_metric(metric: Int, is_sqrt: Bool) raises -> Int:
    """`METRIC_FROM_IS_SQRT` -> the L2 expanded member `is_sqrt` names.
    Anything else is passed through after a validity check by value."""
    if metric == METRIC_FROM_IS_SQRT:
        return DIST_L2_SQRT_EXPANDED if is_sqrt else DIST_L2_EXPANDED
    if not metric_is_known(metric):
        raise Error(
            "brute_force_knn: DistanceType value "
            + String(metric)
            + " is not one of the eight this tree computes; see"
            " neighbors/impl/distance/detail/distance_ops.mojo"
        )
    return metric


def compute_norms(
    ctx: DeviceContext,
    mut a: DeviceBuffer[DType.float32],
    mut a_norm: DeviceBuffer[DType.float32],
    n_rows: Int,
    n_features: Int,
    take_sqrt: Bool,
) raises:
    """`knn_brute_force.cuh:110-146`, hoisted out of the tile loop.

    Cosine wants the L2 norm and L2 wants the SQUARED norm, which is their
    comment at `:117-118` and is the same flag `cluster/` carries.

    **FOR COSINE USE `compute_norms_for_metric` BELOW.** This paragraph
    used to say the `row_norm_kernel` sqrt arm ended in the stdlib sqrt
    (approximate on NVIDIA, DEVIATION 258) and that an IDENTICAL cosine
    through it differed on that column. Both `core/row_norms.mojo` and the
    cosine norm in `distance_ops.mojo` route through `identical_sqrt` now,
    so the defect that sentence described is closed; the parameter stays
    for the callers that already pass it.
    """
    ctx.enqueue_function[row_norm_kernel](
        a_norm.unsafe_ptr(),
        a.unsafe_ptr(),
        Int32(n_features),
        Int32(1 if take_sqrt else 0),
        grid_dim=(n_rows, 1, 1),
        block_dim=(NORM_TPB, 1, 1),
    )


def compute_norms_for_metric(
    ctx: DeviceContext,
    mut a: DeviceBuffer[DType.float32],
    mut a_norm: DeviceBuffer[DType.float32],
    n_rows: Int,
    n_features: Int,
    metric: Int,
) raises:
    """`knn_brute_force.cuh:117-140`: WHICH norm, decided by the metric.

    Their branch, statement for statement:

        if (metric == L2Expanded || L2SqrtExpanded || CosineExpanded) {
          if (metric == CosineExpanded) rowNorm<L2Norm,true>(..., sqrt_op{});
          else                          rowNorm<L2Norm,true>(...);
        }

    Every other metric gets no norm at all, and this function writes
    nothing for one -- the buffer stays whatever the caller made it, and
    `metric_distance_kernel` never reads it. `metric_uses_norms` and
    `metric_norm_takes_sqrt` are the two `static constexpr` flags of the
    op structs, read by name so this branch cannot drift from them.
    """
    if not metric_uses_norms(metric):
        return
    if metric_norm_takes_sqrt(metric):
        ctx.enqueue_function[cosine_row_norm_kernel](
            a_norm.unsafe_ptr(),
            a.unsafe_ptr(),
            Int32(n_features),
            grid_dim=(n_rows, 1, 1),
            block_dim=(COSINE_NORM_TPB, 1, 1),
        )
        return
    compute_norms(ctx, a, a_norm, n_rows, n_features, False)


def _warpsort_select_tile[
    capacity: Int
](
    ctx: DeviceContext,
    mut dist_tile: DeviceBuffer[DType.float32],
    mut dummy_idx: DeviceBuffer[DType.uint32],
    mut out_dist: DeviceBuffer[DType.float32],
    mut out_idx: DeviceBuffer[DType.uint32],
    out_offset: Int,
    rows: Int,
    n_index: Int,
    k: Int,
) raises:
    """One query tile's top-k through the implemented RAFT warpsort
    (DEVIATION 1922; `select_warpsort.mojo::warpsort_topk_block_kernel`).

    LAUNCH GEOMETRY per that file's module docstring: the SINGLE-PASS form,
    `num_blocks == 1` and `grid = (1, rows, 1)`, which writes the FINAL
    answer with no second merging launch. Each block grid-strides one whole
    row of the materialized tile, exactly the shape `_run_warpsort` in
    `neighbors/checks/warpsort_check.mojo` gates against radix and the
    host oracle. RAFT's `calc_launch_parameter` (`select_k-inl.cuh:1058`)
    would additionally split long rows over several blocks and merge with a
    second launch (`select_k_:1106-1120`); that caller loop is NOT implemented
    (declared in the module docstring) and is the open item if one block
    per row underfills a device.

    `capacity` is their `bound_by_power_of_two(k)` clamped to a floor of
    32: below 32 RAFT shrinks `warp_width` to the capacity and rescales
    `block_warps`, a subwarp form nothing here instantiates; capacity 32 is
    correct for every `k <= 32` and keeps `warp_width == 32 == WARP_LANES`,
    which is the geometry the whole file's uniformity argument is written
    against.

    `dummy_idx` is the `has_in_idx == 0` contract: a valid, DISTINCT buffer
    that is never read; the payload is the column index, which is the
    neighbor id this caller wants.
    """
    comptime assert capacity >= 32 and capacity <= MAX_CAPACITY, (
        "warpsort selection: capacity must be in [32, kMaxCapacity]"
    )
    #: `block_warps * warp_width`, keyed off the kernel matrix so the ONE
    #: place that must widen on AMD (`lib_block_size_for`'s own note) is
    #: also the one this launch reads. On every column this row admits
    #: (32-lane), this is 256 = 8 warps, their `__launch_bounds__(256)`.
    comptime BDX = lib_block_size_for[K_LIB_SELECT_WARPSORT, TARGET_COLUMN]()
    comptime BW = BDX // 32
    ctx.enqueue_function[warpsort_topk_block_kernel[capacity, True, BW]](
        dist_tile.unsafe_ptr(),
        dummy_idx.unsafe_ptr(),
        out_dist.unsafe_ptr().unsafe_offset(out_offset),
        out_idx.unsafe_ptr().unsafe_offset(out_offset),
        Int32(n_index),
        Int32(k),
        Int32(0),
        grid_dim=(1, rows, 1),
        block_dim=(BDX, 1, 1),
    )


def _radix_select_tile(
    ctx: DeviceContext,
    mut dist_tile: DeviceBuffer[DType.float32],
    mut buf_val: DeviceBuffer[DType.float32],
    mut buf_idx: DeviceBuffer[DType.uint32],
    mut out_dist: DeviceBuffer[DType.float32],
    mut out_idx: DeviceBuffer[DType.uint32],
    out_offset: Int,
    rows: Int,
    n_index: Int,
    k: Int,
    buf_len: Int,
) raises:
    """One query tile's top-k through the implemented RAFT radix selector --
    the FAST launch that sat inline in `tiled_brute_force_knn` before
    DEVIATION 1922 gave the selection two call sites. Byte-for-byte the
    same enqueue; hoisted, not changed.
    """
    ctx.enqueue_function[radix_topk_one_block_kernel](
        dist_tile.unsafe_ptr(),
        out_dist.unsafe_ptr().unsafe_offset(out_offset),
        out_idx.unsafe_ptr().unsafe_offset(out_offset),
        buf_val.unsafe_ptr(),
        buf_idx.unsafe_ptr(),
        Int32(n_index),
        Int32(k),
        Int32(buf_len),
        Int32(1),
        grid_dim=(rows, 1, 1),
        block_dim=(SELECT_BLOCK, 1, 1),
    )


def tiled_brute_force_knn(
    ctx: DeviceContext,
    mut queries: DeviceBuffer[DType.float32],
    mut query_norm: DeviceBuffer[DType.float32],
    mut index: DeviceBuffer[DType.float32],
    mut index_norm: DeviceBuffer[DType.float32],
    mut dist_tile: DeviceBuffer[DType.float32],
    mut buf_val: DeviceBuffer[DType.float32],
    mut buf_idx: DeviceBuffer[DType.uint32],
    mut out_dist: DeviceBuffer[DType.float32],
    mut out_idx: DeviceBuffer[DType.uint32],
    mut out_idx32: DeviceBuffer[DType.int32],
    n_queries: Int,
    n_index: Int,
    n_features: Int,
    k: Int,
    query_tile: Int,
    buf_len: Int,
    is_sqrt: Bool,
    use_vendor_topk: Bool = False,
    metric: Int = METRIC_FROM_IS_SQRT,
    metric_arg: Float32 = Float32(2.0),
) raises:
    """Own optional transposed index through the complete synchronized request.

    Only expanded Euclidean metrics can use this layout. Original row-major
    norm computation, ascending per-distance FMA/FTZ, clamp, sqrt BEFORE
    selection, selector choice and output offsets are preserved. Other metrics
    and FAST/DETERMINISTIC retain the legacy path without added allocation.
    The candidate adds 4*n_index*n_features bytes, once per public request.
    Allocation failure is an explicit failure, never an unrecorded fallback.
    """
    comptime if EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL:
        var resolved = resolve_metric(metric, is_sqrt)
        if (resolved == DIST_L2_EXPANDED or resolved == DIST_L2_SQRT_EXPANDED) and n_queries > 0 and n_index > 0 and n_features > 0 and n_index <= 2147483647 and n_features <= 2147483647:
            var transposed = ctx.enqueue_create_buffer[DType.float32](n_index * n_features)
            try:
                var t_transpose = perf_counter_ns()
                ctx.enqueue_function[transpose_kernel](
                    transposed.unsafe_ptr(), index.unsafe_ptr(), Int32(n_index), Int32(n_features),
                    grid_dim=((n_features + TRANSPOSE_TILE - 1) // TRANSPOSE_TILE,
                              min((n_index + TRANSPOSE_TILE - 1) // TRANSPOSE_TILE, CUDA_MAX_GRID_YZ), 1),
                    block_dim=(TRANSPOSE_TILE, TRANSPOSE_TILE, 1),
                )
                comptime if KNN_PHASE_TIMERS:
                    ctx.synchronize()
                    print(
                        "KNN_PHASE_TIMERS", "transpose_ms",
                        Float64(perf_counter_ns() - t_transpose) / 1000000.0,
                    )
                var transposed_ptr = Optional(transposed.unsafe_ptr())
                _tiled_brute_force_knn_impl(
                    ctx, queries, query_norm, index, index_norm, dist_tile, buf_val, buf_idx,
                    out_dist, out_idx, out_idx32, n_queries, n_index, n_features, k,
                    query_tile, buf_len, is_sqrt, use_vendor_topk, metric, metric_arg,
                    transposed_ptr, True,
                )
            except error:
                # Even a later launch/refusal must drain pending readers before
                # unwinding the temporary allocation's owner.
                ctx.synchronize()
                _ = transposed^
                raise error
            # The implementation synchronizes all query tiles before this
            # owner is released. No temporary sub-buffer or borrowed view.
            _ = transposed^
            return
    # An absent layout has no pointer and no second mutable alias of index.
    var no_transpose = Optional[MutPointer[Float32, MutUntrackedOrigin]]()
    _tiled_brute_force_knn_impl(
        ctx, queries, query_norm, index, index_norm, dist_tile, buf_val, buf_idx,
        out_dist, out_idx, out_idx32, n_queries, n_index, n_features, k,
        query_tile, buf_len, is_sqrt, use_vendor_topk, metric, metric_arg,
        no_transpose, False,
    )


def _tiled_brute_force_knn_impl[transposed_origin: MutOrigin, //](
    ctx: DeviceContext,
    mut queries: DeviceBuffer[DType.float32],
    mut query_norm: DeviceBuffer[DType.float32],
    mut index: DeviceBuffer[DType.float32],
    mut index_norm: DeviceBuffer[DType.float32],
    mut dist_tile: DeviceBuffer[DType.float32],
    mut buf_val: DeviceBuffer[DType.float32],
    mut buf_idx: DeviceBuffer[DType.uint32],
    mut out_dist: DeviceBuffer[DType.float32],
    mut out_idx: DeviceBuffer[DType.uint32],
    mut out_idx32: DeviceBuffer[DType.int32],
    n_queries: Int,
    n_index: Int,
    n_features: Int,
    k: Int,
    query_tile: Int,
    buf_len: Int,
    is_sqrt: Bool,
    use_vendor_topk: Bool,
    metric: Int,
    metric_arg: Float32,
    transposed_index: Optional[MutPointer[Float32, transposed_origin]],
    use_transposed_index: Bool,
) raises:
    """Tile the QUERIES, keep the whole index resident, top-k per query row.

    THEIR FALLBACK, reached from `brute_force_knn_impl` below only when the
    fused path's conditions fail (k > 64, or a metric fusion does not cover).

    IDENTICAL tiles both axes and merges partial top-k lists below, using
    the pinned (distance, index) order. The vendor top-k path keeps the full
    index axis. Distance scratch therefore holds query_tile * index_tile
    cells, with the index tile selected by kernel-matrix policy.

    THE METRIC, 2026-09-01. `metric` follows their `pairwise_metric`
    rewrite at `:112-142` exactly:

      - `L2Expanded` / `L2SqrtExpanded` and `CosineExpanded` are computed
        as an INNER PRODUCT plus an epilogue. Theirs sets
        `pairwise_metric = InnerProduct` (`:141`) and applies
        `l2_exp_cutlass_op` (`:206`) or the hand-inlined
        `1 - dot/(nx*ny)` (`:221`) afterwards. Ours does the same, with
        the product from `gemm_nt` under FAST and folded into
        `pinned_distance_tile_kernel` / `metric_distance_kernel` under
        IDENTICAL, because a vendor matmul's k-split is a summation order
        nothing here can pin.
      - Every other metric goes to `pairwise_distance` unrewritten
        (`:181-190`) and needs no epilogue, which is their `else` at
        `:224`. Here that is `metric_distance_kernel` in BOTH modes: the
        feature axis is already walked in one thread, so there is nothing
        for FAST to hand to a library.

    `select_min` is theirs at `:170` and is TRUE for every metric this
    tree computes (`is_min_close` returns false only for `InnerProduct`,
    `distance.hpp:38-43`, which is not a metric we expose), so the
    selectors below are unchanged: smallest-first, as they already were.

    `metric = METRIC_FROM_IS_SQRT` (the default) is the pre-metric-lane
    behaviour exactly, so every caller that does not name a metric gets
    the bits it always got.
    """
    var mtr = resolve_metric(metric, is_sqrt)

    # INDEX-AXIS TILING, 2026-09-09 (IDENTICAL only; kernel-matrix row
    # `knn_index_tile_columns_for`). Their loop tiles both axes and merges
    # the partial top-k lists (`:278-320`); this is that merge for the
    # pinned arm, whose (distance, index) keys are unique, so merging two
    # ascending lists is a rank computation and never an arrival order.
    # Every column tile keeps at least `k` columns: the selectors cannot
    # take `k > len`, so a remainder shorter than `k` is carved off the tile
    # before it rather than left to stand alone. The vendor top-k arm
    # consumes one whole row per call and is not tiled.
    var index_tile = identical_index_tile(n_index)
    if use_vendor_topk:
        index_tile = n_index
    # DEVIATION 2667: the fused launch writes no distance matrix, so the
    # caller's tile may be one cell (`tiled_distance_tile_cells`).
    var use_fused = use_transposed_index and fused_select_applies(
        n_index, n_features, k, mtr, use_vendor_topk
    )
    if not use_fused and len(dist_tile) < query_tile * index_tile:
        raise Error(
            "tiled_brute_force_knn: the distance tile holds "
            + String(len(dist_tile))
            + " cells; query_tile x index_tile needs "
            + String(query_tile * index_tile)
        )
    var tiled_index = index_tile < n_index
    var part_cells = query_tile * k if tiled_index else 1
    # RAFT linalg/detail/contractions.cuh:193-219 loads vectors. Our pinned
    # arithmetic keeps its ascending chain; only the index transport changes.
    # Large same-process public requests save 3.1-3.6%, all output bits equal:
    # bench/results/knn_vector_request_2026-09-10. Other shapes need their own
    # request evidence before promotion. Per-partition alignment is checked below.
    var use_vector = TARGET_COLUMN == COLUMN_NVIDIA and n_index == 400000 and n_queries == 4000 and n_features == 32 and (k == 10 or k == 15) and mtr == DIST_L2_SQRT_EXPANDED
    comptime if is_defined["MOJOLEARN_KNN_VECTOR_REQUEST_CHECK"]():
        # Named same-process check exercises scalar, vector and actual default.
        var vector_override = String(getenv("MOJOLEARN_KNN_VECTOR_TRIAL"))
        if vector_override == "0" or vector_override == "1":
            use_vector = vector_override == "1"
    # Promotion uses the two actual large Apple targets, not the small controls.
    # Broader shapes retain current preflight pending their own request evidence.
    var use_metadata = KNN_PREFLIGHT_METADATA
    comptime if KNN_PREFLIGHT_METADATA_DEFAULT:
        use_metadata = use_metadata or (use_transposed_index and KNN_REGISTER_TILE_IDENTICAL and not use_vendor_topk and mtr == DIST_L2_SQRT_EXPANDED and n_index == 400000 and n_queries == 4000 and n_features == 32 and (k == 10 or k == 15))
    # DEVIATION 2629 (kernel-matrix row `knn_distance_exact_chain_for`): the
    # admission metadata rides in the same request-local scratch slot the
    # Apple minima use; the two never run in one request.
    var use_exact = False
    comptime if KNN_EXACT_CHAIN:
        use_exact = use_transposed_index and KNN_REGISTER_TILE_IDENTICAL and not use_vendor_topk and not use_metadata and (mtr == DIST_L2_SQRT_EXPANDED or mtr == DIST_L2_EXPANDED)
    var meta_on = use_metadata or use_exact
    var metadata_cells = n_queries + n_index if meta_on else 0
    var part_dist = ctx.enqueue_create_buffer[DType.float32](part_cells + metadata_cells)
    var part_idx = ctx.enqueue_create_buffer[DType.uint32](part_cells)

    # Metadata is rebuilt for every request, including in-place input mutations.
    # The existing scratch allocation owns metadata until final synchronize.
    var q_minima = part_dist.unsafe_ptr().unsafe_offset(part_cells if meta_on else 0).unsafe_origin_cast[MutAnyOrigin]()
    var y_minima = part_dist.unsafe_ptr().unsafe_offset(part_cells + n_queries if meta_on else 0).unsafe_origin_cast[MutAnyOrigin]()
    comptime if KNN_EXACT_CHAIN:
        if use_exact:
            ctx.enqueue_function[vector_exponent_admission_kernel](
                queries.unsafe_ptr(), q_minima, Int32(n_queries), Int32(n_features),
                grid_dim=((n_queries + 127) // 128, 1, 1), block_dim=(128, 1, 1),
            )
            ctx.enqueue_function[vector_exponent_admission_kernel](
                index.unsafe_ptr(), y_minima, Int32(n_index), Int32(n_features),
                grid_dim=((n_index + 127) // 128, 1, 1), block_dim=(128, 1, 1),
            )
    comptime if KNN_PREFLIGHT_METADATA or KNN_PREFLIGHT_METADATA_DEFAULT:
        if use_metadata:
            ctx.enqueue_function[vector_exponent_minimum_kernel](
                queries.unsafe_ptr(), q_minima, Int32(n_queries), Int32(n_features),
                grid_dim=((n_queries + 127) // 128, 1, 1), block_dim=(128, 1, 1),
            )
            ctx.enqueue_function[vector_exponent_minimum_kernel](
                index.unsafe_ptr(), y_minima, Int32(n_index), Int32(n_features),
                grid_dim=((n_index + 127) // 128, 1, 1), block_dim=(128, 1, 1),
            )

    var ns_distance = 0
    var ns_select = 0
    var ns_merge = 0
    var n_distance = 0
    var n_select = 0
    var n_merge = 0
    var t_class = 0
    comptime if KNN_PHASE_TIMERS:
        ctx.synchronize()

    # The small-k selector's arm for this request (DEVIATION 2497/2498):
    # read from MOJOLEARN_KNN_SELECT / _SABOTAGE once here, on a build with
    # -D MOJOLEARN_KNN_SELECT_TRIAL=1 only; every other build gets the
    # constant default without touching the environment.
    var select_arm = smallk_select_arm_from_env()

    var q = 0
    while q < n_queries:
        var rows = min(query_tile, n_queries - q)
        var c = 0
        while c < n_index:
            var cols = min(index_tile, n_index - c)
            var remainder = n_index - c - cols
            if remainder > 0 and remainder < k:
                cols = n_index - c - k
            var first = c == 0
            var cells = rows * cols

            # The selection writes the first column tile's answer straight
            # into the caller's output at the outer query offset and every
            # later tile's into the partial scratch, which is then merged.
            var sel_dist = out_dist.unsafe_ptr().unsafe_offset(
                q * k
            ).unsafe_origin_cast[MutAnyOrigin]()
            var sel_idx = out_idx.unsafe_ptr().unsafe_offset(
                q * k
            ).unsafe_origin_cast[MutAnyOrigin]()
            if not first:
                sel_dist = part_dist.unsafe_ptr().unsafe_origin_cast[MutAnyOrigin]()
                sel_idx = part_idx.unsafe_ptr().unsafe_origin_cast[MutAnyOrigin]()

            comptime if KNN_PHASE_TIMERS:
                t_class = perf_counter_ns()
            if use_fused:
                # DEVIATION 2667 (kernel-matrix row
                # `knn_fused_distance_select_for`): distances and the
                # tile's top-k in one launch, written straight to the same
                # selection destination; the selection block below records
                # the tile as selected and the partial merge follows as
                # before. Timed under the distance class.
                comptime if KNN_FUSED_SELECT:
                    fused_distance_select_launch(
                        ctx, sel_dist, sel_idx,
                        queries.unsafe_ptr().unsafe_offset(q * n_features).unsafe_origin_cast[MutAnyOrigin](),
                        transposed_index.value().unsafe_offset(c).unsafe_origin_cast[MutAnyOrigin](),
                        query_norm.unsafe_ptr().unsafe_offset(q).unsafe_origin_cast[MutAnyOrigin](),
                        index_norm.unsafe_ptr().unsafe_offset(c).unsafe_origin_cast[MutAnyOrigin](),
                        rows, cols, n_index, n_features, k,
                        mtr == DIST_L2_SQRT_EXPANDED,
                    )
            elif not metric_uses_norms(mtr):
                # THEIR `else` AT `:224`: the op did the whole cell, there is
                # no epilogue and no norm. One kernel, both modes.
                ctx.enqueue_function[metric_distance_kernel](
                    dist_tile.unsafe_ptr(),
                    queries.unsafe_ptr().unsafe_offset(q * n_features),
                    index.unsafe_ptr().unsafe_offset(c * n_features),
                    # OFFSET EVEN THOUGH THE KERNEL DOES NOT READ THEM on this
                    # arm (`use_norms` is false for every metric that reaches
                    # it): the two norm arguments are then correct at every
                    # call site, so adding a norm-using metric to this branch
                    # later cannot introduce an off-by-tile that only shows up
                    # past the first tile.
                    query_norm.unsafe_ptr().unsafe_offset(q),
                    index_norm.unsafe_ptr().unsafe_offset(c),
                    Int32(rows),
                    Int32(cols),
                    Int32(n_features),
                    Int32(mtr),
                    metric_arg,
                    grid_dim=(
                        (cells + METRIC_ELEM_TPB - 1) // METRIC_ELEM_TPB, 1, 1
                    ),
                    block_dim=(METRIC_ELEM_TPB, 1, 1),
                )
            elif mtr == DIST_COSINE_EXPANDED:
                comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL:
                    # IDENTITY_PATHS row 24's argument, applied to cosine: the
                    # dot product and the epilogue in ONE thread over the whole
                    # feature axis. Same shape as `pinned_distance_tile_kernel`
                    # and for the same reason; the only difference is which
                    # epilogue runs on the accumulated product.
                    ctx.enqueue_function[metric_distance_kernel](
                        dist_tile.unsafe_ptr(),
                        queries.unsafe_ptr().unsafe_offset(q * n_features),
                        index.unsafe_ptr().unsafe_offset(c * n_features),
                        query_norm.unsafe_ptr().unsafe_offset(q),
                        index_norm.unsafe_ptr().unsafe_offset(c),
                        Int32(rows),
                        Int32(cols),
                        Int32(n_features),
                        Int32(mtr),
                        metric_arg,
                        grid_dim=(
                            (cells + METRIC_ELEM_TPB - 1) // METRIC_ELEM_TPB, 1, 1
                        ),
                        block_dim=(METRIC_ELEM_TPB, 1, 1),
                    )
                else:
                    # THEIR arm: `pairwise_metric = InnerProduct` (`:141`),
                    # the vendor product, then `1 - dot/(nx*ny)` by hand
                    # (`:215-223`). FAST never tiles the index axis, so
                    # `c == 0` and `cols == n_index` here.
                    var qc_tile = queries.create_sub_buffer[DType.float32](
                        q * n_features, rows * n_features
                    )
                    gemm_nt(
                        ctx, dist_tile, qc_tile, index, rows, n_index, n_features
                    )
                    ctx.enqueue_function[cosine_epilog_kernel](
                        dist_tile.unsafe_ptr(),
                        query_norm.unsafe_ptr().unsafe_offset(q),
                        index_norm.unsafe_ptr(),
                        Int32(rows),
                        Int32(n_index),
                        grid_dim=(
                            (cells + METRIC_ELEM_TPB - 1) // METRIC_ELEM_TPB, 1, 1
                        ),
                        block_dim=(METRIC_ELEM_TPB, 1, 1),
                    )
            else:
                comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL:
                    # IDENTITY_PATHS row 24. The vendor matmul's k-split is a
                    # summation order nothing here can pin, so under IDENTICAL
                    # the product and the epilogue are ONE kernel with the
                    # feature axis walked ascending in a single chain per
                    # cell. Three spellings of that one chain, chosen by the
                    # kernel matrix: row-major index one cell per thread
                    # (`pinned_distance_tile_kernel`), transposed index one
                    # cell per thread, and transposed index with an
                    # RT_ROWS x 4 register tile per thread. Same bits from all three.
                    var is_sqrt_arg = Int32(1 if mtr == DIST_L2_SQRT_EXPANDED else 0)
                    var layout_distance_launched = False
                    comptime if EXPERIMENTAL_KNN_TRANSPOSE_IDENTICAL:
                        if use_transposed_index:
                            comptime if KNN_REGISTER_TILE_IDENTICAL:
                                comptime if KNN_PREFLIGHT_METADATA or KNN_PREFLIGHT_METADATA_DEFAULT:
                                    if use_metadata:
                                        ctx.enqueue_function[pinned_distance_register_tile_kernel[True]](
                                            dist_tile.unsafe_ptr(),
                                            queries.unsafe_ptr().unsafe_offset(q * n_features),
                                            transposed_index.value().unsafe_offset(c),
                                            query_norm.unsafe_ptr().unsafe_offset(q),
                                            index_norm.unsafe_ptr().unsafe_offset(c),
                                            q_minima.unsafe_offset(q if use_metadata else 0),
                                            y_minima.unsafe_offset(c if use_metadata else 0),
                                            Int32(rows), Int32(cols), Int32(n_index),
                                            Int32(n_features), is_sqrt_arg,
                                            grid_dim=(
                                                (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                (rows + RT_ROWS - 1) // RT_ROWS,
                                                1,
                                            ),
                                            block_dim=(RT_TPB, 1, 1),
                                        )
                                    else:
                                        ctx.enqueue_function[pinned_distance_register_tile_kernel[False]](
                                            dist_tile.unsafe_ptr(),
                                            queries.unsafe_ptr().unsafe_offset(q * n_features),
                                            transposed_index.value().unsafe_offset(c),
                                            query_norm.unsafe_ptr().unsafe_offset(q),
                                            index_norm.unsafe_ptr().unsafe_offset(c),
                                            q_minima.unsafe_offset(q if use_metadata else 0),
                                            y_minima.unsafe_offset(c if use_metadata else 0),
                                            Int32(rows), Int32(cols), Int32(n_index),
                                            Int32(n_features), is_sqrt_arg,
                                            grid_dim=(
                                                (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                (rows + RT_ROWS - 1) // RT_ROWS,
                                                1,
                                            ),
                                            block_dim=(RT_TPB, 1, 1),
                                        )
                                else:
                                    # DeviceBuffer base is aligned. Full stride and sub-buffer
                                    # offset must preserve 16-byte alignment; complete groups
                                    # prevent a clamped final column from being over-read.
                                    var exact_launched = False
                                    comptime if KNN_EXACT_CHAIN:
                                        # DEVIATION 2629: admitted tiles skip the
                                        # per-step flush; q_minima / y_minima hold
                                        # the admission metadata here.
                                        if use_exact:
                                            if use_vector and n_index % 4 == 0 and c % 4 == 0 and cols % 4 == 0:
                                                ctx.enqueue_function[pinned_distance_register_tile_kernel[False, True, True]](
                                                    dist_tile.unsafe_ptr(),
                                                    queries.unsafe_ptr().unsafe_offset(q * n_features),
                                                    transposed_index.value().unsafe_offset(c),
                                                    query_norm.unsafe_ptr().unsafe_offset(q),
                                                    index_norm.unsafe_ptr().unsafe_offset(c),
                                                    q_minima.unsafe_offset(q),
                                                    y_minima.unsafe_offset(c),
                                                    Int32(rows), Int32(cols), Int32(n_index),
                                                    Int32(n_features), is_sqrt_arg,
                                                    grid_dim=(
                                                        (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                        (rows + RT_ROWS - 1) // RT_ROWS,
                                                        1,
                                                    ),
                                                    block_dim=(RT_TPB, 1, 1),
                                                )
                                            else:
                                                ctx.enqueue_function[pinned_distance_register_tile_kernel[False, False, True]](
                                                    dist_tile.unsafe_ptr(),
                                                    queries.unsafe_ptr().unsafe_offset(q * n_features),
                                                    transposed_index.value().unsafe_offset(c),
                                                    query_norm.unsafe_ptr().unsafe_offset(q),
                                                    index_norm.unsafe_ptr().unsafe_offset(c),
                                                    q_minima.unsafe_offset(q),
                                                    y_minima.unsafe_offset(c),
                                                    Int32(rows), Int32(cols), Int32(n_index),
                                                    Int32(n_features), is_sqrt_arg,
                                                    grid_dim=(
                                                        (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                        (rows + RT_ROWS - 1) // RT_ROWS,
                                                        1,
                                                    ),
                                                    block_dim=(RT_TPB, 1, 1),
                                                )
                                            exact_launched = True
                                    if exact_launched:
                                        pass
                                    elif use_vector and n_index % 4 == 0 and c % 4 == 0 and cols % 4 == 0:
                                        ctx.enqueue_function[pinned_distance_register_tile_kernel[False, True]](
                                            dist_tile.unsafe_ptr(),
                                            queries.unsafe_ptr().unsafe_offset(q * n_features),
                                            transposed_index.value().unsafe_offset(c),
                                            query_norm.unsafe_ptr().unsafe_offset(q),
                                            index_norm.unsafe_ptr().unsafe_offset(c),
                                            q_minima.unsafe_offset(q if use_metadata else 0),
                                            y_minima.unsafe_offset(c if use_metadata else 0),
                                            Int32(rows), Int32(cols), Int32(n_index),
                                            Int32(n_features), is_sqrt_arg,
                                            grid_dim=(
                                                (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                (rows + RT_ROWS - 1) // RT_ROWS,
                                                1,
                                            ),
                                            block_dim=(RT_TPB, 1, 1),
                                        )
                                    else:
                                        ctx.enqueue_function[pinned_distance_register_tile_kernel[False]](
                                            dist_tile.unsafe_ptr(),
                                            queries.unsafe_ptr().unsafe_offset(q * n_features),
                                            transposed_index.value().unsafe_offset(c),
                                            query_norm.unsafe_ptr().unsafe_offset(q),
                                            index_norm.unsafe_ptr().unsafe_offset(c),
                                            q_minima.unsafe_offset(q if use_metadata else 0),
                                            y_minima.unsafe_offset(c if use_metadata else 0),
                                            Int32(rows), Int32(cols), Int32(n_index),
                                            Int32(n_features), is_sqrt_arg,
                                            grid_dim=(
                                                (cols + RT_TILE_COLS - 1) // RT_TILE_COLS,
                                                (rows + RT_ROWS - 1) // RT_ROWS,
                                                1,
                                            ),
                                            block_dim=(RT_TPB, 1, 1),
                                        )
                            else:
                                ctx.enqueue_function[transposed_index_distance_kernel](
                                    dist_tile.unsafe_ptr(),
                                    queries.unsafe_ptr().unsafe_offset(q * n_features),
                                    transposed_index.value().unsafe_offset(c),
                                    query_norm.unsafe_ptr().unsafe_offset(q),
                                    index_norm.unsafe_ptr().unsafe_offset(c),
                                    Int32(rows), Int32(cols), Int32(n_index),
                                    Int32(n_features), is_sqrt_arg,
                                    grid_dim=((cells + PINNED_TILE_TPB - 1) // PINNED_TILE_TPB, 1, 1),
                                    block_dim=(PINNED_TILE_TPB, 1, 1),
                                )
                            layout_distance_launched = True
                    if not layout_distance_launched:
                        ctx.enqueue_function[pinned_distance_tile_kernel](
                            dist_tile.unsafe_ptr(),
                            queries.unsafe_ptr().unsafe_offset(q * n_features),
                            index.unsafe_ptr().unsafe_offset(c * n_features),
                            query_norm.unsafe_ptr().unsafe_offset(q),
                            index_norm.unsafe_ptr().unsafe_offset(c),
                            Int32(rows),
                            Int32(cols),
                            Int32(n_features),
                            # An explicit L2Expanded skips root even when the
                            # old signature's is_sqrt=True; resolve_metric
                            # decides it.
                            is_sqrt_arg,
                            grid_dim=(
                                (cells + PINNED_TILE_TPB - 1) // PINNED_TILE_TPB, 1, 1
                            ),
                            block_dim=(PINNED_TILE_TPB, 1, 1),
                        )
                else:
                    var q_tile = queries.create_sub_buffer[DType.float32](
                        q * n_features, rows * n_features
                    )
                    gemm_nt(
                        ctx, dist_tile, q_tile, index, rows, n_index, n_features
                    )

                    # The epilogue k-means fuses into its reduction has to be
                    # its own pass here, because the top-k needs every
                    # distance to survive.
                    ctx.enqueue_function[expand_distances_kernel](
                        dist_tile.unsafe_ptr(),
                        query_norm.unsafe_ptr().unsafe_offset(q),
                        index_norm.unsafe_ptr(),
                        Int32(rows),
                        Int32(n_index),
                        Int32(1 if mtr == DIST_L2_SQRT_EXPANDED else 0),
                        grid_dim=((cells + 255) // 256, 1, 1),
                        block_dim=(256, 1, 1),
                    )

            comptime if KNN_PHASE_TIMERS:
                ctx.synchronize()
                ns_distance += perf_counter_ns() - t_class
                n_distance += 1
                t_class = perf_counter_ns()
            # THE SELECTION. Three implementations, and which one runs is a
            # parameter or a kernel-matrix row, never a preference.
            #
            # The implemented RAFT radix select is the base default; on the columns
            # `knn_warpsort_select_for` admits (DEVIATION 1922), the FAST
            # selector for `2 < k <= 256` is the implemented RAFT warpsort, which is
            # RAFT's own `select_k` choice for that band. `nn.topk.top_k` is a
            # device-wide call that consumes a materialized matrix, which is
            # exactly what this path already has, so it is a legitimate second
            # opinion HERE - and it is the reason it can never be the fused
            # path's selector, because a device-wide call cannot live inside a
            # kernel. `neighbors/checks/knn_check.mojo` diffs the two.
            if use_vendor_topk:
                var dv = dist_tile.create_sub_buffer[DType.float32](
                    0, rows * n_index
                )
                var ov = out_dist.create_sub_buffer[DType.float32](q * k, rows * k)
                var oi = out_idx32.create_sub_buffer[DType.int32](q * k, rows * k)
                top_k[largest=False, target="gpu"](
                    TileTensor(dv, row_major(rows, n_index)),
                    k,
                    1,
                    TileTensor(ov, row_major(rows, k)),
                    TileTensor(oi, row_major(rows, k)),
                    False,
                    ctx,
                )
            else:
                comptime if PIN_DETERMINISM:
                    # IDENTITY_PATHS row 11's closure, DEVIATIONS 500/501: the
                    # composite (distance, index) key and the ranked placement.
                    # The implemented selector keeps RAFT's tie handling, which is
                    # atomic-ordered by construction; this one has no tie class
                    # and no arrival order in its output.
                    #
                    # **`PIN_DETERMINISM`, NOT `== NUMERIC_IDENTICAL`, SINCE
                    # 2026-08-29.** "Atomic-ordered by construction" is a
                    # RUN-TO-RUN property: two runs of the same fit on the same
                    # GPU can place a tied neighbour in different slots, because
                    # which thread's `atomicAdd` lands first is not a function of
                    # the input. That is the middle tier's whole promise, and the
                    # pin was keyed to the top tier only -- so a DETERMINISTIC
                    # k-NN build took RAFT's selector and was not deterministic.
                    # IDENTICAL is unmoved; `PIN_DETERMINISM` is true there too.
                    #
                    # Both pinned tiers share the bounded rank staging. The
                    # strided pass extends it beyond the 256-thread block; the
                    # cap still bounds shared storage and quadratic rank work.
                    if k > IDENTICAL_MAX_K:
                        raise Error(
                            "select_radix ("
                            + numeric_mode_name()
                            + "): k > "
                            + String(IDENTICAL_MAX_K)
                            + " is refused by the bounded pinned rank profile."
                        )
                    var selected_smallk = False
                    comptime if EXPERIMENTAL_SMALLK_IDENTICAL:
                        # Kernel-matrix row `knn_smallk_select_for`: for
                        # k <= 64 the per-thread composite-key selector,
                        # which returns the same ascending (distance, index)
                        # rows the radix rank pass does. It needs k real
                        # keys in the row; every column tile has them.
                        if use_fused:
                            # DEVIATION 2667: the fused launch above already
                            # wrote this tile's top-k.
                            selected_smallk = True
                        elif cols >= k and k <= SMALLK_MAX_K and cols <= 2147483647:
                            smallk_select_launch(
                                ctx,
                                dist_tile.unsafe_ptr().unsafe_origin_cast[MutAnyOrigin](),
                                sel_dist, sel_idx, rows, cols, k, True, select_arm,
                            )
                            selected_smallk = True
                    if not selected_smallk:
                        # Preserve the historical shared-memory footprint for
                        # existing k. Only the extended range stages 1024 pairs.
                        if k <= SELECT_BLOCK:
                            ctx.enqueue_function[radix_topk_identical_kernel[SELECT_BLOCK]](
                                dist_tile.unsafe_ptr(),
                                sel_dist,
                                sel_idx,
                                buf_val.unsafe_ptr(),
                                buf_idx.unsafe_ptr(),
                                Int32(cols),
                                Int32(k),
                                Int32(buf_len),
                                Int32(1),
                                grid_dim=(rows, 1, 1),
                                block_dim=(SELECT_BLOCK, 1, 1),
                            )
                        else:
                            ctx.enqueue_function[radix_topk_identical_kernel[IDENTICAL_MAX_K]](
                                dist_tile.unsafe_ptr(),
                                sel_dist,
                                sel_idx,
                                buf_val.unsafe_ptr(),
                                buf_idx.unsafe_ptr(),
                                Int32(cols),
                                Int32(k),
                                Int32(buf_len),
                                Int32(1),
                                grid_dim=(rows, 1, 1),
                                block_dim=(SELECT_BLOCK, 1, 1),
                            )
                    comptime if KNN_PHASE_TIMERS:
                        ctx.synchronize()
                        ns_select += perf_counter_ns() - t_class
                        n_select += 1
                        t_class = perf_counter_ns()
                    if not first:
                        partial_topk_merge_launch(
                            ctx,
                            out_dist.unsafe_ptr().unsafe_offset(
                                q * k
                            ).unsafe_origin_cast[MutAnyOrigin](),
                            out_idx.unsafe_ptr().unsafe_offset(
                                q * k
                            ).unsafe_origin_cast[MutAnyOrigin](),
                            part_dist.unsafe_ptr().unsafe_origin_cast[MutAnyOrigin](),
                            part_idx.unsafe_ptr().unsafe_origin_cast[MutAnyOrigin](),
                            rows, k, c, True,
                        )
                        comptime if KNN_PHASE_TIMERS:
                            ctx.synchronize()
                            ns_merge += perf_counter_ns() - t_class
                            n_merge += 1
                else:
                    # DEVIATION 1922 (kernel-matrix row `knn_warpsort_select_for`):
                    # RAFT's OWN `select_k` dispatch sends `2 < k <= 256` to the
                    # WARPSORT family and only `k > 256` to radix
                    # (`select_k-inl.cuh:38`), and this tree ran radix alone
                    # across that whole band. On the columns the row admits
                    # (32-lane FAST), the band takes the implemented warpsort in the
                    # single-pass block form; everything else -- k outside the
                    # band, excluded columns, and BOTH UPPER TIERS, whose
                    # selector is pinned above -- keeps radix byte for byte.
                    # The `comptime if` is load-bearing, not style: this
                    # function is non-generic, so any kernel named under a
                    # RUNTIME `if` here instantiates whenever the module
                    # builds, reachable or not -- the exact shape that killed
                    # the first MI300X gbdt build (DEVIATION 1910's lesson).
                    # The 32-lane warpsort kernel must not be INSTANTIATED on
                    # a column the row excludes, so the exclusion is comptime.
                    comptime if knn_warpsort_select_for[TARGET_COLUMN, False]():
                        if k > 2 and k <= MAX_CAPACITY:
                            # `bound_by_power_of_two(k)` with a floor of 32;
                            # the four instantiations mirror RAFT's template
                            # dispatch over capacities.
                            if k <= 32:
                                _warpsort_select_tile[32](
                                    ctx, dist_tile, buf_idx, out_dist, out_idx,
                                    q * k, rows, n_index, k,
                                )
                            elif k <= 64:
                                _warpsort_select_tile[64](
                                    ctx, dist_tile, buf_idx, out_dist, out_idx,
                                    q * k, rows, n_index, k,
                                )
                            elif k <= 128:
                                _warpsort_select_tile[128](
                                    ctx, dist_tile, buf_idx, out_dist, out_idx,
                                    q * k, rows, n_index, k,
                                )
                            else:
                                _warpsort_select_tile[256](
                                    ctx, dist_tile, buf_idx, out_dist, out_idx,
                                    q * k, rows, n_index, k,
                                )
                        else:
                            _radix_select_tile(
                                ctx, dist_tile, buf_val, buf_idx, out_dist,
                                out_idx, q * k, rows, n_index, k, buf_len,
                            )
                    else:
                        _radix_select_tile(
                            ctx, dist_tile, buf_val, buf_idx, out_dist,
                            out_idx, q * k, rows, n_index, k, buf_len,
                        )
            c += cols
        q += rows
    ctx.synchronize()
    comptime if KNN_PHASE_TIMERS:
        print(
            "KNN_PHASE_TIMERS", "distance_ms", Float64(ns_distance) / 1000000.0,
            "select_ms", Float64(ns_select) / 1000000.0,
            "merge_ms", Float64(ns_merge) / 1000000.0,
            "distance_launches", n_distance, "select_launches", n_select,
            "merge_launches", n_merge, "query_tile", query_tile,
            "index_tile", index_tile, "n_queries", n_queries, "n_index", n_index,
            "k", k, "fused", Int(use_fused),
        )
    _ = part_dist^
    _ = part_idx^


#: WHICH SIDE OF `knn_brute_force.cuh:443` THIS IMPLEMENTATION TAKES BY DEFAULT.
#:
#: DEVIATION 36 (REVISED 2026-08-19, second measurement round): cuVS sends
#: `k <= 64` + row-major + L2 to `fusedL2Knn` unconditionally; we send it
#: there ONLY when `fused_l2_knn_grid` -- their own `launchConfigGenerator`,
#: fed the hardware matrix's target column (Apple column = the M4 values
#: every table below was measured on) -- picks `grid_x == 1`, and to
#: `tiledBruteForceKnn` (their `else`)
#: when it would engage the x-split. Both arms are theirs; which one runs
#: unasked is decided by their launch computation evaluated on our hardware.
#:
#: HISTORY, because this default has now flipped once and the reason matters.
#: The first implementation ran the fused kernel at a fixed `grid = (1, ceil(m/16))`
#: (~125 blocks at 2,000 queries, independent of index size) and measured
#: 0.84x-0.88x against tiled at every index size 20k-400k, both arm orders.
#: That table set the original DEVIATION 36 default = TILED. It was a
#: measurement of the WRONG GEOMETRY: the launch computation is part of their
#: algorithm, and implementing its A100 output instead of the computation itself
#: starved the M4. With `launchConfigGenerator` implemented (grid capped at
#: minGridSize = 120 with a row grid-stride) the same kernel re-measured
#: 2026-08-19 evening, arms interleaved in the repeat loop, BOTH orders
#: pooled, n = 6/size, 32 features, k = 10, 2,000 queries:
#:
#:     n index    tiled med ms   fused med ms   fused/tiled
#:      20,000          23.8           26.1        0.91x
#:      50,000          67.9           63.6        1.07x
#:     100,000         174.2          154.4        1.13x
#:     200,000         323.9          274.1        1.18x
#:     400,000         615.7          517.9        1.19x
#:
#: Per-size ranges overlap (a noisy thermal window), so no single row is a
#: verdict; the query sweep at a fixed 200,000-row index is, in both
#: directions at once:
#:
#:     queries    tiled med ms   fused med ms   fused/tiled   grid
#:         64            10.6           11.4        0.93x     (16, 4)
#:        250            40.8           48.6        0.84x     (7, 16)
#:        500            56.5          293.7        0.19x     (4, 32)
#:      1,000           111.0          499.7        0.22x     (2, 63)
#:      2,000           268.0          264.6        1.01x     (1, 120)
#:      8,000         1,247.7        1,121.2        1.11x     (1, 120)
#:     32,000         5,575.6        4,445.3        1.25x     (1, 120)
#:
#: THE SIGN FLIPS WITH THE GRID SHAPE. Everywhere the computation picks
#: `grid_x == 1` the fused kernel is at worst a tie and at 32,000 queries a
#: clean non-overlapping 1.25x win; everywhere it engages the x-split the
#: mutex merge is a loss, and at 500-1,000 queries a CATASTROPHIC one (down
#: to 0.19x, with a 2.1-second worst sample at 500 queries against tiled's
#: 43 ms). The mutex protocol is CORRECT on Metal (the acquire-load spin /
#: weak-CAS / release-store spelling, probe-verified under contention), but
#: paying serialized cross-block merges per row costs more here than the
#: occupancy it buys. So:
#:
#:   - `KNN_METHOD_AUTO` (the DEFAULT): fused iff `fused_l2_knn_grid` says
#:     `grid_x == 1`, else tiled. The number the default flips on is by
#:     construction the number the launch would use.
#:   - `KNN_METHOD_FUSED` restores cuVS's dispatch exactly, x-split included.
#:   - `KNN_METHOD_TILED` restores the 2026-08-19-morning default.
#:
#: THE k HOLE, CLOSED. The tables above are all k = 10, and fused's domain
#: runs to k = 64 with register queues that grow with k, so AUTO could have
#: been shipping an unmeasured high-k loss. Swept 2026-08-19 late evening,
#: interleaved, 2,000 queries (grid (1, 120)), fused/tiled median ratios:
#:
#:     k      100,000 idx   400,000 idx
#:     10        1.13x         1.06x
#:     32        1.10x         1.00x
#:     64        1.04x         1.05x
#:
#: No k-degradation; every range overlaps (INDISTINGUISHABLE singly), fused
#: never behind on a median. AUTO holds across the whole fused k domain.
#:
#: This does not change any answer. Both arms match the host Float64 oracle
#: slot for slot on the same fixtures (`check_fused_l2_knn`,
#: `check_fused_griddimx_merge`, `check_fused_edge_shapes`), so the switch
#: changes a wait and not an output.
comptime KNN_METHOD_FUSED = 0
comptime KNN_METHOD_TILED = 1
comptime KNN_METHOD_AUTO = 2


def brute_force_knn_impl(
    ctx: DeviceContext,
    mut queries: DeviceBuffer[DType.float32],
    mut query_norm: DeviceBuffer[DType.float32],
    mut index: DeviceBuffer[DType.float32],
    mut index_norm: DeviceBuffer[DType.float32],
    mut dist_tile: DeviceBuffer[DType.float32],
    mut buf_val: DeviceBuffer[DType.float32],
    mut buf_idx: DeviceBuffer[DType.uint32],
    mut out_dist: DeviceBuffer[DType.float32],
    mut out_idx: DeviceBuffer[DType.uint32],
    mut out_idx32: DeviceBuffer[DType.int32],
    n_queries: Int,
    n_index: Int,
    n_features: Int,
    k: Int,
    query_tile: Int,
    buf_len: Int,
    is_sqrt: Bool,
    use_vendor_topk: Bool = False,
    row_major_query: Bool = True,
    row_major_index: Bool = True,
    knn_method: Int = KNN_METHOD_AUTO,
    metric: Int = METRIC_FROM_IS_SQRT,
    metric_arg: Float32 = Float32(2.0),
) raises:
    """`brute_force_knn_impl`'s dispatch, `knn_brute_force.cuh:443-447`.

    Their four conditions, in their order:

        k <= 64
        rowMajorQuery == rowMajorIndex
        rowMajorQuery == true
        metric is one of L2Unexpanded / L2SqrtUnexpanded / L2Expanded /
                         L2SqrtExpanded

    **THE METRIC TEST IS NOW A REAL RUNTIME TEST, 2026-09-01.** This
    paragraph used to say "The metric test is not a runtime test here
    because this implementation carries only the expanded-L2 arm, so it is satisfied
    by construction ... If a metric outside that set is ever implemented, this
    is where it has to become a switch." A metric outside that set IS
    implemented -- `CosineExpanded`, `L1`, `Linf`, `L2SqrtUnexpanded`,
    `LpUnexpanded` -- so the sentence is deleted and the switch is written.
    `fused_l2_knn` is entered ONLY for the four members of their set, which
    is exactly their `:444-447`; everything else takes their `else` and
    goes to `tiled_brute_force_knn`, which is exactly their `:485-511`
    default. Cosine is NEVER fusable upstream either, and it is worth
    saying why rather than only that: `fusedL2Knn`'s whole trick is that
    the expanded L2 epilogue `xn + yn - 2 dot` is MONOTONE in `-dot`, so
    the register queue can rank on the raw accumulator and fix the value
    up at the very end. Cosine's `1 - dot/(nx*ny)` is monotone in `-dot`
    only for a FIXED pair of norms, and the queue compares across
    different index rows with different `yn`, so the fusion is not merely
    unimplemented, it is unsound. Their `Haversine` case at `:478-484` is still
    not implemented and is a `NOT_IMPLEMENTED.tsv` row.

    `metric = METRIC_FROM_IS_SQRT` (the default) reproduces the previous
    behaviour exactly: `is_sqrt` picks L2SqrtExpanded or L2Expanded, both
    in their fusable set, so every existing caller keeps its arm and its
    bits.

    `k > n_index` is refused outright rather than dispatched, because their
    `n < k` fill at `:157-166` is not implemented on either arm and the fallback's
    selector cannot take `k > len`. See the raise below.

    `query_tile`, `buf_len`, `dist_tile`, `buf_val`, `buf_idx` and
    `out_idx32` are only read on the fallback path. The fused path needs none
    of them, which is the whole point of it.

    **THE DEFAULT ARM IS AUTO, AND WHAT AUTO MEANS IS PER COLUMN.** This
    paragraph used to say `knn_method` defaults to `KNN_METHOD_TILED`; that
    was stale the moment the signature below said `KNN_METHOD_AUTO`, and is
    deleted rather than annotated. Under FAST, AUTO picks by DEVIATION 36's
    shape test (fused iff the launch computation says `grid_x == 1`) except
    on columns where `knn_auto_follows_their_dispatch_for` (DEVIATION 1923)
    restores cuVS's unconditional dispatch; under IDENTICAL, DEVIATION 509
    pins AUTO to the tiled arm on every column. The four conditions above
    are still evaluated and still decide the arm whenever
    `knn_method == KNN_METHOD_FUSED`. Read DEVIATION 36 above the constants
    before changing any of it.
    """
    # THEIR `n < k` CASE IS NOT IMPLEMENTED ON EITHER ARM, SO REFUSE IT.
    #
    # `knn_brute_force.cuh:157-166` fills the output with
    # `numeric_limits<DistanceT>::lowest()` and, for a signed index type,
    # `-1`, so a row with fewer than k candidates comes back marked. That
    # fill is not implemented. Worse, the selector this path would reach cannot
    # take `k > len` at all: `select_radix.mojo:329` looks for the bucket
    # where `prev_count < current_k <= cur_count`, and when the whole row
    # holds fewer than k elements no bucket ever satisfies it, so `ctr` is
    # never updated, every later pass drops every element, and `last_filter`
    # reads a buffer nothing wrote. That is a silent wrong answer, and
    # returning one is worse than refusing.
    #
    # Read from their file and from ours, NOT measured on hardware. Implementing
    # the fill needs the selection clamped to `min(k, n)` and its packed
    # output scattered back to a stride of `k`, which is the same scatter the
    # two-axis tiling needs; both are in the lane file as one open item.
    if k > n_index:
        raise Error(
            "brute_force_knn_impl: k > n_index. Their `n < k` short-fill at"
            " knn_brute_force.cuh:157-166 is not implemented and the implemented radix"
            " selector cannot take k > len; see the lane file."
        )

    # Their four conditions, unchanged, AND our own method switch. The
    # switch is a separate clause rather than a rewrite of theirs so that
    # `knn_method = KNN_METHOD_FUSED` restores their dispatch exactly. The
    # AUTO default asks the launch computation itself which regime this shape
    # is in; see DEVIATION 36 above the constants for the measurements.
    var mtr = resolve_metric(metric, is_sqrt)

    # THEIR FOURTH CONDITION, `:444-447`, as a value test.
    var metric_is_fusable = (
        mtr == DIST_L2_UNEXPANDED
        or mtr == DIST_L2_SQRT_UNEXPANDED
        or mtr == DIST_L2_EXPANDED
        or mtr == DIST_L2_SQRT_EXPANDED
    )
    # ...and OUR narrower one. `fused_l2_knn` carries only the EXPANDED
    # half of their set (the file's own docstring says so: it is the
    # `Policy2x8` expanded kernel), so an explicitly requested
    # `L2Unexpanded` / `L2SqrtUnexpanded` takes the tiled arm here where
    # cuVS would fuse it. That is a MISSING ARM, not a different answer:
    # `metric_distance_kernel`'s `l2_unexp_core` is their unexpanded op,
    # and it is the same distance their fused kernel would compute by the
    # other identity. Recorded in `neighbors/NOT_IMPLEMENTED.tsv`.
    var fused_arm_carries = (
        mtr == DIST_L2_EXPANDED or mtr == DIST_L2_SQRT_EXPANDED
    )

    var want_fused = knn_method == KNN_METHOD_FUSED
    if knn_method == KNN_METHOD_AUTO:
        comptime if GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL:
            # THE ARM PIN, IDENTITY_PATHS row 23. AUTO normally chooses by
            # SHAPE -- fused when the launch computation says `grid_x == 1`,
            # tiled when it would engage the x-split -- and the two arms
            # resolve a tie in the k-th distance differently: the tiled arm's
            # composite key takes the LOWEST INDEX (DEVIATION 500) while the
            # fused arm's FAISS queue compares the distance only. A
            # shape-dependent arm therefore makes the ANSWER depend on how
            # many queries the caller happened to pass, which is not a
            # property an identical column can have.
            #
            # DEVIATION 509 SUPERSEDES 502'S CHOICE OF ARM, and the reason is
            # a column, not a preference. 502 pinned AUTO to the FUSED arm
            # (cuVS's own dispatch, `knn_brute_force.cuh:443`) and that is
            # well-defined on a 32-lane column -- but `fused_l2_knn` REFUSES
            # at its entry wherever `lib_lane_width_for[TARGET_COLUMN]() !=
            # 32`, because the FAISS queue is a 32-lane bitonic network and
            # a 64-wide wavefront addresses the wrong half of it (row 23's
            # own refusal). So under 502 the IDENTICAL build of k-NN did not
            # merely lose its tie guarantee on AMD, it RAISED: the pinned
            # arm was one that cannot exist on one of the three columns this
            # tree claims. A dispatch that is unrunnable on a column is not
            # that column's dispatch.
            #
            # AUTO therefore pins to the TILED arm on EVERY column under
            # IDENTICAL. That arm is the one whose answer is NAMED rather
            # than merely reproducible:
            #
            #   - `select_radix_identical` ranks over the composite
            #     `(twiddle_in(distance) << 32) | index` key, so equidistant
            #     neighbours come back LOWEST INDEX FIRST by construction and
            #     the tie class does not exist (DEVIATIONS 500, 501);
            #   - `pinned_distance_tile` accumulates each cell in ONE thread
            #     over the whole feature axis, ascending, with no vendor
            #     matmul and no k-split (DEVIATION 505);
            #   - neither kernel contains a warp primitive or reads a lane
            #     width, and the selector's only block collective is a
            #     prefix sum over Int32 histogram counts, which is exact at
            #     any tree shape.
            #
            # The price is measured, not argued: `price-unsupervised-identity`
            # puts `knn.tiled` at 2.85x `knn.auto`'s FAST arm on the M4, so
            # this is what the identical column costs for `k <= 64`. It buys
            # the only thing the column is for -- the same bits on Metal, PTX
            # and AMDGPU -- and it buys it on all three rather than on two.
            #
            # `KNN_METHOD_FUSED` is untouched: it restores their dispatch
            # exactly, keeps 502's `grid_x = 1` pin so its tie set stays a
            # pure function of `(m, n, k)`, and keeps refusing on a column
            # whose lane width is neither32 nor64 (IDENTICAL logical32 groups).
            want_fused = False
        else:
            comptime if knn_auto_follows_their_dispatch_for[
                TARGET_COLUMN, False
            ]():
                # DEVIATION 1923 (kernel-matrix row): on this column AUTO
                # restores cuVS's dispatch UNCONDITIONALLY -- fused for the
                # whole `k <= 64` row-major L2 band, x-split and mutex merge
                # included. DEVIATION 36's `grid_x == 1` gate was measured
                # entirely on Apple milliseconds (the Metal x-split cliff,
                # 0.19x at 500-1,000 queries); on the vendor whose own
                # scheduler the mutex protocol was written for, the gate was
                # sending the H100's 4,000-query benchmark shape to the
                # TILED arm cuVS never takes there. The row's docstring in
                # `checks/kernel_matrix.mojo` carries the argument;
                # `run_knn`'s `ours-fused` / `ours-tiled` arms are the A/B
                # that confirms or flips it.
                want_fused = True
            else:
                var g = fused_l2_knn_grid(n_queries, n_index)
                want_fused = g[0] == 1

    # DEVIATION 512: THE ARM MUST EXIST ON THIS COLUMN BEFORE AUTO PICKS IT.
    #
    # Found by compiling this file against `MOJOLEARN_COLUMN_AMD` on the Mac
    # (2026-08-23), which is a build the four-column matrix supports and
    # nothing had ever run: `check_knn_fused_tie_set_is_geometry_invariant`
    # died with `fusedL2kNN: the FAISS warp queue is a 32-lane bitonic
    # network and this target column's lane width is 64`.
    #
    # HISTORICAL refusal (row23), now retained outside IDENTICAL. The
    # IDENTICAL CDNA path uses explicit logical32 queue collectives.
    # Before that closure the refusal was reached through the
    # DEFAULT. `fused_l2_knn` is refused wherever the lane width is not 32,
    # but AUTO's geometry test does not know that, so on a 64-wide wavefront
    # every `k <= 64` row-major query whose launch computation returns
    # `grid_x == 1` -- the COMMON shape, and the one DEVIATION 36 measured
    # the fused arm to be fastest at -- raised instead of running. A caller
    # who never named an arm got an exception for a shape class, on a
    # vendor, in the SHIPPED mode. Under IDENTICAL, DEVIATION 509 had
    # already moved AUTO off the fused arm; this is the same hole in FAST,
    # and it is a correctness bug rather than an identity one.
    #
    # Outside IDENTICAL the refusal stays for an EXPLICIT
    # `KNN_METHOD_FUSED`: asking for an arm this column cannot express
    # should say so rather than silently substituting another one with a
    # different tie rule. AUTO, which by definition did not ask, takes the
    # tiled arm.
    comptime fused_arm_exists = lib_lane_width_for[TARGET_COLUMN]() == 32 or (GLOBAL_NUMERIC_MODE == NUMERIC_IDENTICAL and lib_lane_width_for[TARGET_COLUMN]() == 64)
    comptime if not fused_arm_exists:
        if knn_method == KNN_METHOD_AUTO:
            want_fused = False

    # A METRIC OUTSIDE THE FUSABLE SET IS NOT AN ERROR, IT IS THEIR `else`.
    # `KNN_METHOD_FUSED` asks for an arm; asking for it with cosine or Lp
    # is asking for an arm that does not exist upstream either, so it is
    # refused BY NAME rather than silently substituted -- the same rule
    # DEVIATION 512 applies to a column whose lane width cannot express
    # the FAISS queue.
    if knn_method == KNN_METHOD_FUSED and not fused_arm_carries:
        raise Error(
            "brute_force_knn_impl: KNN_METHOD_FUSED was asked for with"
            " metric "
            + String(mtr)
            + "; fusedL2Knn covers only the L2 expanded pair"
            " (knn_brute_force.cuh:444-447 admits four L2 tags and cuVS"
            " itself never fuses cosine or Lp). Use KNN_METHOD_AUTO or"
            " KNN_METHOD_TILED."
        )
    if not metric_is_fusable or not fused_arm_carries:
        want_fused = False

    var fused_ok = (
        k <= FKNN_MAX_NN
        and row_major_query == row_major_index
        and row_major_query
        and want_fused
    )
    if fused_ok:
        fused_l2_knn(
            ctx,
            queries,
            query_norm,
            index,
            index_norm,
            out_dist,
            out_idx,
            n_queries,
            n_index,
            n_features,
            k,
            is_sqrt,
        )
    else:
        tiled_brute_force_knn(
            ctx,
            queries,
            query_norm,
            index,
            index_norm,
            dist_tile,
            buf_val,
            buf_idx,
            out_dist,
            out_idx,
            out_idx32,
            n_queries,
            n_index,
            n_features,
            k,
            query_tile,
            buf_len,
            is_sqrt,
            use_vendor_topk,
            mtr,
            metric_arg,
        )
