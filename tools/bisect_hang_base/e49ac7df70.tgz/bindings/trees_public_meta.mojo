# SPDX-License-Identifier: Apache-2.0
# The meta-estimators' public operations in one native call each:
# VotingClassifier/VotingRegressor, StackingClassifier/StackingRegressor,
# MultiOutputRegressor/MultiOutputClassifier, OneVsRestClassifier and
# CalibratedClassifierCV (python/mojolearn/_expansion_trees.py). This is the
# Python orchestration those methods ran, step for step: the parameter checks
# with their wording, the member clones, the cv folds, the x_trees glue
# kernels in the same order with the same arguments, and the fitted state.
#
# Members are exact built-in mojolearn estimators with connected ABI plans.
# Clone, fit and prediction call those compiled operations directly; Python
# methods, constructors, property hooks and custom splitters never execute.
#
# Round trips removed against the Python path: X is converted to float32
# once per operation and handed to every member; the fold rows are copied
# out of the one device fold buffer as int32 Arrays (no memoryview list).
#
# CalibratedClassifierCV(GaussianNB) no longer takes the x_prep one-program
# fit (MOJOLEARN_CALIB_GNB_FOLDS, FAST + Apple only): that program was
# assembled by the prep family's Python program builder, so the native
# driver takes the reference route (one GaussianNB fit per fold through its
# native entry, the same calibrators). IDENTICAL never took it; the x_prep
# kernels stay in place for the prep family.
from std.python import Python, PythonObject
from bindings.py_balanced import py_call, py_type, py_get, py_contains, py_setitem, py_setattr, py_fields
from bindings.py_attr import py_attr
from bindings.native_loaded_module import native_loaded_module
from bindings.py_typed_call import py_call_typed
from bindings.classical_arrays import classical_wrap_array, _store_code
from bindings.trees_public_inputs import (
    TreesMatrix, TreesLabels, TreesView, _view_of_array, trees_builtins, trees_table, trees_entry, trees_helper, trees_empty,
    trees_vector, trees_reshape, trees_address, trees_f32, trees_view, trees_check_rank, trees_itemsize,
    trees_check_sample_weight, trees_encode_labels, trees_decode_labels, trees_cast,
)
from bindings.trees_public_forest import _check_mode, _repr, _str, _truthy, _is_bool, _is_integral, _refuse
from bindings.trees_public_boost import (
    _mode, _xt, _x, _P, _F, _A, _x_f32, _as_array, _fsum, _arange, _class_major, _gather, _gather_codes,
    _gather_vec, _gather_view, _gather_codes_view, _gather_vec_view, _argmax, _scale,
)
from bindings.trees_public_score import trees_accuracy, trees_r2
from bindings.prep_native_estimator import (
    prep_estimator_admit, prep_estimator_clone, prep_estimator_call, prep_estimator_has,
    prep_estimator_plan, prep_native_context, prep_native_split, prep_entry_call,
)
from bindings.classical_labels import _label_list
from bindings.classifier_public_lifecycle import classifier_label_list
from bindings.classical_pandas import native_pandas_exact
from bindings.native_buffer_owner import native_buffer_view
from bindings.native_array_storage import native_array_from_values
from bindings.msel_inputs import msel_admit, msel_input_count
from bindings.trees_meta_admission import meta_admit_configuration
from bindings.trees_staged_input import trees_stage_members, trees_unstage
from bindings.trees_side_records import trees_side_get, trees_side_put


comptime _F32P = MutPointer[Float32, MutUntrackedOrigin]
comptime _F64P = MutPointer[Float64, MutUntrackedOrigin]
comptime _I32P = MutPointer[Int32, MutUntrackedOrigin]
comptime _I64P = MutPointer[Int64, MutUntrackedOrigin]


# ------------------------------------------------------------- utilities


def meta_kind(model: PythonObject, context: PythonObject) raises -> String:
    """The connected meta schema of the model's class (or an ancestor)."""
    var b = trees_builtins()
    var table = context["trees_meta_classes"]
    var mro = py_call(b.type.__dict__["__mro__"].__get__, py_type(model))
    for i in range(len(mro)):  # driver-loop: over the class ancestry metadata
        var kind = py_get(table, mro[i])
        if kind is not None:
            return String(kind)
    raise Error("TypeError: the native meta-estimator owner requires a connected meta-estimator class")


def _attr(owner: PythonObject, name: String, default: PythonObject) raises -> PythonObject:
    """`getattr(owner, name, default)`."""
    return py_call(trees_builtins().getattr, owner, PythonObject(name), default)


def _has(owner: PythonObject, name: String) raises -> Bool:
    return Bool(py=py_call(trees_builtins().hasattr, owner, PythonObject(name)))


def _call_kw(callable: PythonObject, args: PythonObject, kwargs: PythonObject) raises -> PythonObject:
    """`callable(*args, **kwargs)` of a Python tuple and dict, borrowing both."""
    ref cpy = Python().cpython()
    var result = cpy.PyObject_Call(callable._obj_ptr, args._obj_ptr, kwargs._obj_ptr)
    if not result:
        raise cpy.unsafe_get_error()
    return PythonObject(from_owned=result)


def _owner(model: PythonObject) raises -> String:
    return String(py_type(model).__name__)


def _copy_block(array: PythonObject, start: Int, stop: Int, typestr: String, context: PythonObject) raises -> PythonObject:
    """`array[start:stop]` of a flat Array as a new Array: a block copy in C."""
    var b = trees_builtins()
    var item = trees_itemsize(typestr)
    var view = py_call(b.memoryview, array._store)
    var raw = py_call(py_attr(py_call(view.cast, "B"), "__getitem__"), py_call(b.slice, PythonObject(start * item), PythonObject(stop * item)))
    var store = py_call(context["array_type"], PythonObject(_store_code(typestr)))
    _ = py_call(store.frombytes, py_call(raw.tobytes))
    return classical_wrap_array(store, Python.tuple(stop - start), typestr, "C", context)


def _f64_word(array: PythonObject, index: Int) raises -> Float64:
    return _F64P(unsafe_from_address=trees_address(array))[index]


def _x_array(X: PythonObject, context: PythonObject) raises -> PythonObject:
    """`as_f32_c(X, ndim=2, name="X")` as the Array the members read."""
    var m = _x_f32(X, context)
    return _as_array(m, Python.tuple(m.rows, m.cols), context)


def _rows(array: PythonObject) raises -> Int:
    return Int(py=array.shape[0])


def _cols(array: PythonObject) raises -> Int:
    return Int(py=array.shape[1])


def _i32_vec(value: PythonObject, name: String, context: PythonObject) raises -> PythonObject:
    """`as_i32_c(value, ndim=1, name=name)` of a member's predicted codes."""
    var view = trees_view(value, name, context)
    trees_check_rank(view, 1, name)
    var n = view.shape[0]
    var out = trees_vector(n, "<i4", context)
    trees_cast(view.addr, view.typestr, trees_address(out), "<i4", n, context)
    _ = out  # keep the Python object alive through the native call above
    _ = view  # keep the Python object alive through the native call above
    _ = view^
    return out


def _f32_array(value: PythonObject, ndim: Int, name: String, context: PythonObject) raises -> PythonObject:
    """`as_f32_c(value, ndim=ndim, name=name)` as an Array."""
    var m = trees_f32(value, ndim, "C", name, context)
    var shape = Python.tuple(m.rows, m.cols) if ndim == 2 else Python.tuple(m.rows)
    return _as_array(m, shape, context)


def _out2d(x: PythonObject, n: Int, context: PythonObject) raises -> TreesMatrix:
    """`_trees_output_2d(x, n)`: a member's output as a float32 (n, c) block
    (a 1-D output is c = 1)."""
    var shape = _attr(x, "shape", Python.tuple())
    if len(shape) == 2:
        return trees_f32(x, 2, "C", "output", context)
    var v = trees_f32(x, 1, "C", "output", context)
    if v.rows != n:
        raise Error("cannot reshape Array of size " + String(v.rows) + " into shape (" + String(n) + ", 1)")
    var _keep_ret_v = TreesMatrix(v.keep, v.addr, n, 1, True)
    _ = v  # keep the Python object alive through the native call above
    return _keep_ret_v^


def _int_list(values: PythonObject) raises -> PythonObject:
    return py_call(trees_builtins().list, py_call(trees_builtins().map, trees_builtins().int, values))


def _codes_array(var values: PythonObject, context: PythonObject) raises -> PythonObject:
    """`Array.from_list([int(c) for c in values], "<i4")`."""
    var b = trees_builtins()
    # A fitted native classifier may expose ClassLabels. Read its verified
    # list storage instead of asking it for a buffer or invoking list hooks.
    values = classifier_label_list(values, context)
    var listed = values if py_type(values) is b.list or py_type(values) is b.tuple else _label_list(values, context)
    var store = py_call(context["array_type"], PythonObject("i"), _int_list(listed))
    return classical_wrap_array(store, Python.tuple(len(store)), "<i4", "C", context)


comptime _MEMBER_CODES_SLOT = "trees_meta_member_codes_v1"


def _member_class_codes(member: PythonObject, context: PythonObject) raises -> PythonObject:
    """`(classes_, listed classes, int32 code Array, index of 1 or -1)` of a
    fitted member, kept per member in the native side table (lane
    perf2-trees, 2026-11-06: every soft-vote, stacking, multi-output and
    calibrated predict rebuilt the int32 Array, one `int()` per class plus an
    `array('i')`, for every member on every call). The record is reused while
    the member's `classes_` is the recorded object and its listed labels are
    the recorded objects one by one (identity only), so a refit, a replaced
    or an in-place edited `classes_` rebuilds it. The Array is only read by
    the glue kernels (`x_trees_accumulate_cols`, the calibrated fusion), never
    written. Same values as before: no bits change."""
    var b = trees_builtins()
    var classes = _attr(member, "classes_", PythonObject(None))
    var values = classifier_label_list(classes, context)
    var listed = values if py_type(values) is b.list or py_type(values) is b.tuple else _label_list(values, context)
    var held = trees_side_get(_MEMBER_CODES_SLOT, member)
    if held is not None and held[0] is classes and len(held[1]) == len(listed):
        var same = True
        for i in range(len(listed)):  # driver-loop: over the member's fitted classes (identity only)
            if not (held[1][i] is listed[i]):
                same = False
                break
        if same:
            return held
    var subs = _int_list(listed)
    var store = py_call(context["array_type"], PythonObject("i"), subs)
    var array = classical_wrap_array(store, Python.tuple(len(store)), "<i4", "C", context)
    var at = -1
    for i in range(len(subs)):  # driver-loop: over the member's fitted classes
        if Int(py=subs[i]) == 1:
            at = i
            break
    var record = Python.tuple(classes, py_call(b.list, listed), array, PythonObject(at))
    _ = trees_side_put(_MEMBER_CODES_SLOT, member, record)
    return record


def _sub_cols(member: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_trees_sub_cols`: a member's classes (the ensemble's codes) as int32."""
    return _member_class_codes(member, context)[2]


def _index_of_one(member: PythonObject, context: PythonObject) raises -> Int:
    """`[int(c) for c in member.classes_].index(1)`, or -1 when 1 is absent."""
    return Int(py=_member_class_codes(member, context)[3])


def _one_col(xt: PythonObject, p: TreesMatrix, j: Int, context: PythonObject) raises -> PythonObject:
    """Column j of a float32 (n, c) block as an (n, 1) Array (`_gather`)."""
    var rows = _arange(xt, p.rows, context)
    var col = _codes_array(Python.list(PythonObject(j)), context)
    return _gather(xt, p.addr, p.rows, p.cols, rows, col, context)


# ------------------------------------------------------------- x_trees glue


def _acc_cols_w(xt: PythonObject, acc: PythonObject, x: PythonObject, cols: PythonObject, n: Int, k: Int,
                weight: Float64, context: PythonObject) raises:
    var xa = trees_f32(x, 2, "C", "sub-estimator output", context)
    var cols_view = _view_of_array(cols)
    _ = py_call_typed(_x(xt, "x_trees_accumulate_cols"), _A(acc), _P(xa.addr), _P(cols_view.addr),
                      Python.list(_P(n), _P(k), _P(cols_view.shape[0]), _F(weight)))
    _ = cols_view
    _ = xa  # keep the Python object alive through the native call above
    _ = xa^


def _acc_w(xt: PythonObject, acc: PythonObject, x: PythonObject, n: Int, weight: Float64,
           context: PythonObject) raises:
    var xa = trees_f32(x, 1, "C", "sub-estimator output", context)
    _ = py_call_typed(_x(xt, "x_trees_accumulate"), _A(acc), _P(xa.addr), Python.list(_P(n), _F(weight)))
    _ = xa  # keep the Python object alive through the native call above
    _ = xa^


def _acc_votes(xt: PythonObject, acc: PythonObject, codes: PythonObject, n: Int, k: Int, on: Float64) raises:
    _ = py_call_typed(_x(xt, "x_trees_accumulate_onehot"), _A(acc), _A(codes),
                      Python.list(_P(n), _P(k), _F(on), _F(0.0)))


def _place_view(xt: PythonObject, dst: TreesView, n_rows: Int, n_cols: Int, blk: TreesMatrix, rows: TreesView,
                col0: Int) raises -> Int:
    """Scatter a block using retained, operation-local Array metadata."""
    _ = py_call_typed(_x(xt, "x_trees_scatter"), _P(dst.addr), _P(blk.addr), _P(rows.addr),
                      Python.list(_P(n_rows), _P(n_cols), _P(rows.shape[0]), _P(blk.cols), _P(col0)))
    _ = dst
    _ = rows
    _ = blk  # retain every address owner until the native call completes
    return blk.cols


def _place(xt: PythonObject, dst: PythonObject, n_rows: Int, n_cols: Int, blk: TreesMatrix, rows: PythonObject,
           col0: Int) raises -> Int:
    """`_TreesWrapperBase._place`: the block's columns into dst at col0."""
    return _place_view(xt, _view_of_array(dst), n_rows, n_cols, blk, _view_of_array(rows), col0)


def _zeros(count: Int, context: PythonObject) raises -> PythonObject:
    return trees_vector(count, "<f8", context)


def _class_zero(xt: PythonObject, n: Int, context: PythonObject) raises -> PythonObject:
    """`_class_major([0.0], n)`: a zero-filled buffer (`trees_empty` fills
    zero bytes, +0.0), without the separate fill program it used to run
    (lane perf-sweep-trees, 2026-11-05). Same bits."""
    _ = xt
    return trees_vector(n, "<f8", context)


# ---------------------------------------------------------------- members


def _require_member(est: PythonObject, owner: String, context: PythonObject) raises:
    prep_estimator_admit(est, owner, context)


def _clone(est: PythonObject, context: PythonObject) raises -> PythonObject:
    return prep_estimator_clone(est, context)


def _fit_member(member: PythonObject, X: PythonObject, y: PythonObject, weights: PythonObject,
                context: PythonObject) raises:
    var keywords = Python.dict()
    if weights is not None:
        py_setitem(keywords, "sample_weight", weights)
    _ = prep_estimator_call(member, "fit", Python.tuple(X, y), context, keywords)


def _takes_weights(est: PythonObject, context: PythonObject) raises -> Bool:
    var plan = prep_estimator_plan(est, context)
    if plan is None:
        return False
    var keywords = py_get(py_get(plan, "keywords", Python.dict()), "fit", Python.tuple())
    return py_contains(keywords, PythonObject("sample_weight"))


def _member_weights(names: PythonObject, ests: PythonObject, sample_weight: PythonObject, n: Int,
                    context: PythonObject) raises -> PythonObject:
    """`_trees_member_weights`: None stays None; otherwise every member must
    take `sample_weight`, and the weights are checked once against X."""
    if sample_weight is None:
        return PythonObject(None)
    for i in range(len(ests)):  # driver-loop: over members
        if not _takes_weights(ests[i], context):
            var who = String("") if names[i] is None else " " + _str(names[i])
            raise Error("Underlying estimator" + who + " does not support sample weights.")
    var w = trees_check_sample_weight(sample_weight, n, context)
    return _as_array(w, Python.tuple(n), context)


struct Active(Copyable, Movable):
    """`_trees_estimators(estimators)`: the active names and estimators."""
    var names: PythonObject
    var ests: PythonObject

    def __init__(out self, names: PythonObject, ests: PythonObject):
        self.names = names
        self.ests = ests


def _active(estimators: PythonObject, owner: String, context: PythonObject) raises -> Active:
    var b = trees_builtins()
    if not _truthy(estimators):
        raise Error("estimators must be a non-empty list of (name, estimator)")
    var items = py_call(b.list, estimators)
    var all_names = Python.list()
    var names = Python.list()
    var ests = Python.list()
    for i in range(len(items)):  # driver-loop: over the (name, estimator) entries
        var pair = py_call(b.tuple, items[i])
        if len(pair) != 2:
            raise Error("estimators must be a non-empty list of (name, estimator)")
        _ = py_call(all_names.append, pair[0])
    if len(py_call(b.set, all_names)) != len(all_names):
        raise Error("estimator names must be unique")
    for i in range(len(items)):  # driver-loop: over the (name, estimator) entries
        var pair = py_call(b.tuple, items[i])
        var est = pair[1]
        if py_type(est) is b.str and String(est) == "drop":
            continue
        _ = py_call(names.append, pair[0])
        _ = py_call(ests.append, est)
    if len(ests) == 0:
        raise Error("all estimators are 'drop'")
    for i in range(len(ests)):  # driver-loop: over members
        _require_member(ests[i], owner, context)
    return Active(names, ests)


def _named(names: PythonObject, fitted: PythonObject) raises -> PythonObject:
    var out = Python.dict()
    for i in range(len(fitted)):  # driver-loop: over members
        py_setitem(out, names[i], fitted[i])
    return out


def _set(model: PythonObject, name: String, value: PythonObject) raises:
    py_setattr(model, name, value)


def _check_x(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_TreesWrapperBase._check_X`."""
    if not _truthy(_attr(model, "_fitted", PythonObject(False))):
        raise Error("RuntimeError: this estimator is not fitted yet")
    var Xa = _x_array(X, context)
    var fitted = Int(py=_attr(model, "n_features_in_", PythonObject(0)))
    if _cols(Xa) != fitted:
        raise Error("X has " + String(_cols(Xa)) + " features, fit saw " + String(fitted))
    return Xa


def _refuse_jobs(model: PythonObject, verbose: Bool, why: String) raises:
    if verbose:
        if _attr(model, "n_jobs", PythonObject(None)) is not None or _truthy(_attr(model, "verbose", PythonObject(0))):
            _refuse("n_jobs/verbose", why)
    elif _attr(model, "n_jobs", PythonObject(None)) is not None:
        _refuse("n_jobs", why)


# ------------------------------------------------------------------ cv folds


def _cv_value(cv: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_trees_cv(cv)`: an int number of folds (None: 5), or `cv` itself when
    it is a splitter or an iterable of (train, test) index pairs."""
    var b = trees_builtins()
    if cv is None:
        return PythonObject(5)
    var native = prep_native_context(context)
    if py_type(py_type(cv)) is b.type and py_contains(native["family_msel_splitter_layouts"], py_type(cv)):
        return cv
    if py_type(cv) is b.list or py_type(cv) is b.tuple:
        msel_admit(cv, native)
        return cv
    if py_type(cv) is not b.int:
        raise Error("TypeError: cv requires an integer, native splitter or list of index pairs; Python callbacks cannot execute")
    if _is_bool(cv) or not _is_integral(cv, context) or Bool(py=cv < PythonObject(2)):
        raise Error("cv=" + _repr(cv) + ": an int >= 2, a splitter with split(X, y), or an iterable of"
                    + " (train, test) index pairs")
    return py_call(b.int, cv)


def _index_i64(v: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_trees_index_i64`: a cv index list as an int64 Array."""
    try:
        var view = trees_view(v, "cv rows", context)
        var n = view.size()
        var out = trees_vector(n, "<i8", context)
        trees_cast(view.addr, view.typestr, trees_address(out), "<i8", n, context)
        _ = out  # keep the Python object alive through the native call above
        _ = view  # keep the Python object alive through the native call above
        _ = view^
        return out
    except:
        var store = py_call(context["array_type"], PythonObject("q"), v)
        return classical_wrap_array(store, Python.tuple(len(store)), "<i8", "C", context)


def _native_folds(xt: PythonObject, n_splits: Int, n: Int, codes: PythonObject, n_classes: Int,
                  context: PythonObject) raises -> PythonObject:
    """`_trees_native_folds`: the fold rows the device made, each fold's
    (train rows, test rows) as int32 Arrays."""
    var counts = trees_vector(n_splits + 1, "<i4", context)
    var rows = trees_vector(n_splits * n, "<i4", context)
    var c32 = counts
    var k = 0
    if codes is not None:
        c32 = codes
        k = n_classes
    var status = Int(py=py_call_typed(_x(xt, "x_trees_device_folds"), _A(c32), _A(rows), _A(counts),
                                      Python.list(_P(n), _P(n_splits), _P(k))))
    _ = c32  # keep the Python object alive through the native call above
    _ = rows  # keep the Python object alive through the native call above
    _ = counts  # keep the Python object alive through the native call above
    if status == 1:
        raise Error("n_splits=" + String(n_splits) + " cannot be greater than the number of members in each class")
    _ = c32  # keep the Python object alive through the native calls above
    _ = rows  # keep the Python object alive through the native calls above
    _ = counts  # keep the Python object alive through the native calls above
    if status != 0:
        raise Error("y codes outside [0, n_classes)")
    _ = c32  # keep the Python object alive through the native calls above
    _ = rows  # keep the Python object alive through the native calls above
    _ = counts  # keep the Python object alive through the native calls above
    var cnt = _I32P(unsafe_from_address=trees_address(counts))
    _ = counts  # keep the Python object alive through the native call above
    var used = 0
    for i in range(n_splits):  # driver-loop: over the cv folds
        if Int(cnt[i]) > 0:
            used = i
        _ = counts  # keep the Python object alive through the native calls above
    used += 1
    var out = Python.list()
    for i in range(used):  # driver-loop: over the cv folds
        var c = Int(cnt[i])
        _ = counts  # keep the Python object alive through the native call above
        var base = i * n
        var tr = _copy_block(rows, base, base + n - c, "<i4", context)
        var te = _copy_block(rows, base + n - c, base + n, "<i4", context)
        _ = py_call(out.append, Python.tuple(tr, te))
    return out


def _splits(xt: PythonObject, cv: PythonObject, X: PythonObject, y: PythonObject, n: Int, codes: PythonObject,
            partition: Bool, n_classes: Int, context: PythonObject) raises -> PythonObject:
    """`_trees_splits`: [(train rows, test rows)] as int32 Arrays."""
    var b = trees_builtins()
    var c = _cv_value(cv, context)
    var n_x = msel_input_count(X, prep_native_context(context))
    var n_y = n
    if codes is not None:
        var codes_view = _view_of_array(codes)
        n_y = codes_view.shape[0]
    if n != n_x or n != n_y or n_x != n_y:
        raise Error("Found input variables with inconsistent numbers of samples: [" + String(n_x) + ", "
                    + String(n_y) + "]")
    if py_type(c) is b.int:
        return _native_folds(xt, Int(py=c), n, codes, n_classes, context)
    var pairs = c
    if py_contains(prep_native_context(context)["family_msel_splitter_layouts"], py_type(c)):
        pairs = prep_native_split(c, X, y, context)
    var out = Python.list()
    var seen = trees_vector(n if n > 1 else 1, "<i8", context)
    var check = trees_helper(context, "check_indices_i64")
    var bincount = trees_helper(context, "bincount_i64")
    for pair in pairs:  # cpu-route: user cv splitter or iterable of index pairs, validated natively per pair
        var both = py_call(b.tuple, pair)
        if len(both) != 2:
            raise Error("each cv split must be a (train, test) pair")
        var tr = _index_i64(both[0], context)
        var te = _index_i64(both[1], context)
        var ntr = Int(py=tr.size)
        var nte = Int(py=te.size)
        if ntr == 0 or nte == 0:
            raise Error("every cv split needs train and test rows")
        if Int(py=py_call_typed(check, _A(tr), _P(ntr), _P(n))) == 1:
            raise Error("a cv index is outside [0, " + String(n) + ")")
        _ = tr  # keep the Python object alive through the native calls above
        if Int(py=py_call_typed(check, _A(te), _P(nte), _P(n))) == 1:
            raise Error("a cv index is outside [0, " + String(n) + ")")
        _ = te  # keep the Python object alive through the native calls above
        _ = py_call_typed(bincount, _A(te), _P(3), _P(nte), _P(n), _A(seen), _P(1))
        _ = te  # keep the Python object alive through the native call above
        _ = seen  # keep the Python object alive through the native call above
        var tr32 = trees_vector(ntr, "<i4", context)
        var te32 = trees_vector(nte, "<i4", context)
        trees_cast(trees_address(tr), "<i8", trees_address(tr32), "<i4", ntr, context)
        _ = tr32  # keep the Python object alive through the native call above
        _ = tr  # keep the Python object alive through the native call above
        trees_cast(trees_address(te), "<i8", trees_address(te32), "<i4", nte, context)
        _ = te32  # keep the Python object alive through the native call above
        _ = te  # keep the Python object alive through the native call above
        _ = py_call(out.append, Python.tuple(tr32, te32))
    if len(out) == 0:
        raise Error("cv produced no splits")
    if partition:
        var m = n if n > 1 else 1
        var stat = trees_helper(context, "reduce_stat")
        var low = Int(py=py_call_typed(stat, _A(seen), _P(3), _P(m), _P(0)))
        _ = seen  # keep the Python object alive through the native call above
        var high = Int(py=py_call_typed(stat, _A(seen), _P(3), _P(m), _P(1)))
        _ = seen  # keep the Python object alive through the native call above
        if low != 1 or high != 1:
            raise Error("cross_val_predict only works for partitions: every row must be in exactly one test set")
        _ = seen  # keep the Python object alive through the native calls above
    return out


# ------------------------------------------------------------------ Voting


def _voting_weights(model: PythonObject) raises -> PythonObject:
    """`VotingClassifier._weights`: one float per fitted member."""
    var b = trees_builtins()
    var m = len(_attr(model, "estimators_", Python.list()))
    var given = _attr(model, "weights", PythonObject(None))
    var w = Python.list()
    if given is None:
        for _ in range(m):  # driver-loop: over members
            _ = py_call(w.append, PythonObject(1.0))
    else:
        var items = py_call(b.list, given)
        for i in range(len(items)):  # driver-loop: over the user weights (one per member)
            _ = py_call(w.append, py_call_typed(b.float, items[i]))
    if len(w) != m:
        raise Error("weights has " + String(len(w)) + " entries, there are " + String(m) + " estimators")
    return w


def _voting_fit(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                classifier: Bool, context: PythonObject) raises -> PythonObject:
    var fields = py_fields(model)
    var owner = _owner(model)
    if classifier:
        var voting = _attr(model, "voting", PythonObject(None))
        if not py_contains(Python.tuple("hard", "soft"), voting):
            raise Error("voting must be 'hard' or 'soft'")
    _refuse_jobs(model, True, "the members fit one after another.")
    var Xa = _x_array(X, context)
    var target = y
    if classifier:
        var labels = trees_encode_labels(y, context)
        _set(model, "classes_", labels.classes)
        _set(model, "n_classes_", PythonObject(len(labels.classes)))
        target = labels.codes
    var active = _active(_attr(model, "estimators", PythonObject(None)), owner, context)
    var weights = _member_weights(active.names, active.ests, sample_weight, _rows(Xa), context)
    var fitted = Python.list()
    _set(model, "estimators_", fitted)
    for i in range(len(active.ests)):  # driver-loop: over members
        var e = _clone(active.ests[i], context)
        _fit_member(e, Xa, target, weights, context)
        _ = py_call(fitted.append, e)
    _set(model, "named_estimators_", _named(active.names, fitted))
    _set(model, "n_features_in_", PythonObject(_cols(Xa)))
    _set(model, "_fitted", PythonObject(True))
    if classifier:
        _ = _voting_weights(model)
    _ = fields
    return model


def _voting_soft(model: PythonObject, xt: PythonObject, Xa: PythonObject, context: PythonObject) raises -> PythonObject:
    """`VotingClassifier._soft`: the weighted average of the members'
    probabilities, class-major (n * k)."""
    var n = _rows(Xa)
    var k = Int(py=_attr(model, "n_classes_", PythonObject(0)))
    var acc = _class_zero(xt, n * k, context)
    var w = _voting_weights(model)
    var members = _attr(model, "estimators_", Python.list())
    for i in range(len(members)):  # driver-loop: over members
        var e = members[i]
        _acc_cols_w(xt, acc, prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context), _sub_cols(e, context), n, k, Float64(py=w[i]), context)
    _scale(xt, acc, _fsum(w, context))
    return acc


def _voting_predict_proba(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    if String(_attr(model, "voting", PythonObject(""))) == "hard":
        raise Error("AttributeError: predict_proba is not available when voting='hard'")
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var k = Int(py=_attr(model, "n_classes_", PythonObject(0)))
    return trees_reshape(_voting_soft(model, xt, Xa, context), Python.tuple(_rows(Xa), k), context)


def _voting_predict(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var k = Int(py=_attr(model, "n_classes_", PythonObject(0)))
    var acc: PythonObject
    if String(_attr(model, "voting", PythonObject(""))) == "soft":
        acc = _voting_soft(model, xt, Xa, context)
    else:
        acc = _zeros(n * k, context)
        var w = _voting_weights(model)
        var members = _attr(model, "estimators_", Python.list())
        for i in range(len(members)):  # driver-loop: over members
            _acc_votes(xt, acc, _i32_vec(prep_estimator_call(members[i], "predict", Python.tuple(Xa), context), "codes", context), n, k, Float64(py=w[i]))
    return trees_decode_labels(_attr(model, "classes_", PythonObject(None)), _argmax(xt, acc, n, k, context), context)


def _voting_transform(model: PythonObject, X: PythonObject, classifier: Bool, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var members = _attr(model, "estimators_", Python.list())
    var m = len(members)
    var soft = classifier and String(_attr(model, "voting", PythonObject(""))) == "soft"
    var k = Int(py=_attr(model, "n_classes_", PythonObject(0))) if classifier else 1
    var width = m * k if soft else m
    var out = _zeros(n * width, context)
    var rows = _arange(xt, n, context)
    for j in range(m):  # driver-loop: over members
        var e = members[j]
        if soft:
            var p = _zeros(n * k, context)
            _acc_cols_w(xt, p, prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context), _sub_cols(e, context), n, k, 1.0, context)
            var blk = trees_f32(trees_reshape(p, Python.tuple(n, k), context), 2, "C", "p", context)
            _ = _place(xt, out, n, width, blk, rows, j * k)
            _ = blk^
        else:
            var blk = _out2d(prep_estimator_call(e, "predict", Python.tuple(Xa), context), n, context)
            _ = _place(xt, out, n, width, blk, rows, j)
            _ = blk^
    return trees_reshape(out, Python.tuple(n, width), context)


def _voting_regress(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    """`VotingRegressor.predict`: the weighted average of the members'
    predictions."""
    var b = trees_builtins()
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var members = _attr(model, "estimators_", Python.list())
    var m = len(members)
    var given = _attr(model, "weights", PythonObject(None))
    var w = Python.list()
    if given is None:
        for _ in range(m):  # driver-loop: over members
            _ = py_call(w.append, PythonObject(1.0))
    else:
        var items = py_call(b.list, given)
        for i in range(len(items)):  # driver-loop: over the user weights (one per member)
            _ = py_call(w.append, py_call_typed(b.float, items[i]))
    if len(w) != m:
        raise Error("weights has " + String(len(w)) + " entries, there are " + String(m) + " estimators")
    var acc = _zeros(n, context)
    for i in range(m):  # driver-loop: over members
        _acc_w(xt, acc, prep_estimator_call(members[i], "predict", Python.tuple(Xa), context), n, Float64(py=w[i]), context)
    _scale(xt, acc, _fsum(w, context))
    return acc


# ---------------------------------------------------------------- Stacking


def _stacking_validate(model: PythonObject, context: PythonObject) raises:
    _refuse_jobs(model, True, "the members fit one after another.")
    var method = _attr(model, "stack_method", PythonObject("auto"))
    if not py_contains(Python.tuple("auto", "predict_proba", "decision_function", "predict"), method):
        raise Error("stack_method must be auto, predict_proba, decision_function or predict")
    _ = _cv_value(_attr(model, "cv", PythonObject(None)), context)


def _stack_method(model: PythonObject, est: PythonObject, classifier: Bool, context: PythonObject) raises -> PythonObject:
    """`_StackingBase._method`."""
    var method = _attr(model, "stack_method", PythonObject("auto"))
    if String(method) != "auto":
        return method
    if classifier:
        if prep_estimator_has(est, "predict_proba", context):
            return PythonObject("predict_proba")
        if prep_estimator_has(est, "decision_function", context):
            return PythonObject("decision_function")
    return PythonObject("predict")


def _stack_out(xt: PythonObject, est: PythonObject, method: String, Xs: PythonObject, n: Int, binary: Bool,
               context: PythonObject) raises -> PythonObject:
    """`_StackingBase._out`: a binary predict_proba keeps its second column."""
    var out = prep_estimator_call(est, method, Python.tuple(Xs), context)
    if method == "predict_proba" and binary:
        var p = _out2d(out, n, context)
        var col = _one_col(xt, p, 1, context)
        _ = p^
        return col
    return out


def _stacking_fit(model: PythonObject, X: PythonObject, y_full: PythonObject, codes: Bool, splits: PythonObject,
                  final: PythonObject, sample_weight: PythonObject, classifier: Bool,
                  context: PythonObject) raises -> PythonObject:
    """`_StackingBase._fit_stack`. `y_full` is the int32 codes (classifier)
    or the float32 targets (regressor); a fold's targets are gathered."""
    var owner = _owner(model)
    var xt = _xt(py_fields(model), context)
    var Xa = _x_array(X, context)
    # This call owns the admitted X, y and optional weight storage. Member
    # fits cannot replace these local owners. A subsequent fit admits afresh.
    var x_view = _view_of_array(Xa)
    var y_view = _view_of_array(y_full)
    var n = x_view.shape[0]
    var d = x_view.shape[1]
    var active = _active(_attr(model, "estimators", PythonObject(None)), owner, context)
    _require_member(final, owner, context)
    var all_names = py_call(trees_builtins().list, active.names)
    var all_ests = py_call(trees_builtins().list, active.ests)
    _ = py_call(all_names.append, PythonObject("final_estimator"))
    _ = py_call(all_ests.append, final)
    var sw = _member_weights(all_names, all_ests, sample_weight, n, context)
    var sw_addr = 0
    if sw is not None:
        sw_addr = trees_address(sw)
    var fitted = Python.list()
    _set(model, "estimators_", fitted)
    for i in range(len(active.ests)):  # driver-loop: over members
        var e = _clone(active.ests[i], context)
        _fit_member(e, Xa, y_full, sw, context)
        _ = py_call(fitted.append, e)
    var methods = Python.list()
    var native_methods = List[String]()
    for i in range(len(fitted)):  # driver-loop: over members
        var method = _stack_method(model, fitted[i], classifier, context)
        _ = py_call(methods.append, method)
        native_methods.append(String(method))
    _set(model, "stack_method_", methods)
    var binary = _truthy(_attr(model, "_binary", PythonObject(False)))
    var passthrough = _truthy(_attr(model, "passthrough", PythonObject(False)))
    var head_n = n if n < 2 else 2
    var head = _gather(xt, x_view.addr, n, d, _arange(xt, head_n, context), _arange(xt, d, context), context)
    _ = Xa  # keep the Python object alive through the native call above
    var widths = Python.list()
    var native_widths = List[Int]()
    var total = 0
    for i in range(len(fitted)):  # driver-loop: over members
        var blk = _out2d(_stack_out(xt, fitted[i], native_methods[i], head, head_n, binary, context), 2, context)
        _ = Xa  # keep the Python object alive through the native call above
        _ = py_call(widths.append, PythonObject(blk.cols))
        native_widths.append(blk.cols)
        total += blk.cols
        _ = blk^
    var width = total + (d if passthrough else 0)
    var meta = _zeros(n * width, context)
    var meta_view = _view_of_array(meta)
    var cols_view = _view_of_array(_arange(xt, d, context))
    for f in range(len(splits)):  # driver-loop: over the cv folds
        # Each fold has different index buffers; snapshot them once here,
        # then share the retained native descriptors across all its members.
        var tr_view = _view_of_array(splits[f][0])
        var te_view = _view_of_array(splits[f][1])
        var col0 = 0
        # The fold's train/test gathers are the same for every member: made
        # once per fold, not once per member (p3-trees; folds x members host
        # copies of X, y and the weights before). Members never write their
        # inputs (the scikit-learn fit contract), so sharing them is safe.
        var y_tr: PythonObject
        if codes:
            y_tr = _gather_codes_view(xt, y_view, tr_view, context)
        else:
            y_tr = _gather_vec_view(xt, y_view.addr, y_view.shape[0], tr_view, context)
        var w_tr = PythonObject(None)
        if sw is not None:
            w_tr = _gather_vec_view(xt, sw_addr, n, tr_view, context)
            _ = sw  # keep the Python object alive through the native call above
        var Xtr = _gather_view(xt, x_view.addr, n, d, tr_view, cols_view, context)
        _ = Xa  # keep the Python object alive through the native call above
        var Xte = _gather_view(xt, x_view.addr, n, d, te_view, cols_view, context)
        _ = Xa  # keep the Python object alive through the native call above
        for i in range(len(active.ests)):  # driver-loop: over members
            var e = _clone(active.ests[i], context)
            _fit_member(e, Xtr, y_tr, w_tr, context)
            var blk = _out2d(_stack_out(xt, e, native_methods[i], Xte, te_view.shape[0], binary, context), te_view.shape[0], context)
            _ = Xa  # keep the Python object alive through the native call above
            var got = _place_view(xt, meta_view, n, width, blk, te_view, col0)
            _ = blk^
            if got != native_widths[i]:
                raise Error("a member's output width changed between folds (a class missing from a fold)")
            col0 += got
    if passthrough:
        var xb = TreesMatrix(Xa, x_view.addr, n, d, True)
        _ = Xa  # keep the Python object alive through the native call above
        _ = _place_view(xt, meta_view, n, width, xb, _view_of_array(_arange(xt, n, context)), total)
        _ = Xa  # keep the Python object alive through the native call above
        _ = xb^
        _ = Xa  # keep the Python object alive through the native call above
    _ = x_view
    _ = y_view
    _set(model, "_widths_", widths)
    _set(model, "named_estimators_", _named(active.names, fitted))
    var final_ = _clone(final, context)
    _set(model, "final_estimator_", final_)
    var meta32 = _f32_array(trees_reshape(meta, Python.tuple(n, width), context), 2, "meta", context)
    _fit_member(final_, meta32, y_full, sw, context)
    _set(model, "n_features_in_", PythonObject(d))
    _set(model, "_fitted", PythonObject(True))
    return model


def _stacking_transform(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_StackingBase.transform`: the meta features (float64)."""
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var x_view = _view_of_array(Xa)
    var n = x_view.shape[0]
    var d = x_view.shape[1]
    var widths = _attr(model, "_widths_", Python.list())
    var total = 0
    for i in range(len(widths)):  # driver-loop: over members
        total += Int(py=widths[i])
    var passthrough = _truthy(_attr(model, "passthrough", PythonObject(False)))
    var width = total + (d if passthrough else 0)
    var meta = _zeros(n * width, context)
    var meta_view = _view_of_array(meta)
    var rows_view = _view_of_array(_arange(xt, n, context))
    var binary = _truthy(_attr(model, "_binary", PythonObject(False)))
    var col0 = 0
    var members = _attr(model, "estimators_", Python.list())
    var methods = _attr(model, "stack_method_", Python.list())
    for i in range(len(members)):  # driver-loop: over members
        var blk = _out2d(_stack_out(xt, members[i], String(methods[i]), Xa, n, binary, context), n, context)
        col0 += _place_view(xt, meta_view, n, width, blk, rows_view, col0)
        _ = blk^
    if passthrough:
        var xb = TreesMatrix(Xa, x_view.addr, n, d, True)
        _ = Xa  # keep the Python object alive through the native call above
        _ = _place_view(xt, meta_view, n, width, xb, rows_view, col0)
        _ = Xa  # keep the Python object alive through the native call above
        _ = xb^
        _ = Xa  # keep the Python object alive through the native call above
    _ = x_view
    return trees_reshape(meta, Python.tuple(n, width), context)


def _stacking_classifier_fit(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                             context: PythonObject) raises -> PythonObject:
    _stacking_validate(model, context)
    var labels = trees_encode_labels(y, context)
    _set(model, "classes_", labels.classes)
    var k = len(labels.classes)
    _set(model, "_binary", PythonObject(k == 2))
    var xt = _xt(py_fields(model), context)
    var splits = _splits(xt, _attr(model, "cv", PythonObject(None)), X, y, labels.n, labels.codes, True, k, context)
    var final = _attr(model, "final_estimator", PythonObject(None))
    if final is None:
        final = prep_estimator_clone(context["native_estimator_defaults"]["LogisticRegression"], context)
    return _stacking_fit(model, X, labels.codes, True, splits, final, sample_weight, True, context)


def _stacking_regressor_fit(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                            context: PythonObject) raises -> PythonObject:
    _stacking_validate(model, context)
    var y32 = _f32_array(y, 1, "y", context)
    var xt = _xt(py_fields(model), context)
    var splits = _splits(xt, _attr(model, "cv", PythonObject(None)), X, y, _rows(y32), PythonObject(None), True, 0,
                         context)
    var final = _attr(model, "final_estimator", PythonObject(None))
    if final is None:
        final = prep_estimator_clone(context["native_estimator_defaults"]["Ridge"], context)
    return _stacking_fit(model, X, y32, False, splits, final, sample_weight, False, context)


def _stacking_meta32(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    return _f32_array(_stacking_transform(model, X, context), 2, "meta", context)


def _stacking_predict(model: PythonObject, X: PythonObject, classifier: Bool, context: PythonObject) raises -> PythonObject:
    var final_ = _attr(model, "final_estimator_", PythonObject(None))
    var Xm = _stacking_meta32(model, X, context)
    if not classifier:
        return prep_estimator_call(final_, "predict", Python.tuple(Xm), context)
    var codes = _i32_vec(prep_estimator_call(final_, "predict", Python.tuple(Xm), context), "codes", context)
    return trees_decode_labels(_attr(model, "classes_", PythonObject(None)), codes, context)


def _stacking_predict_proba(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var final_ = _attr(model, "final_estimator_", PythonObject(None))
    var k = len(_attr(model, "classes_", Python.list()))
    var Xm = _stacking_meta32(model, X, context)
    var n = _rows(Xm)
    var xt = _xt(py_fields(model), context)
    var acc = _class_zero(xt, n * k, context)
    _acc_cols_w(xt, acc, prep_estimator_call(final_, "predict_proba", Python.tuple(Xm), context), _sub_cols(final_, context), n, k, 1.0, context)
    return trees_reshape(acc, Python.tuple(n, k), context)


# ------------------------------------------------------------- MultiOutput


def _multioutput_y(Y: PythonObject) raises:
    """`_trees_multioutput_y`: scikit-learn's refusal of a 1-D target."""
    var b = trees_builtins()
    var nd = _attr(Y, "ndim", PythonObject(None))
    if nd is None and Bool(py=py_call(b.isinstance, Y, Python.tuple(b.list, b.tuple))):
        var nested = len(Y) > 0 and Bool(py=py_call(b.isinstance, Y[0], Python.tuple(b.list, b.tuple)))
        nd = PythonObject(2 if nested else 1)
    if nd is not None and Int(py=py_call(b.int, nd)) < 2:
        raise Error("y must have at least two dimensions for multi-output regression but has only one.")


def _ridge_multi_entry(model: PythonObject, est: PythonObject, sample_weight: PythonObject,
                       context: PythonObject) raises -> PythonObject:
    """`_multiout_ridge_entry`: the estimators binding table when it has the
    one-program ridge (FAST + Apple builds) and `est` is a plain Ridge, else
    None."""
    var ridge = py_type(context["native_estimator_defaults"]["Ridge"])
    var plain = py_type(est) is ridge
    if plain:
        # Ridge checks its parameters at fit; this route skips Ridge.fit.
        _ = prep_estimator_call(est, "validate_params", Python.tuple(), context)
    if sample_weight is not None or not plain or _truthy(_attr(est, "normalize", PythonObject(False))):
        return PythonObject(None)
    try:
        var table = trees_table(context, _mode(py_fields(est), context), "_mojolearn_estimators")
        if trees_entry(table, "ridge_fit_multi") is None:
            return PythonObject(None)
        return table
    except:
        return PythonObject(None)


def _multioutput_ridge_fit(model: PythonObject, table: PythonObject, Xa: PythonObject, Ya: PythonObject,
                           context: PythonObject) raises -> PythonObject:
    """`MultiOutputRegressor._fit_ridge_multi`: every target in one ridge
    program (glm/impl/ridge_multi.mojo)."""
    var n = _rows(Xa)
    var d = _cols(Xa)
    var m = _cols(Ya)
    var est = _attr(model, "estimator", PythonObject(None))
    var intercept = _truthy(_attr(est, "fit_intercept", PythonObject(True)))
    var xm: PythonObject
    var work_x = Xa
    if intercept:
        # `_column_means(b, Xa, None)` (`_means`: lm_col_sums, lm_means_finish)
        # then `_center` (lm_center).
        var sums = _zeros(d, context)
        _ = py_call_typed(trees_entry(table, "lm_col_sums"), _A(Xa), _A(sums), Python.list(_P(n), _P(d)))
        _ = sums  # keep the Python object alive through the native call above
        var m64 = _zeros(d, context)
        xm = trees_vector(d, "<f4", context)
        _ = py_call_typed(trees_entry(table, "lm_means_finish"), _A(sums), _A(m64), _A(xm),
                          Python.list(_P(d), _P(n), _P(0)), _F(0.0))
        _ = m64  # keep the Python object alive through the native call above
        _ = sums  # keep the Python object alive through the native call above
        work_x = trees_empty(Python.tuple(n, d), "<f4", context)
        _ = py_call_typed(trees_entry(table, "lm_center"), _A(Xa), _A(xm), _A(work_x), Python.list(_P(n), _P(d)))
        _ = work_x  # keep the Python object alive through the native call above
    else:
        xm = trees_vector(d, "<f4", context)
    var coef = trees_vector(m * d, "<f4", context)
    var ymean = trees_vector(m, "<f4", context)
    var icpt32 = trees_vector(m, "<f4", context)
    var params = Python.list(_P(n), _P(d), _P(m), py_call_typed(trees_builtins().float, _attr(est, "alpha", PythonObject(1.0))),
                             _P(1 if intercept else 0))
    if intercept:
        _ = py_call(params.append, _A(xm))
        _ = py_call(params.append, _A(icpt32))
        _ = icpt32  # keep the Python object alive through the native call above
    _ = py_call_typed(trees_entry(table, "ridge_fit_multi"), _A(work_x), _A(Ya), _A(coef), _A(ymean), params)
    _ = icpt32  # keep the Python object alive through the native call above
    _ = ymean  # keep the Python object alive through the native call above
    _ = coef  # keep the Python object alive through the native call above
    _ = work_x  # keep the Python object alive through the native call above
    var fitted = Python.list()
    var ym = _F32P(unsafe_from_address=trees_address(ymean))
    _ = ymean  # keep the Python object alive through the native call above
    var ic = _F32P(unsafe_from_address=trees_address(icpt32))
    _ = icpt32  # keep the Python object alive through the native call above
    for j in range(m):  # driver-loop: over the output columns (one fitted ridge each)
        var e = _clone(est, context)
        _set(e, "solver_", PythonObject("eig"))
        _set(e, "coef_", _copy_block(coef, j * d, (j + 1) * d, "<f4", context))
        _set(e, "_x_mean", xm)
        _set(e, "_y_mean", PythonObject(Float64(ym[j]) if intercept else 0.0))
        _ = ymean  # keep the Python object alive through the native call above
        _set(e, "intercept_", PythonObject(Float64(ic[j]) if intercept else 0.0))
        _ = icpt32  # keep the Python object alive through the native call above
        _set(e, "n_features_in_", PythonObject(d))
        _ = py_call(fitted.append, e)
    _set(model, "estimators_", fitted)
    _set(model, "_multi_ridge", Python.tuple(coef, icpt32, m))
    _set(model, "n_features_in_", PythonObject(d))
    _set(model, "_fitted", PythonObject(True))
    return model


def _multioutput_regressor_fit(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                               context: PythonObject) raises -> PythonObject:
    _refuse_jobs(model, False, "the columns fit one after another.")
    var xt = _xt(py_fields(model), context)
    var Xa = _x_array(X, context)
    _multioutput_y(y)
    var Ya = _f32_array(y, 2, "y", context)
    if _rows(Ya) != _rows(Xa):
        raise Error("y has " + String(_rows(Ya)) + " rows, X has " + String(_rows(Xa)))
    var est = _attr(model, "estimator", PythonObject(None))
    _require_member(est, _owner(model), context)
    var weights = _member_weights(Python.list(PythonObject(None)), Python.list(est), sample_weight, _rows(Xa), context)
    _set(model, "_multi_ridge", PythonObject(None))
    var table = _ridge_multi_entry(model, est, weights, context)
    if table is not None and _cols(Ya) > 0:
        return _multioutput_ridge_fit(model, table, Xa, Ya, context)
    var n = _rows(Xa)
    var fitted = Python.list()
    _set(model, "estimators_", fitted)
    var rows = _arange(xt, n, context)
    for j in range(_cols(Ya)):  # driver-loop: over the output columns (one member each)
        var e = _clone(est, context)
        var col = _codes_array(Python.list(PythonObject(j)), context)
        var yj = trees_reshape(_gather(xt, trees_address(Ya), n, _cols(Ya), rows, col, context), Python.tuple(n), context)
        _ = Ya  # keep the Python object alive through the native call above
        _fit_member(e, Xa, yj, weights, context)
        _ = Ya  # keep the Python object alive through the native call above
        _ = py_call(fitted.append, e)
    _set(model, "n_features_in_", PythonObject(_cols(Xa)))
    _set(model, "_fitted", PythonObject(True))
    return model


def _multioutput_regressor_predict(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var members = _attr(model, "estimators_", Python.list())
    var m = len(members)
    var mr = _attr(model, "_multi_ridge", PythonObject(None))
    if mr is not None:
        var outputs = Int(py=mr[2])
        var out = trees_empty(Python.tuple(n, outputs), "<f4", context)
        var table = trees_table(context, _mode(py_fields(members[0]), context), "_mojolearn_estimators")
        _ = py_call_typed(trees_entry(table, "ridge_predict_multi"), _A(Xa), _A(mr[0]), _A(mr[1]), _A(out),
                          Python.list(_P(n), _P(_cols(Xa)), _P(outputs)))
        _ = out  # keep the Python object alive through the native call above
        _ = Xa  # keep the Python object alive through the native call above
        return out
    var out = _zeros(n * m, context)
    var rows = _arange(xt, n, context)
    for j in range(m):  # driver-loop: over members
        var blk = _out2d(prep_estimator_call(members[j], "predict", Python.tuple(Xa), context), n, context)
        _ = _place(xt, out, n, m, blk, rows, j)
        _ = blk^
    return trees_reshape(out, Python.tuple(n, m), context)


def _has_buffer(value: PythonObject) raises -> Bool:
    """`_buffer._has_buffer`: `memoryview(value)` succeeds."""
    try:
        var view = py_call(trees_builtins().memoryview, value)
        _ = py_call(view.release)
        return True
    except:
        return False


def _label_columns(Y: PythonObject, xt: PythonObject, context: PythonObject) raises -> PythonObject:
    """`_trees_label_words(Y)` then its native transpose: a numeric 2-D label
    buffer as `(T, n, m)`, T the (m, n) 8-byte words (float64 for a float
    dtype, int64 for an integer one) whose rows are the label columns; None
    for anything else (bool, str, object, nested lists, uint64), which keeps
    the Python rows."""
    var b = trees_builtins()
    var dtype = _attr(Y, "dtype", PythonObject(None))
    var nd = _attr(Y, "ndim", PythonObject(None))
    if nd is None or not Bool(py=nd == PythonObject(2)):
        return PythonObject(None)
    var kind = _attr(dtype, "kind", PythonObject(None))
    if kind is None:
        if py_type(dtype) is not b.str:
            return PythonObject(None)
        kind = py_call(py_attr(py_call(dtype.lstrip, "<>=|"), "__getitem__"), py_call(b.slice, PythonObject(0), PythonObject(1)))
    var k = String(kind)
    if k != "f" and k != "i" and k != "u":
        return PythonObject(None)
    var target = String("<f8") if k == "f" else String("<i8")
    try:
        var view = trees_view(Y, "Y", context)
        if view.ndim() != 2:
            return PythonObject(None)
        if k != "f" and view.typestr != "<i1" and view.typestr != "<i4" and view.typestr != "<i8" and view.typestr != "|i1" and view.typestr != "|u1" and view.typestr != "<u1" and view.typestr != "<u2" and view.typestr != "<u4":
            return PythonObject(None)
        var n = view.shape[0]
        var m = view.shape[1]
        var T = trees_vector(m * n, target, context)
        if view.c_order():
            var W = trees_vector(n * m, target, context)
            trees_cast(view.addr, view.typestr, trees_address(W), target, n * m, context)
            _ = W  # keep the Python object alive through the native call above
            _ = view  # keep the Python object alive through the native call above
            _ = py_call_typed(_x(xt, "x_trees_transpose_f64"), _A(W), _A(T), Python.list(_P(n), _P(m)))
            _ = W  # keep the Python object alive through the native call above
            _ = T  # keep the Python object alive through the native call above
        elif view.f_order():
            # a column-major buffer's storage is already the (m, n) columns
            trees_cast(view.addr, view.typestr, trees_address(T), target, n * m, context)
            _ = T  # keep the Python object alive through the native call above
            _ = view  # keep the Python object alive through the native call above
        else:
            return PythonObject(None)
        _ = view^
        return Python.tuple(T, n, m)
    except:
        return PythonObject(None)


def _multioutput_classifier_fit(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                                context: PythonObject) raises -> PythonObject:
    var b = trees_builtins()
    _refuse_jobs(model, False, "the columns fit one after another.")
    var Xa = _x_array(X, context)
    var n = _rows(Xa)
    var target = y
    var listed = py_type(y) is b.list or py_type(y) is b.tuple
    if not listed and native_pandas_exact(y):
        target = _label_list(y, context)
    var nd = _attr(target, "ndim", PythonObject(None))
    if nd is not None and Bool(py=nd == PythonObject(1)):
        raise Error("y must have at least two dimensions for multi-output classification but has only one.")
    _multioutput_y(target)
    var est = _attr(model, "estimator", PythonObject(None))
    _require_member(est, _owner(model), context)
    var weights = _member_weights(Python.list(PythonObject(None)), Python.list(est), sample_weight, n, context)
    var fitted = Python.list()
    var classes = Python.list()
    var columns = _label_columns(target, _xt(py_fields(model), context), context)
    if columns is not None:
        var T = columns[0]
        var rows_n = Int(py=columns[1])
        var m = Int(py=columns[2])
        if rows_n != n:
            raise Error("Y has " + String(rows_n) + " rows, X has " + String(n))
        _set(model, "estimators_", fitted)
        _set(model, "classes_", classes)
        for j in range(m):  # driver-loop: over the output columns (one member each)
            var labels = trees_encode_labels(_copy_block(T, j * rows_n, (j + 1) * rows_n, String(T.dtype), context), context)
            var e = _clone(est, context)
            _fit_member(e, Xa, labels.codes, weights, context)
            _ = py_call(fitted.append, e)
            _ = py_call(classes.append, labels.classes)
    else:
        var rows = Python.list()
        if _has(target, "tolist"):
            rows = _label_list(target, context)  # cpu-route: label objects (str/mixed) no Array holds, one output column at a time
        else:
            rows = py_call(b.list, py_call(b.map, b.list, target))  # cpu-route: label objects (str/mixed) no Array holds
        if len(rows) != n:
            raise Error("y has " + String(len(rows)) + " rows, X has " + String(n))
        if len(rows) > 0 and not _has(rows[0], "__len__"):
            raise Error("y must have at least two dimensions for multi-output classification but has only one.")
        var m = len(rows[0])
        _set(model, "estimators_", fitted)
        _set(model, "classes_", classes)
        var getter = native_loaded_module("operator").itemgetter
        for j in range(m):  # driver-loop: over the output columns (one member each)
            var column = py_call(b.list, py_call(b.map, py_call(getter, PythonObject(j)), rows))  # cpu-route: label objects (str/mixed) no Array holds, one output column at a time
            var labels = trees_encode_labels(column, context)
            var e = _clone(est, context)
            _fit_member(e, Xa, labels.codes, weights, context)
            _ = py_call(fitted.append, e)
            _ = py_call(classes.append, labels.classes)
    _set(model, "n_features_in_", PythonObject(_cols(Xa)))
    _set(model, "_fitted", PythonObject(True))
    return model


def _multioutput_classifier_predict(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var b = trees_builtins()
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var members = _attr(model, "estimators_", Python.list())
    var classes = _attr(model, "classes_", Python.list())
    var cols = Python.list()
    var stacked = True
    var all_int = True
    for j in range(len(members)):  # driver-loop: over members
        var col = trees_decode_labels(classes[j], _i32_vec(prep_estimator_call(members[j], "predict", Python.tuple(Xa), context), "codes", context), context)
        _ = py_call(cols.append, col)
        if py_type(col) is not context["array_class"]:
            stacked = False
        elif String(col.dtype) != "<i8":
            all_int = False
            if String(col.dtype) != "<f8":
                stacked = False
    if stacked:
        var kind = String("<i8") if all_int else String("<f8")
        var addrs = Python.list()
        var keep = Python.list()
        for j in range(len(cols)):  # driver-loop: over members
            var col = cols[j]
            if String(col.dtype) != kind:
                var wide = trees_vector(n, kind, context)
                trees_cast(trees_address(col), String(col.dtype), trees_address(wide), kind, n, context)
                _ = wide  # keep the Python object alive through the native call above
                _ = col  # keep the Python object alive through the native call above
                col = wide
            _ = py_call(keep.append, col)
            _ = py_call(addrs.append, _A(col))
            _ = col  # keep the Python object alive through the native call above
        var out = trees_vector(n * len(cols), kind, context)
        _ = py_call_typed(_x(xt, "x_trees_stack_w64"), addrs, _A(out), Python.list(_P(n)))
        _ = out  # keep the Python object alive through the native call above
        _ = keep
        return trees_reshape(out, Python.tuple(n, len(cols)), context)
    # label objects (str, mixed) no Array holds: row tuples of them
    var lists = Python.list()
    for j in range(len(cols)):  # driver-loop: over members
        var col = cols[j]
        _ = py_call(lists.append, col if py_type(col) is b.list or py_type(col) is b.tuple else _label_list(col, context))
    var ints = True
    for j in range(len(lists)):  # driver-loop: over members (each column's first label)
        if len(lists[j]) > 0 and not Bool(py=py_call(b.isinstance, lists[j][0], b.int)):
            ints = False
    var zipped = py_call(b.list, py_call(b.map, b.list, _call_kw(b.zip, py_call(b.tuple, lists), Python.dict())))  # cpu-route: label objects (str/mixed) no Array holds
    # Pack exact int/float/bool label objects (bool classes) into one numeric
    # store as before. Any other label object (str, mixed) cannot live in a
    # numeric Array: native_array_from_values refuses it, which made every
    # string-label multi-output predict raise. Those outputs are returned as
    # the per-row label lists (one list of m labels per row), the same label
    # objects the single-output classifiers return for str classes.
    var flat = Python.list()
    for i in range(len(zipped)):  # driver-loop: completed output labels
        _ = py_call(flat.extend, zipped[i])
    var store = PythonObject(None)
    try:
        store = native_array_from_values("q" if ints else "d", flat)
    except:
        return zipped
    return classical_wrap_array(store, Python.tuple(len(zipped), len(cols)), "<i8" if ints else "<f8", "C", context)


def _multioutput_classifier_proba(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var members = _attr(model, "estimators_", Python.list())
    var classes = _attr(model, "classes_", Python.list())
    var out = Python.list()
    for j in range(len(members)):  # driver-loop: over members
        var k = len(classes[j])
        var acc = _zeros(n * k, context)
        _acc_cols_w(xt, acc, prep_estimator_call(members[j], "predict_proba", Python.tuple(Xa), context), _sub_cols(members[j], context), n, k, 1.0, context)
        _ = py_call(out.append, trees_reshape(acc, Python.tuple(n, k), context))
    return out


def _multioutput_classifier_score(model: PythonObject, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
                                  context: PythonObject) raises -> PythonObject:
    """`MultiOutputClassifier.score`: the (weighted) fraction of rows whose
    every output matches."""
    var b = trees_builtins()
    var pred = _multioutput_classifier_predict(model, X, context)
    var truth = trees_view(y, "y", context)
    var shown = py_call(b.tuple, pred.shape)
    var truth_shape = Python.list()
    for k in range(truth.ndim()):  # driver-loop: over array rank metadata
        _ = py_call(truth_shape.append, PythonObject(truth.shape[k]))
    if not Bool(py=py_call(b.tuple, truth_shape) == shown):
        raise Error("y has shape " + _repr(py_call(b.tuple, truth_shape)) + ", the predictions have shape " + _repr(shown))
    var n = _rows(pred)
    var m = _cols(pred)
    # One mismatch flag per cell (the base binding's elementwise compare at
    # one exact dtype), one all-match flag per row (x_neighbors
    # `xn_row_all_zero`), then the (weighted) accuracy of those flags.
    var pdt = String(pred.dtype)
    var tdt = truth.typestr
    var t_int = tdt == "<i4" or tdt == "<i8" or tdt == "<u4" or tdt == "<u1" or tdt == "<u2" or tdt == "<i1"
    var p_int = pdt == "<i8"
    var size = n * m
    var eq = py_call(context["array_type"], PythonObject("B"), py_call(context["native_bytes_type"], size))
    var equal = trees_helper(context, "equal_elements")
    var tc = trees_vector(size, "<i8" if t_int else "<f8", context)
    trees_cast(truth.addr, tdt, trees_address(tc), "<i8" if t_int else "<f8", size, context)
    _ = tc  # keep the Python object alive through the native call above
    _ = truth  # keep the Python object alive through the native call above
    if t_int == p_int:
        _ = py_call_typed(equal, _A(tc), _A(pred), _P(3 if p_int else 1), _P(size), py_call(eq.buffer_info)[0])
        _ = tc  # keep the Python object alive through the native call above
        _ = pred  # keep the Python object alive through the native call above
    else:
        var ints = tc if t_int else pred
        var flts = pred if t_int else tc
        _ = py_call_typed(equal, _A(ints), _A(flts), _P(9), _P(size), py_call(eq.buffer_info)[0])
        _ = flts  # keep the Python object alive through the native call above
        _ = ints  # keep the Python object alive through the native call above
    _ = truth^
    var flip = py_call(b.bytes.maketrans, py_call(b.bytes, Python.list(PythonObject(0), PythonObject(1))),
                       py_call(b.bytes, Python.list(PythonObject(1), PythonObject(0))))
    var miss_u1 = py_call(context["array_type"], PythonObject("B"), py_call(py_call(eq.tobytes).translate, flip))
    var miss = trees_vector(size, "<i4", context)
    _cast_u1(miss_u1, miss, size, context)
    var hit = trees_vector(n, "<i4", context)
    var xn = trees_table(context, _mode(py_fields(model), context), "_mojolearn_x_neighbors")
    _ = py_call_typed(trees_entry(xn, "xn_row_all_zero"), Python.list(_A(miss), _A(hit)), Python.list(_P(n), _P(m)),
                      Python.list())
    _ = hit  # keep the Python object alive through the native call above
    _ = miss  # keep the Python object alive through the native call above
    var store = py_call(py_attr(py_call(context["array_type"], PythonObject("i"), Python.list(PythonObject(1))), "__mul__"), PythonObject(n))
    var ones = classical_wrap_array(store, Python.tuple(n), "<i4", "C", context)
    var mode = py_get(py_fields(model), "numeric_mode")
    return PythonObject(trees_accuracy(ones, hit, sample_weight, mode, context))


def _cast_u1(source: PythonObject, out_buf: PythonObject, size: Int, context: PythonObject) raises:
    """`astype("<i4")` of a uint8 flag store."""
    trees_cast(Int(py=py_call(source.buffer_info)[0]), "<u1", trees_address(out_buf), "<i4", size, context)


# --------------------------------------------------------------- OneVsRest


def _indicator(xt: PythonObject, codes: TreesView, j: Int, context: PythonObject) raises -> PythonObject:
    """`OneVsRestClassifier._indicator`: the 0/1 targets of class j."""
    var n = codes.shape[0]
    var yj = trees_vector(n, "<i4", context)
    _ = py_call_typed(_x(xt, "x_trees_indicator_codes"), _P(codes.addr), _A(yj), _P(0), Python.list(_P(n), _P(j)))
    _ = codes
    _ = yj  # keep the owners alive through the native call above
    return yj


def _ovr_fit(model: PythonObject, X: PythonObject, y: PythonObject, context: PythonObject) raises -> PythonObject:
    _refuse_jobs(model, True, "the classes fit one after another.")
    var xt = _xt(py_fields(model), context)
    var Xa = _x_array(X, context)
    var labels = trees_encode_labels(y, context)
    _set(model, "classes_", labels.classes)
    var k = len(labels.classes)
    if k < 2:
        raise Error("y has fewer than 2 classes")
    var est = _attr(model, "estimator", PythonObject(None))
    _require_member(est, _owner(model), context)
    var targets = Python.list()
    if k == 2:
        _ = py_call(targets.append, labels.codes)
    else:
        var codes_view = _view_of_array(labels.codes)
        for j in range(k):  # driver-loop: over the classes (one native indicator each)
            _ = py_call(targets.append, _indicator(xt, codes_view, j, context))
    var fitted = Python.list()
    _set(model, "estimators_", fitted)
    for i in range(len(targets)):  # driver-loop: over members
        var e = _clone(est, context)
        _fit_member(e, Xa, targets[i], PythonObject(None), context)
        _ = py_call(fitted.append, e)
    _set(model, "n_features_in_", PythonObject(_cols(Xa)))
    _set(model, "_fitted", PythonObject(True))
    return model


def _proba_positive(xt: PythonObject, e: PythonObject, Xa: PythonObject, context: PythonObject) raises -> PythonObject:
    """`OneVsRestClassifier._proba_positive`: predict_proba's column for
    code 1 (zeros when the member never saw it), float32 (n,)."""
    var n = _rows(Xa)
    var p = _out2d(prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context), n, context)
    var at = _index_of_one(e, context)
    if at < 0:
        _ = p^
        return trees_vector(n, "<f4", context)
    var col = _one_col(xt, p, at, context)
    _ = p^
    return trees_reshape(col, Python.tuple(n), context)


def _positive(xt: PythonObject, e: PythonObject, Xa: PythonObject, context: PythonObject) raises -> PythonObject:
    """`OneVsRestClassifier._positive`: decision_function when the member
    has one, else predict_proba's column for code 1."""
    if prep_estimator_has(e, "decision_function", context):
        return _f32_array(prep_estimator_call(e, "decision_function", Python.tuple(Xa), context), 1, "score", context)
    return _proba_positive(xt, e, Xa, context)


def _ovr_fused(xt: PythonObject, fused: PythonObject, members: PythonObject, Xa: PythonObject, n: Int, k: Int,
               decision: Bool, finish: Int, context: PythonObject) raises -> PythonObject:
    """The k > 2 OneVsRest epilogue through `x_trees_ovr_assemble`: the
    members' positive columns (`_positive` when `decision`, else
    `_proba_positive`) widened into the scores and finished (normalized, or
    the row argmax) as one device program with one readback (lane
    perf-sweep-trees, 2026-11-05; before it a gather and a scatter, each with
    its readbacks, per member). Same kernels and widening: no bit moves."""
    var keep = Python.list()
    var columns = Python.list()
    for j in range(len(members)):  # driver-loop: over members
        var e = members[j]
        if decision and prep_estimator_has(e, "decision_function", context):
            var score = _f32_array(prep_estimator_call(e, "decision_function", Python.tuple(Xa), context), 1, "score", context)
            var blk = _out2d(score, n, context)
            _ = py_call(keep.append, blk.keep)
            _ = py_call(columns.append, Python.tuple(_P(blk.addr), _P(blk.cols), _P(0)))
            _ = blk^
        else:
            var p = _out2d(prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context), n, context)
            var at = _index_of_one(e, context)
            _ = py_call(keep.append, p.keep)
            _ = py_call(columns.append, Python.tuple(_P(p.addr), _P(p.cols), _P(at)))
            _ = p^
    var out = trees_vector(n, "<i4", context) if finish == 2 else trees_vector(n * k, "<f8", context)
    _ = py_call_typed(fused, _A(out), columns, Python.list(_P(n), _P(k), _P(finish)))
    _ = out  # keep the Python object alive through the native call above
    _ = keep  # keep the members' blocks alive through the native call above
    return out


def _ovr_predict(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var classes = _attr(model, "classes_", PythonObject(None))
    var k = len(classes)
    var members = _attr(model, "estimators_", Python.list())
    if k == 2:
        return trees_decode_labels(classes, _i32_vec(prep_estimator_call(members[0], "predict", Python.tuple(Xa), context), "codes", context), context)
    var fused = py_get(xt, PythonObject("x_trees_ovr_assemble"))
    if fused is not None and len(members) == k:
        return trees_decode_labels(classes, _ovr_fused(xt, fused, members, Xa, n, k, True, 2, context), context)
    var acc = _class_zero(xt, n * k, context)
    var rows = _arange(xt, n, context)
    for j in range(len(members)):  # driver-loop: over members
        var blk = _out2d(_positive(xt, members[j], Xa, context), n, context)
        _ = _place(xt, acc, n, k, blk, rows, j)
        _ = blk^
    return trees_decode_labels(classes, _argmax(xt, acc, n, k, context), context)


def _ovr_predict_proba(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var k = len(_attr(model, "classes_", Python.list()))
    var members = _attr(model, "estimators_", Python.list())
    if k == 2:
        # `_trees_binary_proba`: rows (1 - p, p) of the positive column
        var p = _f32_array(_proba_positive(xt, members[0], Xa, context), 1, "p", context)
        var out = trees_vector(2 * n, "<f8", context)
        _ = py_call_typed(_x(xt, "x_trees_binary_proba"), _A(p), _A(out), Python.list(_P(n)))
        _ = out  # keep the Python object alive through the native call above
        _ = p  # keep the Python object alive through the native call above
        return trees_reshape(out, Python.tuple(n, 2), context)
    var fused = py_get(xt, PythonObject("x_trees_ovr_assemble"))
    if fused is not None and len(members) == k:
        return trees_reshape(_ovr_fused(xt, fused, members, Xa, n, k, False, 1, context), Python.tuple(n, k), context)
    var acc = _class_zero(xt, n * k, context)
    var rows = _arange(xt, n, context)
    for j in range(len(members)):  # driver-loop: over members
        var blk = _out2d(_proba_positive(xt, members[j], Xa, context), n, context)
        _ = _place(xt, acc, n, k, blk, rows, j)
        _ = blk^
    _ = py_call_typed(_x(xt, "x_trees_normalize_rows"), _A(acc), Python.list(_P(n), _P(k)))
    _ = acc  # keep the Python object alive through the native call above
    return trees_reshape(acc, Python.tuple(n, k), context)


# ------------------------------------------------------------- Calibration


def _calibrated_validate(model: PythonObject, context: PythonObject) raises:
    var method = _attr(model, "method", PythonObject("sigmoid"))
    if not py_contains(Python.tuple("sigmoid", "isotonic"), method):
        raise Error("method must be 'sigmoid' or 'isotonic'")
    _refuse_jobs(model, False, "the folds fit one after another.")
    var ensemble = _attr(model, "ensemble", PythonObject(True))
    if not py_contains(Python.tuple(True, False), ensemble):
        _refuse("ensemble=" + _repr(ensemble), "True or False.")
    _ = _cv_value(_attr(model, "cv", PythonObject(None)), context)


def _cal_scores(model: PythonObject, xt: PythonObject, e: PythonObject, Xa: PythonObject,
                context: PythonObject) raises -> PythonObject:
    """`CalibratedClassifierCV._scores`: (n, c) float64 scores, c = 1 when
    binary, else one column per class."""
    var n = _rows(Xa)
    var k = len(_attr(model, "classes_", Python.list()))
    var out: PythonObject
    if prep_estimator_has(e, "decision_function", context):
        out = prep_estimator_call(e, "decision_function", Python.tuple(Xa), context)
    else:
        out = prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context)
    var blk = _out2d(out, n, context)
    if k == 2:
        var acc = _zeros(n, context)
        if blk.cols == 1:
            _ = py_call_typed(_x(xt, "x_trees_accumulate"), _A(acc), _P(blk.addr), Python.list(_P(n), _F(1.0)))
            _ = acc  # keep the Python object alive through the native call above
            _ = blk  # keep the Python object alive through the native call above
        else:
            var at = _index_of_one(e, context)
            if at < 0:
                raise Error("1 is not in list")
            var col = _one_col(xt, blk, at, context)
            _ = py_call_typed(_x(xt, "x_trees_accumulate"), _A(acc), _A(col), Python.list(_P(n), _F(1.0)))
            _ = col  # keep the Python object alive through the native call above
            _ = acc  # keep the Python object alive through the native call above
        _ = blk^
        return trees_reshape(acc, Python.tuple(n, 1), context)
    var acc = _class_zero(xt, n * k, context)
    # Keep the freshly allocated class-index array until accumulate_cols has
    # consumed it. _A(_sub_cols(...)) returned only an address to a temporary.
    var sub_cols = _sub_cols(e, context)
    _ = py_call_typed(_x(xt, "x_trees_accumulate_cols"), _A(acc), _P(blk.addr), _A(sub_cols),
                      Python.list(_P(n), _P(k), _P(len(_attr(e, "classes_", Python.list()))), _F(1.0)))
    _ = sub_cols
    _ = acc  # keep the Python object alive through the native call above
    _ = blk^
    return trees_reshape(acc, Python.tuple(n, k), context)


def _fit_calibrators(model: PythonObject, xt: PythonObject, S: PythonObject, codes: PythonObject,
                     context: PythonObject) raises -> PythonObject:
    """`CalibratedClassifierCV._fit_calibrators`: one calibrator per class
    column, the column and its 0/1 target made natively."""
    var n = _rows(S)
    var c = _cols(S)
    var sigmoid = String(_attr(model, "method", PythonObject("sigmoid"))) == "sigmoid"
    var St = S
    if c > 1:
        St = trees_vector(c * n, "<f8", context)
        _ = py_call_typed(_x(xt, "x_trees_transpose_f64"), _A(S), _A(St), Python.list(_P(n), _P(c)))
        _ = St  # keep the Python object alive through the native call above
    var yj = trees_vector(n, "<i4", context)
    var y64 = PythonObject(None)
    if not sigmoid:
        y64 = trees_vector(n, "<f8", context)
    var cals = Python.list()
    for j in range(c):  # driver-loop: over the class columns (one calibrator each)
        var cls = 1 if c == 1 else j
        var f = trees_address(St) + 8 * j * n
        _ = St  # keep the Python object alive through the native call above
        _ = py_call_typed(_x(xt, "x_trees_indicator_codes"), _A(codes), _A(yj),
                          _A(y64) if y64 is not None else _P(0), Python.list(_P(n), _P(cls)))
        _ = yj  # keep the Python object alive through the native call above
        _ = y64  # keep the Python object alive through the native call above
        if sigmoid:
            var ab = trees_vector(2, "<f8", context)
            _ = py_call_typed(_x(xt, "x_trees_platt_fit"), _P(f), _A(yj), _A(ab), Python.list(_P(n)))
            _ = ab  # keep the Python object alive through the native call above
            _ = yj  # keep the Python object alive through the native call above
            _ = St  # keep the Python object alive through the native call above
            _ = py_call(cals.append, Python.tuple(PythonObject("sigmoid"),
                                                  Python.tuple(PythonObject(_f64_word(ab, 0)), PythonObject(_f64_word(ab, 1)))))
        else:
            var kx = trees_vector(n, "<f8", context)
            var ky = trees_vector(n, "<f8", context)
            var m = Int(py=py_call_typed(_x(xt, "x_trees_isotonic_fit"), _P(f), _A(y64), _A(kx), _A(ky), Python.list(_P(n))))
            _ = ky  # keep the Python object alive through the native call above
            _ = kx  # keep the Python object alive through the native call above
            _ = y64  # keep the Python object alive through the native call above
            _ = St  # keep the Python object alive through the native call above
            _ = py_call(cals.append, Python.tuple(PythonObject("isotonic"),
                                                  Python.tuple(_copy_block(kx, 0, m, "<f8", context),
                                                               _copy_block(ky, 0, m, "<f8", context), PythonObject(m))))
            _ = ky  # keep the Python object alive through the native call above
            _ = kx  # keep the Python object alive through the native call above
            _ = y64  # keep the Python object alive through the native call above
    return cals


def _calibrated_probs(model: PythonObject, xt: PythonObject, e: PythonObject, cals: PythonObject, Xa: PythonObject,
                      context: PythonObject) raises -> PythonObject:
    """`CalibratedClassifierCV._calibrated`: the flat (n, k) probabilities of
    one (member, calibrators) pair."""
    var n = _rows(Xa)
    var k = len(_attr(model, "classes_", Python.list()))
    var S = _cal_scores(model, xt, e, Xa, context)
    var c = _cols(S)
    var w = 2 if k == 2 else k
    var acc = trees_vector(n * w, "<f8", context)
    for j in range(len(cals)):  # driver-loop: over the class columns (one calibrator each)
        var entry = cals[j]
        var col = 1 if k == 2 else j
        var par = entry[1]
        if String(entry[0]) == "sigmoid":
            _ = py_call_typed(_x(xt, "x_trees_platt_apply_strided"), _A(S), _A(acc),
                              Python.list(_P(n), par[0], par[1], _P(n * c), _P(c), _P(j), _P(n * w), _P(w), _P(col)))
            _ = acc  # keep the Python object alive through the native call above
            _ = S  # keep the Python object alive through the native call above
        else:
            _ = py_call_typed(_x(xt, "x_trees_isotonic_predict_strided"), _A(par[0]), _A(par[1]), _A(S), _A(acc),
                              Python.list(par[2], _P(n), _P(n * c), _P(c), _P(j), _P(n * w), _P(w), _P(col)))
            _ = acc  # keep the Python object alive through the native call above
            _ = S  # keep the Python object alive through the native call above
    if k == 2:
        _ = py_call_typed(_x(xt, "x_trees_complement_pairs"), _A(acc), Python.list(_P(n)))
        _ = acc  # keep the Python object alive through the native call above
        return acc
    _ = py_call_typed(_x(xt, "x_trees_normalize_rows"), _A(acc), Python.list(_P(n), _P(k)))
    _ = acc  # keep the Python object alive through the native call above
    return acc


def _calibrated_fit(model: PythonObject, X: PythonObject, y: PythonObject, context: PythonObject) raises -> PythonObject:
    _calibrated_validate(model, context)
    var xt = _xt(py_fields(model), context)
    var Xa = _x_array(X, context)
    var n = _rows(Xa)
    var d = _cols(Xa)
    var labels = trees_encode_labels(y, context)
    _set(model, "classes_", labels.classes)
    var k = len(labels.classes)
    if k < 2:
        raise Error("y has fewer than 2 classes")
    var base = _attr(model, "estimator", PythonObject(None))
    if base is None:
        base = prep_estimator_clone(context["native_estimator_defaults"]["LinearSVC"], context)
    _require_member(base, _owner(model), context)
    _set(model, "_cal_fast", PythonObject(None))
    var ensemble = _truthy(_attr(model, "ensemble", PythonObject(True)))
    var splits = _splits(xt, _attr(model, "cv", PythonObject(None)), X, y, n, labels.codes, not ensemble, k, context)
    var cols = _arange(xt, d, context)
    var pairs = Python.list()
    _set(model, "calibrated_classifiers_", pairs)
    if ensemble:
        for f in range(len(splits)):  # driver-loop: over the cv folds
            var tr = splits[f][0]
            var te = splits[f][1]
            var e = _clone(base, context)
            _fit_member(e, _gather(xt, trees_address(Xa), n, d, tr, cols, context),
                        _gather_codes(xt, labels.codes, tr, context), PythonObject(None), context)
            _ = Xa  # keep the Python object alive through the native call above
            var Xte = _gather(xt, trees_address(Xa), n, d, te, cols, context)
            _ = Xa  # keep the Python object alive through the native call above
            var cals = _fit_calibrators(model, xt, _cal_scores(model, xt, e, Xte, context),
                                        _gather_codes(xt, labels.codes, te, context), context)
            _ = Xa  # keep the Python object alive through the native call above
            _ = py_call(pairs.append, Python.tuple(e, cals))
    else:
        var c = 1 if k == 2 else k
        var S = _zeros(n * c, context)
        for f in range(len(splits)):  # driver-loop: over the cv folds
            var tr = splits[f][0]
            var te = splits[f][1]
            var e = _clone(base, context)
            _fit_member(e, _gather(xt, trees_address(Xa), n, d, tr, cols, context),
                        _gather_codes(xt, labels.codes, tr, context), PythonObject(None), context)
            _ = Xa  # keep the Python object alive through the native call above
            var Xte = _gather(xt, trees_address(Xa), n, d, te, cols, context)
            _ = Xa  # keep the Python object alive through the native call above
            var blk = trees_f32(_cal_scores(model, xt, e, Xte, context), 2, "C", "scores", context)
            _ = Xa  # keep the Python object alive through the native call above
            _ = _place(xt, S, n, c, blk, te, 0)
            _ = blk^
        var e = _clone(base, context)
        _fit_member(e, Xa, labels.codes, PythonObject(None), context)
        _ = py_call(pairs.append, Python.tuple(e, _fit_calibrators(model, xt, trees_reshape(S, Python.tuple(n, c), context),
                                                                   labels.codes, context)))
    _set(model, "n_features_in_", PythonObject(d))
    _set(model, "_fitted", PythonObject(True))
    return model


def _calibrated_fused(model: PythonObject, xt: PythonObject, fused: PythonObject, pairs: PythonObject,
                      Xa: PythonObject, n: Int, k: Int, context: PythonObject) raises -> PythonObject:
    """`_calibrated_proba` through `x_trees_calibrated_proba`: the members'
    scores, then the whole epilogue (scores, calibrators, complement or
    normalization, float32 narrowing, the mean) as one device program with
    one readback (lane perf-sweep-trees, 2026-11-05; before it about twenty
    glue round trips per pair). Same kernels in the same order: no bit moves
    (xtrees/calibrated_apply.mojo)."""
    var keep = Python.list()
    var rows = Python.list()
    for i in range(len(pairs)):  # driver-loop: over the (member, calibrators) pairs
        var e = pairs[i][0]
        var cals = pairs[i][1]
        var out: PythonObject
        if prep_estimator_has(e, "decision_function", context):
            out = prep_estimator_call(e, "decision_function", Python.tuple(Xa), context)
        else:
            out = prep_estimator_call(e, "predict_proba", Python.tuple(Xa), context)
        var blk = _out2d(out, n, context)
        _ = py_call(keep.append, blk.keep)
        var at = 0
        var cols_addr = 0
        var ks = 0
        if k == 2:
            if blk.cols != 1:
                at = _index_of_one(e, context)
                if at < 0:
                    raise Error("1 is not in list")
        else:
            var sub_cols = _sub_cols(e, context)
            _ = py_call(keep.append, sub_cols)
            cols_addr = trees_address(sub_cols)
            ks = len(_attr(e, "classes_", Python.list()))
        var described = Python.list()
        for j in range(len(cals)):  # driver-loop: over the class columns (one calibrator each)
            var entry = cals[j]
            var par = entry[1]
            if String(entry[0]) == "sigmoid":
                _ = py_call(described.append, Python.tuple(_P(0), par[0], par[1], _P(0), _P(0), _P(0)))
            else:
                _ = py_call(keep.append, par[0])
                _ = py_call(keep.append, par[1])
                _ = py_call(described.append, Python.tuple(_P(1), _F(0.0), _F(0.0), _A(par[0]), _A(par[1]), par[2]))
        _ = py_call(rows.append, Python.tuple(_P(blk.addr), _P(blk.cols), _P(at), _P(cols_addr), _P(ks), described))
        _ = blk^
    var acc = trees_vector(n * k, "<f8", context)
    _ = py_call_typed(fused, _A(acc), rows, Python.list(_P(n), _P(k)))
    _ = acc  # keep the Python object alive through the native call above
    _ = keep  # keep the members' blocks, class codes and knots alive through the native call above
    return trees_reshape(acc, Python.tuple(n, k), context)


def _calibrated_proba(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var Xa = _check_x(model, X, context)
    var xt = _xt(py_fields(model), context)
    var n = _rows(Xa)
    var k = len(_attr(model, "classes_", Python.list()))
    var pairs = _attr(model, "calibrated_classifiers_", Python.list())
    var fused = py_get(xt, PythonObject("x_trees_calibrated_proba"))
    if fused is not None and k >= 2:
        return _calibrated_fused(model, xt, fused, pairs, Xa, n, k, context)
    var acc = _class_zero(xt, n * k, context)
    for i in range(len(pairs)):  # driver-loop: over the (member, calibrators) pairs
        var p = _calibrated_probs(model, xt, pairs[i][0], pairs[i][1], Xa, context)
        _acc_w(xt, acc, p, n * k, 1.0, context)
    _scale(xt, acc, Float64(len(pairs)))
    return trees_reshape(acc, Python.tuple(n, k), context)


def _calibrated_predict(model: PythonObject, X: PythonObject, context: PythonObject) raises -> PythonObject:
    var p = _calibrated_proba(model, X, context)
    var xt = _xt(py_fields(model), context)
    var classes = _attr(model, "classes_", PythonObject(None))
    return trees_decode_labels(classes, _argmax(xt, p, _rows(p), len(classes), context), context)


# ------------------------------------------------------------------- score


def _regressor_score(model: PythonObject, prediction: PythonObject, y: PythonObject, sample_weight: PythonObject,
                     context: PythonObject) raises -> PythonObject:
    """`RegressorScoreMixin.score`: the float32 R^2 of the prediction."""
    var mode = py_get(py_fields(model), "numeric_mode")
    var truth = trees_f32(y, -1, "C", "y", context)
    var pred = trees_f32(prediction, -1, "C", "prediction", context)
    if len(_attr(pred.keep, "shape", Python.tuple(0))) == 2 or len(_attr(truth.keep, "shape", Python.tuple(0))) == 2:
        # 2-D targets: the metrics family's public r2_score (its multioutput
        # program), on the same float32 blocks.
        var metrics = context["native_meta_metrics"]
        var selected = mode if mode is not None else context["backend_fields"]["_DEFAULT_MODE"]
        var binding = metrics[2][selected]
        if py_type(binding) is trees_builtins().str:
            raise Error(String(binding))
        var result = prep_entry_call(metrics[0], Python.tuple(PythonObject(None), "family_mcls_r2",
                                     Python.tuple(binding, truth.keep, pred.keep, sample_weight,
                                                  "uniform_average", True, mode), metrics[1]))
        _ = truth^
        _ = pred^
        return result
    var result = trees_r2(truth.keep, pred.keep, sample_weight, mode, context)
    _ = truth^
    _ = pred^
    return PythonObject(result)


def _meta_predict(model: PythonObject, kind: String, X: PythonObject, context: PythonObject) raises -> PythonObject:
    if kind == "voting_classifier":
        return _voting_predict(model, X, context)
    if kind == "voting_regressor":
        return _voting_regress(model, X, context)
    if kind == "stacking_classifier":
        return _stacking_predict(model, X, True, context)
    if kind == "stacking_regressor":
        return _stacking_predict(model, X, False, context)
    if kind == "multioutput_regressor":
        return _multioutput_regressor_predict(model, X, context)
    if kind == "multioutput_classifier":
        return _multioutput_classifier_predict(model, X, context)
    if kind == "ovr":
        return _ovr_predict(model, X, context)
    if kind == "calibrated":
        return _calibrated_predict(model, X, context)
    raise Error("unknown meta-estimator schema " + kind)


def _meta_fit(model: PythonObject, kind: String, X: PythonObject, y: PythonObject, sample_weight: PythonObject,
              context: PythonObject) raises -> PythonObject:
    if kind == "voting_classifier":
        return _voting_fit(model, X, y, sample_weight, True, context)
    if kind == "voting_regressor":
        return _voting_fit(model, X, y, sample_weight, False, context)
    if kind == "stacking_classifier":
        return _stacking_classifier_fit(model, X, y, sample_weight, context)
    if kind == "stacking_regressor":
        return _stacking_regressor_fit(model, X, y, sample_weight, context)
    if kind == "multioutput_regressor":
        return _multioutput_regressor_fit(model, X, y, sample_weight, context)
    if kind == "multioutput_classifier":
        return _multioutput_classifier_fit(model, X, y, sample_weight, context)
    if kind == "ovr":
        return _ovr_fit(model, X, y, context)
    if kind == "calibrated":
        return _calibrated_fit(model, X, y, context)
    raise Error("unknown meta-estimator schema " + kind)


def _meta_transform(model: PythonObject, kind: String, X: PythonObject, context: PythonObject) raises -> PythonObject:
    if kind == "voting_classifier":
        return _voting_transform(model, X, True, context)
    if kind == "voting_regressor":
        return _voting_transform(model, X, False, context)
    if kind == "stacking_classifier" or kind == "stacking_regressor":
        return _stacking_transform(model, X, context)
    raise Error("AttributeError: '" + _owner(model) + "' object has no attribute 'transform'")


def _fit_params_weight(fit_params: PythonObject) raises -> PythonObject:
    """`fit(X, y, **fit_params)`: only `sample_weight` is a fit parameter."""
    var b = trees_builtins()
    var keys = py_call(b.list, fit_params)
    for i in range(len(keys)):  # small-loop(keyword arguments): the caller's fit parameters
        if String(keys[i]) != "sample_weight":
            raise Error("TypeError: fit() got an unexpected keyword argument '" + String(keys[i]) + "'")
    return py_get(fit_params, PythonObject("sample_weight"))


def meta_operation(model: PythonObject, operation: String, args: PythonObject,
                   context: PythonObject) raises -> PythonObject:
    """The meta-estimators' methods (`trees_meta_*`) reached directly (a
    composed estimator's plan, cross-validation): admit, then run."""
    prep_estimator_admit(model, "native meta-estimator", context)
    meta_admit_configuration(model, context)
    msel_admit(args, prep_native_context(context))
    return meta_admitted_operation(model, meta_kind(model, context), operation, args, context)


def _member_list(model: PythonObject, kind: String) raises -> PythonObject:
    """The fitted members a prediction of `model` runs on X itself."""
    if kind == "calibrated":
        var pairs = _attr(model, "calibrated_classifiers_", Python.list())
        var members = Python.list()
        for i in range(len(pairs)):  # driver-loop: over the (member, calibrators) pairs
            _ = py_call(members.append, pairs[i][0])
        return members
    return _attr(model, "estimators_", Python.list())


def _staged_input(model: PythonObject, kind: String, X: PythonObject, context: PythonObject) raises -> PythonObject:
    """`(Xa, staged)`: X converted once (`_check_x`, which every prediction
    path runs first; on the converted Array it returns that Array) and staged
    as the one device copy its forest members share (bindings/trees_staged_input.mojo).
    Any refusal here leaves `(X, [])`: the operation then raises it itself,
    in its own order and words."""
    var Xa: PythonObject
    try:
        Xa = _check_x(model, X, context)
    except:
        return Python.tuple(X, Python.list())
    # Staging never leaves a binary staged on a refusal: a failed stage is
    # unstaged inside trees_stage_members, and the caller unstages the rest.
    return Python.tuple(Xa, trees_stage_members(_member_list(model, kind), trees_address(Xa), _rows(Xa), _cols(Xa),
                                                context))


def meta_admitted_operation(model: PythonObject, kind: String, operation: String, args: PythonObject,
                            context: PythonObject) raises -> PythonObject:
    """`meta_operation` after its admission. The public door
    (bindings/trees_public_meta_lifecycle.mojo) has already admitted the
    model, its constructor configuration (a native clone of the meta-estimator
    and every member) and the arguments, and read `kind`; it calls this
    directly (lane perf-meta-estimators, 2026-11-05: every public call used
    to pay that admission twice, the second time inside meta_operation).
    A prediction (predict, predict_proba, transform, score) stages X once
    for its forest members (lane perf-sweep-trees, 2026-11-05)."""
    if (operation == "trees_meta_predict" or operation == "trees_meta_predict_proba"
            or operation == "trees_meta_transform" or operation == "trees_meta_score"):
        var prepared = _staged_input(model, kind, args[0], context)
        var call = Python.list(prepared[0])
        for i in range(1, len(args)):  # small-loop(args): the call's remaining positional arguments
            _ = py_call(call.append, args[i])
        var result = PythonObject(None)
        try:
            result = _meta_dispatch(model, kind, operation, py_call(trees_builtins().tuple, call), context)
        finally:
            trees_unstage(prepared[1])
        return result
    return _meta_dispatch(model, kind, operation, args, context)


def _meta_dispatch(model: PythonObject, kind: String, operation: String, args: PythonObject,
                   context: PythonObject) raises -> PythonObject:
    if operation == "trees_meta_fit":
        return _meta_fit(model, kind, args[0], args[1], args[2], context)
    if operation == "trees_meta_predict":
        return _meta_predict(model, kind, args[0], context)
    if operation == "trees_meta_predict_proba":
        if kind == "voting_classifier":
            return _voting_predict_proba(model, args[0], context)
        if kind == "stacking_classifier":
            return _stacking_predict_proba(model, args[0], context)
        if kind == "multioutput_classifier":
            return _multioutput_classifier_proba(model, args[0], context)
        if kind == "ovr":
            return _ovr_predict_proba(model, args[0], context)
        if kind == "calibrated":
            return _calibrated_proba(model, args[0], context)
        raise Error("AttributeError: '" + _owner(model) + "' object has no attribute 'predict_proba'")
    if operation == "trees_meta_transform":
        return _meta_transform(model, kind, args[0], context)
    if operation == "trees_meta_fit_transform":
        var fitted = _meta_fit(model, kind, args[0], args[1], _fit_params_weight(args[2]), context)
        _ = fitted
        # The transform half stages X for its forest members like transform.
        var prepared = _staged_input(model, kind, args[0], context)
        var result = PythonObject(None)
        try:
            result = _meta_transform(model, kind, prepared[0], context)
        finally:
            trees_unstage(prepared[1])
        return result
    if operation == "trees_meta_score":
        var X = args[0]
        var y = args[1]
        var sample_weight = args[2]
        if kind == "multioutput_classifier":
            return _multioutput_classifier_score(model, X, y, sample_weight, context)
        var prediction = _meta_predict(model, kind, X, context)
        if kind.endswith("_regressor"):
            return _regressor_score(model, prediction, y, sample_weight, context)
        var mode = py_get(py_fields(model), "numeric_mode")
        return PythonObject(trees_accuracy(y, prediction, sample_weight, mode, context))
    raise Error("unknown meta-estimator operation " + operation)
