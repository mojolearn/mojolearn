# SPDX-License-Identifier: Apache-2.0
# Native fit/refine boundaries for IVFIndex and the approximate ANN indexes.
# Public wrappers hand over inputs, settings and a binding placeholder; this
# owner admits the live binding, retains input descriptors, validates targets,
# executes the existing algorithms and completes fitted state/results.
# Numerical exports still use the existing packed CPython extension ABI; a
# descriptor-only ANN provider remains explicit migration work. No arithmetic
# or vendor identity lane is introduced by these boundary repairs.
from std.memory import memcpy, MutPointer
from std.python import Python, PythonObject
from bindings.native_loaded_module import native_loaded_module, NativeModules
from bindings.native_prepared_owner import prepared_drop
from bindings.native_buffer_owner import native_storage_allocate, native_buffer_view
from bindings.py_balanced import py_call, py_type, py_get, py_contains, py_fields, py_setitem, py_setattr
from bindings.classical_arrays import classical_address, classical_kind, classical_is_array
from bindings.classical_attributes import classical_connect_numpy, classical_check_layout
from bindings.classical_validate import classical_view, classical_refuse_sparse, classical_estimator_name
from providers.python.estimator_binding_pyapi import estimator_arguments, estimator_binding_mode
from providers.python.neural_descriptor_pyapi import neural_descriptor_entry
from providers.python.array_metadata_pyapi import ArrayMetadata, array_shape_once, array_metadata_once
from core.cast_in import CAST_KIND_SIGNED, CAST_KIND_UNSIGNED
from bindings.family_common import (
    FAMILY_I32P, family_repr, family_str, family_is_str, family_isinstance, family_call, family_array,
    family_as_f32, family_f32_snapshot, family_field, family_type_name,
)
from core.neighbors_ann_impl import ann_candidates_i32
from bindings.parallel_public_result import parallel_public_result
from bindings.neighbors_ann_query_native import neighbors_ann_search, ann_pq_materialize, ann_stored_drop
from bindings.mode_metadata_native import _fields
from bindings.p3nc_fitted_freeze import fitted_freeze
from providers.python.estimator_lifecycle_pyapi import estimator_outside, estimator_fit_begin
from providers.python.neighbors_public_lifecycle_pyapi import (
    NeighborPublicCall, _target, neighbors_public_end, neighbors_public_finish, neighbors_public_refusal,
)


# ---------------------------------------------------------------- shared steps

# The IVF query admission stamp's slot in the native prepared registry
# (bindings/native_prepared_owner.mojo): weakly keyed by the model, outside
# `__dict__`, never pickled. Written by the first query, dropped by fit/extend.
comptime IVF_QUERY_STATE_SLOT = "neighbor_ivf_query_state_v1"


def _ann_int(owner: String, name: String, value: PythonObject) raises -> PythonObject:
    """`_expansion_ann._ann_int` (and `_ivf_impl._int_param`, the same rule
    under owner "IVFIndex"): an int that is not a bool, as `int(v)`."""
    var b = native_loaded_module("builtins")
    if py_type(value) is not b.int:
        raise Error("TypeError: mojolearn " + owner + ": " + name + " must be an int, got " + family_type_name(value))
    return value


def _ann_param(fields: PythonObject, owner: String, name: String) raises -> PythonObject:
    """`self._p(name)`: the constructor parameter `name` through `_ann_int`."""
    return _ann_int(owner, name, family_field(fields, name))


def _ann_empty(count: Int, typestr: String, context: PythonObject) raises -> PythonObject:
    """`_buffer.empty((count,), typestr)`: a zero-filled C-order Array, with
    `Array`'s refusal of a negative dimension."""
    if count < 0:
        raise Error("mojolearn: negative dimension in shape (" + String(count) + ",)")
    return family_array(Python.tuple(count), typestr, context)


def _ann_view(other: PythonObject, shape: PythonObject, context: PythonObject) raises -> PythonObject:
    """`other.reshape(shape)` of a C-order Array (`Array._view_of`): the
    same memory under a new shape, `other` kept alive through `_base`."""
    var b = native_loaded_module("builtins")
    var rank = len(shape)
    var size = 1
    for k in range(rank):  # driver-loop: over array rank metadata
        size *= Int(py=shape[k])
    if size != Int(py=other.size):
        raise Error("mojolearn: cannot reshape size " + String(Int(py=other.size)) + " into " + family_repr(shape))
    var item = Int(py=other.itemsize)
    var steps = List[Int](length=rank, fill=0)
    var step = item
    for k in range(rank):  # driver-loop: over array rank metadata
        var axis = rank - 1 - k
        steps[axis] = step
        step *= Int(py=shape[axis])
    var strides = Python.list()
    for k in range(rank):  # driver-loop: over array rank metadata
        _ = py_call(strides.append, PythonObject(steps[k]))
    var view = native_storage_allocate(context["array_class"])
    py_setattr(view, "_store", other._store)
    py_setattr(view, "_base", other)
    py_setattr(view, "_pin", other._pin)
    py_setattr(view, "_mv", other._mv)
    py_setattr(view, "_addr", other._addr)
    py_setattr(view, "_readonly", other._readonly)
    py_setattr(view, "shape", py_call(b.tuple, shape))
    py_setattr(view, "dtype", other.dtype)
    py_setattr(view, "ndim", PythonObject(rank))
    py_setattr(view, "size", PythonObject(size))
    py_setattr(view, "itemsize", PythonObject(item))
    py_setattr(view, "nbytes", PythonObject(size * item))
    py_setattr(view, "order", PythonObject("C"))
    py_setattr(view, "strides", py_call(b.tuple, strides))
    return view


def _ann_as_array(x: PythonObject, context: PythonObject) raises -> PythonObject:
    """The float32 C-order X as the mojolearn Array `as_f32_c` returned: the
    converted copy or the caller's Array as is, or a zero-copy Array view of
    the caller's buffer (`Array.from_buffer`)."""
    if classical_is_array(x, context):
        return x
    return _ann_buffer_array(x, Int(py=x.shape[0]), Int(py=x.shape[1]), Int(py=classical_address(x)), context)


def _ann_buffer_array(x: PythonObject, rows: Int, cols: Int, address: Int,
                      context: PythonObject) raises -> PythonObject:
    # The native buffer export pins storage only; dtype, shape and address
    # come from the operation's captured descriptor rather than Python fields.
    var pin = native_buffer_view(x)
    var array = native_storage_allocate(context["array_class"])
    py_setattr(array, "_store", x)
    py_setattr(array, "_base", PythonObject(None))
    py_setattr(array, "_pin", pin)
    py_setattr(array, "_mv", py_call(py_call(pin.cast, "B").cast, "f"))
    py_setattr(array, "_addr", PythonObject(address))
    py_setattr(array, "_readonly", pin.readonly)
    py_setattr(array, "shape", Python.tuple(rows, cols))
    py_setattr(array, "dtype", PythonObject("<f4"))
    py_setattr(array, "ndim", PythonObject(2))
    py_setattr(array, "size", PythonObject(rows * cols))
    py_setattr(array, "nbytes", PythonObject(rows * cols * 4))
    py_setattr(array, "itemsize", PythonObject(4))
    py_setattr(array, "strides", Python.tuple(cols * 4, 4))
    py_setattr(array, "order", PythonObject("C"))
    return array


def _ann_entry(binding: PythonObject, name: String) raises -> PythonObject:
    """`binding.<name>`: the attribute lookup the Python method made (a
    by-name refusal of a host binding is raised unchanged)."""
    return neural_descriptor_entry(binding, name)


def _ann_release(fields: PythonObject, release: String) raises:
    """`_release_resident`: pop the held `(key, handle, binding)`, if any,
    and release it through the minting binding's `release` entry. Quiet on a
    binding that cannot be reached any more or a handle already gone."""
    var cached = py_call(fields.pop, PythonObject("_resident"), PythonObject(None))
    if cached is None:
        return
    var b = native_loaded_module("builtins")
    if py_type(cached) is not b.tuple or len(cached) != 3 or py_type(cached[1]) is not b.int:
        raise Error("TypeError: ANN resident state requires its native key, handle and module")
    if py_type(cached[2]) is not py_type(b):
        raise Error("TypeError: ANN resident state requires its compiled module owner")
    # Import-connected query aliases hold entries minted by the original
    # module. Read only the exact module dictionary, never __getattr__.
    var entry = py_get(py_fields(cached[2]), release)
    if entry is None:
        return
    if py_type(entry) is not py_type(b.len) or py_type(entry.__self__) is not py_type(b):
        raise Error("TypeError: ANN release requires a compiled module entry")
    try:
        _ = py_call(entry, cached[1])
    except:
        pass


def _ann_key_entry(fields: PythonObject, name: String) raises -> PythonObject:
    """One element of `_resident_key`: ("device",) for an array not in the
    instance dict, else (id, address, shape) of the stored array."""
    var b = native_loaded_module("builtins")
    var a = py_get(fields, PythonObject(name), PythonObject(None))
    if a is None:
        return Python.tuple(PythonObject("device"))
    return Python.tuple(py_call(b.id, a), a._addr, py_call(b.tuple, a.shape))


# ---------------------------------------------------------------- IVFIndex


def _ivf_metric(fields: PythonObject, context: PythonObject) raises -> PythonObject:
    """`IVFIndex._metric_code`."""
    var b = native_loaded_module("builtins")
    var metric = family_field(fields, "metric")
    var table = context["family_xn_ann_ivf_metrics"]
    if py_type(metric) is b.str:
        if not py_contains(table, metric):
            raise Error("mojolearn IVFIndex: metric must be one of " + family_repr(py_call(b.sorted, table))
                        + ", got " + family_repr(metric))
        return table[metric]
    # Exact words before conversion or equality: arbitrary numeric protocols
    # must never execute while admitting mutable estimator parameters.
    if py_type(metric) is not b.int and py_type(metric) is not b.float:
        raise Error("TypeError: mojolearn IVFIndex: metric must be an exact native name or code")
    var code = Float64(py=metric)
    if code != 0.0 and code != 1.0:
        raise Error("mojolearn IVFIndex: the metric codes are 0 (L2Expanded) and 1 (L2SqrtExpanded)")
    return PythonObject(Int(code))


def ann_keep_array(source: PythonObject, x: PythonObject, context: PythonObject) raises -> PythonObject:
    """What `as_f32_c(source)` returned for the converted `x`: the caller's
    own C-order float32 Array itself, else `_ann_as_array(x)`."""
    if (classical_is_array(source, context) and String(source.dtype) == "<f4"
            and String(source.order) == "C"):
        return source
    return _ann_as_array(x, context)


def _ivf_extension(fields: PythonObject, binding: PythonObject, context: PythonObject) raises:
    """`IVFIndex._extension`: the binary's own compile-time mode must be the
    one requested (`int(fn()) != _MODE_CODE.get(want)`)."""
    var b = native_loaded_module("builtins")
    var operator = native_loaded_module("operator")
    var want = py_get(fields, PythonObject("numeric_mode"), PythonObject(None))
    if want is None or not Bool(py=py_call(b.bool, want)):
        want = context["backend_fields"]["_DEFAULT_MODE"]
    var getter = family_call(b.getattr, binding, PythonObject("ivf_numeric_mode"), PythonObject(None))
    if getter is not None:
        var got = family_call(b.int, family_call(getter))
        var wanted = py_get(context["family_xn_ann_ivf_mode_codes"], want, PythonObject(None))
        if Bool(py=family_call(operator.ne, got, wanted)):
            raise Error("RuntimeError: mojolearn IVFIndex: numeric_mode=" + family_repr(want) + " was requested but "
                        + family_str(family_call(b.getattr, binding, PythonObject("__name__")))
                        + " reports another compile-time mode; rebuild it with bash bindings/build_ivf.sh")


def _ivf_fit(model: PythonObject, args: PythonObject, context: PythonObject,
               x_snapshot: ArrayMetadata) raises -> PythonObject:
    """`IVFIndex.fit(X)`: `ivf_flat_build_resident` when the binding has it
    (the list vectors stay in its handle), else `ivf_flat_build`."""
    var b = native_loaded_module("builtins")
    var binding = args[0]
    var fields = _fields(model)
    _ = py_call(fields.pop, PythonObject("_device_list_data"), PythonObject(None))
    # A refit replaces every fitted array: drop the query admission stamp
    # (bindings/neighbor_query_native.mojo `_admit_state`, kept in the native
    # prepared registry outside `__dict__`) and what it holds.
    var stamp_mods = NativeModules()
    prepared_drop(stamp_mods, IVF_QUERY_STATE_SLOT, model)
    _ann_release(fields, "ivf_flat_index_release")
    var x = x_snapshot.keep
    var n = x_snapshot.shape[0]
    var dim = x_snapshot.shape[1]
    var n_lists_o = _ann_param(fields, "IVFIndex", "n_lists")
    var iters = _ann_param(fields, "IVFIndex", "kmeans_n_iters")
    var seed = _ann_param(fields, "IVFIndex", "random_state")
    var metric = _ivf_metric(fields, context)
    var n_lists = Int(py=n_lists_o)
    if n_lists < 1:
        raise Error("mojolearn IVFIndex: n_lists must be at least 1, got " + String(n_lists))
    var centers = _ann_empty(n_lists * dim, "<f4", context)
    var norms = _ann_empty(n_lists, "<f4", context)
    var offsets = _ann_empty(n_lists + 1, "<i4", context)
    var indices = _ann_empty(n, "<i4", context)
    _ivf_extension(fields, binding, context)
    var params = Python.list(PythonObject(n), PythonObject(dim), n_lists_o, iters, metric, seed)
    var resident_build = neural_descriptor_entry(binding, "ivf_flat_build_resident", False)
    if resident_build is not None:
        # ORDER MATCHES bindings/_mojolearn_ivf.mojo (ivf_flat_build_resident):
        # x, centers_out, center_norms_out, offsets_out, indices_out;
        # n, dim, n_lists, kmeans_n_iters, metric, seed.
        var handle = family_call(b.int, family_call(
            resident_build,
            Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(norms),
                        classical_address(offsets), classical_address(indices)),
            params))
        _ = x_snapshot  # retain the captured storage owners through native execution
        _ = centers  # keep the Python object alive through the native call above
        _ = norms  # keep the Python object alive through the native call above
        _ = offsets  # keep the Python object alive through the native call above
        _ = indices  # keep the Python object alive through the native call above
        _ = py_call(fields.pop, PythonObject("list_data_"), PythonObject(None))
        py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
        py_setitem(fields, "center_norms_", norms)
        py_setitem(fields, "list_offsets_", offsets)
        py_setitem(fields, "list_indices_", indices)
        py_setitem(fields, "n_features_in_", PythonObject(dim))
        py_setitem(fields, "n_rows_", PythonObject(n))
        py_setitem(fields, "n_lists_", n_lists_o)
        py_setitem(fields, "metric_code_", metric)
        py_setitem(fields, "_device_list_data", PythonObject(True))
        # `self._resident_key(False) + (id(native),)`
        var arrays = Python.tuple(_ann_key_entry(fields, "centers_"), _ann_key_entry(fields, "center_norms_"),
                                  _ann_key_entry(fields, "list_offsets_"), _ann_key_entry(fields, "list_indices_"),
                                  _ann_key_entry(fields, "list_data_"))
        var key = Python.tuple(arrays, fields["n_rows_"], fields["n_features_in_"], fields["n_lists_"],
                               fields["metric_code_"], PythonObject(False), py_call(b.id, binding))
        py_setitem(fields, "_resident", Python.tuple(key, handle, binding))
        # p3-neighbors-cluster (hazard class A): the handle's key holds
        # identity, address and shape only, so the fresh fitted Arrays are
        # read-only from here on (bindings/p3nc_fitted_freeze.mojo).
        _ = fitted_freeze(fields["centers_"], context)
        _ = fitted_freeze(fields["center_norms_"], context)
        _ = fitted_freeze(fields["list_offsets_"], context)
        _ = fitted_freeze(fields["list_indices_"], context)
        return model
    var data = _ann_empty(n * dim, "<f4", context)
    var build = neural_descriptor_entry(binding, "ivf_flat_build", False)
    if build is None:
        raise Error("ImportError: mojolearn IVFIndex: "
                    + family_str(family_call(b.getattr, binding, PythonObject("__name__"), binding))
                    + " exports no ivf_flat_build; this binary predates the build and search split, "
                    + "rebuild it with bash bindings/build_ivf.sh")
    # ORDER MATCHES bindings/ivf_index_arrays.mojo (ivf_flat_build):
    # x, centers_out, center_norms_out, offsets_out, indices_out, list_data_out.
    _ = family_call(build,
                    Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(norms),
                                classical_address(offsets), classical_address(indices), classical_address(data)),
                    params)
    _ = x_snapshot  # retain the captured storage owners through native execution
    _ = centers  # keep the Python object alive through the native call above
    _ = norms  # keep the Python object alive through the native call above
    _ = offsets  # keep the Python object alive through the native call above
    _ = indices  # keep the Python object alive through the native call above
    _ = data  # keep the Python object alive through the native call above
    py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
    py_setitem(fields, "center_norms_", norms)
    py_setitem(fields, "list_offsets_", offsets)
    py_setitem(fields, "list_indices_", indices)
    py_setitem(fields, "list_data_", _ann_view(data, Python.tuple(n, dim), context))
    # p3-neighbors-cluster: fitted index arrays are read-only from fit on (the
    # resident device copy is keyed by identity; bindings/p3nc_fitted_freeze.mojo).
    _ = fitted_freeze(fields["centers_"], context)
    _ = fitted_freeze(fields["center_norms_"], context)
    _ = fitted_freeze(fields["list_offsets_"], context)
    _ = fitted_freeze(fields["list_indices_"], context)
    _ = fitted_freeze(fields["list_data_"], context)
    py_setitem(fields, "n_features_in_", PythonObject(dim))
    py_setitem(fields, "n_rows_", PythonObject(n))
    py_setitem(fields, "n_lists_", n_lists_o)
    py_setitem(fields, "metric_code_", metric)
    return model


# ---------------------------------------------------------------- IVFPQIndex


def _pq_fit(model: PythonObject, args: PythonObject, context: PythonObject,
               x_snapshot: ArrayMetadata) raises -> PythonObject:
    """`IVFPQIndex.fit(X)`: `x_ann_ivf_pq_build_resident` when the binding
    has it (`codes_` stays in its handle), else `x_ann_ivf_pq_build`."""
    var b = native_loaded_module("builtins")
    var binding = args[0]
    var fields = _fields(model)
    # A refit replaces the fitted arrays: drop the search's stored-array
    # stamp (and the arrays it retains) now, not at the next search.
    ann_stored_drop(model)
    # `self._NAME`, the class's name in `_p`'s refusals (read off the class).
    var owner = String("IVFPQIndex")
    _ = py_call(fields.pop, PythonObject("_device_codes"), PythonObject(None))
    _ann_release(fields, "x_ann_index_release")
    var x = x_snapshot.keep
    var n = x_snapshot.shape[0]
    var dim = x_snapshot.shape[1]
    var n_lists_o = _ann_param(fields, owner, "n_lists")
    var pq_dim_o = _ann_param(fields, owner, "pq_dim")
    var pq_bits_o = _ann_param(fields, owner, "pq_bits")
    var n_lists = Int(py=n_lists_o)
    var pq_dim = Int(py=pq_dim_o)
    var pq_bits = Int(py=pq_bits_o)
    if not (1 <= pq_dim and pq_dim <= dim):
        raise Error("mojolearn IVFPQIndex: pq_dim must be in [1, " + String(dim) + "], got " + String(pq_dim))
    if not (1 <= pq_bits and pq_bits <= 8):
        raise Error("mojolearn IVFPQIndex: pq_bits must be in [1, 8], got " + String(pq_bits))
    if not (1 <= n_lists and n_lists <= n):
        raise Error("mojolearn IVFPQIndex: n_lists must be in [1, " + String(n) + "], got " + String(n_lists))
    # `-(-dim // pq_dim)`: the ceiling of dim / pq_dim (both positive here).
    var pq_len = (dim + pq_dim - 1) // pq_dim
    var n_codes = 1 << pq_bits
    var centers = _ann_empty(n_lists * dim, "<f4", context)
    var offsets = _ann_empty(n_lists + 1, "<i4", context)
    var indices = _ann_empty(n, "<i4", context)
    var codebooks = _ann_empty(pq_dim * n_codes * pq_len, "<f4", context)
    var resident_build = neural_descriptor_entry(binding, "x_ann_ivf_pq_build_resident", False)
    if resident_build is not None:
        # x, centers, offsets, list_indices, codebooks (bindings/_mojolearn_x_ann.mojo);
        # n, dim, n_lists, kmeans_n_iters, seed, pq_dim, pq_bits, pq_kmeans_n_iters.
        var addrs = Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(offsets),
                                classical_address(indices), classical_address(codebooks))
        var iters = _ann_param(fields, owner, "kmeans_n_iters")
        var seed = _ann_param(fields, owner, "random_state")
        var pq_iters = _ann_param(fields, owner, "pq_kmeans_n_iters")
        var handle = family_call(b.int, family_call(
            resident_build, addrs,
            Python.list(PythonObject(n), PythonObject(dim), n_lists_o, iters, seed, pq_dim_o, pq_bits_o, pq_iters)))
        _ = x_snapshot  # retain the captured storage owners through native execution
        _ = centers  # keep the Python object alive through the native call above
        _ = offsets  # keep the Python object alive through the native call above
        _ = indices  # keep the Python object alive through the native call above
        _ = codebooks  # keep the Python object alive through the native call above
        _ = py_call(fields.pop, PythonObject("codes_"), PythonObject(None))
        py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
        py_setitem(fields, "list_offsets_", offsets)
        py_setitem(fields, "list_indices_", indices)
        py_setitem(fields, "codebooks_", _ann_view(codebooks, Python.tuple(pq_dim, n_codes, pq_len), context))
        py_setitem(fields, "n_features_in_", PythonObject(dim))
        py_setitem(fields, "n_rows_", PythonObject(n))
        py_setitem(fields, "n_lists_", n_lists_o)
        py_setitem(fields, "pq_dim_", pq_dim_o)
        py_setitem(fields, "pq_bits_", pq_bits_o)
        py_setitem(fields, "pq_len_", PythonObject(pq_len))
        py_setitem(fields, "_device_codes", PythonObject(True))
        # `self._resident_key(native)` over `_SAVE_ARRAYS`
        var arrays = Python.tuple(_ann_key_entry(fields, "centers_"), _ann_key_entry(fields, "list_offsets_"),
                                  _ann_key_entry(fields, "list_indices_"), _ann_key_entry(fields, "codebooks_"),
                                  _ann_key_entry(fields, "codes_"))
        var key = Python.tuple(arrays, py_call(b.id, binding))
        py_setitem(fields, "_resident", Python.tuple(key, handle, binding))
        # p3-neighbors-cluster (hazard class A): read-only fitted Arrays.
        _ = fitted_freeze(fields["centers_"], context)
        _ = fitted_freeze(fields["list_offsets_"], context)
        _ = fitted_freeze(fields["list_indices_"], context)
        _ = fitted_freeze(fields["codebooks_"], context)
        return model
    var codes = _ann_empty(n * pq_dim, "<i4", context)
    var build = _ann_entry(binding, "x_ann_ivf_pq_build")
    # x, centers, offsets, list_indices, codebooks, codes;
    # n, dim, n_lists, kmeans_n_iters, seed, pq_dim, pq_bits, pq_kmeans_n_iters.
    var addrs = Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(offsets),
                            classical_address(indices), classical_address(codebooks), classical_address(codes))
    var iters = _ann_param(fields, owner, "kmeans_n_iters")
    var seed = _ann_param(fields, owner, "random_state")
    var pq_iters = _ann_param(fields, owner, "pq_kmeans_n_iters")
    _ = family_call(build, addrs,
                    Python.list(PythonObject(n), PythonObject(dim), n_lists_o, iters, seed, pq_dim_o, pq_bits_o, pq_iters))
    _ = x_snapshot  # retain the captured storage owners through native execution
    _ = centers  # keep the Python object alive through the native call above
    _ = offsets  # keep the Python object alive through the native call above
    _ = indices  # keep the Python object alive through the native call above
    _ = codebooks  # keep the Python object alive through the native call above
    _ = codes  # keep the Python object alive through the native call above
    py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
    py_setitem(fields, "list_offsets_", offsets)
    py_setitem(fields, "list_indices_", indices)
    py_setitem(fields, "codebooks_", _ann_view(codebooks, Python.tuple(pq_dim, n_codes, pq_len), context))
    py_setitem(fields, "codes_", _ann_view(codes, Python.tuple(n, pq_dim), context))
    # p3-neighbors-cluster: fitted index arrays are read-only from fit on (the
    # resident device copy is keyed by identity; bindings/p3nc_fitted_freeze.mojo).
    _ = fitted_freeze(fields["centers_"], context)
    _ = fitted_freeze(fields["list_offsets_"], context)
    _ = fitted_freeze(fields["list_indices_"], context)
    _ = fitted_freeze(fields["codebooks_"], context)
    _ = fitted_freeze(fields["codes_"], context)
    py_setitem(fields, "n_features_in_", PythonObject(dim))
    py_setitem(fields, "n_rows_", PythonObject(n))
    py_setitem(fields, "n_lists_", n_lists_o)
    py_setitem(fields, "pq_dim_", pq_dim_o)
    py_setitem(fields, "pq_bits_", pq_bits_o)
    py_setitem(fields, "pq_len_", PythonObject(pq_len))
    return model


# ---------------------------------------------------------------- IVFSQIndex


def _sq_fit(model: PythonObject, args: PythonObject, context: PythonObject,
               x_snapshot: ArrayMetadata) raises -> PythonObject:
    """`IVFSQIndex.fit(X)` through `x_ann_ivf_sq_build`."""
    var binding = args[0]
    var fields = _fields(model)
    # A refit replaces the fitted arrays: drop the search's stored-array
    # stamp (and the arrays it retains) now, not at the next search.
    ann_stored_drop(model)
    var owner = String("IVFSQIndex")
    _ann_release(fields, "x_ann_index_release")
    var x = x_snapshot.keep
    var n = x_snapshot.shape[0]
    var dim = x_snapshot.shape[1]
    var n_lists_o = _ann_param(fields, owner, "n_lists")
    var n_lists = Int(py=n_lists_o)
    if not (1 <= n_lists and n_lists <= n):
        raise Error("mojolearn IVFSQIndex: n_lists must be in [1, " + String(n) + "], got " + String(n_lists))
    var train_per_list = PythonObject(0)  # 0: the binding's default training rows
    if family_field(fields, "max_train_points_per_cluster") is not None:
        train_per_list = _ann_param(fields, owner, "max_train_points_per_cluster")
        if Int(py=train_per_list) < 1:
            raise Error("mojolearn IVFSQIndex: max_train_points_per_cluster must be positive or None, "
                        + "got " + String(Int(py=train_per_list)))
    var centers = _ann_empty(n_lists * dim, "<f4", context)
    var offsets = _ann_empty(n_lists + 1, "<i4", context)
    var indices = _ann_empty(n, "<i4", context)
    var vmin = _ann_empty(dim, "<f4", context)
    var delta = _ann_empty(dim, "<f4", context)
    var codes = _ann_empty(n * dim, "<i4", context)
    var build = _ann_entry(binding, "x_ann_ivf_sq_build")
    # x, centers, offsets, list_indices, vmin, delta, codes;
    # n, dim, n_lists, kmeans_n_iters, seed, train_rows_per_list.
    var addrs = Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(offsets),
                            classical_address(indices), classical_address(vmin), classical_address(delta),
                            classical_address(codes))
    var iters = _ann_param(fields, owner, "kmeans_n_iters")
    var seed = _ann_param(fields, owner, "random_state")
    _ = family_call(build, addrs, Python.list(PythonObject(n), PythonObject(dim), n_lists_o, iters, seed, train_per_list))
    _ = x_snapshot  # retain the captured storage owners through native execution
    _ = centers  # keep the Python object alive through the native call above
    _ = offsets  # keep the Python object alive through the native call above
    _ = indices  # keep the Python object alive through the native call above
    _ = vmin  # keep the Python object alive through the native call above
    _ = delta  # keep the Python object alive through the native call above
    _ = codes  # keep the Python object alive through the native call above
    py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
    py_setitem(fields, "list_offsets_", offsets)
    py_setitem(fields, "list_indices_", indices)
    py_setitem(fields, "sq_vmin_", vmin)
    py_setitem(fields, "sq_delta_", delta)
    py_setitem(fields, "codes_", _ann_view(codes, Python.tuple(n, dim), context))
    # p3-neighbors-cluster: fitted index arrays are read-only from fit on (the
    # resident device copy is keyed by identity; bindings/p3nc_fitted_freeze.mojo).
    _ = fitted_freeze(fields["centers_"], context)
    _ = fitted_freeze(fields["list_offsets_"], context)
    _ = fitted_freeze(fields["list_indices_"], context)
    _ = fitted_freeze(fields["sq_vmin_"], context)
    _ = fitted_freeze(fields["sq_delta_"], context)
    _ = fitted_freeze(fields["codes_"], context)
    py_setitem(fields, "n_features_in_", PythonObject(dim))
    py_setitem(fields, "n_rows_", PythonObject(n))
    py_setitem(fields, "n_lists_", n_lists_o)
    return model


# ---------------------------------------------------------------- IVFRaBitQIndex


def _rabitq_fit(model: PythonObject, args: PythonObject, context: PythonObject,
               x_snapshot: ArrayMetadata) raises -> PythonObject:
    """`IVFRaBitQIndex.fit(X)` through `x_ann_ivf_rabitq_build`."""
    var binding = args[0]
    var fields = _fields(model)
    # A refit replaces the fitted arrays: drop the search's stored-array
    # stamp (and the arrays it retains) now, not at the next search.
    ann_stored_drop(model)
    var owner = String("IVFRaBitQIndex")
    _ann_release(fields, "x_ann_index_release")
    var x = x_snapshot.keep
    var n = x_snapshot.shape[0]
    var dim = x_snapshot.shape[1]
    var n_lists_o = _ann_param(fields, owner, "n_lists")
    var n_lists = Int(py=n_lists_o)
    if not (1 <= n_lists and n_lists <= n):
        raise Error("mojolearn IVFRaBitQIndex: n_lists must be in [1, " + String(n) + "], got " + String(n_lists))
    var D = 1
    while D < dim:  # small-loop(D: the power-of-two ceiling of the feature count, at most 63 doublings)
        D *= 2
    var words = (D + 31) // 32
    var centers = _ann_empty(n_lists * dim, "<f4", context)
    var offsets = _ann_empty(n_lists + 1, "<i4", context)
    var indices = _ann_empty(n, "<i4", context)
    var codes = _ann_empty(n * words, "<i4", context)
    var norms = _ann_empty(n, "<f4", context)
    var ips = _ann_empty(n, "<f4", context)
    var build = _ann_entry(binding, "x_ann_ivf_rabitq_build")
    # x, centers, offsets, list_indices, codes, norms, ips; n, dim, n_lists, kmeans_n_iters, seed.
    var addrs = Python.list(PythonObject(x_snapshot.source.addr), classical_address(centers), classical_address(offsets),
                            classical_address(indices), classical_address(codes), classical_address(norms),
                            classical_address(ips))
    var iters = _ann_param(fields, owner, "kmeans_n_iters")
    var seed = _ann_param(fields, owner, "random_state")
    _ = family_call(build, addrs, Python.list(PythonObject(n), PythonObject(dim), n_lists_o, iters, seed))
    _ = x_snapshot  # retain the captured storage owners through native execution
    _ = centers  # keep the Python object alive through the native call above
    _ = offsets  # keep the Python object alive through the native call above
    _ = indices  # keep the Python object alive through the native call above
    _ = codes  # keep the Python object alive through the native call above
    _ = norms  # keep the Python object alive through the native call above
    _ = ips  # keep the Python object alive through the native call above
    py_setitem(fields, "centers_", _ann_view(centers, Python.tuple(n_lists, dim), context))
    py_setitem(fields, "list_offsets_", offsets)
    py_setitem(fields, "list_indices_", indices)
    py_setitem(fields, "codes_", _ann_view(codes, Python.tuple(n, words), context))
    py_setitem(fields, "norms_", norms)
    py_setitem(fields, "ip_factors_", ips)
    # p3-neighbors-cluster: fitted index arrays are read-only from fit on (the
    # resident device copy is keyed by identity; bindings/p3nc_fitted_freeze.mojo).
    _ = fitted_freeze(fields["centers_"], context)
    _ = fitted_freeze(fields["list_offsets_"], context)
    _ = fitted_freeze(fields["list_indices_"], context)
    _ = fitted_freeze(fields["codes_"], context)
    _ = fitted_freeze(fields["norms_"], context)
    _ = fitted_freeze(fields["ip_factors_"], context)
    py_setitem(fields, "n_features_in_", PythonObject(dim))
    py_setitem(fields, "n_rows_", PythonObject(n))
    py_setitem(fields, "n_lists_", n_lists_o)
    py_setitem(fields, "seed_", _ann_param(fields, owner, "random_state"))
    return model


# ---------------------------------------------------------------- CagraIndex


def _cagra_fit(model: PythonObject, args: PythonObject, context: PythonObject,
               x_snapshot: ArrayMetadata) raises -> PythonObject:
    """`CagraIndex.fit(X)` through `x_ann_cagra_build`; the index keeps X."""
    var binding = args[0]
    var fields = _fields(model)
    # A refit replaces the fitted arrays: drop the search's stored-array
    # stamp (and the arrays it retains) now, not at the next search.
    ann_stored_drop(model)
    var owner = String("CagraIndex")
    _ann_release(fields, "x_ann_index_release")
    var x = x_snapshot.keep
    var n = x_snapshot.shape[0]
    var d = x_snapshot.shape[1]
    # `min(self._p("intermediate_graph_degree"), n - 1)`, then
    # `min(self._p("graph_degree"), kdeg)`
    var kdeg = min(Int(py=_ann_param(fields, owner, "intermediate_graph_degree")), n - 1)
    var deg = min(Int(py=_ann_param(fields, owner, "graph_degree")), kdeg)
    var graph = _ann_empty(n * deg, "<i4", context)
    var build = _ann_entry(binding, "x_ann_cagra_build")
    # x, graph_out; n, d, intermediate_graph_degree, graph_degree
    _ = family_call(build, Python.list(PythonObject(x_snapshot.source.addr), classical_address(graph)),
                    Python.list(PythonObject(n), PythonObject(d), PythonObject(kdeg), PythonObject(deg)))
    _ = x_snapshot  # retain the captured storage owners through native execution
    _ = graph  # keep the Python object alive through the native call above
    # p3-neighbors-cluster (caller-aliased inputs): the index keeps X, and the
    # resident device copy is keyed by the kept array's identity. Unless the
    # conversion already made an owned copy, fit keeps an owned snapshot, never
    # the caller's own buffer, and it is read-only from here on.
    var dataset: PythonObject
    if x_snapshot.copied and x_snapshot.is_array:
        dataset = x_snapshot.keep
    else:
        var flat = _ann_empty(n * d, "<f4", context)
        memcpy(dest=MutPointer[Float32, MutUntrackedOrigin](unsafe_from_address=Int(py=classical_address(flat))),
               src=MutPointer[Float32, MutUntrackedOrigin](unsafe_from_address=x_snapshot.source.addr), count=n * d)
        _ = x_snapshot  # the source storage stays alive through the copy above
        dataset = _ann_view(flat, Python.tuple(n, d), context)
    py_setitem(fields, "dataset_", dataset)
    py_setitem(fields, "graph_", _ann_view(graph, Python.tuple(n, deg), context))
    _ = fitted_freeze(dataset, context)
    _ = fitted_freeze(fields["graph_"], context)
    py_setitem(fields, "n_features_in_", PythonObject(d))
    py_setitem(fields, "n_rows_", PythonObject(n))
    py_setitem(fields, "graph_degree_", PythonObject(deg))
    return model


# ---------------------------------------------------------------- refine


def _ann_bool_sequence(value: PythonObject) raises -> Bool:
    var b = native_loaded_module("builtins")
    var cls = py_type(value)
    if cls is b.bool:
        return True
    if cls is not b.list and cls is not b.tuple:
        return False
    for i in range(len(value)):  # driver-loop: exact native sequence boolean admission
        if not _ann_bool_sequence(value[i]):
            return False
    return True


def _refine(args: PythonObject, context: PythonObject) raises -> PythonObject:
    """`refine(dataset, queries, candidates, k, numeric_mode, metric)`:
    args are (binding, dataset, queries, candidates, k, metric)."""
    var b = native_loaded_module("builtins")
    classical_connect_numpy(context)
    var metric = args[5]
    if py_type(metric) is not b.str:
        raise Error("TypeError: mojolearn refine: metric must be an exact native string")
    if not py_contains(Python.tuple("sqeuclidean", "euclidean"), metric):
        raise Error("mojolearn refine: metric must be 'sqeuclidean' or 'euclidean' "
                    + "(inner product is not implemented), got " + family_repr(metric))
    var x = family_f32_snapshot(args[1], 2, "dataset", context)
    var q = family_f32_snapshot(args[2], 2, "queries", context)
    var n = x.shape[0]
    var d = x.shape[1]
    var m = q.shape[0]
    if q.shape[1] != d:
        raise Error("mojolearn refine: queries have " + String(q.shape[1]) + " features, the dataset has " + String(d))
    # Native admission precedes candidate rank/dtype reads; never invoke
    # NumPy.asarray or an arbitrary candidate object's array protocols.
    var candidate = classical_view(args[3], context, "candidates")
    var shape = array_shape_once(candidate, context)
    if len(shape) != 2 or shape[0] != m:
        raise Error("mojolearn refine: candidates must be an integer array of shape (" + String(m) + ", k0)")
    var k0 = shape[1]
    var c = array_metadata_once(candidate, shape^, "candidates", context, True)
    if c.source.kind != CAST_KIND_SIGNED and c.source.kind != CAST_KIND_UNSIGNED:
        raise Error("mojolearn refine: candidates must be an integer array")
    # Without NumPy the native sequence owner represents a bool sequence as
    # int8. Retain asarray's boolean refusal while accepting real int8 buffers.
    if (py_type(args[3]) is b.list or py_type(args[3]) is b.tuple) and _ann_bool_sequence(args[3]):
        raise Error("mojolearn refine: candidates must be an integer array")
    var k_o = _ann_int("refine", "k", args[4])
    var k = Int(py=k_o)
    var native = estimator_binding_mode(args[6], "_mojolearn_x_ann", context) if args[0] is None else args[0]
    # The kernel skips every id outside [0, n) (refine_core.refine_cell); an
    # id beyond int32 is refused here, then the ids are narrowed to int32.
    var c32 = _ann_empty(m * k0, "<i4", context)
    if m * k0 > 0:
        var fits = ann_candidates_i32(c.source.addr, c.source.s0, c.source.s1, m, k0,
                                      c.source.itemsize, c.source.kind == CAST_KIND_SIGNED, not c.native_byte_order,
                                      FAMILY_I32P(unsafe_from_address=Int(py=classical_address(c32))))
        _ = c
        _ = c32
        if not fits:
            raise Error("mojolearn refine: a candidate index exceeds int32")
    var dist = _ann_empty(m * k, "<f4", context)
    var idx = _ann_empty(m * k, "<i4", context)
    var root = Bool(py=metric == PythonObject("euclidean"))
    var params = Python.list(PythonObject(n), PythonObject(d), PythonObject(m), PythonObject(k0), k_o)
    if root:
        _ = py_call(params.append, PythonObject(1))
    var entry = _ann_entry(native, "x_ann_refine")
    # dataset, queries, candidates, out_d, out_i; n, d, m, k0, k (+ root:
    # the binding takes the euclidean roots)
    _ = family_call(entry,
                    Python.list(PythonObject(x.source.addr), PythonObject(q.source.addr), classical_address(c32),
                                classical_address(dist), classical_address(idx)),
                    params)
    _ = x  # keep the Python object alive through the native call above
    _ = q  # keep the Python object alive through the native call above
    _ = c32  # keep the Python object alive through the native call above
    _ = dist  # keep the Python object alive through the native call above
    _ = idx  # keep the Python object alive through the native call above
    return parallel_public_result(Python.tuple(_ann_view(dist, Python.tuple(m, k), context),
                                  _ann_view(idx, Python.tuple(m, k), context)),
                                  "refine", PythonObject(None), context)


def neighbors_ann_operation(model: PythonObject, operation: String, var args: PythonObject,
                            context: PythonObject) raises -> PythonObject:
    # NumPy's connected types first, so an ndarray input is read as one
    # buffer whichever door ran first in the process.
    classical_connect_numpy(context)
    if operation == "family_xn_ann_getstate":
        var fields = _fields(model)
        if py_contains(fields, "_device_codes"):
            _ = ann_pq_materialize(model, context)
        var state = py_call(native_loaded_module("builtins").dict, fields)
        _ = py_call(state.pop, "_resident", PythonObject(None))
        _ = py_call(state.pop, "_device_codes", PythonObject(None))
        return state
    if model is not None:
        classical_check_layout(model, context)
        var name = String("_mojolearn_ivf") if operation == "family_xn_ann_ivf_fit" else String("_mojolearn_x_ann")
        args = estimator_arguments(model, name, args, context)
    if operation == "family_xn_ann_refine":
        return _refine(args, context)
    if operation == "family_xn_ann_pq_search":
        return neighbors_ann_search(model, 0, args, context)
    if operation == "family_xn_ann_sq_search":
        return neighbors_ann_search(model, 1, args, context)
    if operation == "family_xn_ann_rabitq_search":
        return neighbors_ann_search(model, 2, args, context)
    if operation == "family_xn_ann_cagra_search":
        return neighbors_ann_search(model, 3, args, context)
    if not operation.endswith("_fit"):
        raise Error("RuntimeError: unknown neighbors operation " + operation)
    # The fit envelope owns the former _mode fitted/input/output decorators.
    # The original input descriptor and storage owners survive the whole fit;
    # algorithm owners consume that descriptor instead of reading X again.
    var fields = _fields(model)
    var name = classical_estimator_name(model)
    classical_refuse_sparse(args[1], name)
    var snapshot = family_f32_snapshot(args[1], 2, "X", context)
    var rows = snapshot.shape[0]
    var columns = snapshot.shape[1]
    if len(args) > 2:
        _ = _target(args[2], rows, name, False, False, False, context)
    var depth = estimator_fit_begin(fields)
    var call = NeighborPublicCall(args, fields, args[1], "fit", True, estimator_outside(), depth, rows, columns)
    var result = PythonObject(None)
    try:
        if operation == "family_xn_ann_ivf_fit":
            result = _ivf_fit(model, args, context, snapshot)
        elif operation == "family_xn_ann_pq_fit":
            result = _pq_fit(model, args, context, snapshot)
        elif operation == "family_xn_ann_sq_fit":
            result = _sq_fit(model, args, context, snapshot)
        elif operation == "family_xn_ann_rabitq_fit":
            result = _rabitq_fit(model, args, context, snapshot)
        elif operation == "family_xn_ann_cagra_fit":
            result = _cagra_fit(model, args, context, snapshot)
        else:
            raise Error("RuntimeError: unknown neighbors operation " + operation)
    except error:
        var failure = neighbors_public_refusal(error, call, model)
        raise failure^
    finally:
        neighbors_public_end(model, call)
    _ = snapshot
    return neighbors_public_finish(model, operation, result, call, context)
